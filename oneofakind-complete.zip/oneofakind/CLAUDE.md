# ONEOFAKIND — instructions for Claude Code

Read this file first in every session. Then read `docs/IMPLEMENTATION_BACKLOG.md` and pick the next unchecked task.

## What this is
Premium fashion resale/thrift marketplace for Pakistan. Web first (this repo), mobile apps later on the same API.
Three item-level arrangements: SELF_MANAGED, MANAGED_RESALE (consignment), DIRECT_PURCHASE (platform-owned after transfer).

## Hard rules (never break)
1. **Production protection**: never touch oneofakindretro.com, its DNS/email, or production payment credentials. Sandbox only. No production deploys without explicit human approval.
2. **Money** = integer minor units + currency code, via `@ooak/shared` `money()`. No floats, no Decimal for money.
3. **Status changes** go through the state machines in `packages/shared/src/states.ts` (`assert`). Never write a status directly.
4. **Stock**: an Item may only be sold from `RESERVED`. Reservation + sale happen in DB transactions with row locks / optimistic `version`. Items are one-of-a-kind (`OrderItem.itemId` is unique).
5a. **Bundles**: exactly 5/10/15 pieces, same brand AND style, validated ONLY via `validateBundleComposition` in `@ooak/shared`. A piece is retail OR in one bundle. Reserve/sell all pieces atomically (ordered row locks). Never ship a partial lot. Bundle price is allocated across pieces with `allocateBundlePrice`; damaged claims are per piece. See `docs/WORKFLOWS.md` §3b.
5b. **Labels/scanning**: codes only via `makeCode`/`parseScan` in `@ooak/shared`; one active code per entity; dispatch code only after `verifyPackScan` = COMPLETE; labels hold no data (server resolves, role-scoped). Spec: `docs/LABELS_AND_SCANNING.md`.
5d. **Bundle prices are hidden from non-verified users — server-side.** Every bundle payload goes through `redactBundlePrices(payload, canViewBundlePrices(viewer, sellerId))`; price sort/filter only via `allowedBundleSorts`; lot pages are cached without prices; no prices in OG/JSON-LD/emails for non-verified. Test it.
5f. **Payouts only to the seller's own-name account**, verified by staff (`payoutVerifiedAt`); no PAID statement without it. **On-behalf actions** only by `SELLER_AGENT`/`ADMIN` via `canActOnBehalf`; forbidden actions need the seller's own OTP.
5e. **Onboarding**: sellers/resellers may be registered by staff from WhatsApp documents (`docs/ONBOARDING.md`). Record consent, store IDs only in the restricted bucket, activate via the person's own OTP, act "on behalf" with `AuditLog.onBehalfOfId`, never impersonate. Phones always via `normalizePkPhone`.
5c. **Bundle buyers** must hold `VERIFIED_RESELLER` — enforce in the API, not just the UI. Bundles: grade A/B only, mixed sizes/colours allowed.
5. **Direct purchase**: `TRANSFERRED` is the only state meaning ownership moved. Never show "purchased/paid" copy earlier. Ledger treatment differs from consignment (see `docs/WORKFLOWS.md` §Accounting).
6. **Webhooks**: verify signature, store raw in `PaymentEvent`, idempotent on `(provider,eventId)`. Never invent payment/courier/payout status.
7. **AI**: server-side adapters only. Originals are never overwritten; generated media is a separate `MediaAsset` with `aiLabel=true`. Never invent measurements, material, authenticity, colour or condition. User photos private, consented, with retention.
8. **No mockups claimed as features.** If it is not wired to the API and DB, say so.
9. Keep `docs/ROUTE_INVENTORY.md` and `docs/DATABASE_SCHEMA.md` in sync with code in the same commit.

## Workflow per milestone
Plan → implement → run `pnpm typecheck && pnpm lint && pnpm test` → report **actual** results, changed files, what is incomplete, credentials needed → tick the backlog → commit. Do not start the next milestone until told.

## Stack
pnpm workspaces · `apps/web` Next.js (App Router, TS, Tailwind) · `apps/api` NestJS + Prisma + PostgreSQL · `packages/shared` (money, states) · `packages/design-tokens` · Redis + BullMQ for jobs · S3-compatible storage (MinIO local).

## Conventions
- TypeScript strict. Zod (or class-validator) on every API input. REST under `/v1`. Cursor pagination.
- Errors: RFC7807 problem+json. Never leak stack traces.
- Tests: Vitest for pure logic, Jest/Supertest + real Postgres for API. Concurrency tests are mandatory for reservation/checkout.
- Design: use tokens from `packages/design-tokens`. Buyer UI editorial; seller UI efficient; admin UI dense and accurate.
- Currency display: PKR, no decimals. English only in v1 (no RTL/Urdu work). Keep UI strings centralised.
- Business rules decided: prepaid only (NO COD), local gateway + local courier, returns ONLY for damaged items, see `docs/COMMERCIAL_POLICY.md`. Never build COD or a general-returns path.
