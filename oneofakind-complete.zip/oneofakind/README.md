# ONEOFAKIND

Premium fashion resale marketplace for Pakistan — web first, mobile later on the same API. Three item arrangements: self-managed, managed resale (consignment) and direct purchase, plus 5/10/15-piece bundles for verified resellers.

Engineering rules: `CLAUDE.md`. Plan and specs: `docs/`. How to run, deploy and operate: **`docs/RUNBOOK.md`**. What is built and what isn't: **`START_HERE.md`**.

## Stack
pnpm workspaces · `apps/web` Next.js 15 (App Router, Tailwind + `@ooak/design-tokens`) · `apps/api` NestJS 11 + Prisma 6 + PostgreSQL 16 · `packages/shared` (money, state machines, bundle/label/onboarding rules) · sandbox payment/courier adapters · local AI adapters.

## Quick start
```bash
corepack enable && pnpm install
cp .env.example .env && cp .env.example apps/api/.env
createdb ooak && createdb ooak_test          # or: pnpm infra:up, then create ooak_test
pnpm --filter @ooak/shared build && pnpm --filter @ooak/api db:generate
pnpm --filter @ooak/api db:migrate && pnpm --filter @ooak/api db:seed
pnpm --filter @ooak/api dev                  # :4000
pnpm --filter @ooak/web dev                  # :3000 — log in as admin with +923000000001 (dev OTP shown on screen)
```

## Checks
`pnpm lint && pnpm typecheck && pnpm test` · `pnpm --filter @ooak/web build` · `pnpm e2e` (against a running, seeded stack).
