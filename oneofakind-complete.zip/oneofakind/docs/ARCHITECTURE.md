# Architecture

```
Browser ─▶ Next.js (apps/web, Vercel) ─▶ NestJS API (apps/api)  ─▶ PostgreSQL (Prisma)
                                           │  ├─▶ Redis + BullMQ workers (AI, webhooks, emails, reservation expiry, settlements)
                                           │  ├─▶ S3-compatible storage (private + public buckets, signed URLs)
                                           │  └─▶ Provider adapters: Payments · Couriers · AI (text/image/try-on) · SMS/Email
Future: Expo/React Native ─▶ same REST API
```

## Principles
- **Modular monolith.** One deployable API, strict module boundaries (no cross-module DB access; call services). Extract later only with evidence.
- **Domain logic in pure packages** (`@ooak/shared`) — usable by API, web and mobile, trivially testable.
- **State machines everywhere** statuses exist; services call `assert`.
- **Money**: integer minor units; PKR default; ledger is double-entry and append-only.
- **Provider adapters** behind interfaces: `PaymentProvider`, `CourierProvider`, `ImageProvider`, `TryOnProvider`, `TextProvider`, `Notifier`. A `sandbox`/fake adapter ships first so everything is testable offline.
- **Transactional outbox** for events that must not be lost (order paid → fulfilment, ledger posts).

## Inventory concurrency (the core correctness problem)
One-of-a-kind stock means two buyers will race for the same item.
1. Add-to-cart does not reserve. Checkout start reserves: in one transaction `SELECT … FOR UPDATE` the Item row, require `stockState=AVAILABLE` and listing `PUBLISHED`, set `RESERVED`, insert `StockReservation(expiresAt=now+15m)`, bump `version`.
2. Payment captured (verified webhook) → `RESERVED→SOLD`, create `OrderItem` (unique `itemId` is the backstop).
3. Expiry job releases reservations → `AVAILABLE`.
4. Test: N parallel checkouts for one item ⇒ exactly one succeeds.
5. **Bundles:** lock the Bundle row and all member Item rows in a **fixed order (by item id)** inside one transaction to avoid deadlocks; require bundle `PUBLISHED` and every item `AVAILABLE`; write N `StockReservation` rows tagged with `bundleId`. All-or-nothing. A bundle reservation (15 → proposed 30 min) expires as a unit. Two buyers racing for one bundle, or a bundle vs a retail buyer racing for one of its pieces (impossible by `channel`, but test it) ⇒ exactly one wins.

## Labels & scanning
Dedicated `codes` module: Postgres sequences per code kind, idempotent issue, void/reissue, append-only `ScanEvent`. Pack verification logic lives in `@ooak/shared/packing.ts` (pure, tested). Full spec: `LABELS_AND_SCANNING.md`.

## Auth
Short-lived access token + rotating refresh token (hashed in `Session`). httpOnly, SameSite cookies for web; bearer for mobile later. Phone OTP + email verification (Pakistan: phone is primary identity). RBAC via `User.roles[]` + permission guard decorators per endpoint; seller data scoped by `sellerId` in every query (tests for cross-tenant access).

## Media & AI pipeline
Upload: client → signed PUT to private bucket → API registers `MediaAsset(ORIGINAL)`. AI: enqueue `AiJob` → worker calls adapter with timeout/retry → output stored as new `MediaAsset(kind=GENERATED_*|BACKGROUND_REMOVED, aiLabel=true, sourceAssetId=original)` → seller reviews → `approvedForPublish`. Public site only serves approved, labelled assets via CDN. Every job records provider, cost, latency, error. Feature flags per capability; core flows never await AI.

## 3D
React Three Fiber, lazy-loaded only on product pages with an `ASSET_3D`; poster image + "view in 3D" button; GLB size budget (≤3 MB), Draco/meshopt; no 3D on listing grids.

## Environments
local (docker-compose) → staging (separate DB, sandbox providers, noindex, basic-auth) → production (not before explicit approval). Separate repo and domain from oneofakindretro.com.

## Observability & security
Structured logs with request IDs, Sentry (web+api), health/readiness endpoints, rate limiting (per-IP + per-user on auth/OTP/upload/AI), Helmet, CSP, upload MIME/size sniffing + malware scan hook, audit log on privileged actions, secrets only in env/secret manager.

## Pakistan-specific notes
Prepaid only (no COD) — no courier cash-remittance flow to reconcile. Gateway: one local provider chosen by Moon; courier: one local courier chosen by Moon — verify current API/sandbox terms in `PROVIDER_EVALUATION.md` before building adapters. Seller KYC: store only last-4 of national ID in app DB; keep documents in a restricted bucket or outside the system.
