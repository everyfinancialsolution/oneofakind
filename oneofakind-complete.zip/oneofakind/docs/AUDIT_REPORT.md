# Audit report (M0.1) — groundwork review

Scope: README, CLAUDE.md, every file in `docs/`, `apps/api/prisma/schema.prisma`, `packages/shared`.
Method: read everything, ran `pnpm install`, `pnpm test` (67 pass), `prisma validate` with the real engine (valid), applied the schema to a real PostgreSQL 16 and seeded it.

## 1. Contradictions found and how they were resolved
| # | Where | Contradiction | Resolution |
|---|---|---|---|
| C1 | Website brief (Oct 2026) vs `DECISIONS.md` D-07 | Brief says "payment-provider adapters and COD where eligible" | **No COD** (D-07 is a later, explicit owner decision). No COD code exists. |
| C2 | Brief vs D-13 | Brief describes general "returns and refunds" | **Damaged-only returns** (D-13). `/returns/new` only accepts damage/undisclosed-defect claims within 48 h of delivery. |
| C3 | Brief `/seller/[slug]` storefront vs `/seller` portal | Route collision | Kept D-06: public storefront is `/sellers/[slug]`. |
| C4 | `ARCHITECTURE.md` "short-lived access token + rotating refresh token" | Over-engineered for a cookie-based web client | One opaque, random session token in an httpOnly SameSite=Lax cookie; only its SHA-256 is stored (`Session.refreshHash`); 30-day sliding expiry; revocable server-side. Bearer header accepted for the future mobile app. Recorded as D-32. |
| C5 | `ARCHITECTURE.md` "BullMQ for jobs" vs operational simplicity | Redis-backed queues for every job | BullMQ is used for AI jobs (retries/timeouts). Periodic sweeps (reservation expiry, retention, offer expiry) run as in-process interval jobs guarded by Postgres advisory locks, so one API instance or many is safe. D-33. |

## 2. Gaps fixed in the schema (small, clearly-correct)
- `OtpChallenge` (phone OTP login was decided but had no table; only a hash of the code is stored, attempts limited).
- `Notification` (outbound SMS/in-app log; WhatsApp stays manual in v1).
- `DirectPurchase` → `Item.directPurchaseId` (an offer can cover a collection; `OwnershipTransfer` is per item). Added `title`, `expectedRetailMinor`, `sellerAskMinor`, `paymentRef`, `decisionNote`.
- `BuyingBudget` (brief: "direct-purchase approvals and buying budgets" had no table).
- `ManagedResaleAgreement.status/requestNote/approvedAt` (a seller *requests* the service before an agreement is active).
- `IntakeManifestLine.categoryId/brandName` (lines create EXPECTED items, which need a category).
- `FulfilmentGroup.deliveredAt` (starts the 48 h damage window and the 7-day payout hold), `Order.paidAt`, `Payment.checkoutUrl`, `ReturnRequest.refundMinor`, `MediaAsset.position`.
- `Setting` (runtime config: courier flat rates, feature flags) and `ContentBlock` (home/campaign CMS).
- Trigram GIN indexes modelled in Prisma (`ops: raw("gin_trgm_ops")`) so `migrate diff` stays empty.

## 3. Integrity rules implemented as SQL (`prisma/migrations/*_integrity`)
CHECKs on every money column; ledger entry one-sided; **deferred constraint trigger: every ledger txn balances at COMMIT**; append-only triggers on `LedgerEntry`, `AuditLog`, `ScanEvent`; partial unique indexes (one active reservation per item, one active bundle per item, one active scan code per entity per kind); cart line XOR; scan code kind↔reference CHECK and immutability; sequences for SKUs, order refs, application refs and scan codes; bundle publish trigger (count = size, active tier, same brand/style/arrangement/owner, channel BUNDLE); retail/bundle channel triggers; FTS GIN expression index.
**Rule for future migrations:** create with `pnpm --filter @ooak/api db:migrate:new`, then confirm the generated SQL does not drop any object above (verified today: `prisma migrate diff` against the live DB is empty).

## 4. Risks (open)
| Risk | Severity | Mitigation / owner |
|---|---|---|
| Payment gateway and courier not named | High (blocks real money) | Sandbox adapters with the same interfaces are built; swap when Moon names providers. |
| Platform-owned items keep `Item.sellerId` = original seller | Medium | Storefront shows "ONEOFAKIND" when `ownerType = PLATFORM`; a `displaySellerId` is not needed yet. |
| UK WhatsApp number for Pakistani applicants | Low | Config-driven; add a PK number later if needed. |
| ID documents arrive via staff phones (WhatsApp) | Medium (privacy) | Restricted storage, access logging, 90-day deletion job, staff procedure in `ONBOARDING.md`. |
| Single region DB without backups in dev | Medium | Staging/prod runbook in `docs/RUNBOOK.md` requires managed Postgres with PITR. |
| Legal wording for consignment / ownership transfer | Medium | Policy pages ship with placeholder legal text clearly marked "draft — needs legal review". |

## 5. Not changed (deliberately)
Variants stay absent (items are unique). Multi-currency stays modelled but PKR-only. Commission numbers stay as adopted defaults (config).
