# Route Inventory
Legend — Render: SSG/ISR/SSR/CSR. Auth: public / customer / seller / warehouse / support / finance / moderator / admin. Status updated as built (☐ planned, ◐ partial, ☑ done).

## Public marketplace (apps/web)
| Route | Purpose | Render | Auth | Status |
|---|---|---|---|---|
| `/` | Editorial home, new arrivals, drops, featured sellers | ISR | public | ☐ |
| `/discover` | Feed, style collections, recommendations | SSR+CSR | public | ☐ |
| `/shop` | Category index | ISR | public | ☐ |
| `/category/[slug]` | Category listing + filters | SSR | public | ☐ |
| `/search` | Search, sort, filters (size, condition, price, seller, city) | SSR | public | ☐ |
| `/product/[slug]` | Product plate: photos, condition, measurements, seller, delivery/returns | ISR (+live stock check CSR) | public | ☐ |
| `/compare` | Compare 2–4 items (condition, price, measurements) | CSR | public | ☐ |
| `/sellers/[slug]` | Public storefront | ISR | public | ☐ |
| `/collections/[slug]` | Curated collections / drops | ISR | public | ☐ |
| `/wishlist` | Saved items | CSR | customer | ☐ |
| `/cart` | Cart grouped by seller, stock validation | CSR | public/customer | ☐ |
| `/checkout` | Address, delivery, payment, review | SSR | customer | ☐ |
| `/orders`, `/orders/[id]` | Orders + tracking | SSR | customer | ☐ |
| `/returns`, `/returns/new` | Return/refund requests | SSR | customer | ☐ |
| `/help`, `/help/[slug]` | Help centre | SSG | public | ☐ |
| `/about` | Company, sustainability | SSG | public | ☐ |
| `/policies/[slug]` | Terms, privacy, returns, seller terms | SSG | public | ☐ |
| `/account/*` | Profile, addresses, privacy/consents, delete-account request | SSR | customer | ☐ |
| `/login` | Single phone-number + OTP login for buyers, sellers, verified resellers (no passwords) | SSR | public | ☐ |
| `/sell` | Landing for sellers: how it works, fees, "Apply" and "Apply on WhatsApp" | SSG | public | ☐ |
| `/reseller` | Landing for resellers: bundles overview (no prices), "Apply" and "Apply on WhatsApp" | SSG | public | ☐ |
| `/seller/apply`, `/reseller/apply` | Self-serve applications (phone OTP, documents via camera upload), status page | SSR | public/customer | ☐ |
| `/activate/[token]` | Activation of a staff-registered account (confirm phone by OTP, accept terms) | SSR | public | ☐ |

### Bundles storefront (second mode; header switch "Single pieces | Bundles")
| Route | Purpose | Render | Auth | Status |
|---|---|---|---|---|
| `/bundles` | Bundle home: filter by size (5/10/15), brand, style, grade; **price filter/sort only for verified resellers** | ISR | public | ☐ |
| `/bundles/brand/[brand]` | Bundles for a brand | ISR | public | ☐ |
| `/bundles/style/[style]` | Bundles for a style | ISR | public | ☐ |
| `/bundles/[slug]` | Lot page: **contact sheet of every piece** (photo, grade, size, measurements), size/colour/grade breakdown, shipping weight; **price, price/piece and % below retail shown to verified resellers only (server-side redaction; cached page has no prices)** | ISR (+live availability CSR) | public | ☐ |
Cart and checkout handle bundle lines alongside single pieces (grouped per seller). Order detail shows the bundle and its pieces.

**Route change vs brief:** public storefront is `/sellers/[slug]` (plural) so it cannot collide with the authenticated `/seller/*` portal. Reason: the brief used `/seller/[slug]` for the storefront *and* `/seller` for the portal.

## Seller portal (`/seller/*`, role=seller)
☑ `/seller` overview · `/seller/apply` · `/seller/listings` · `/seller/listings/new` (photo-first wizard) · `/seller/listings/[id]` · `/seller/inventory` · `/seller/orders` · `/seller/orders/[groupId]` (pack scan → dispatch) · `/seller/offers` · `/seller/earnings` (statements) · `/seller/storefront` · `/seller/managed-resale` · `/seller/direct-purchase` (+ `/new`, `/[id]`) · `/seller/labels` · `/seller/bundles` (+ `/new` builder) · `/seller/analytics` · `/seller/activity` · `/seller/settings` (payout account) · `/seller/support` (tickets, removed-listing appeals)
☑ `/seller/studio` (AI background removal, listing text helper, 3D model upload)

## Warehouse (`/ops/*`, role=warehouse/admin) — separate shell, tablet/handheld first
☑ `/ops` today · `/ops/scan` · `/ops/receiving` (+ manifests) · `/ops/direct-purchases` (handover) · `/ops/queue/[inspection|photography|price-approval|rejected]` · `/ops/items/[id]` (inspect, photos, catalogue) · `/ops/pick-pack` · `/ops/pack` · `/ops/dispatch` · `/ops/bundling` · `/ops/locations` · `/ops/movements` · `/ops/labels` · `/ops/returns` · `/ops/unsold`

## Admin (`/admin/*`, staff roles; nav filtered by role, every endpoint role-checked)
☑ `/admin` dashboard (queues) · `/admin/onboarding` · `/admin/onboarding/new` (assisted registration from WhatsApp/phone/in person) · `/admin/onboarding/[ref]` (docs, consent evidence, decision) · `/admin/sellers` (suspend/reinstate) · `/admin/sellers/[id]` (list on behalf — SELLER_AGENT/ADMIN) · `/admin/users` · `/admin/users/[id]` (role grants, disable) · `/admin/moderation` (listings + lots) · `/admin/moderation/reports` (reports & appeals) · `/admin/orders` (staff cancel + refund before dispatch) · `/admin/claims` (damage claims) · `/admin/support` (tickets, disputes) · `/admin/buying` · `/admin/buying/[id]` (offer, transfer) · `/admin/buying/budgets` · `/admin/agreements` · `/admin/finance` (reconciliation) · `/admin/finance/payouts` (own-name verification) · `/admin/finance/statements` (generate/finalise/paid, CSV) · `/admin/finance/ledger` · `/admin/finance/payments` · `/admin/catalog` (categories, styles, brands) · `/admin/cms` · `/admin/collections` · `/admin/settings` (shipping, bundle tiers, commission rules) · `/admin/audit`
☑ `/admin/ai` (usage, failures, retry, cost). Not built (by decision or merged): `/admin/promotions` (campaigns live in CMS; no discount codes in v1), `/admin/shipments`/`/admin/returns` (handled in orders, claims and `/ops/returns`), `/admin/inventory` (warehouse UI)

## API surface (apps/api, `/v1`)
Admin API (M7): `admin/dashboard|users|sellers|audit|settings|bundle-tiers`, `admin/moderation/*`, `reports`, `seller/reports`, `admin/catalog/*` (categories, styles, brands, cms, collections), `support/tickets`, `admin/support`, `admin/disputes`, `admin/orders`, `admin/groups/:id/cancel`, `admin/claims`, `admin/finance/*` (reconciliation, payout-verifications, statements, ledger, payments).
AI API (M8): `seller/studio/items`, `seller/studio/jobs`, `seller/studio/items/:id/background|text|model3d`, `seller/studio/assets/:id/use`, `DELETE seller/studio/assets/:id`, `admin/ai`, `admin/ai/jobs/:id/retry`.

auth · users · sellers · catalog · items · listings · media (signed upload URLs) · search · cart · reservations · checkout · orders · bundles · styles · payments (+ `/webhooks/:provider`) · shipments (+ courier webhooks) · returns · refunds · manifests · inspections · locations · custody · direct-purchases · transfers · statements · ledger · collections · support · disputes · moderation · ai-jobs · admin/* · health. Each module owns its controller, service, DTOs, tests.
