# Prompts for Claude Code — paste one at a time, review, then continue
Open Claude Code in the repo root. It reads `CLAUDE.md` automatically.

## Prompt 00 — Review the groundwork (do this first)
You are the principal architect and tech lead for ONEOFAKIND. This repo already contains groundwork (read `README.md`, `CLAUDE.md`, everything in `docs/`, `apps/api/prisma/schema.prisma`, `packages/shared`).
1. Run `pnpm install`, `pnpm test`, and Prisma validate/generate against the docker Postgres (`pnpm infra:up`). Report real output.
2. Audit docs + schema for gaps, contradictions, security/operational risks, and missing entities. Write findings to `docs/AUDIT_REPORT.md` with a proposed list of schema/doc changes. Do not rewrite existing files wholesale; apply only clearly-correct small fixes and list them.
3. Create the first migration (including the raw-SQL integrity rules listed in `docs/DATABASE_SCHEMA.md` for reservations, ledger, bundles and scan codes) and a `prisma/seed.ts`: 6 sellers, ~60 items across categories/grades/arrangements (some grade C/D to prove bundle rules), StyleTags, BundleTier 5/10/15, 4 valid bundles (5/10/15, mixed sizes/colours, grade A/B), 2 verified resellers + 1 pending application, 3 collections, admin/warehouse/support/finance users with dev-only passwords, ScanCodes for a few items.
4. Update `docs/IMPLEMENTATION_BACKLOG.md` ticks. Stop and report. Do not start M1.

## Prompt 01 — Design system + home (M1)
Build `apps/web` per `docs/ROUTE_INVENTORY.md` and `packages/design-tokens/DESIGN_DIRECTION.md`. Follow the backlog M1 list. Include the "Single pieces | Bundles" mode switch and a bundle lot-sheet component (contact-sheet of every piece). Home uses fixture data behind a data-access interface. Mobile-first, a11y, reduced motion. Provide a `/dev/ui` gallery. Run lint/typecheck/tests + Lighthouse mobile and report numbers. Show screenshots at 390px and 1440px.

## Prompt 02 — API foundation, auth, catalogue (M3, before M2 data wiring)
Implement NestJS skeleton and modules for auth (phone OTP + email, sessions, RBAC), catalogue, items, listings (state machines), media signed uploads, and the raw-SQL integrity migration listed in `docs/DATABASE_SCHEMA.md`. Write the access-boundary and state-transition tests. Report results.

## Prompt 03 — Public marketplace on real data (M2)
Replace fixtures with API calls; implement category/search/product/storefront/collection pages, filters, FTS, share/OG. Seed data from Prompt 00.

## Prompt 04 — Seller portal (M4) — includes bundle builder and `/seller/labels` (item barcode+QR)
## Prompt 05 — Commerce (M5) — must include the concurrency suite (single items AND bundles), webhook idempotency tests, reseller-only bundle gate at API level
## Prompt 06 — Managed resale + direct purchase + `/ops/scan` pack verification & dispatch codes (M6)
## Prompt 07 — Admin + finance (M7) — ledger invariants tested
## Prompt 08 — AI + 3D (M8) — evaluate providers first (`docs/PROVIDER_EVALUATION.md`), fake adapter first
## Prompt 09 — Hardening + staging (M9)
For 04–09 use: "Implement milestone Mx from `docs/IMPLEMENTATION_BACKLOG.md` following `CLAUDE.md`. Report actual test output, changed files, incomplete items, required credentials. Update backlog and route inventory. Stop."

## Always-on reminders (paste when Claude drifts)
- "Don't claim a feature works unless it's wired to the API/DB and tested."
- "All status changes via the state machines; all money via `money()`."
- "Do not touch oneofakindretro.com or any production credential."
