# Labels, Barcodes & Scanning

## Goal
Every listing gets a unique printable barcode + QR for packing. Placing an order generates an order QR (built from the pieces' pack codes) and, once packing is verified, a new barcode + QR for dispatch. Scans prove the right pieces went in the right parcel.

## Code format (implemented + tested in `@ooak/shared/codes.ts`)
`[kind digit][11-digit sequence][GS1 mod-10 check digit]` = 13 digits. Kinds: `1` ITEM_PACK · `2` BUNDLE_PACK · `3` ORDER_PACK · `4` DISPATCH.
- Unique per kind (DB `UNIQUE(code)`; sequence from a Postgres sequence per kind). Check digit catches every single-digit typo (tested).
- Print as **Code 128** (not EAN-13 symbology — these are internal and must never collide with real product GTINs) **plus a QR** whose payload is just `OOAK1:<code>`.
- Labels carry **no data and no personal information**. The server resolves a code and returns only what the scanning user's role may see. Unknown/foreign codes → 404. Rate-limit lookups.

## Lifecycle
| Step | Code | Who/when |
|---|---|---|
| 1. Listing label | **ITEM_PACK** per piece | Seller clicks "Generate label" (single or bulk `/seller/labels`); idempotent — returns the same active code. Warehouse items get one automatically at receiving. If still missing when an order is paid, the system issues it then. Label shows barcode, QR, SKU, brand, size, short title (no price). Placed aside with the item. |
| 2. Lot label | **BUNDLE_PACK** per sealed bundle | At `/ops/bundling` (or seller builder): scan all N piece codes → "Seal lot" → lot code issued; lot label printed. Sealed lot is later scanned as ONE unit. Unsealed seller lots expect each piece code. |
| 3. Order placed (payment verified) | **ORDER_PACK** per fulfilment group (seller package) | Auto-issued. Pack slip prints: order QR + barcode, ship-to, list of expected pack codes (piece codes / lot code). Server derives the expected children from the order — the QR itself stays opaque. |
| 4. Pack verification | scans of ITEM_PACK / BUNDLE_PACK | Scan order QR, then each piece (or lot). `verifyPackScan` → COMPLETE / INCOMPLETE (shows missing) / MISMATCH (wrong or unreadable code). MISMATCH blocks step 5. Every scan writes a `ScanEvent`. |
| 5. Dispatch | **DISPATCH** per shipment | Issued **only after COMPLETE**; `parent = ORDER_PACK`. New barcode + QR on the parcel label together with the courier tracking number. |
| 6. Courier handover | scan DISPATCH | Scan at handover → shipment `READY→PICKED_UP`, items `PACKED→DISPATCHED`, `packVerifiedAt` stays as evidence. Scanning a DISPATCH code before COMPLETE pack is rejected. |

## Dispatch code (decided design)
- **What it is:** a 13-digit internal code (kind `4`), one **per parcel** (`Shipment.parcelIndex / parcelCount`). Shown as Code 128 barcode + QR, with the human-readable digits underneath and "Parcel 1 of 2" if the lot ships in several parcels.
- **When it exists:** only after `verifyPackScan` is COMPLETE for the package (`canIssueDispatch`). Before that the API refuses to issue it. Multi-parcel: pieces are scanned *into* a parcel (`ScanEvent.shipmentId`); each parcel gets its own dispatch code once all of the group's pieces are accounted for.
- **What it links to:** `parent = ORDER_PACK` code, the shipment, the courier tracking number (the courier's own AWB stays the authoritative external ID).
- **What it is NOT:** not a replacement for the courier's barcode. If the courier supplies its own label PDF, print our dispatch code as a separate 50×30 mm sticker beside it; if the courier accepts custom labels, print both on one 100×150 mm label.
- **Label contents:** dispatch barcode + QR · order reference · courier name + tracking no. · ship-to name/city (no phone on the QR) · piece count. No prices.
- **Where it is scanned:** (1) at sealing the parcel (confirm label on the right box), (2) at courier handover → shipment `PICKED_UP`, items `PACKED→DISPATCHED`. A dispatch code scanned twice, or before COMPLETE, is rejected and logged.
- **Customer service use:** support can scan/enter it to see pack-verification evidence (who scanned which pieces, when) when a "missing item" or "damaged" claim comes in.

## Rules
- At most one **active** (not voided) ITEM_PACK per item, BUNDLE_PACK per bundle, ORDER_PACK per group, DISPATCH per shipment (partial unique indexes in SQL).
- Lost/damaged label → **void + reissue** (reason logged, `REPRINTED`). Scanning a voided code = MISMATCH + alert.
- Wrong-parcel guard: an ITEM_PACK already inside a verified/dispatched package cannot be scanned into another.
- Never print a price on item labels. Never encode URLs to public pages that reveal stock/ownership.
- Permissions: warehouse scans anything in their location; sellers only their own items/orders; support read-only; customers cannot scan.
- Bundles never partial: if a lot piece is swapped at packing, the swap is a custody event and the lot code is voided + reissued after re-seal.

## Hardware / UX (thermal printers available — decided)
Sizes are in `LABEL_SPECS` (`@ooak/shared`): item 50×30 mm · lot 100×50 mm · order pack and dispatch 100×150 mm. Labels are rendered as PDFs at exact label size so they print from the browser to any thermal printer driver (set the paper size once per printer). Raw ZPL / ESC-POS output can be added later once we know the printer model(s). Print queue `/ops/labels`; sellers can print item labels from `/seller/labels`. Item labels never include price or personal data (tested).
Handheld USB scanners behave as keyboards (focus a scan input, handle Enter); phones scan with the camera (BarcodeDetector / ZXing fallback). Suggested libs: `bwip-js` (Code 128 + QR, SVG/PNG) and `pdf-lib` (label sheets). Support A4 sheet printing for sellers without a thermal printer (3×8 grid).

## API (planned, `/v1`)
`POST /items/:id/label` · `POST /labels/sheet {itemIds[]}` → PDF · `POST /bundles/:id/seal {scans[]}` · `GET /scan/:raw` (role-scoped resolve) · `POST /scan/pack {groupId, scans[]}` → PackCheck · `POST /scan/dispatch {code}` · `POST /labels/:code/void`.

## Tests required
Code uniqueness under concurrent generation · idempotent label generation (same item twice → one code) · check-digit validation · pack verify COMPLETE/INCOMPLETE/MISMATCH · DISPATCH not issued before COMPLETE · voided code rejected · cross-seller scan denied · lot seal requires exactly N scans of the right pieces.
