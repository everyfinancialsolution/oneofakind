# Test Plan
| Layer | Tool | Must cover |
|---|---|---|
| Pure logic | Vitest (`@ooak/shared`) | money rounding/allocation, all state machines, accounting rules — **exists, 13 passing** |
| API integration | Jest + Supertest + real Postgres (docker/CI service) | each endpoint happy/unhappy path, validation, RBAC |
| Concurrency | Same, with parallel promises | N buyers/1 item → 1 order; reservation expiry vs payment race; double webhook; double checkout submit (idempotency) |
| Bundles | Vitest (exists: 11 tests) + integration | composition rules (brand/style/size/arrangement/owner), price allocation sums exactly, state machine; **integration:** atomic reservation of N items, concurrent buyers on one bundle, item can't be in two bundles or retail+bundle, partial-shipment guard, per-piece damaged refund = allocated share, ledger totals = gateway payment |
| Labels & scanning | Vitest (exists: 12 tests) + integration | check digits, code kinds, pack verification (complete/incomplete/mismatch); **integration:** concurrent label generation is unique + idempotent, DISPATCH only after COMPLETE, voided/foreign codes rejected, role-scoped resolve, lot seal needs exactly the right N scans |
| Reseller gate & price hiding | Vitest (exists) + integration | **non-verified users get NO price field anywhere**: list, detail, search, sort params rejected, cached page HTML, OG/JSON-LD, emails; non-verified cannot add/checkout a bundle at API level; revoke blocks new orders; seller sees only own bundle prices |
| Labels & retention | Vitest (exists) + integration | labels never carry price/PII; exact label sizes; retention job deletes files and keeps last-4 + outcome; docs unreadable after deletion |
| On-behalf & payout | Vitest (exists) + integration | only SELLER_AGENT/ADMIN with consenting approved seller can act; forbidden actions refused even for admin; every on-behalf action writes `onBehalfOfId`; statement cannot be PAID without `payoutVerifiedAt`; payout-detail change forces re-verification |
| Onboarding | Integration | self-serve + staff-assisted produce identical records; cannot submit without consent; missing-doc detection; docs inaccessible to non-staff roles and access logged; activation by OTP; on-behalf actions audited, payout/offer/price approvals refused on behalf; duplicate phone/ID detection |
| Ownership | Integration | direct purchase cannot be listed/sold pre-TRANSFERRED; transfer posts correct ledger |
| Finance | Integration + property tests | every txn balances; refunds reverse proportionally; statements never double-settle a line; payout excludes disputed/in-window lines |
| Access boundaries | Integration matrix | seller A cannot read/modify seller B's items/orders/statements; customer cannot access /seller,/ops,/admin APIs; warehouse cannot see finance; finance cannot edit listings |
| Webhooks | Integration | bad signature rejected; replay idempotent; out-of-order events handled |
| AI | Unit + integration with fake adapter | status, retries, timeout, quota, cost accounting; provider outage doesn't block listing/checkout |
| Web components | Vitest + Testing Library | price/condition badge/gallery/filters |
| E2E | Playwright (mobile + desktop viewport) | seller lists → buyer buys → seller dispatches → statement correct; managed item intake→sale; direct purchase → transfer |
| A11y/perf | axe, Lighthouse CI | WCAG AA on key pages; LCP/CLS budgets |
| Security | Checklist + dependency audit | OWASP ASVS L2 subset, upload abuse, rate limits, CSP |
Definition of done for any milestone: tests written, run, results quoted verbatim in the report.
