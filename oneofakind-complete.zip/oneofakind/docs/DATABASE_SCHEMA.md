# Database Schema
Source of truth: `apps/api/prisma/schema.prisma` (validated under Prisma 6). This file explains intent; keep in sync.

## Core relationships
```
User 1─1 SellerProfile 1─* Item ─* MediaAsset / ConditionReport / CustodyEvent
Item *─1 Category, Brand?, StorageLocation?     Item 1─* Listing (relist history)
Item 1─* StockReservation        Item 1─0..1 live OrderItem (partial unique itemId WHERE voidedAt IS NULL)
Order 1─* FulfilmentGroup(per seller) 1─* OrderItem ; Order 1─* Payment 1─* PaymentEvent/Refund
FulfilmentGroup 1─* Shipment 1─* ShipmentEvent
SellerProfile 1─* ManagedResaleAgreement 1─* IntakeManifest 1─* IntakeManifestLine ─? Item
SellerProfile 1─* DirectPurchase 1─* OwnershipTransfer ─ Item
LedgerAccount 1─* LedgerEntry (txnId groups balanced entries) ; SellerStatement 1─* StatementLine(unique orderItemId)
AiJob 1─* MediaAsset(generated)  ;  AuditLog, IdempotencyKey, ConsentRecord, CommissionRule
```

## Integrity rules enforced at DB level
- `Item.sku` unique; one live `OrderItem` per item (partial unique index `WHERE voidedAt IS NULL` — a cancelled/refunded line is voided, so the piece can be sold again); `StatementLine.orderItemId` unique (settled once).
- `PaymentEvent (provider,eventId)` unique ⇒ idempotent webhooks. `Order.idempotencyKey` unique ⇒ duplicate checkout submits safe.
- `Item.version` for optimistic locking; reservations expire via job.

## Rules to add as raw SQL migrations (Prisma can't express them) — Milestone 3/7
1. `CHECK (price_minor >= 0)` on money columns; `CHECK (debit_minor >= 0 AND credit_minor >= 0 AND (debit_minor = 0 OR credit_minor = 0))` on LedgerEntry.
2. Trigger or deferred constraint: per `txn_id`, `SUM(debit)=SUM(credit)`. LedgerEntry is append-only (revoke UPDATE/DELETE from app role).
3. Partial unique index: one active (`releasedAt IS NULL`) reservation per item.
4. `AuditLog` append-only (same privilege approach).
5. Full-text search: `tsvector` generated column on Item title/description/brand + GIN index (Postgres FTS first; Meilisearch/Typesense only if needed). Consider `pg_trgm` for typo tolerance.

## Bundles (added)
`StyleTag` (style taxonomy) · `BundleTier` (allowed sizes, seed 5/10/15, admin-editable) · `Bundle` · `BundleItem` (active membership + `refRetailMinor` used to allocate price) · `OrderBundleLine` (+ `OrderItem.bundleLineId`) · `Item.styleId/channel/weightGrams` · `CartItem.bundleId` · `StockReservation.bundleId` · `CommissionRule.channel`.
Extra raw-SQL migration rules:
1. Partial unique index `ON bundle_item(item_id) WHERE released_at IS NULL` — an item is in at most ONE active bundle.
2. `CHECK ((item_id IS NOT NULL) <> (bundle_id IS NOT NULL))` on `cart_item`.
3. Trigger on `Bundle` → `PUBLISHED`: active `BundleItem` count = `size`, `size` exists in active `BundleTier`, all items share bundle's brand/style/arrangement/owner (defence in depth; the app validator in `@ooak/shared` is primary).
4. Trigger: item with active bundle membership cannot have a `PUBLISHED` retail listing, and vice versa (`channel` consistency).
5. Platform-owned item caveat: after `OwnershipTransfer`, `Item.sellerId` still points at the original seller. Platform bundles use `Bundle.sellerId = NULL` and storefront shows "ONEOFAKIND". Decide in audit whether to add `Item.displaySellerId`.

## Labels / reseller verification (added)
`ScanCode` (13-digit code, kind, links to item/bundle/group/shipment, parent for DISPATCH→ORDER_PACK, void fields) · `ScanEvent` (append-only scan log) · `ResellerVerification` · `Role.VERIFIED_RESELLER` · `FulfilmentGroup.packVerifiedAt/By`.
Extra raw-SQL rules: partial unique indexes on `scan_code(item_id) WHERE kind='ITEM_PACK' AND voided_at IS NULL` (same for bundle_id/BUNDLE_PACK, group_id/ORDER_PACK, shipment_id/DISPATCH); CHECK exactly the right reference column is set per kind; `ScanEvent` append-only; per-kind Postgres sequences feeding `makeCode`; app role cannot UPDATE `scan_code.code`.

## Onboarding (added)
`OnboardingApplication` (reference, kind, channel, status, consent fields, registeredById) · `OnboardingDocument` (restricted-bucket keys, receivedVia, verification) · `User.createdByStaffId/activatedAt` · `AuditLog.onBehalfOfId` · `SellerProfile.applicationId` / `ResellerVerification.applicationId`. Extra rules: documents readable only by onboarding/support/admin and every read logged; scheduled job deletes ID images per retention; unique-ish checks on normalised phone (+ ID last-4) to flag duplicates for review.

## As built — migrations (apps/api/prisma/migrations)
| Migration | What it adds |
|---|---|
| `20261013000000_init` | All models below; `pg_trgm` extension; trigram indexes (Prisma-modelled). |
| `20261013000100_integrity` | Money CHECKs; deferred trigger: every ledger `txnId` balances; append-only `LedgerEntry`/`AuditLog`/`ScanEvent`; partial unique indexes (one active reservation per item, one active bundle membership, one active scan code per kind and entity); sequences for SKUs, order refs, application refs and scan codes; bundle-publish and channel-consistency triggers; FTS expression index. |
| `20261013000200_live_order_lines` | `OrderItem.voidedAt`, `OrderBundleLine.voidedAt`; partial unique "one live line per item / per bundle". |
| `20261013000300_managed_resale` | `Item.proposedPriceMinor/priceApprovedAt` (seller approves managed prices); `Manifest.courier/trackingNo/receivedAt/reconciledAt`. |
| `20261013000400_ai_studio` | `MediaAsset.useInListing` (AI outputs start `false`; approval publishes only chosen assets); CHECK: an asset with `aiJobId` must have `aiLabel = true`; `AiJob(state, createdAt)` index. |

Platform tables added during M3–M6: `OtpChallenge` (hashed OTP codes, attempts, expiry) · `Notification` (in-app) · `BuyingBudget` (direct-purchase spend limits) · `Setting` (runtime config: shipping rates, features) · `ContentBlock` (CMS home/campaign blocks) · `Item.directPurchaseId` · `Refund.orderItemId/mode` (`CANCEL`/`DAMAGE`/`SHIPPING`/`LATE_PAYMENT` — drives ledger treatment).

Ledger conventions: platform accounts use `ownerRef = "PLATFORM"` (never NULL, so the `(type, ownerRef, currency)` unique key applies); seller payables use the seller profile id. Platform-owned fulfilment groups use `sellerId = "PLATFORM"`.

Media publishing: `approvedForPublish` is set only by moderation approval (listing or lot), and only for `ORIGINAL`/`EDITED`/`BACKGROUND_REMOVED`/`ASSET_3D` assets with `useInListing = true`. `GENERATED_TRYON` is never public.

## Known open modelling questions
Variants are intentionally absent (items are unique). Multi-currency is modelled (currency code everywhere) but PKR-only in v1. Seller payout details are provider-tokenised JSON — decide provider first. `Item.measurements` JSON shape is validated per `Category.attributeSchema`.
