# Implementation Backlog (dependency-ordered)
☐ todo · ◐ in progress · ☑ done. Pre-work already done is marked ☑ (P).

## M0 — Groundwork
- ☑(P) Monorepo skeleton, docker-compose, env example, CI, CLAUDE.md
- ☑(P) `@ooak/shared`: money + state machines + accounting rule (13 tests)
- ☑(P) Prisma schema v0.1 validated
- ☑(P) Docs set, design tokens
- ☑ M0.1 Claude Code audit pass: review all docs/schema for gaps; produce `docs/AUDIT_REPORT.md` (do NOT rewrite files wholesale; propose diffs)
- ☑ M0.2 `pnpm install`, confirm CI green, run `prisma validate` with real engine, first migration

## M1 — Foundation & design system (web)
- ☑ Next.js 15 app (App Router, TS strict, Tailwind with `@ooak/design-tokens`); fonts self-hosted via fontsource variable packages (no runtime Google fetch)
- ☑ Primitives: Button, Field/Select/Checkbox, Badge/GradeBadge/StatusPill, Price, Sheet (dialog), Toast, Skeleton, product cards, Gallery, seller chip
- ☑ Layout shells: public, seller, ops, admin (`PortalShell`); responsive nav; footer. English only in v1 (no RTL, by decision)
- ☑ Home page on the real API (fixtures were never needed — API landed first)
- ☐ Storybook / `/dev/ui` gallery; axe + Lighthouse budget in CI (moved to M9)
## M2 — Public marketplace
- ☑ Category/search/product/storefront/collection pages on real API read endpoints; filters, sorting, cursor pagination; OG metadata + WhatsApp share URLs
- ☑ `/reseller`, `/sell` landing pages; `/seller/apply`, `/reseller/apply`, `/activate/[ref]`; bundle price redaction + purchase gate (API first, UI second); lot pages cached WITHOUT prices
- ☑ Single phone-OTP login (`/login`); `normalizePkPhone` everywhere phones are stored/matched
- ☑ Bundles public: `/bundles`, brand/style pages, lot page with contact sheet, size/brand/style filters, price-per-piece + % below retail; header mode switch
- ☑ Postgres FTS (+pg_trgm); seed script with ~60 realistic items, 6 sellers
## M3 — Auth, catalogue, inventory (API)
- ☑ NestJS skeleton, config, problem+json, Prisma service, health
- ☑ Auth (phone OTP), opaque httpOnly sessions, RBAC guards, rate limits, consent records. (Email login not built — phone OTP only, by decision)
- ☑ Codes module: sequences, idempotent item labels, label PDFs (bwip-js + pdf-lib), void/reissue, `ScanEvent` log, partial-unique-index SQL
- ☑ Label PDF renderer per `LABEL_SPECS` (exact-size thermal PDFs) + `/ops/labels` print queue; A4 sheet fallback for sellers
- ☑ Retention job (hourly, advisory-locked): hard-delete `OnboardingDocument` files past `deleteAfter` (90 days after decision), keep last-4 + outcome
- ☑ Onboarding module: applications, documents (restricted storage, every view audited), references, consent capture, activation via own OTP, role grant/revoke, SMS hooks (sandbox notifier; WhatsApp manual in v1)
- ☑ `SELLER_AGENT` role + admin grant UI; `canActOnBehalf` enforced in every on-behalf endpoint; seller consent flag `allowStaffListing`
- ☑ Payout verification: staff screen (ID name vs account title with `compareNames` hint), `payoutVerifiedAt` gate on PAID statements
- ☑ Audit `onBehalfOfId` + "created by ONEOFAKIND team" activity feed
- ☑ StyleTag/BundleTier modules; Bundle service using `validateBundleComposition` + `bundle` state machine; bundle SQL integrity migration
- ☑ Catalogue modules; Item/Listing services using state machines; SKU sequence; media upload (sharp → WebP, EXIF stripped)
- ☑ Raw SQL migration: CHECKs, partial unique reservation index, append-only grants
- ☑ Tests: access boundaries, state transitions, SKU uniqueness
## M4 — Seller portal
- ☑ `/seller/labels` + "Generate label" on every listing; seller pack slip + dispatch label print
- ☑ Bundle builder (`/seller/bundles/new`): brand+style → pick 5/10/15 eligible pieces → price → submit for review
- ☑ Listing create/edit/pause, photo upload, measurements per category, inventory table, storefront editor, settings & payout account, earnings, analytics, activity, support
## M5 — Commerce
- ☑ Cart, reservation service + expiry worker, idempotent checkout, order grouping per seller, sandbox payment adapter + signed webhooks, courier adapter interface + sandbox, tracking, damage-only claims, refunds (prepaid only — no COD)
- ☑ Bundle checkout: atomic multi-item reservation (ordered locks), `OrderBundleLine` + allocated `OrderItem` shares, weight-based shipping, per-piece damaged claims
- ☑ **Concurrency test suite** (N buyers/1 item, N resellers/1 lot), webhook replay tests
## M6 — Managed resale & direct purchase
- ☑ `/ops/scan` unified scan screen (keyboard-wedge + camera), pack verification, dispatch-code issue, courier handover scan; lot sealing
- ☑ `/ops/bundling` assembly queue, piece swap with audit, never-partial-shipment rule
- ☑ Agreements, manifests, receiving, inspection, photo/catalogue queues, locations, custody trail, pick/pack/dispatch, unsold review; direct-purchase offers, approvals, budgets, transfer
## M7 — Admin & finance
- ☑ `/admin/onboarding` queue + `/admin/onboarding/new` assisted registration (docs from WhatsApp, consent evidence, submit, approve/reject/request docs); staff "list on behalf" tool at `/admin/sellers/[id]`
- ☑ Seller Lite UX: photo-first listing wizard, plain-English copy, WhatsApp help button with reference
- ☑ Bundle moderation, tier (5/10/15 only) and style admin, bundle ledger per-piece entries
- ☑ Moderation queue, IP/prohibited/counterfeit reports + seller appeals, tickets + disputes (dispute holds settlement), statements (DRAFT→FINALIZED→PAID), payout records + ledger posting, reconciliation view, ledger/payments viewers, audit viewer, users & roles UI, CMS blocks, collections, settings, staff group cancel with full refund
## M8 — AI & 3D
- ☑ Adapter interfaces (`ImageAdapter`, `TextAdapter`) + local adapters: background removal (edge flood-fill heuristic, refuses non-plain backgrounds) and fact-only listing text template; real providers plug in via `AI_IMAGE_PROVIDER` / `AI_TEXT_PROVIDER` (no external provider wired — needs a vendor choice + credentials)
- ☑ AiJob worker: DB queue claimed with `FOR UPDATE SKIP LOCKED`, timeout, up to 3 retries (never for user errors), stale-job recovery, daily quota per seller, latency + cost recorded; `/admin/ai` usage, failures, retry
- ☑ `/seller/studio`: background removal → separate `MediaAsset` (`aiLabel`, `sourceAssetId`, `useInListing=false`), seller chooses, published only via moderation; listing text suggestions with "missing facts" list
- ☑ 3D: `.glb` upload (validated glTF 2.0 header), private until approval, served to the existing R3F viewer on the product page
- ☐ Labelled model imagery (GENERATED_MODEL) and try-on (GENERATED_TRYON, behind flag + consent) — not built: needs a real image-generation provider; avatar spike (doc only) not written
## M9 — Hardening & staging
- ☑ E2E (Playwright, `e2e/`): buyer prepaid checkout, bundle price gating (guest/customer/reseller), moderation, assisted registration consent gate, AI studio, mobile layout — 7 passing; sessions reused to respect OTP rate limits
- ☑ Security headers: web CSP/HSTS/frame/referrer/permissions; API helmet; checklist in `docs/SECURITY.md`
- ☑ ESLint (flat config, zero warnings) wired into `pnpm lint`; CI runs lint, typecheck, tests (real Postgres), web build and an E2E job
- ☑ Backup/restore drill (pg_dump/pg_restore, counts + triggers + ledger balance verified) and runbook (`docs/RUNBOOK.md`)
- ☐ Staging deploy (noindex) — needs hosting + storage credentials
- ☐ Load test on checkout, Sentry — need staging + DSN
- ☐ Storybook/`/dev/ui` gallery, axe + Lighthouse budget in CI
- ☐ Pilot checklist sign-off (runbook §6 lists the blockers)
