# Runbook — local, staging, operations

> Hard rule: never touch oneofakindretro.com, its DNS/email, or production payment credentials. Staging is sandbox-only and `noindex`. Production needs explicit human approval.

## 1. Local development
Requirements: Node 22, pnpm 9 (`corepack enable`), Postgres 16 (or `pnpm infra:up` for Postgres + Redis + MinIO via Docker).

```bash
pnpm install
cp .env.example .env && cp .env.example apps/api/.env      # dev defaults work as-is
createdb ooak && createdb ooak_test                         # skip if using docker compose (then create ooak_test only)
pnpm --filter @ooak/shared build                            # API/web load @ooak/shared from dist/
pnpm --filter @ooak/api db:generate
pnpm --filter @ooak/api db:migrate                          # prisma migrate deploy (never `migrate reset` on shared DBs)
pnpm --filter @ooak/api db:seed                             # wipes + recreates DEMO data; refuses NODE_ENV=production
pnpm --filter @ooak/api dev                                 # API on :4000
pnpm --filter @ooak/web dev                                 # web on :3000 (proxies /v1/* to the API)
```
Logins (phone OTP; the dev code is shown on screen while `OTP_DEV_ECHO=true`):

| Role | Phone |
|---|---|
| Admin | +923000000001 |
| Warehouse | +923000000002 |
| Support | +923000000003 |
| Finance | +923000000004 |
| Moderator | +923000000005 |
| Seller agent | +923000000006 |
| Seller (Lahore Vintage Co.) | +923010000001 |
| Verified reseller | +923020000001 |
| Buyer | +923030000001 |

Sandbox payments/courier: the checkout "pay" page has *Simulate successful/failed payment*; admins can advance sandbox shipments (`POST /v1/sandbox/courier/:trackingNo/advance`) and flush refunds (`POST /v1/sandbox/refunds/flush`). These endpoints exist only while the sandbox providers are configured.

## 2. Checks (what CI runs)
```bash
pnpm lint        # ESLint (flat config, zero warnings allowed)
pnpm typecheck   # tsc for shared, api, web, e2e
pnpm test        # shared + web (Vitest), api (Jest + real Postgres on DATABASE_URL_TEST, incl. concurrency)
pnpm --filter @ooak/web build
pnpm e2e         # Playwright against a running, seeded stack (E2E_BASE_URL, default http://localhost:3000)
```
API tests TRUNCATE their database and refuse any database whose name doesn't end in `_test`.

## 3. Staging (sandbox) — to set up once credentials/hosting are chosen
Not deployed yet. Target shape (docs/ARCHITECTURE.md):
- **Web**: `next build && next start` behind HTTPS. Env: `API_INTERNAL_URL` (private API URL), `NEXT_PUBLIC_SITE_URL`, `STAGING_NOINDEX=true`.
- **API**: `pnpm --filter @ooak/api build && node dist/main.js`. Env per `.env.example`, plus for staging: `NODE_ENV=staging`, `COOKIE_SECURE=true`, `OTP_DEV_ECHO=false` (needs a real SMS adapter — see §6), `STORAGE_DRIVER=s3` + S3/R2 credentials (single **private** bucket), long random webhook secrets.
- **DB**: managed Postgres 16 with PITR. Migrations: `pnpm --filter @ooak/api db:migrate` as a release step (never `migrate dev`/`reset`).
- **Jobs**: run the API with `JOBS_ENABLED=true` (sweeps use Postgres advisory locks, so multiple instances are safe).
- **Health**: `GET /health` (liveness), `GET /health/ready` (DB).
- Basic auth or IP allow-list in front of staging until launch; `X-Robots-Tag: noindex` is added by `STAGING_NOINDEX=true`.

## 4. Background jobs (in-process, advisory-locked)
| Lock | Every | Job |
|---|---|---|
| 7001 | 1 min | Expire stock reservations (release pieces; late payments are refunded, never fulfilled) |
| 7002 | 5 min | Expire buyer offers |
| 7003 | 10 min | Complete delivered groups after the claim window |
| 7004 | daily | Delete onboarding ID images 90 days after decision (keeps last-4 + outcome) and consent evidence |
| 7005 | 15 s | Run queued AI jobs (timeout, 3 retries, stale recovery) |

## 5. Backups and restore (drill performed 13 Oct 2026 on the dev DB)
```bash
pg_dump -Fc -d "$DATABASE_URL" -f ooak-$(date +%F).dump
createdb ooak_restore && pg_restore -d postgresql://…/ooak_restore --no-owner ooak-YYYY-MM-DD.dump
```
Drill result: row counts identical for User/Item/Order/LedgerEntry/AuditLog/MediaAsset; all 8 integrity triggers restored; ledger debits − credits = 0 after restore. **Media lives in object storage, not the DB** — enable bucket versioning/replication separately; a DB restore without the bucket leaves media 404s. Restricted onboarding documents must stay in the private bucket and respect the 90-day deletion (don't resurrect deleted IDs from old backups into the app).

## 6. Credentials/decisions needed before staging → pilot
| Needed | Why | Where it plugs in |
|---|---|---|
| Payment gateway (sandbox then live) | Real prepaid checkout | `src/modules/commerce/providers.ts` (`PaymentProvider`) + webhook signature |
| Courier API (sandbox then live) | Labels, tracking webhooks | same file (`CourierProvider`) |
| SMS provider | OTP when `OTP_DEV_ECHO=false` | `NotifierService.sendSms` |
| Object storage (R2/S3) | Media + restricted documents | `STORAGE_DRIVER=s3`, `S3_*` |
| AI provider (optional) | Better background removal / model imagery | `src/modules/ai/adapters.ts` |
| Error monitoring DSN (e.g. Sentry) | Alerts | not wired yet |
| Hosting (web, API, Postgres) | Staging | §3 |

## 7. Incident quick reference
- **Ledger doesn't reconcile**: `/admin/finance` shows the difference. Do not mark statements paid. Check `/admin/finance/payments` (webhook trail) vs `/admin/finance/ledger`.
- **Webhook storm / replays**: idempotent on `(provider, eventId)`; bad signatures are rejected and logged.
- **Stuck reservations**: job 7001; verify `JOBS_ENABLED=true` and the API log line `reservations: N`.
- **AI failing**: `/admin/ai` shows failures and lets admins retry; user errors (e.g. busy background) are not retried by design.
- **A seller reports a payout to the wrong account**: payouts require `payoutVerifiedAt` (own-name). Check `/admin/audit` for `PAYOUT_ACCOUNT_VERIFIED` and `STATEMENT_PAID`.
