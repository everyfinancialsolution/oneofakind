# Provider evaluation template (Claude Code fills with *current* docs, not memory)
For each candidate record: official docs URL · pricing · Pakistan availability · commercial-use rights for outputs · data retention/training policy · latency (measured on 20 real thrift photos) · failure modes · SDK/REST quality · sandbox availability · webhook signing scheme.
Categories: **Payments** (local gateway: cards, wallets, bank transfer — no COD) · **Couriers** (rates, label, tracking webhooks) · **Background removal** · **Image editing / model imagery** · **Virtual try-on** (test on real garments before committing) · **Text (listing assist)** · **SMS OTP** (Pakistan routes!) · **Email**.
Decision output: shortlist of 2 per category + recommendation + adapter interface notes.
