# Product Requirements — ONEOFAKIND Web Marketplace v1

## Goal
Validate the whole resale business in a browser: seller onboarding, catalogue, managed resale, direct purchase, orders, AI studio. Mobile apps later reuse the API.

## Account types & onboarding
Buyer · Seller · Verified reseller, one phone-OTP login. Sellers/resellers apply themselves **or are registered by our team from documents sent on WhatsApp** (most sellers are not web-savvy). See `ONBOARDING.md`.

## Personas
| Persona | Needs |
|---|---|
| Buyer | Trust in condition + measurements, discovery, easy prepaid checkout, tracking, damage-claim returns |
| Individual seller | List quickly from a phone, know fees, get paid on time |
| Thrift reseller / business | Bulk listing, inventory/SKU, orders, statements, storefront |
| Managed-resale consignor | Hand over stock, track every piece, approve prices, see statements |
| Warehouse operator | Receive, inspect, photograph, shelve, pick/pack — fast, scan-friendly |
| Support / Finance / Moderator / Admin | Disputes, reconciliation, moderation, configuration, audit |

## Selling arrangements (item level; a seller can mix)
| | Self-managed | Managed resale | Direct purchase |
|---|---|---|---|
| Owner until sale | Seller | Seller | Seller → **Platform after TRANSFERRED** |
| Physical custody | Seller | Platform warehouse | Platform warehouse |
| Platform earns | Commission | Commission + service fee | Full margin (sale − cost) |
| Ledger | Agent | Agent | Principal (revenue + COGS) |
| Price control | Seller | Seller, approval if agreement says | Platform |

## Two sales models on one site (decided)
| | **Retail** (`/shop`) | **Bundles** (`/bundles`) — Fleek-style lots |
|---|---|---|
| Unit sold | One piece | A fixed lot of **exactly 5, 10 or 15 pieces** |
| Composition | Any | **Same brand AND same style** (e.g. 10 Nike track jackets). **Sizes and colours may be mixed** (spread shown per piece). **Only grade A and B pieces** |
| Buyer | Consumers | **Verified resellers only** may purchase **and see prices** (apply at `/reseller/apply` or via WhatsApp; admin reviews). Lot contents (every piece) are browsable by everyone; **prices are hidden from non-verified users** |
| Pricing | Per-item price | One lot price (shown also as price-per-piece and % below retail value) |
| Transparency | Item page | Lot page shows **every piece**: photo, grade, size, measurements (a contact-sheet view) |
| Stock | Item sold from `RESERVED` | All N items reserved/sold atomically, or none |
| Return | Damaged only | Damaged only, claimed **per piece** (refund = that piece's allocated share) |
A piece is sold either retail or inside one bundle, never both (`Item.channel`). Bundles come from the platform's own stock (direct purchase), managed-resale stock, **and other sellers' own stock** (decided). No "mystery/unsorted" lots in v1 — every piece is individually inspected and photographed.

## Functional scope (v1 = launch-pilot definition)
See `ROUTE_INVENTORY.md` for every surface. Pilot acceptance (from brief, plus bundles): a 5-, 10- and 15-piece bundle can each be assembled, sold, shipped and settled with correct per-piece financial records; a seller registers, lists a real item, receives an order, dispatches, sees the correct financial record; managed item is traceable intake→sale/return; direct purchase transfers ownership correctly; buyers see accurate condition and delivery terms; site works when an AI provider is down.

## Non-functional
- Mobile-first responsive (most Pakistani traffic is mobile, often mid-range Android on variable networks): LCP < 2.5s on 4G mobile for home/product pages; image CDN with AVIF/WebP, responsive sizes.
- WCAG 2.2 AA, reduced motion, keyboard focus visible.
- Security: RBAC, validation, rate limits, secure sessions, protected uploads, audit logs.
- Reliability: no overselling (concurrency-tested), idempotent payments/webhooks, AI optional.
- Privacy: consent records, private user photos, retention + deletion, account deletion request.
- English only at launch. Keep strings out of components so translation is possible later, but no RTL/Urdu work in v1.

## Explicitly out of v1
Avatar fashion (architecture spike only), native apps, live chat, international shipping, auctions, production payment credentials, migration of oneofakindretro.com.

## Success metrics (pilot)
Listing time per item (target < 3 min with AI assist), % listings approved first pass, oversell incidents (must be 0), reconciliation mismatches (must be 0), order→dispatch time, return rate by condition grade.
