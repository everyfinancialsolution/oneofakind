# Security review checklist (M9)
☑ in place and tested · ◐ partial · ☐ not done (with reason)

## Identity & sessions
- ☑ Phone OTP only; codes hashed, attempt-limited, rate-limited per number (verified by the E2E run hitting the limit); dev echo refused in production at boot.
- ☑ Opaque session token in an httpOnly, SameSite cookie; only its SHA-256 is stored; `COOKIE_SECURE` required in production; logout revokes; disabling a user revokes all sessions (tested).
- ☑ RBAC on every endpoint via the global `SessionGuard` + `@Auth(...)`; web layouts gate for UX only. Role grants ADMIN-only, audited, no self-demotion (tested).
- ☑ On-behalf actions only via `canActOnBehalf` (SELLER_AGENT/ADMIN + seller opt-in); price approval, offers, payout and phone changes refused (tested). `AuditLog.onBehalfOfId` recorded.

## Data protection
- ☑ Onboarding documents in restricted storage, staff-role reads only, every view audited; deleted 90 days after decision by job 7004.
- ☑ Damage-claim photos private; evidence reads audited. Try-on images can never be public.
- ☑ Bundle prices redacted server-side for non-verified viewers at every depth (unit + API + E2E tests, incl. page HTML).
- ☑ Media served by the API with ownership checks; uploads content-sniffed (never trusting extension/MIME), re-encoded to WebP with EXIF stripped; SVG served with a locked-down CSP; `.glb` header-validated.
- ☑ Errors are RFC 7807 problem+json; no stack traces; internal AI/provider errors are not leaked to users (tested).

## Money & integrity
- ☑ Integer minor units; DB CHECKs; deferred trigger that every ledger transaction balances; append-only ledger/audit/scan logs.
- ☑ Reservation/checkout concurrency tests (10 buyers/1 item, 5 resellers/1 lot ⇒ exactly one winner).
- ☑ Webhooks: HMAC signature verified, raw payload stored, idempotent on `(provider, eventId)`, replay tests.
- ☑ Payouts only after own-name verification; statement lines settled once (unique `orderItemId`).

## Transport & browser
- ☑ API: helmet (CSP, HSTS, nosniff, frame protections), `x-powered-by` off, CORS limited to the web origin.
- ☑ Web: CSP (same-origin; API proxied under /v1), `frame-ancestors 'none'`, X-Frame-Options DENY, Referrer-Policy, Permissions-Policy (camera self only for scanning), HSTS in production, `noindex` header on staging. E2E asserts no CSP violations on the tested flows.
- ◐ CSP still allows `'unsafe-inline'` scripts (Next bootstrap). Next step: per-request nonces via middleware.
- ☑ Rate limiting (global throttler; stricter OTP limits).

## Not done (needs a decision, credentials or infrastructure)
- ☐ Error monitoring (Sentry or similar) — needs a DSN.
- ☐ Load test of checkout at target traffic — needs staging hardware; concurrency correctness is covered by tests.
- ☐ Dependency/secret scanning in CI (e.g. `pnpm audit`, gitleaks) — add when the repo has CI minutes.
- ☐ Penetration test before public launch.
