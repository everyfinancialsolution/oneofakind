# Workflows

State names match `packages/shared/src/states.ts` (tested). Every transition = `assert` + audit event.

## 1. Self-managed sale
Seller creates Item(arrangement=SELF_MANAGED, state=READY_TO_LIST→AVAILABLE on listing approval) → Listing DRAFT→PENDING_REVIEW→PUBLISHED (moderator) → buyer checkout reserves → payment → SOLD → seller marks packed/dispatched (or courier adapter creates label) → DELIVERED → settlement after return window.

## 2. Managed resale
1. Seller requests service → admin creates/approves `ManagedResaleAgreement` (commission bps, fees, approval rule, storage days, unsold policy).
2. Seller submits `IntakeManifest` (lines) → Items created `EXPECTED`.
3. Manifest APPROVED → IN_TRANSIT → warehouse RECEIVING scans each line: RECEIVED / MISSING / DECLINED / DISPUTED. Each physical handover writes a `CustodyEvent`.
4. IN_INSPECTION: grade, measurements, defects → `ConditionReport(source=WAREHOUSE)`. Fail → REJECTED → return-to-seller (custody events).
5. Photography/cataloguing queue → price proposal → if `requiresPriceApproval`, seller approves → READY_TO_LIST → AVAILABLE → listing.
6. Sale → pick/pack/dispatch from warehouse → settlement.
7. Unsold past `storageDays`: seller notified → reprice / return / donate per agreement.
Traceability requirement: query "all events for SKU X" returns intake→sale/return in order.

## 3. Direct purchase
SUBMITTED → UNDER_REVIEW (buyer team) → OFFER_MADE (needs approver + budget code; offer expires) → seller ACCEPTED → AWAITING_HANDOVER (item physically received + verified) → AWAITING_PAYMENT (platform pays seller; reference captured) → **TRANSFERRED** (creates `OwnershipTransfer`, sets `Item.ownerType=PLATFORM`, `costMinor`, posts ledger). Before TRANSFERRED the UI says "offer accepted — awaiting handover/payment", never "sold/purchased". Platform may not list/sell the item until TRANSFERRED (`saleAccounting` throws).

## 3b. Bundles (second sales model)
**Who can buy / see prices:** only users with `VERIFIED_RESELLER` (checked server-side at add-to-cart AND checkout). Lot contents are browsable by all; **prices are redacted server-side for everyone else** (`redactBundlePrices`), with a "Verified resellers only — apply" CTA.
**Build:** seller (own stock — own and other sellers' stock are both supported), warehouse (managed stock) or buying team (platform-owned stock) picks a brand + style, then selects exactly 5/10/15 eligible pieces (`validateBundleComposition` is the single gate: same brand, same style, **grade A or B only, sizes/colours may be mixed**, same arrangement, same owner/seller, pieces `READY_TO_LIST|AVAILABLE`, not already bundled, no live retail listing, bundle price below retail value). Pieces flip to `channel=BUNDLE` and get an active `BundleItem` row. Bundle `DRAFT→PENDING_REVIEW→PUBLISHED` (moderator checks brand/style/photos).
**Sell:** checkout reserves **all N items + the bundle in one transaction** (any item not `AVAILABLE` → whole reservation fails with a clear "bundle no longer available"). Payment verified → bundle `RESERVED→SOLD`, all items `RESERVED→SOLD`. One `OrderBundleLine` (full price) + N `OrderItem` rows carrying `allocateBundlePrice` shares (sum exactly = price paid).
**Fulfil:** managed/platform stock bundles are packed at the warehouse (`/ops/bundling` → pick/pack). **Never ship a partial lot.** If a piece is found damaged/missing at packing, ops swaps in an equivalent piece (same brand+style, grade ≥ original) with an audit + custody record; if none exists, the bundle order is cancelled and refunded in full.
**Weight/shipping:** courier fee from the sum of `Item.weightGrams` against the courier rate card (items without weight cannot be bundled for sale).
**Returns:** damaged-only, per piece. Refund = that piece's allocated share (+ platform pays return shipping on approved claims). The rest of the lot is unaffected. Pieces disclosed in the condition report are not eligible.
**Unbundle:** `REMOVED` (or unsold expiry) releases `BundleItem.releasedAt`, sets items back to `channel=RETAIL`.
**Accounting:** same as retail per piece using allocated shares — agent commission uses the *bundle* commission rate; platform-owned lots use principal-sale entries (revenue = allocated share, COGS = each piece's cost). Because shares sum exactly to the price, ledger totals reconcile to the gateway payment.

## 3c. Onboarding (sellers + verified resellers)
Full spec: `ONBOARDING.md`. Paths: self-serve, **WhatsApp-assisted (staff register on the applicant's behalf, consent recorded)**, phone/in-person assisted. `OnboardingApplication` (DRAFT→SUBMITTED→DOCS_REQUESTED/UNDER_REVIEW→APPROVED|REJECTED|WITHDRAWN) with `OnboardingDocument`s in a restricted bucket. Approve → SellerProfile VERIFIED, or ResellerVerification + `VERIFIED_RESELLER` role. Staff-created accounts are activated by the person via phone OTP. Staff act "on behalf of" with audit, never by impersonation.

## 3d. Labels & scanning
See `LABELS_AND_SCANNING.md`: item label (unique barcode+QR) → lot seal → order QR on payment → pack verification by scanning → dispatch barcode+QR → scan at courier handover.

## 4. Checkout & payment
Cart → `POST /checkout` (idempotency key) → validate items still AVAILABLE → reserve (15 min) → create Order(PENDING_PAYMENT) + FulfilmentGroups per seller → Payment INITIATED with provider.
- Provider redirect/intent → **verified webhook** → PaymentEvent stored → CAPTURED → Order PAID → items SOLD.
- **No COD.** Prepaid only (decision D-07).
- Failure/expiry: reservation released, items AVAILABLE.

## 5. Fulfilment, returns, refunds
Group → Shipment (seller-arranged tracking entry or courier adapter) → events from courier webhooks/polling → DELIVERED starts return window. ReturnRequest REQUESTED→APPROVED→IN_TRANSIT→RECEIVED→REFUNDED. Warehouse inspects returned item: `RETURNED_TO_STOCK`→`IN_INSPECTION`→relist, or dispute. Refund = provider refund + reversing ledger entries; partial refunds supported.

## 6. Accounting (double-entry; amounts in minor units)
**Agent sale (self-managed / managed) — price P, commission c, shipping S collected:**
- Dr CUSTOMER_RECEIVABLE/CASH_PROVIDER (P+S) · Cr SELLER_PAYABLE (P − c) · Cr COMMISSION_REVENUE (c) · Cr (shipping accounts as configured)
**Principal sale (direct purchase, owner=PLATFORM) — price P, cost K:**
- Dr CASH_PROVIDER P · Cr PLATFORM_REVENUE P · Dr COGS K · Cr INVENTORY_ASSET K
**Ownership transfer (direct purchase):** Dr INVENTORY_ASSET K · Cr CASH_PROVIDER K (platform paid seller).
**Refund:** reverse the original entries proportionally (`allocate`). **Settlement:** Dr SELLER_PAYABLE · Cr CASH_PROVIDER at payout, linked to `SellerStatement`. Payout only for order lines past return window and not disputed.
Invariant tests: every txn balances; seller payable = Σ eligible lines − payouts; no OrderItem settled twice.

## 7. AI listing assist
Upload photos → (optional) background removal job → text/attribute suggestions from *verified* inputs (category, brand, seller-entered measurements/condition) → seller edits and confirms → published. Suggestions never populate measurements/material/authenticity. Generated imagery labelled; try-on previews private to the user session, deleted per retention policy.
