# Open questions for Moon (answers unblock specific milestones)
1. **Payments (blocks M5):** *name* the local gateway and share sandbox keys/docs (decided: local gateway, no COD).
2. **Couriers (M5):** *name* the local courier and share API/sandbox access (decided: local courier).
3. **Commission & fees:** adopted as defaults in `COMMERCIAL_POLICY.md` (veto/adjust any number; they are config, not code). Revisit after the first ~100 orders using real handling and gateway costs.
5. **Warehouse:** one location (city?) at pilot? Scanners/barcode labels (printer)?
6. **Seller KYC:** what ID verification do you require, and who reviews it?
7. **Legal:** terms for consignment & direct purchase (ownership transfer wording) — who drafts? Tax/FBR invoicing needs for platform-owned stock sales?
9. **Brand assets:** logo, name styling, any photography; preferred display typeface if already decided.
10. **Hosting region/budget:** API/DB host (Railway/Render/Fly/AWS Mumbai/…); monthly budget cap including AI costs.
11. **AI:** acceptable cost per listing; any provider preference; stance on generated model imagery (label wording).
12. **Authenticity:** will you list branded/luxury items? Needs an authentication policy and brand-verification flow.


18. **Bundle lot photo:** one lot photo plus every piece photo (proposed)?



23. **Printer model(s):** which thermal printer brand/model (and for how many stations)? Needed to choose between browser-PDF printing (default, works with any) and raw ZPL/ESC-POS.
24. **Overnight WhatsApp rota:** who owns nights/weekends so the 24/7 promise holds?

## Decided (Oct 2026)
Retail + bundle models (bundles = 5/10/15 pieces, same brand + style, mixed sizes/colours OK, grade A/B only, verified resellers only, own + other sellers' stock) · unique barcode + QR for every listing, order QR, dispatch barcode+QR · Onboarding on WhatsApp +44 7513 875488 (open 24/7) · ID images deleted 90 days after decision · thermal printers available · payouts only to a bank account in the seller's own name · only authorised staff (`SELLER_AGENT`) may list on a seller's behalf · Local payment gateway · no COD · local courier · returns only for damaged items · English only.
