# Onboarding: Sellers & Verified Resellers

## Principle
Most sellers are not comfortable with websites. So **registration must never depend on the website**. Every applicant can (1) do it themselves in minutes, or (2) send documents on WhatsApp and let our team register them. Both paths produce the same record, the same review, and the same audit trail.

## Three account types (one login system)
| Type | What they do | How they get in |
|---|---|---|
| **Buyer** | Buy single pieces | Self-register (phone OTP) |
| **Seller** | List and sell; managed resale; direct-purchase offers | Apply → verified → seller account |
| **Verified reseller** | Buy bundles; see bundle prices | Apply → verified → `VERIFIED_RESELLER` role |
Login is one phone-number + OTP screen (`/login`) for everyone; no passwords to forget. Two public entry pages explain the offer and start applications: **`/sell`** (sellers) and **`/reseller`** (resellers). Reseller area ("official login") shows bundle prices and the purchase flow only after approval. An applicant can be both a seller and a reseller (two applications).

## Three ways to register
1. **Self-serve** — `/seller/apply` or `/reseller/apply`: name, phone (OTP-verified), city, shop link (optional), upload documents (phone camera). ~3 minutes.
2. **WhatsApp-assisted (primary path for sellers)** — "Apply on WhatsApp" button opens `wa.me/<our number>` with a prefilled message containing the applicant's **reference number** (e.g. `OOAK-S-000123`, created when they tap). They send photos of documents + answer 4 questions. Staff open `/admin/onboarding/new` (or the existing draft), fill the form on their behalf, upload the documents from the chat, record consent, submit. Applicant receives an SMS/WhatsApp message to confirm and activate.
3. **Phone / in-person assisted** — same staff form; channel recorded as `ASSISTED_PHONE` / `ASSISTED_IN_PERSON`.
**Business WhatsApp number: +44 7513 875488 — open 24/7 (decided)** (kept in config `WHATSAPP_BUSINESS_NUMBER`, never hard-coded; links built with `whatsappLink()`). Run it in the free **WhatsApp Business app** (business profile, quick-reply templates for "send these 3 documents", greeting/away messages, labels per applicant stage) — that is enough for v1. Note it is a UK number: Pakistani sellers can message it like any WhatsApp contact, but consider adding a Pakistani business number later if applicants hesitate.
v1 does **not** integrate the WhatsApp Business API (approval, cost, templates). WhatsApp is a manual staff channel with a deep link and reference numbers. Revisit after volume is known.

## Documents (adopted defaults, configurable — `REQUIRED_DOCS` in `@ooak/shared`)
| Applicant | Required | Optional |
|---|---|---|
| Seller | National ID front + back; **payout account proof — bank/wallet account must be in the seller's OWN name** (decided; title must match the ID name) | Shop/social link |
| Reseller | National ID front + back; **shop proof** (shop photo/signboard, or storefront/social link with activity) | Business registration / NTN |
Review checks: ID readable and name matches; payout account title matches; shop proof is real and active; no duplicate phone/ID across accounts; not on the suspended list. Staff may mark documents unreadable → `DOCS_REQUESTED` (applicant told exactly which ones, in plain words).

## Handling IDs sent over WhatsApp (sensitive)
- Upload each document into the restricted bucket via the admin tool, then **delete it from the chat/phone gallery**; do not forward IDs to other chats or keep them on personal phones.
- Documents are never public, access is logged, and they follow a retention rule (**decided:** delete ID images 90 days after approval/rejection, keep only the last 4 ID digits + verification outcome; `OnboardingDocument.deleteAfter` set at decision time, nightly job hard-deletes — `ID_DOC_RETENTION_DAYS`).
- Only onboarding/support/admin roles can open them. The QR/label system never touches them.

## Consent for assisted registration
Because we are creating the account for them, record **how the person agreed** to (a) our seller/reseller terms and (b) us registering them: method (`WHATSAPP_MESSAGE`, `PHONE_CALL`, `IN_PERSON`), date, and evidence (a screenshot of their "I agree" message or a call note) in `OnboardingApplication.consentMethod/consentEvidenceKey`. No application can be submitted without it.

## Activation (assisted accounts)
Staff-created users have `createdByStaffId` set and no activation. The applicant gets a message with a link; they confirm their phone by OTP and accept the terms → `activatedAt` set → they can log in. Staff never know or set their login; there is no shared password. Until activation, staff may prepare listings **on their behalf** (below).

## Own-name payout rule (decided)
Payouts go only to a bank/wallet account **in the seller's own name**. Staff compare the ID name with the account title (`compareNames` gives EXACT / PARTIAL / MISMATCH as a hint; a human decides). Only then is `SellerProfile.payoutVerifiedAt` set. **No statement can be marked PAID while `payoutVerifiedAt` is empty.** Changing payout details later requires the seller's own OTP confirmation and re-verification (staff can never change it on their behalf).

## Acting on someone's behalf (audit-first)
**Who may do this (decided: authorised people only):** staff with the `SELLER_AGENT` role (or `ADMIN`), granted individually by an admin. Support/finance/moderators do not get it by default. The seller must also have consented (`SellerProfile.allowStaffListing`, captured during onboarding). Staff are **never** logged in as the seller (no impersonation). Instead staff tools perform actions with an explicit "on behalf of" marker; every such action writes `AuditLog.onBehalfOfId` and appears in the seller's activity feed ("Created by ONEOFAKIND team for you"). Allowed (`ON_BEHALF_ALLOWED`): create/edit **draft** listings from photos the seller sent, upload photos, request labels, build bundle drafts, submit for review (moderation still applies). Never allowed (`ON_BEHALF_FORBIDDEN`): change payout details or phone, accept offers or direct-purchase offers, approve prices, close the account — those need the seller's own OTP confirmation.

## Simple seller experience (design requirements)
Phone-first, large tap targets, one task per screen, plain words (no jargon: "Add item", "Sent to buyer", "Money on its way"), photo-first listing wizard (4 photos → 6 fields → submit), progress shown as steps, status messages by SMS/WhatsApp. Every screen has a "Get help on WhatsApp" button prefilled with their reference. Managed resale remains the zero-effort option: they hand over stock, we do everything.
Language: English only (decided). Because many sellers are not comfortable with websites, keep wording to simple English and rely on the assisted paths; revisit Roman-Urdu/Urdu for the *seller* side only if support load shows it is needed.

## Staff queue (`/admin/onboarding`)
Filters: kind, channel, status, assigned-to, age. SLA (adopted): WhatsApp is always open; an automatic greeting acknowledges instantly with the reference number; target first human reply **within 1 hour**; decision **within 2 working days** after documents are complete. Because the channel is 24/7, set a rota/owner for nights and weekends so "always open" is true, and use away-message text only as a fallback. Actions: assign, request documents, approve, reject (reason required), re-send activation. Approve → (SELLER) creates `SellerProfile` (`VERIFIED`) | (RESELLER) creates `ResellerVerification` + grants `VERIFIED_RESELLER`. Revoke later from the seller/reseller record (audit-logged). Rejected applicants may re-apply as a new application.

## Bundle prices are hidden until verified
Everyone can browse lots and see every piece (photo, grade, size, measurements). **Prices are visible only to verified resellers, the owning seller, and finance/admin/support/moderator staff.** Enforcement is server-side (`canViewBundlePrices`, `redactBundlePrices`, `allowedBundleSorts` in `@ooak/shared`): no price in API responses, search results, sort/filter options, cached/ISR pages, Open Graph/WhatsApp previews, JSON-LD, sitemaps or emails to non-verified users. Lot pages are cached **without** prices; verified users load prices via an authenticated, non-cached request. Non-verified visitors see "Verified resellers only — apply to see prices" with the apply and WhatsApp buttons.
