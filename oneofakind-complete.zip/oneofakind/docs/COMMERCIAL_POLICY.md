# Commercial Policy — v1 defaults
**DECIDED:** prepaid only (local gateway), local courier, returns only for damaged items, English only.
**ADOPTED AS DEFAULTS (Oct 2026), change any time:** all percentages/day-counts below. Reference implementation + tests: `packages/shared/src/commercial.ts`. Every number lives in config / `CommissionRule` / `ManagedResaleAgreement` — never hard-coded — so they can change without a deploy.

## 1. Commission & fees (proposed)
| Arrangement | Platform takes | Notes |
|---|---|---|
| Self-managed | **12%** of item price | Seller holds stock, packs, hands to courier. Lower take because platform does no handling. |
| Managed resale | **35%** up to PKR 5,000 · **30%** PKR 5,001–20,000 · **25%** above PKR 20,000 | Covers intake, inspection, photography, storage (90 days), packing, support. No upfront fee. Tiering protects margin on cheap pieces where handling cost is a fixed amount. |
| Direct purchase | Offer = **35–45%** of expected resale price (target 40%) | Platform takes inventory risk, keeps the full margin. Buying team approves each offer against a monthly budget. |
| Payment gateway fee | **Pass-through at cost** (buyer-side or absorbed in commission — decide once gateway rates are known) | Check actual gateway rate; do not guess. |
| Listing fee | **PKR 0** at launch | Reduces seller friction during pilot. |

Rough unit economics to sanity-check (illustrative, replace with real costs): item sells at PKR 4,000 managed → platform 35% = 1,400. Costs to cover: photography + handling + packing + storage + support ≈ 400–700 + gateway ≈ 2–3% (~100). Leaves a thin but positive margin; below ~PKR 2,000 managed items are likely unprofitable → **set a managed-resale minimum item price of PKR 2,000** (below that: self-managed only).

## 2. Money flow timing (proposed)
- Seller earnings become **payable 7 days after confirmed delivery** (covers the damage-claim window), then paid out weekly. Disputed lines are held.
- Buyer pays item + flat courier fee (flat PKR rate by zone, set from the courier's rate card).
- Gateway refunds go back to the original payment method.

## 3. Returns — damaged items only (decided)
- Eligible: item arrived **damaged** or with a **defect not disclosed** in the listing/condition report.
- NOT eligible: change of mind, size/fit, colour preference, anything disclosed in the condition report.
- **Claim window: 48 hours from delivery** (proposed). Buyer submits photos (and unboxing video where available) via `/returns/new`.
- Outcome: refund (full or partial) or replace n/a (items are unique) → refund only. Return shipping paid by platform on approved claims.
- Who bears the cost (proposed): managed resale/direct purchase → platform (our inspection missed it); self-managed → seller (deducted from payable; disputes go to support).
- Because buyers cannot return for fit, the product page **must** show measurements in cm and the condition grade prominently. This is the core trust feature, not optional.
- Policy page `/policies/returns` states this plainly. Checkout shows it before payment.

## 4. Managed-resale unsold stock (proposed)
- Storage included: **90 days**.
- Day 45: suggest **-15%** markdown (auto-applied if seller opted in, else needs approval).
- Day 75: suggest **-25%** from original.
- Day 90: seller chooses: collect (platform pays outbound courier fee deducted from future payable) / extend (PKR fee per item per 30 days — set after warehouse cost known) / donate.

## 5. Other defaults (proposed)
- Reservation hold at checkout: 15 minutes.
- Buyer offers (make-an-offer): expire in 24h; seller may set a floor price.
- Direct-purchase offers expire in 72h.
- Minimum payout: PKR 1,000 (carry over below that).

## 6. Bundles (proposed — all numbers configurable per tier/rule)
| Item | Proposal |
|---|---|
| Sizes | **5, 10, 15** pieces exactly (admin-editable `BundleTier`) |
| Buyers | **Verified resellers only** (admin-reviewed) |
| Composition | Same brand **and** same style; **sizes and colours may be mixed**; **grade A and B pieces only**; each piece individually graded + photographed |
| Sources | Platform-owned stock, managed-resale stock, and other sellers' own stock |
| Lot price | Seller/buying team sets one price. Guidance: **55–65% of the sum of piece retail values** (**enforced**: lot price must be ≥25% below the sum of piece retail values; configurable) |
| Floor | **Enforced** minimum **PKR 1,000 per piece** (5-pack ≥ 5,000) to protect margin after handling and courier |
| Commission | Self-managed bundle **8%** · managed-resale bundle **20%** · platform-owned bundle: platform keeps margin (no commission) |
| Direct-purchase stock for bundles | Buy at **35–45%** of expected *retail* value; sell lot at **~60%** → ~20 points of retail value (~33% of lot revenue) gross margin before handling/courier/gateway. Verify with real costs. |
| Shipping | Weight-based using the courier rate card (sum of piece weights); shown before payment. Pieces without a recorded weight cannot enter a bundle. |
| Reservation hold | **30 min** for bundles (larger payments), 15 min for single pieces |
| Returns | Damaged-only, **per piece**, 48 h from delivery, photos required. Refund = that piece's allocated share. Rest of the lot is final. Platform pays return shipping on approved claims. |
| Broken lot at packing | Swap with equivalent (same brand+style, grade ≥ original); if impossible cancel + full refund. Never ship partial. |
| Payout timing | Same as retail: 7 days after confirmed delivery |

Why wholesale margin is thinner: lower per-piece price but handling cost per piece is similar, so bundles only work if pieces are bought cheaply (direct purchase / managed stock) and handled in batches. Track margin per bundle size from day one.

## 7. Condition grades (adopted; enforced in code via `GRADE_CRITERIA`)
| Letter | Internal grade | Meaning | Bundles |
|---|---|---|---|
| **A** | New with tags, Excellent | No stains, holes, repairs, odour or broken fastenings; nothing a buyer notices at arm's length | ✅ |
| **B** | Very good | Light wear only (slight fade, minor pilling, faint creasing); no stains/holes/repairs; any minor mark photographed | ✅ |
| **C** | Good | Visible wear or small disclosed flaws (small stain, minor hole, loose seam, replaced button) | ❌ retail only |
| **D** | Fair | Significant flaws, fully photographed and disclosed, clear discount | ❌ retail only |
Grading integrity for bundles: grade must come from a **warehouse inspection**, or from a **verified seller** with random platform audits (proposed 10% of lots). Repeated mis-grading → seller loses bundle access. Inspector's grade is final; buyers see the letter, the criteria text and every piece's photos.

## 8. Dispatch code (adopted)
See `LABELS_AND_SCANNING.md` §Dispatch: one DISPATCH barcode+QR **per parcel**, issued only when pack verification is COMPLETE, printed on the parcel label next to the courier tracking number, scanned at courier handover.
