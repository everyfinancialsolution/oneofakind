import { Test } from "@nestjs/testing";
import type { INestApplication } from "@nestjs/common";
import type { ConditionGrade, Prisma, Role, SellingArrangement } from "@prisma/client";
import { randomUUID } from "node:crypto";
import request from "supertest";
import { AppModule } from "../src/app.module";
import { hashToken, newSessionToken } from "../src/common/auth";
import { PrismaService } from "../src/common/prisma.service";
import { configureApp } from "../src/main";

export interface Ctx { app: INestApplication; prisma: PrismaService; http: () => ReturnType<typeof request> }

export async function makeApp(): Promise<Ctx> {
  const mod = await Test.createTestingModule({ imports: [AppModule] }).compile();
  const app = mod.createNestApplication({ rawBody: true });
  configureApp(app);
  await app.init();
  const prisma = app.get(PrismaService);
  return { app, prisma, http: () => request(app.getHttpServer()) };
}

export async function truncateAll(prisma: PrismaService) {
  const [{ db }] = await prisma.$queryRawUnsafe<{ db: string }[]>("SELECT current_database() AS db");
  if (!db.endsWith("_test")) throw new Error(`Refusing to truncate non-test database "${db}"`);
  const tables = await prisma.$queryRawUnsafe<{ tablename: string }[]>(`SELECT tablename FROM pg_tables WHERE schemaname='public' AND tablename <> '_prisma_migrations'`);
  await prisma.$executeRawUnsafe(`TRUNCATE ${tables.map((t) => `"${t.tablename}"`).join(", ")} RESTART IDENTITY CASCADE`);
}

let phoneSeq = 1000000;
export const nextPhone = () => `+9233${String(phoneSeq++).padStart(8, "0")}`;
const uid = () => randomUUID().slice(0, 8);

/** Test fixtures. Writes directly to the DB (bypasses business services) - use only to arrange state. */
export function fx(prisma: PrismaService) {
  const f = {
    async user(roles: Role[] = ["CUSTOMER"], extra: Partial<Prisma.UserCreateInput> = {}) {
      return prisma.user.create({ data: { name: `User ${uid()}`, phone: nextPhone(), phoneVerified: new Date(), activatedAt: new Date(), roles, ...extra } });
    },
    /** Returns a Cookie header value for a fresh session. */
    async login(userId: string) {
      const token = newSessionToken();
      await prisma.session.create({ data: { userId, refreshHash: hashToken(token), expiresAt: new Date(Date.now() + 86_400_000) } });
      return `ooak_session=${token}`;
    },
    async seller(opts: { allowStaffListing?: boolean; payoutVerified?: boolean; status?: "VERIFIED" | "PENDING" | "SUSPENDED" } = {}) {
      const user = await f.user(["CUSTOMER", "SELLER"]);
      const profile = await prisma.sellerProfile.create({
        data: {
          userId: user.id, slug: `seller-${uid()}`, displayName: `Seller ${uid()}`, type: "RESELLER", status: opts.status ?? "VERIFIED", city: "Lahore",
          allowStaffListing: opts.allowStaffListing ?? false, payoutAccountTitle: user.name, payoutVerifiedAt: opts.payoutVerified === false ? null : new Date(),
        },
      });
      return { user, profile, cookie: await f.login(user.id) };
    },
    async category(slug = `cat-${uid()}`) { return prisma.category.create({ data: { slug, name: slug } }); },
    async brand(name = `Brand ${uid()}`) { return prisma.brand.create({ data: { name, slug: name.toLowerCase().replace(/[^a-z0-9]+/g, "-") } }); },
    async style(slug = `style-${uid()}`) { return prisma.styleTag.create({ data: { slug, name: slug } }); },
    async item(o: {
      sellerId: string; categoryId: string; brandId?: string; styleId?: string; priceMinor?: number; grade?: ConditionGrade; title?: string;
      arrangement?: SellingArrangement; ownerType?: "SELLER" | "PLATFORM"; stockState?: Prisma.ItemCreateInput["stockState"]; channel?: "RETAIL" | "BUNDLE";
      weightGrams?: number; size?: string; color?: string; publish?: boolean; costMinor?: number; locationId?: string;
    }) {
      const item = await prisma.item.create({
        data: {
          sku: `T-${uid()}`, sellerId: o.sellerId, categoryId: o.categoryId, brandId: o.brandId, styleId: o.styleId, priceMinor: o.priceMinor ?? 500_000,
          conditionGrade: o.grade ?? "EXCELLENT", title: o.title ?? `Test item ${uid()}`, arrangement: o.arrangement ?? "SELF_MANAGED", ownerType: o.ownerType ?? "SELLER",
          stockState: o.stockState ?? "AVAILABLE", channel: o.channel ?? "RETAIL", weightGrams: o.weightGrams ?? 500, size: o.size ?? "M", color: o.color ?? "Black",
          costMinor: o.costMinor, locationId: o.locationId, measurements: { chest_cm: 55, length_cm: 70 },
        },
      });
      await prisma.mediaAsset.create({ data: { itemId: item.id, kind: "ORIGINAL", visibility: "PUBLIC", storageKey: `public/test/${item.id}.jpg`, mime: "image/jpeg", bytes: 10, approvedForPublish: true } });
      let listing = null;
      if (o.publish !== false && (o.channel ?? "RETAIL") === "RETAIL") {
        listing = await prisma.listing.create({ data: { itemId: item.id, sellerId: o.sellerId, slug: `l-${uid()}`, state: "PUBLISHED", publishedAt: new Date() } });
      }
      return { item, listing };
    },
    async tiers() {
      for (const size of [5, 10, 15]) await prisma.bundleTier.upsert({ where: { size }, update: {}, create: { size, minPriceMinor: 100_000 * size } });
    },
    /** A published bundle of `size` grade-A pieces of one brand+style for the given seller. */
    async bundle(o: { sellerId: string; categoryId: string; size?: number; priceMinor?: number; pieceMinor?: number; arrangement?: SellingArrangement }) {
      await f.tiers();
      const size = o.size ?? 5;
      const brand = await f.brand();
      const style = await f.style();
      const pieces = [];
      for (let i = 0; i < size; i++) {
        pieces.push((await f.item({ sellerId: o.sellerId, categoryId: o.categoryId, brandId: brand.id, styleId: style.id, priceMinor: o.pieceMinor ?? 400_000, channel: "BUNDLE", publish: false, arrangement: o.arrangement, size: ["S", "M", "L"][i % 3] })).item);
      }
      const retail = pieces.reduce((a, p) => a + p.priceMinor, 0);
      const b = await prisma.bundle.create({
        data: {
          sku: `TL-${uid()}`, slug: `b-${uid()}`, title: `Bundle ${uid()}`, sellerId: o.sellerId, ownerType: "SELLER", arrangement: o.arrangement ?? "SELF_MANAGED",
          brandId: brand.id, styleId: style.id, categoryId: o.categoryId, size, priceMinor: o.priceMinor ?? Math.round(retail * 0.6), retailValueMinor: retail,
          state: "PUBLISHED", publishedAt: new Date(), items: { create: pieces.map((p, i) => ({ itemId: p.id, position: i, refRetailMinor: p.priceMinor })) },
        },
      });
      return { bundle: b, pieces, brand, style };
    },
  };
  return f;
}

/** Recursively collects every key in a JSON value (used to prove no price field leaks at any depth). */
export function allKeys(v: unknown, out = new Set<string>()): Set<string> {
  if (Array.isArray(v)) v.forEach((x) => allKeys(x, out));
  else if (v && typeof v === "object") for (const [k, x] of Object.entries(v)) { out.add(k); allKeys(x, out); }
  return out;
}
