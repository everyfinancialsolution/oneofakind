import sharp from "sharp";
import { randomUUID } from "node:crypto";
import { ListingService } from "../src/modules/seller/listing.service";
import { ManagedService } from "../src/modules/ops/managed.service";
import { type Ctx, fx, makeApp, truncateAll } from "./helpers";

describe("warehouse ops, managed resale and direct purchase", () => {
  let c: Ctx;
  let f: ReturnType<typeof fx>;
  let catId: string;
  let img: Buffer;
  beforeAll(async () => { c = await makeApp(); f = fx(c.prisma); img = await sharp({ create: { width: 600, height: 750, channels: 3, background: "#456" } }).jpeg().toBuffer(); });
  beforeEach(async () => {
    await truncateAll(c.prisma);
    catId = (await c.prisma.category.create({ data: { slug: "jackets", name: "Jackets", attributeSchema: { measurements: ["chest_cm", "length_cm"] } } })).id;
    await c.prisma.storageLocation.create({ data: { code: "LHR-A-01-1" } });
    await c.prisma.setting.create({ data: { key: "shipping.flatRates", value: { LOCAL: 25_000, NATIONAL: 35_000, localCities: ["Lahore"] } } });
  });
  afterAll(async () => c.app.close());

  const staff = async (role: "WAREHOUSE" | "ADMIN" | "FINANCE" | "MODERATOR") => { const u = await f.user([role]); return { user: u, cookie: await f.login(u.id) }; };

  it("managed resale: request → agreement → manifest → receive → inspect → photos → seller approves price → live → sold; full custody trail", async () => {
    const s = await f.seller();
    const admin = await staff("ADMIN");
    const wh = await staff("WAREHOUSE");
    await c.http().post("/v1/seller/managed-resale/manifests").set("Cookie", s.cookie).send({ lines: [{ description: "Jacket", categoryId: catId, expectedPriceMinor: 500_000 }] }).expect(409);
    const req = await c.http().post("/v1/seller/managed-resale/request").set("Cookie", s.cookie).send({ note: "20 jackets" }).expect(201);
    await c.http().post(`/v1/admin/agreements/${req.body.id}/approve`).set("Cookie", admin.cookie).send({ commissionBps: 3000, requiresPriceApproval: true }).expect(200);
    const low = await c.http().post("/v1/seller/managed-resale/manifests").set("Cookie", s.cookie).send({ lines: [{ description: "Cheap tee", categoryId: catId, expectedPriceMinor: 100_000 }] }).expect(400);
    expect(JSON.stringify(low.body)).toMatch(/minimum/);
    const m = await c.http().post("/v1/seller/managed-resale/manifests").set("Cookie", s.cookie).send({ lines: [{ description: "Carhartt Detroit jacket", categoryId: catId, brandName: "Carhartt", expectedPriceMinor: 1_500_000 }, { description: "Levi's trucker", categoryId: catId, expectedPriceMinor: 700_000 }] }).expect(201);
    await c.http().post(`/v1/seller/managed-resale/manifests/${m.body.id}/submit`).set("Cookie", s.cookie).expect(200);
    await c.http().post(`/v1/ops/manifests/${m.body.id}/approve`).set("Cookie", wh.cookie).expect(200);
    await c.http().post(`/v1/seller/managed-resale/manifests/${m.body.id}/ship`).set("Cookie", s.cookie).send({ courier: "Leopards", trackingNo: "LP123" }).expect(200);
    const man = (await c.http().get(`/v1/ops/manifests/${m.body.id}`).set("Cookie", wh.cookie).expect(200)).body.manifest;
    const [l1, l2] = man.lines;
    const rec = await c.http().post(`/v1/ops/manifests/${m.body.id}/lines/${l1.id}`).set("Cookie", wh.cookie).send({ outcome: "RECEIVED" }).expect(200);
    expect(rec.body.code[0]).toBe("1"); // warehouse items get an ITEM_PACK label at receiving
    await c.http().post(`/v1/ops/manifests/${m.body.id}/reconcile`).set("Cookie", wh.cookie).expect(409);
    await c.http().post(`/v1/ops/manifests/${m.body.id}/lines/${l2.id}`).set("Cookie", wh.cookie).send({ outcome: "MISSING", note: "Not in carton" }).expect(200);
    await c.http().post(`/v1/ops/manifests/${m.body.id}/reconcile`).set("Cookie", wh.cookie).expect(200);
    const itemId = l1.itemId;
    await c.http().post(`/v1/ops/items/${itemId}/inspect`).set("Cookie", wh.cookie).send({ pass: true, grade: "EXCELLENT", measurements: { chest_cm: 60 } }).expect(422);
    await c.http().post(`/v1/ops/items/${itemId}/inspect`).set("Cookie", wh.cookie).send({ pass: true, grade: "EXCELLENT", measurements: { chest_cm: 60, length_cm: 72 }, size: "L", color: "Brown", weightGrams: 1300, locationCode: "LHR-A-01-1" }).expect(200);
    await c.http().post(`/v1/ops/items/${itemId}/catalogue`).set("Cookie", wh.cookie).send({ title: "Carhartt Detroit jacket", priceMinor: 1_400_000 }).expect(422);
    for (let i = 0; i < 2; i++) await c.http().post(`/v1/ops/items/${itemId}/photos`).set("Cookie", wh.cookie).attach("file", img, { filename: "p.jpg", contentType: "image/jpeg" }).expect(201);
    const cat = await c.http().post(`/v1/ops/items/${itemId}/catalogue`).set("Cookie", wh.cookie).send({ title: "Carhartt Detroit jacket", priceMinor: 1_400_000 }).expect(200);
    expect(cat.body.needsSellerApproval).toBe(true);
    expect((await c.prisma.listing.findFirstOrThrow({ where: { itemId } })).state).toBe("DRAFT");
    // staff can never approve the price for the seller
    const agentAttempt = await c.http().post(`/v1/admin/sellers/${s.profile.id}/on-behalf/approve-price`).set("Cookie", admin.cookie).expect(403);
    expect(agentAttempt.body.code).toBe("ON_BEHALF_REFUSED");
    await c.http().post(`/v1/seller/managed-resale/items/${itemId}/price`).set("Cookie", s.cookie).send({ approve: true }).expect(200);
    const l = await c.prisma.listing.findFirstOrThrow({ where: { itemId } });
    expect(l.state).toBe("PENDING_REVIEW");
    await c.app.get(ListingService).approve(l.id, admin.user.id);
    expect((await c.prisma.item.findUniqueOrThrow({ where: { id: itemId } })).priceMinor).toBe(1_400_000);
    // traceability: every handover in order
    const trail = await c.prisma.custodyEvent.findMany({ where: { itemId }, orderBy: { createdAt: "asc" } });
    expect(trail.map((t) => t.toParty)).toEqual(["COURIER:LP123", "WAREHOUSE:LHR", "WAREHOUSE:LHR"]);
    const missingItem = await c.prisma.item.findUniqueOrThrow({ where: { id: l2.itemId } });
    expect(missingItem.stockState).toBe("WITHDRAWN");
    // the warehouse group appears in packing once bought
    const b = await f.user(); const bc = await f.login(b.id);
    await c.http().post("/v1/cart/items").set("Cookie", bc).send({ listingSlug: l.slug }).expect(201);
    const co = (await c.http().post("/v1/checkout").set("Cookie", bc).set("Idempotency-Key", randomUUID()).send({ address: { recipient: "Bilal", phone: "03001112233", line1: "Somewhere 1", city: "Lahore" }, paymentMethod: "WALLET", acceptTerms: true }).expect(201)).body;
    await c.http().post(`/v1/sandbox/payments/${co.paymentId}/complete`).set("Cookie", bc).send({ outcome: "success" }).expect(200);
    const packing = (await c.http().get("/v1/ops/packing").set("Cookie", wh.cookie).expect(200)).body.groups;
    expect(packing[0].picks[0].location).toBe("LHR-A-01-1");
    const order = await c.prisma.order.findFirstOrThrow();
    expect(order.shippingMinor).toBe(25_000); // warehouse (Lahore) → Lahore = local rate
  });

  it("direct purchase: offer rules, seller's own OTP to accept, no listing before TRANSFERRED, costs allocated, ledger posted", async () => {
    const s = await f.seller();
    const admin = await staff("ADMIN");
    const finance = await staff("FINANCE");
    const wh = await staff("WAREHOUSE");
    await c.prisma.buyingBudget.create({ data: { code: "BUY-TEST", label: "Test", limitMinor: 3_000_000, periodStart: new Date(Date.now() - 86_400_000), periodEnd: new Date(Date.now() + 30 * 86_400_000) } });
    const sub = await c.http().post("/v1/seller/direct-purchase").set("Cookie", s.cookie).send({ title: "Three jackets", description: "Good condition lot", sellerAskMinor: 2_000_000, pieces: [{ title: "Jacket A", categoryId: catId, expectedRetailMinor: 2_000_000 }, { title: "Jacket B", categoryId: catId, expectedRetailMinor: 1_000_000 }, { title: "Jacket C", categoryId: catId, expectedRetailMinor: 1_000_000 }] }).expect(201);
    const id = sub.body.id;
    expect((await c.http().get(`/v1/seller/direct-purchase/${id}`).set("Cookie", s.cookie)).body.submission.offerMinor).toBeNull();
    // 40% of 4,000,000 expected retail = 1,600,000 target; 900,000 is outside the 35–45% guide without a note
    const out = await c.http().post(`/v1/admin/direct-purchases/${id}/offer`).set("Cookie", admin.cookie).send({ offerMinor: 900_000, budgetCode: "BUY-TEST" }).expect(422);
    expect(out.body.code).toBe("OUTSIDE_RANGE");
    const over = await c.http().post(`/v1/admin/direct-purchases/${id}/offer`).set("Cookie", admin.cookie).send({ offerMinor: 3_500_000, budgetCode: "BUY-TEST", note: "rare" }).expect(409);
    expect(over.body.code).toBe("OVER_BUDGET");
    await c.http().post(`/v1/admin/direct-purchases/${id}/offer`).set("Cookie", admin.cookie).send({ offerMinor: 1_600_000, budgetCode: "BUY-TEST" }).expect(200);
    const noCode = await c.http().post(`/v1/seller/direct-purchase/${id}/respond`).set("Cookie", s.cookie).send({ accept: true }).expect(400);
    expect(noCode.body.code).toBe("CONFIRMATION_REQUIRED");
    const { devCode } = (await c.http().post("/v1/auth/confirm/request").set("Cookie", s.cookie)).body;
    const acc = await c.http().post(`/v1/seller/direct-purchase/${id}/respond`).set("Cookie", s.cookie).send({ accept: true, code: devCode }).expect(200);
    expect(acc.body.state).toBe("AWAITING_HANDOVER");
    const items = await c.prisma.item.findMany({ where: { directPurchaseId: id }, orderBy: { priceMinor: "desc" } });
    expect(items.every((i) => i.ownerType === "SELLER")).toBe(true);
    // finance can't pay before the warehouse has received and checked the pieces
    await c.http().post(`/v1/admin/direct-purchases/${id}/transfer`).set("Cookie", finance.cookie).send({ paymentRef: "IBFT-1" }).expect(409);
    await c.http().post(`/v1/ops/direct-purchases/${id}/receive`).set("Cookie", wh.cookie).send({ itemIds: items.map((i) => i.id) }).expect(200);
    // listing is impossible before ownership transfer
    await c.http().post(`/v1/ops/items/${items[0]!.id}/inspect`).set("Cookie", wh.cookie).send({ pass: true, grade: "VERY_GOOD", measurements: { chest_cm: 55, length_cm: 70 } }).expect(200);
    for (let i = 0; i < 2; i++) await c.http().post(`/v1/ops/items/${items[0]!.id}/photos`).set("Cookie", wh.cookie).attach("file", img, { filename: "p.jpg", contentType: "image/jpeg" });
    const early = await c.http().post(`/v1/ops/items/${items[0]!.id}/catalogue`).set("Cookie", wh.cookie).send({ title: "Jacket A", priceMinor: 2_000_000 }).expect(409);
    expect(early.body.code).toBe("NOT_TRANSFERRED");
    await c.http().post(`/v1/admin/direct-purchases/${id}/transfer`).set("Cookie", finance.cookie).send({ paymentRef: "IBFT-778812" }).expect(200);
    const after = await c.prisma.item.findMany({ where: { directPurchaseId: id } });
    expect(after.every((i) => i.ownerType === "PLATFORM")).toBe(true);
    expect(after.reduce((a, i) => a + (i.costMinor ?? 0), 0)).toBe(1_600_000);
    expect(await c.prisma.ownershipTransfer.count({ where: { directPurchaseId: id } })).toBe(3);
    const inv = await c.prisma.ledgerAccount.findFirstOrThrow({ where: { type: "INVENTORY_ASSET", ownerRef: "PLATFORM" } });
    const sum = await c.prisma.ledgerEntry.aggregate({ where: { accountId: inv.id }, _sum: { debitMinor: true } });
    expect(sum._sum.debitMinor).toBe(1_600_000);
    await c.http().post(`/v1/ops/items/${items[0]!.id}/catalogue`).set("Cookie", wh.cookie).send({ title: "Jacket A", priceMinor: 2_000_000 }).expect(200);
    expect((await c.prisma.directPurchase.findUniqueOrThrow({ where: { id } })).state).toBe("TRANSFERRED");
  });

  it("lot sealing needs exactly the right N piece scans; swaps require same brand/style and grade ≥ original", async () => {
    await f.tiers();
    const s = await f.seller();
    const wh = await staff("WAREHOUSE");
    const { bundle, pieces, brand, style } = await f.bundle({ sellerId: s.profile.id, categoryId: catId, size: 5, arrangement: "MANAGED_RESALE" });
    const svcCodes = [];
    for (const p of pieces) svcCodes.push((await c.http().post("/v1/ops/labels").set("Cookie", wh.cookie).send({ itemIds: [p.id] })).status);
    const codes = (await c.prisma.scanCode.findMany({ where: { itemId: { in: pieces.map((p) => p.id) } } })).map((x) => x.code);
    const partial = await c.http().post(`/v1/ops/bundles/${bundle.id}/seal`).set("Cookie", wh.cookie).send({ scans: codes.slice(0, 4) }).expect(200);
    expect(partial.body.sealed).toBe(false);
    const sealed = await c.http().post(`/v1/ops/bundles/${bundle.id}/seal`).set("Cookie", wh.cookie).send({ scans: codes }).expect(200);
    expect(sealed.body.sealed).toBe(true);
    expect(sealed.body.code[0]).toBe("2");
    const worse = await f.item({ sellerId: s.profile.id, categoryId: catId, brandId: brand.id, styleId: style.id, grade: "GOOD", publish: false, arrangement: "MANAGED_RESALE" });
    const badSwap = await c.http().post(`/v1/ops/bundles/${bundle.id}/swap`).set("Cookie", wh.cookie).send({ outItemId: pieces[0]!.id, inItemId: worse.item.id, reason: "stain found" }).expect(400);
    expect(badSwap.body.code).toBe("SWAP_GRADE");
    const good = await f.item({ sellerId: s.profile.id, categoryId: catId, brandId: brand.id, styleId: style.id, grade: "EXCELLENT", publish: false, arrangement: "MANAGED_RESALE" });
    await c.http().post(`/v1/ops/bundles/${bundle.id}/swap`).set("Cookie", wh.cookie).send({ outItemId: pieces[0]!.id, inItemId: good.item.id, reason: "stain found" }).expect(200);
    expect(await c.prisma.scanCode.count({ where: { bundleId: bundle.id, voidedAt: null } })).toBe(0); // re-seal required
    expect((await c.prisma.item.findUniqueOrThrow({ where: { id: pieces[0]!.id } })).stockState).toBe("LOST_OR_DAMAGED");
    expect(await c.prisma.bundleItem.count({ where: { bundleId: bundle.id, releasedAt: null } })).toBe(5);
    void svcCodes;
  });

  it("ops endpoints are warehouse/admin only; unsold sweep suggests markdowns", async () => {
    const s = await f.seller();
    await c.http().get("/v1/ops/overview").set("Cookie", s.cookie).expect(403);
    const fin = await staff("FINANCE");
    await c.http().get("/v1/ops/overview").set("Cookie", fin.cookie).expect(403);
    const { item, listing } = await f.item({ sellerId: s.profile.id, categoryId: catId, arrangement: "MANAGED_RESALE" });
    await c.prisma.listing.update({ where: { id: listing!.id }, data: { publishedAt: new Date(Date.now() - 50 * 86_400_000) } });
    const u = await c.app.get(ManagedService).unsold();
    expect(u.find((x) => x.id === item.id)?.suggestion).toBe("MARKDOWN_15");
  });
});
