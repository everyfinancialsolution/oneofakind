import { allKeys, type Ctx, fx, makeApp, truncateAll } from "./helpers";

describe("public catalogue, search and bundle price redaction", () => {
  let c: Ctx;
  let f: ReturnType<typeof fx>;
  beforeAll(async () => { c = await makeApp(); f = fx(c.prisma); });
  beforeEach(async () => truncateAll(c.prisma));
  afterAll(async () => c.app.close());

  it("search returns only published, available retail items; filters and sorts work", async () => {
    const s = await f.seller();
    const jackets = await f.category("jackets");
    const shoes = await f.category("shoes");
    const levis = await f.brand("Levis");
    await f.item({ sellerId: s.profile.id, categoryId: jackets.id, brandId: levis.id, title: "Levis trucker denim jacket", priceMinor: 700_000, grade: "VERY_GOOD" });
    await f.item({ sellerId: s.profile.id, categoryId: jackets.id, title: "Wool harrington jacket", priceMinor: 300_000, grade: "GOOD" });
    await f.item({ sellerId: s.profile.id, categoryId: shoes.id, title: "Leather boots", priceMinor: 900_000 });
    await f.item({ sellerId: s.profile.id, categoryId: shoes.id, title: "Sold boots", stockState: "SOLD" });
    await f.item({ sellerId: s.profile.id, categoryId: shoes.id, title: "Draft boots", publish: false });

    const all = await c.http().get("/v1/listings").expect(200);
    expect(all.body.total).toBe(3);
    const q = await c.http().get("/v1/listings?q=denim").expect(200);
    expect(q.body.items.map((i: { title: string }) => i.title)).toEqual(["Levis trucker denim jacket"]);
    const typo = await c.http().get("/v1/listings?q=jackt").expect(200);
    expect(typo.body.items.length).toBeGreaterThan(0);
    const cat = await c.http().get("/v1/listings?category=jackets&sort=price_asc").expect(200);
    expect(cat.body.items.map((i: { priceMinor: number }) => i.priceMinor)).toEqual([300_000, 700_000]);
    const grade = await c.http().get("/v1/listings?grade=B").expect(200);
    expect(grade.body.items).toHaveLength(1);
    const brand = await c.http().get("/v1/listings?brand=levis").expect(200);
    expect(brand.body.items[0].brand.name).toBe("Levis");
    const price = await c.http().get("/v1/listings?minPrice=500000").expect(200);
    expect(price.body.items).toHaveLength(2);
    const facets = await c.http().get("/v1/listings/facets?category=jackets").expect(200);
    expect(facets.body.grades.map((g: { value: string }) => g.value)).toEqual(["B", "C"]);
  });

  it("cursor pagination walks every result exactly once", async () => {
    const s = await f.seller();
    const cat = await f.category();
    for (let i = 0; i < 7; i++) await f.item({ sellerId: s.profile.id, categoryId: cat.id, priceMinor: 100_000 + i });
    const seen: string[] = [];
    let cursor: string | null = null;
    do {
      const r: { body: { items: Array<{ sku: string }>; nextCursor: string | null } } = await c.http().get(`/v1/listings?limit=3${cursor ? `&cursor=${cursor}` : ""}`).expect(200);
      seen.push(...r.body.items.map((i) => i.sku));
      cursor = r.body.nextCursor;
    } while (cursor);
    expect(new Set(seen).size).toBe(7);
  });

  it("product page: draft listings are hidden from the public but previewable by the owner", async () => {
    const s = await f.seller();
    const cat = await f.category();
    const { item } = await f.item({ sellerId: s.profile.id, categoryId: cat.id, publish: false });
    const l = await c.prisma.listing.create({ data: { itemId: item.id, sellerId: s.profile.id, slug: "draft-one", state: "DRAFT" } });
    await c.http().get(`/v1/listings/${l.slug}`).expect(404);
    const preview = await c.http().get(`/v1/listings/${l.slug}`).set("Cookie", s.cookie).expect(200);
    expect(preview.body.preview).toBe(true);
    expect(preview.headers["cache-control"]).toContain("no-store");
  });

  it("product payload carries measurements, grade criteria, fulfilment and the no-COD / damaged-only terms", async () => {
    const s = await f.seller();
    const cat = await f.category();
    const { listing } = await f.item({ sellerId: s.profile.id, categoryId: cat.id });
    const r = await c.http().get(`/v1/listings/${listing!.slug}`).expect(200);
    expect(r.body.item.measurements).toEqual({ chest_cm: 55, length_cm: 70 });
    expect(r.body.item.grade.letter).toBe("A");
    expect(r.body.item.fulfilment.payment).toMatch(/No cash on delivery/);
    expect(r.body.item.fulfilment.returns).toMatch(/damaged/);
    const a = await c.http().get(`/v1/listings/${listing!.slug}/availability`).expect(200);
    expect(a.body.availability).toBe("AVAILABLE");
  });

  describe("bundle prices are hidden from non-verified viewers (server-side)", () => {
    const PRICE_KEYS = ["priceMinor", "retailValueMinor", "pricePerPieceMinor", "savingsBps", "refRetailMinor", "minPricePerPieceMinor"];

    it("anonymous and ordinary customers see every piece but no price field at any depth, in list, detail and home", async () => {
      const s = await f.seller();
      const cat = await f.category();
      const { bundle } = await f.bundle({ sellerId: s.profile.id, categoryId: cat.id, size: 5 });
      const customer = await f.user();
      const cookie = await f.login(customer.id);
      for (const ck of [undefined, cookie]) {
        const req = (p: string) => (ck ? c.http().get(p).set("Cookie", ck) : c.http().get(p));
        const list = await req("/v1/bundles").expect(200);
        const detail = await req(`/v1/bundles/${bundle.slug}`).expect(200);
        const home = await req("/v1/content/home").expect(200);
        for (const body of [list.body, detail.body, home.body]) {
          const keys = allKeys(body);
          for (const k of PRICE_KEYS) expect(keys.has(k)).toBe(false);
        }
        expect(detail.body.bundle.pieces).toHaveLength(5);
        expect(detail.body.bundle.pieces[0].measurements).toBeTruthy();
        expect(detail.body.canSeePrices).toBe(false);
        expect(JSON.stringify(detail.body)).not.toContain(String(bundle.priceMinor));
      }
      const anon = await c.http().get(`/v1/bundles/${bundle.slug}`).expect(200);
      expect(anon.headers["cache-control"]).toContain("public");
    });

    it("price sorts and filters are refused for non-verified viewers", async () => {
      const r = await c.http().get("/v1/bundles?sort=price_asc").expect(400);
      expect(r.body.code).toBe("SORT_NOT_ALLOWED");
      await c.http().get("/v1/bundles?sort=savings").expect(400);
      const f2 = await c.http().get("/v1/bundles?minPrice=100").expect(400);
      expect(f2.body.code).toBe("FILTER_NOT_ALLOWED");
      await c.http().get("/v1/bundles?sort=brand").expect(200);
    });

    it("verified resellers see prices and may price-sort; responses are never shared-cached", async () => {
      const s = await f.seller();
      const cat = await f.category();
      const { bundle } = await f.bundle({ sellerId: s.profile.id, categoryId: cat.id, size: 5 });
      const reseller = await f.user(["CUSTOMER", "VERIFIED_RESELLER"]);
      const cookie = await f.login(reseller.id);
      const d = await c.http().get(`/v1/bundles/${bundle.slug}`).set("Cookie", cookie).expect(200);
      expect(d.body.bundle.priceMinor).toBe(bundle.priceMinor);
      expect(d.body.bundle.pricePerPieceMinor).toBe(Math.round(bundle.priceMinor / 5));
      expect(d.body.canPurchase).toBe(true);
      expect(d.headers["cache-control"]).toContain("no-store");
      await c.http().get("/v1/bundles?sort=price_asc").set("Cookie", cookie).expect(200);
    });

    it("a seller sees prices of their own bundles only", async () => {
      const a = await f.seller();
      const b = await f.seller();
      const cat = await f.category();
      const own = await f.bundle({ sellerId: a.profile.id, categoryId: cat.id });
      const other = await f.bundle({ sellerId: b.profile.id, categoryId: cat.id });
      const ownR = await c.http().get(`/v1/bundles/${own.bundle.slug}`).set("Cookie", a.cookie).expect(200);
      expect(ownR.body.bundle.priceMinor).toBe(own.bundle.priceMinor);
      const otherR = await c.http().get(`/v1/bundles/${other.bundle.slug}`).set("Cookie", a.cookie).expect(200);
      expect(otherR.body.bundle.priceMinor).toBeUndefined();
      const list = await c.http().get("/v1/bundles").set("Cookie", a.cookie).expect(200);
      const bySlug = Object.fromEntries(list.body.bundles.map((x: { slug: string; priceMinor?: number }) => [x.slug, x.priceMinor]));
      expect(bySlug[own.bundle.slug]).toBe(own.bundle.priceMinor);
      expect(bySlug[other.bundle.slug]).toBeUndefined();
    });
  });

  it("media: unapproved photos are visible to the owner and staff only", async () => {
    const s = await f.seller();
    const cat = await f.category();
    const { item } = await f.item({ sellerId: s.profile.id, categoryId: cat.id, publish: false });
    const m = await c.prisma.mediaAsset.create({ data: { itemId: item.id, kind: "ORIGINAL", storageKey: `private/test/${item.id}-2.jpg`, mime: "image/jpeg", bytes: 3 } });
    const { StorageService } = await import("../src/common/storage.service");
    await c.app.get(StorageService).put(m.storageKey, Buffer.from([0xff, 0xd8, 0xff]), "image/jpeg");
    await c.http().get(`/v1/media/${m.id}`).expect(404);
    const other = await f.user();
    await c.http().get(`/v1/media/${m.id}`).set("Cookie", await f.login(other.id)).expect(404);
    const own = await c.http().get(`/v1/media/${m.id}`).set("Cookie", s.cookie).expect(200);
    expect(own.headers["cache-control"]).toContain("no-store");
    const staff = await f.user(["MODERATOR"]);
    await c.http().get(`/v1/media/${m.id}`).set("Cookie", await f.login(staff.id)).expect(200);
  });
});
