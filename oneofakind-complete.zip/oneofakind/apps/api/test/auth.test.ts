import { type Ctx, fx, makeApp, truncateAll } from "./helpers";

describe("phone OTP auth", () => {
  let c: Ctx;
  beforeAll(async () => { c = await makeApp(); });
  beforeEach(async () => truncateAll(c.prisma));
  afterAll(async () => c.app.close());

  const requestCode = async (phone: string) => (await c.http().post("/v1/auth/otp/request").send({ phone }).expect(200)).body;

  it("normalises Pakistani numbers and rejects invalid ones", async () => {
    const r = await requestCode("0300-123 4567");
    expect(r.phone).toBe("+923001234567");
    expect(r.devCode).toMatch(/^\d{6}$/);
    expect(r.isNewAccount).toBe(true);
    const bad = await c.http().post("/v1/auth/otp/request").send({ phone: "1234567" }).expect(400);
    expect(bad.body.code).toBe("INVALID_PHONE");
    expect(bad.headers["content-type"]).toContain("application/problem+json");
  });

  it("creates a new account only after terms are accepted and a name is given, then sets an httpOnly cookie", async () => {
    const { devCode } = await requestCode("03001112222");
    const noTerms = await c.http().post("/v1/auth/otp/verify").send({ phone: "03001112222", code: devCode }).expect(409);
    expect(noTerms.body.code).toBe("TERMS_REQUIRED");
    const noName = await c.http().post("/v1/auth/otp/verify").send({ phone: "03001112222", code: devCode, acceptTerms: true }).expect(409);
    expect(noName.body.code).toBe("NAME_REQUIRED");
    const ok = await c.http().post("/v1/auth/otp/verify").send({ phone: "03001112222", code: devCode, acceptTerms: true, name: "Fatima" }).expect(200);
    expect(ok.body.me.user.roles).toEqual(["CUSTOMER"]);
    const cookie = ok.headers["set-cookie"]![0]!;
    expect(cookie).toMatch(/ooak_session=/);
    expect(cookie).toMatch(/HttpOnly/i);
    expect(cookie).toMatch(/SameSite=Lax/i);
    const consents = await c.prisma.consentRecord.findMany({ where: { userId: ok.body.me.user.id } });
    expect(consents.map((x) => x.type).sort()).toEqual(["PRIVACY", "TERMS"]);
    const me = await c.http().get("/v1/auth/me").set("Cookie", cookie.split(";")[0]!).expect(200);
    expect(me.body.user.name).toBe("Fatima");
    // Only the hash of the session token is stored
    const sessions = await c.prisma.session.findMany();
    expect(sessions[0]!.refreshHash).not.toContain(cookie.split(";")[0]!.split("=")[1]!);
  });

  it("a code works once and wrong codes are limited", async () => {
    const u = await fx(c.prisma).user();
    const { devCode } = await requestCode(u.phone!);
    const wrong = devCode === "000000" ? "111111" : "000000";
    const w = await c.http().post("/v1/auth/otp/verify").send({ phone: u.phone, code: wrong }).expect(400);
    expect(w.body.code).toBe("OTP_INVALID");
    await c.http().post("/v1/auth/otp/verify").send({ phone: u.phone, code: devCode }).expect(200);
    const reuse = await c.http().post("/v1/auth/otp/verify").send({ phone: u.phone, code: devCode }).expect(400);
    expect(reuse.body.code).toBe("OTP_EXPIRED");
  });

  it("locks the challenge after 5 wrong attempts", async () => {
    const u = await fx(c.prisma).user();
    const { devCode } = await requestCode(u.phone!);
    const wrong = devCode === "000000" ? "111111" : "000000";
    for (let i = 0; i < 5; i++) await c.http().post("/v1/auth/otp/verify").send({ phone: u.phone, code: wrong }).expect(400);
    await c.http().post("/v1/auth/otp/verify").send({ phone: u.phone, code: devCode }).expect(429);
  });

  it("rate-limits code requests per phone", async () => {
    for (let i = 0; i < 5; i++) await requestCode("03005556666");
    await c.http().post("/v1/auth/otp/request").send({ phone: "03005556666" }).expect(429);
  });

  it("staff-registered accounts are activated by the person with their own OTP and terms", async () => {
    const staff = await fx(c.prisma).user(["SELLER_AGENT"]);
    const u = await fx(c.prisma).user(["CUSTOMER", "SELLER"], { activatedAt: null, createdByStaffId: staff.id });
    const req = await requestCode(u.phone!);
    expect(req.needsActivation).toBe(true);
    await c.http().post("/v1/auth/otp/verify").send({ phone: u.phone, code: req.devCode }).expect(409);
    await c.http().post("/v1/auth/otp/verify").send({ phone: u.phone, code: req.devCode, acceptTerms: true }).expect(200);
    const after = await c.prisma.user.findUniqueOrThrow({ where: { id: u.id } });
    expect(after.activatedAt).not.toBeNull();
    expect(await c.prisma.auditLog.count({ where: { action: "ACCOUNT_ACTIVATED", entityId: u.id } })).toBe(1);
  });

  it("logout revokes the session server-side", async () => {
    const u = await fx(c.prisma).user();
    const cookie = await fx(c.prisma).login(u.id);
    await c.http().get("/v1/auth/me").set("Cookie", cookie).expect(200).then((r) => expect(r.body.user.id).toBe(u.id));
    await c.http().post("/v1/auth/logout").set("Cookie", cookie).expect(200);
    const after = await c.http().get("/v1/auth/me").set("Cookie", cookie).expect(200);
    expect(after.body.user).toBeNull();
  });

  it("disabled users are treated as signed out", async () => {
    const u = await fx(c.prisma).user(["CUSTOMER"], { disabledAt: new Date() });
    const cookie = await fx(c.prisma).login(u.id);
    expect((await c.http().get("/v1/auth/me").set("Cookie", cookie)).body.user).toBeNull();
  });
});
