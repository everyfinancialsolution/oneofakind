import sharp from "sharp";
import { randomUUID } from "node:crypto";
import { CheckoutService } from "../src/modules/commerce/checkout.service";
import { FulfilmentService } from "../src/modules/commerce/fulfilment.service";
import { SIG_HEADER, sign } from "../src/modules/commerce/providers";
import { type Ctx, fx, makeApp, truncateAll } from "./helpers";

const ADDRESS = { recipient: "Fatima Noor", phone: "0300 1234567", line1: "House 12, Street 4, DHA", city: "Karachi" };

describe("commerce: cart, checkout, payments, fulfilment, damage claims", () => {
  let c: Ctx;
  let f: ReturnType<typeof fx>;
  let catId: string;
  beforeAll(async () => { c = await makeApp(); f = fx(c.prisma); });
  beforeEach(async () => {
    await truncateAll(c.prisma);
    catId = (await f.category("jackets")).id;
    await c.prisma.setting.create({ data: { key: "shipping.flatRates", value: { LOCAL: 25_000, NATIONAL: 35_000, localCities: ["Lahore"] } } });
    await c.prisma.setting.create({ data: { key: "shipping.bundleRatePerKgMinor", value: 12_000 } });
  });
  afterAll(async () => c.app.close());

  async function buyer(roles: Array<"CUSTOMER" | "VERIFIED_RESELLER"> = ["CUSTOMER"]) { const u = await f.user(roles); return { user: u, cookie: await f.login(u.id) }; }
  const addToCart = (cookie: string, body: object) => c.http().post("/v1/cart/items").set("Cookie", cookie).send(body);
  const checkout = (cookie: string, key = randomUUID()) => c.http().post("/v1/checkout").set("Cookie", cookie).set("Idempotency-Key", key).send({ address: ADDRESS, paymentMethod: "CARD", acceptTerms: true });
  const pay = (cookie: string, paymentId: string, outcome: "success" | "fail" = "success") => c.http().post(`/v1/sandbox/payments/${paymentId}/complete`).set("Cookie", cookie).send({ outcome });
  async function ledgerSum(type: string, ownerRef = "PLATFORM") {
    const a = await c.prisma.ledgerAccount.findFirst({ where: { type: type as never, ownerRef } });
    if (!a) return 0;
    const s = await c.prisma.ledgerEntry.aggregate({ where: { accountId: a.id }, _sum: { debitMinor: true, creditMinor: true } });
    return (s._sum.debitMinor ?? 0) - (s._sum.creditMinor ?? 0);
  }

  it("happy path: idempotent checkout reserves, verified payment sells, ledger balances with correct commission", async () => {
    const s = await f.seller();
    const { listing, item } = await f.item({ sellerId: s.profile.id, categoryId: catId, priceMinor: 500_000 });
    const b = await buyer();
    await addToCart(b.cookie, { listingSlug: listing!.slug }).expect(201);
    const key = randomUUID();
    const r1 = await checkout(b.cookie, key).expect(201);
    const r2 = await checkout(b.cookie, key).expect(201);
    expect(r2.body.orderRef).toBe(r1.body.orderRef);
    expect(r2.body.duplicate).toBe(true);
    expect((await c.prisma.item.findUniqueOrThrow({ where: { id: item.id } })).stockState).toBe("RESERVED");
    const order = await c.prisma.order.findUniqueOrThrow({ where: { reference: r1.body.orderRef } });
    expect(order.state).toBe("PENDING_PAYMENT");
    expect(order.shippingMinor).toBe(35_000); // Lahore seller → Karachi = national rate
    expect(order.totalMinor).toBe(535_000);
    await pay(b.cookie, r1.body.paymentId).expect(200);
    const paid = await c.prisma.order.findUniqueOrThrow({ where: { id: order.id } });
    expect(paid.state).toBe("PAID");
    expect((await c.prisma.item.findUniqueOrThrow({ where: { id: item.id } })).stockState).toBe("SOLD");
    expect((await c.prisma.listing.findUniqueOrThrow({ where: { id: listing!.id } })).state).toBe("SOLD_OUT");
    expect(await c.prisma.scanCode.count({ where: { kind: "ORDER_PACK" } })).toBe(1);
    // 12% self-managed commission on 5,000 = 600
    expect(await ledgerSum("CASH_PROVIDER")).toBe(535_000);
    expect(-(await ledgerSum("SELLER_PAYABLE", s.profile.id))).toBe(440_000);
    expect(-(await ledgerSum("COMMISSION_REVENUE"))).toBe(60_000);
    expect(-(await ledgerSum("PLATFORM_REVENUE"))).toBe(35_000);
    const all = await c.prisma.ledgerEntry.aggregate({ _sum: { debitMinor: true, creditMinor: true } });
    expect(all._sum.debitMinor).toBe(all._sum.creditMinor);
  });

  it("CONCURRENCY: 10 buyers race for one item ⇒ exactly one order", async () => {
    const s = await f.seller();
    const { listing, item } = await f.item({ sellerId: s.profile.id, categoryId: catId });
    const buyers = await Promise.all(Array.from({ length: 10 }, () => buyer()));
    for (const b of buyers) await addToCart(b.cookie, { listingSlug: listing!.slug }).expect(201);
    const results = await Promise.all(buyers.map((b) => checkout(b.cookie)));
    const ok = results.filter((r) => r.status === 201);
    const conflicts = results.filter((r) => r.status === 409);
    expect(ok).toHaveLength(1);
    expect(conflicts).toHaveLength(9);
    expect(conflicts.every((r) => r.body.code === "ITEMS_UNAVAILABLE")).toBe(true);
    expect(await c.prisma.stockReservation.count({ where: { itemId: item.id, releasedAt: null } })).toBe(1);
    expect(await c.prisma.order.count()).toBe(1);
  });

  it("CONCURRENCY: 5 verified resellers race for one bundle ⇒ one wins; all pieces reserved atomically; shares sum to the lot price", async () => {
    const s = await f.seller();
    const { bundle, pieces } = await f.bundle({ sellerId: s.profile.id, categoryId: catId, size: 5, priceMinor: 1_234_567 });
    const resellers = await Promise.all(Array.from({ length: 5 }, () => buyer(["CUSTOMER", "VERIFIED_RESELLER"])));
    for (const r of resellers) await addToCart(r.cookie, { bundleSlug: bundle.slug }).expect(201);
    const results = await Promise.all(resellers.map((r) => checkout(r.cookie)));
    expect(results.filter((r) => r.status === 201)).toHaveLength(1);
    const items = await c.prisma.item.findMany({ where: { id: { in: pieces.map((p) => p.id) } } });
    expect(items.every((i) => i.stockState === "RESERVED")).toBe(true);
    expect((await c.prisma.bundle.findUniqueOrThrow({ where: { id: bundle.id } })).state).toBe("RESERVED");
    const lines = await c.prisma.orderItem.findMany({ where: { bundleLineId: { not: null } } });
    expect(lines).toHaveLength(5);
    expect(lines.reduce((a, l) => a + l.priceMinor, 0)).toBe(1_234_567);
    // pay and check the ledger reconciles to the gateway amount
    const winner = resellers[results.findIndex((r) => r.status === 201)]!;
    const w = results.find((r) => r.status === 201)!;
    await pay(winner.cookie, w.body.paymentId).expect(200);
    const order = await c.prisma.order.findUniqueOrThrow({ where: { reference: w.body.orderRef } });
    expect(await ledgerSum("CASH_PROVIDER")).toBe(order.totalMinor);
    expect((await c.prisma.bundle.findUniqueOrThrow({ where: { id: bundle.id } })).state).toBe("SOLD");
  });

  it("bundles can be added and bought by verified resellers only (API gate)", async () => {
    const s = await f.seller();
    const { bundle } = await f.bundle({ sellerId: s.profile.id, categoryId: catId });
    const customer = await buyer();
    const r = await addToCart(customer.cookie, { bundleSlug: bundle.slug }).expect(403);
    expect(r.body.code).toBe("RESELLER_ONLY");
    await addToCart("", { bundleSlug: bundle.slug }).expect(403);
  });

  it("webhooks: bad signature rejected; replays processed once; a failure after capture is ignored", async () => {
    const s = await f.seller();
    const { listing } = await f.item({ sellerId: s.profile.id, categoryId: catId });
    const b = await buyer();
    await addToCart(b.cookie, { listingSlug: listing!.slug });
    const co = (await checkout(b.cookie)).body;
    const p = await c.prisma.payment.findUniqueOrThrow({ where: { id: co.paymentId } });
    const event = { eventId: "evt_1", type: "payment.succeeded", providerRef: p.providerRef, amountMinor: p.amountMinor };
    const raw = JSON.stringify(event);
    await c.http().post("/v1/webhooks/payments/sandbox").set("content-type", "application/json").set(SIG_HEADER, "deadbeef").send(raw).expect(400);
    const good = sign("test-webhook-secret", raw);
    await c.http().post("/v1/webhooks/payments/sandbox").set("content-type", "application/json").set(SIG_HEADER, good).send(raw).expect(200);
    const entries = await c.prisma.ledgerEntry.count();
    const replay = await c.http().post("/v1/webhooks/payments/sandbox").set("content-type", "application/json").set(SIG_HEADER, good).send(raw).expect(200);
    expect(replay.body.duplicate).toBe(true);
    expect(await c.prisma.ledgerEntry.count()).toBe(entries);
    const fail = JSON.stringify({ ...event, eventId: "evt_2", type: "payment.failed" });
    await c.http().post("/v1/webhooks/payments/sandbox").set("content-type", "application/json").set(SIG_HEADER, sign("test-webhook-secret", fail)).send(fail).expect(200);
    expect((await c.prisma.payment.findUniqueOrThrow({ where: { id: p.id } })).state).toBe("CAPTURED");
    expect(await c.prisma.paymentEvent.count()).toBe(2);
  });

  it("expired reservations release the item (and it can be bought again); a late payment is refunded, never fulfilled", async () => {
    const s = await f.seller();
    const { listing, item } = await f.item({ sellerId: s.profile.id, categoryId: catId });
    const b1 = await buyer();
    await addToCart(b1.cookie, { listingSlug: listing!.slug });
    const co = (await checkout(b1.cookie)).body;
    await c.prisma.stockReservation.updateMany({ data: { expiresAt: new Date(Date.now() - 1000) } });
    expect(await c.app.get(CheckoutService).expireReservations()).toBe(1);
    expect((await c.prisma.item.findUniqueOrThrow({ where: { id: item.id } })).stockState).toBe("AVAILABLE");
    expect((await c.prisma.order.findUniqueOrThrow({ where: { reference: co.orderRef } })).state).toBe("CANCELLED");
    // someone else can now buy it (voided line doesn't block the partial unique index)
    const b2 = await buyer();
    await addToCart(b2.cookie, { listingSlug: listing!.slug }).expect(201);
    const co2 = (await checkout(b2.cookie).expect(201)).body;
    await pay(b2.cookie, co2.paymentId).expect(200);
    // b1's money arrives late ⇒ auto refund, b1's order stays cancelled
    await pay(b1.cookie, co.paymentId).expect(200);
    const p1 = await c.prisma.payment.findUniqueOrThrow({ where: { id: co.paymentId }, include: { refunds: true } });
    expect(p1.refunds[0]?.mode).toBe("LATE_PAYMENT");
    expect(p1.state).toBe("REFUNDED");
    expect((await c.prisma.order.findUniqueOrThrow({ where: { reference: co.orderRef } })).state).toBe("CANCELLED");
    expect(await ledgerSum("REFUNDS_PAYABLE")).toBe(0);
  });

  it("seller fulfilment: mismatch blocks dispatch; complete pack → dispatch code → handover → delivered; double handover rejected", async () => {
    const s = await f.seller();
    const { listing } = await f.item({ sellerId: s.profile.id, categoryId: catId });
    const b = await buyer();
    await addToCart(b.cookie, { listingSlug: listing!.slug });
    const co = (await checkout(b.cookie)).body;
    await pay(b.cookie, co.paymentId);
    const list = await c.http().get("/v1/seller/orders").set("Cookie", s.cookie).expect(200);
    const groupId = list.body.orders[0].groupId;
    const detail = (await c.http().get(`/v1/seller/orders/${groupId}`).set("Cookie", s.cookie).expect(200)).body.group;
    expect(detail.shipTo.city).toBe("Karachi");
    await c.http().post(`/v1/seller/orders/${groupId}/dispatch`).set("Cookie", s.cookie).send({}).expect(409);
    const other = await f.seller();
    await c.http().get(`/v1/seller/orders/${groupId}`).set("Cookie", other.cookie).expect(404);
    const wrong = await c.http().post(`/v1/seller/orders/${groupId}/pack`).set("Cookie", s.cookie).send({ scans: ["1000000009991"] }).expect(200);
    expect(wrong.body.status).not.toBe("COMPLETE");
    const okPack = await c.http().post(`/v1/seller/orders/${groupId}/pack`).set("Cookie", s.cookie).send({ scans: detail.expectedCodes.map((x: string) => `OOAK1:${x}`) }).expect(200);
    expect(okPack.body.status).toBe("COMPLETE");
    const d = await c.http().post(`/v1/seller/orders/${groupId}/dispatch`).set("Cookie", s.cookie).send({}).expect(200);
    const code = d.body.shipments[0].code;
    expect(code[0]).toBe("4");
    await c.http().post("/v1/seller/orders/handover").set("Cookie", s.cookie).send({ code }).expect(200);
    await c.http().post("/v1/seller/orders/handover").set("Cookie", s.cookie).send({ code }).expect(409);
    const admin = await f.user(["ADMIN"]);
    await c.http().post(`/v1/sandbox/courier/${d.body.shipments[0].trackingNo}/advance`).set("Cookie", await f.login(admin.id)).send({ status: "DELIVERED" }).expect(200);
    const order = await c.http().get(`/v1/orders/${co.orderRef}`).set("Cookie", b.cookie).expect(200);
    expect(order.body.order.groups[0].items[0].stockState).toBe("DELIVERED");
    expect(order.body.order.groups[0].items[0].canClaim).toBe(true);
    expect(order.body.order.state).toBe("FULFILLED");
    expect(await c.prisma.scanEvent.count({ where: { action: "MISMATCH" } })).toBeGreaterThanOrEqual(1);
  });

  it("damage claims: photos required, within 48 h; approve → receive → refund reverses the seller's payable", async () => {
    const s = await f.seller();
    const { listing } = await f.item({ sellerId: s.profile.id, categoryId: catId, priceMinor: 400_000 });
    const b = await buyer();
    await addToCart(b.cookie, { listingSlug: listing!.slug });
    const co = (await checkout(b.cookie)).body;
    await pay(b.cookie, co.paymentId);
    const fs = c.app.get(FulfilmentService);
    const g = await c.prisma.fulfilmentGroup.findFirstOrThrow();
    const expected = await fs.expectedCodes(g.id, null);
    await fs.verifyPack(g.id, expected, { actorId: s.user.id, sellerId: s.profile.id });
    const d = await fs.dispatch(g.id, { actorId: s.user.id, sellerId: s.profile.id }, {});
    await fs.handover(d.shipments[0]!.code!, { actorId: s.user.id, sellerId: s.profile.id });
    const sh = await c.prisma.shipment.findFirstOrThrow();
    await c.prisma.$transaction((tx) => fs.moveShipment(tx, sh.id, "DELIVERED", { test: true }));
    const oi = await c.prisma.orderItem.findFirstOrThrow();
    const photo = await sharp({ create: { width: 400, height: 300, channels: 3, background: "#844" } }).jpeg().toBuffer();
    await c.http().post(`/v1/orders/${co.orderRef}/claims`).set("Cookie", b.cookie).field("orderItemId", oi.id).field("reason", "DAMAGED_IN_TRANSIT").field("description", "Seam torn along the back").expect(400);
    const claim = await c.http().post(`/v1/orders/${co.orderRef}/claims`).set("Cookie", b.cookie).field("orderItemId", oi.id).field("reason", "DAMAGED_IN_TRANSIT").field("description", "Seam torn along the back").attach("photos", photo, { filename: "d.jpg", contentType: "image/jpeg" }).expect(201);
    const payableBefore = -(await ledgerSum("SELLER_PAYABLE", s.profile.id));
    const { ReturnsService } = await import("../src/modules/commerce/returns.service");
    const rs = c.app.get(ReturnsService);
    const staff = await f.user(["SUPPORT"]);
    await rs.decide(staff.id, claim.body.id, { approve: true, note: "Photos show transit damage" });
    await rs.markInTransit(staff.id, claim.body.id);
    await rs.markReceived(staff.id, claim.body.id);
    const admin = await f.user(["ADMIN"]);
    await c.http().post("/v1/sandbox/refunds/flush").set("Cookie", await f.login(admin.id)).expect(200);
    const refund = await c.prisma.refund.findFirstOrThrow({ where: { returnId: claim.body.id } });
    expect(refund.state).toBe("SUCCEEDED");
    expect(refund.amountMinor).toBe(400_000);
    const payableAfter = -(await ledgerSum("SELLER_PAYABLE", s.profile.id));
    expect(payableBefore - payableAfter).toBe(352_000); // seller's share (88%) reversed for self-managed damage
    expect((await c.prisma.orderItem.findUniqueOrThrow({ where: { id: oi.id } })).voidedAt).not.toBeNull();
    // claims after the window are refused
    await c.prisma.fulfilmentGroup.update({ where: { id: g.id }, data: { deliveredAt: new Date(Date.now() - 49 * 3_600_000) } });
    const { ReturnsService: RS } = await import("../src/modules/commerce/returns.service");
    const el = await c.app.get(RS).eligibility(oi.id);
    expect(el.eligible).toBe(false);
  });

  it("guest cart merges into the account on login; customers can't reach seller orders", async () => {
    const s = await f.seller();
    const { listing } = await f.item({ sellerId: s.profile.id, categoryId: catId });
    const add = await c.http().post("/v1/cart/items").send({ listingSlug: listing!.slug }).expect(201);
    const guest = add.headers["set-cookie"]![0]!.split(";")[0]!;
    const b = await buyer();
    const merged = await c.http().get("/v1/cart").set("Cookie", `${guest}; ${b.cookie}`).expect(200);
    expect(merged.body.lines).toHaveLength(1);
    await c.http().get("/v1/seller/orders").set("Cookie", b.cookie).expect(403);
  });
});
