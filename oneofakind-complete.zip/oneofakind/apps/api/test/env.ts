import { tmpdir } from "node:os";
import { join } from "node:path";

process.env.NODE_ENV = "test";
process.env.DATABASE_URL = process.env.DATABASE_URL_TEST ?? "postgresql://ooak:ooak@localhost:5432/ooak_test?schema=public";
process.env.JOBS_ENABLED = "false";
process.env.OTP_DEV_ECHO = "true";
process.env.STORAGE_DRIVER = "local";
process.env.STORAGE_DIR = join(tmpdir(), "ooak-test-storage");
process.env.PAYMENT_WEBHOOK_SECRET = "test-webhook-secret";
process.env.COURIER_WEBHOOK_SECRET = "test-courier-secret";
