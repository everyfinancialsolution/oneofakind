import sharp from "sharp";
import { createHash } from "node:crypto";
import { StorageService } from "../src/common/storage.service";
import { LocalImageAdapter } from "../src/modules/ai/adapters";
import { AiService } from "../src/modules/ai/ai.service";
import { ListingService } from "../src/modules/seller/listing.service";
import { type Ctx, fx, makeApp, truncateAll } from "./helpers";

/** A dark "garment" on a plain light backdrop - what we ask sellers to shoot. */
const garmentPhoto = () => sharp({ create: { width: 600, height: 750, channels: 3, background: "#e9e4dc" } })
  .composite([{ input: Buffer.from('<svg width="600" height="750"><path d="M180 120h240l80 120-60 40v380H160V280l-60-40z" fill="#5a2a2a"/></svg>'), top: 0, left: 0 }]).jpeg().toBuffer();
const noisyPhoto = async () => {
  const raw = Buffer.alloc(300 * 300 * 3);
  for (let i = 0; i < raw.length; i++) raw[i] = (i * 7919) % 256;
  return sharp(raw, { raw: { width: 300, height: 300, channels: 3 } }).jpeg().toBuffer();
};
/** Minimal valid binary glTF 2.0 header + empty JSON chunk. */
const glb = () => {
  const json = Buffer.from('{"asset":{"version":"2.0"}}  ');
  const b = Buffer.alloc(12 + 8 + json.length);
  b.write("glTF", 0, "ascii"); b.writeUInt32LE(2, 4); b.writeUInt32LE(b.length, 8);
  b.writeUInt32LE(json.length, 12); b.write("JSON", 16, "ascii"); json.copy(b, 20);
  return b;
};

describe("AI studio and 3D", () => {
  let c: Ctx;
  let f: ReturnType<typeof fx>;
  let catId: string;
  beforeAll(async () => { c = await makeApp(); f = fx(c.prisma); });
  beforeEach(async () => {
    await truncateAll(c.prisma);
    catId = (await c.prisma.category.create({ data: { slug: "jackets", name: "Jackets & coats", attributeSchema: { measurements: ["chest_cm", "length_cm", "sleeve_cm"] } } })).id;
  });
  afterEach(() => jest.restoreAllMocks());
  afterAll(async () => c.app.close());

  async function sellerWithPhoto(photo: Buffer) {
    const s = await f.seller();
    const { item, listing } = await f.item({ sellerId: s.profile.id, categoryId: catId });
    const up = await c.http().post(`/v1/seller/listings/${item.id}/photos`).set("Cookie", s.cookie).attach("file", photo, { filename: "p.jpg", contentType: "image/jpeg" }).expect(201);
    return { s, item, listing: listing!, photoId: up.body.id as string };
  }

  it("background removal creates a separate, AI-labelled asset; the original is untouched; it goes public only if the seller uses it and moderation approves", async () => {
    const { s, item, listing, photoId } = await sellerWithPhoto(await garmentPhoto());
    const storage = c.app.get(StorageService);
    const original = await c.prisma.mediaAsset.findUniqueOrThrow({ where: { id: photoId } });
    const before = createHash("sha256").update((await storage.get(original.storageKey))!).digest("hex");
    const job = await c.http().post(`/v1/seller/studio/items/${item.id}/background`).set("Cookie", s.cookie).send({ assetId: photoId }).expect(201);
    expect(job.body.state).toBe("QUEUED");
    await c.http().post(`/v1/seller/studio/items/${item.id}/background`).set("Cookie", s.cookie).send({ assetId: photoId }).expect(409);
    expect(await c.app.get(AiService).processDue()).toBe(1);
    const done = await c.prisma.aiJob.findUniqueOrThrow({ where: { id: job.body.id } });
    expect(done.state).toBe("SUCCEEDED");
    expect(done.latencyMs).not.toBeNull();
    const gen = await c.prisma.mediaAsset.findUniqueOrThrow({ where: { id: (done.output as { assetId: string }).assetId } });
    expect(gen).toMatchObject({ kind: "BACKGROUND_REMOVED", aiLabel: true, sourceAssetId: photoId, aiJobId: done.id, useInListing: false, approvedForPublish: false });
    // the output really is a cut-out: corner = clean ivory backdrop, centre = the garment colour
    const { data, info } = await sharp((await storage.get(gen.storageKey))!).raw().toBuffer({ resolveWithObject: true });
    const at = (x: number, y: number) => Array.from(data.subarray((y * info.width + x) * info.channels, (y * info.width + x) * info.channels + 3));
    at(5, 5).forEach((v, i) => expect(Math.abs(v - [246, 243, 238][i]!)).toBeLessThan(6));
    at(info.width >> 1, Math.round(info.height * 0.6)).forEach((v, i) => expect(Math.abs(v - [0x5a, 0x2a, 0x2a][i]!)).toBeLessThan(20));
    const after = createHash("sha256").update((await storage.get(original.storageKey))!).digest("hex");
    expect(after).toBe(before);
    // private until published
    await c.http().get(`/v1/media/${gen.id}`).expect(404);
    await c.http().get(`/v1/media/${gen.id}`).set("Cookie", s.cookie).expect(200);
    // approval without selecting it: stays private
    const ls = c.app.get(ListingService);
    const admin = await f.user(["ADMIN"]);
    await c.prisma.listing.update({ where: { id: listing.id }, data: { state: "PENDING_REVIEW" } });
    await ls.approve(listing.id, admin.id);
    expect((await c.prisma.mediaAsset.findUniqueOrThrow({ where: { id: gen.id } })).approvedForPublish).toBe(false);
    // seller selects it → next approval publishes it with the AI label shown publicly
    await c.http().post(`/v1/seller/studio/assets/${gen.id}/use`).set("Cookie", s.cookie).send({ use: true }).expect(200);
    await c.prisma.listing.update({ where: { id: listing.id }, data: { state: "PENDING_REVIEW" } });
    await ls.approve(listing.id, admin.id);
    const pub = await c.http().get(`/v1/listings/${listing.slug}`).expect(200);
    const img = pub.body.item.images.find((i: { aiLabel: boolean }) => i.aiLabel);
    expect(img).toBeTruthy();
    expect(img.alt).toMatch(/AI-generated/);
    // DB guarantees generated assets carry the label
    await expect(c.prisma.mediaAsset.update({ where: { id: gen.id }, data: { aiLabel: false } })).rejects.toThrow();
  });

  it("refuses (no retry) when the background isn't plain; provider errors retry up to 3 times then fail", async () => {
    const { s, item, photoId } = await sellerWithPhoto(await noisyPhoto());
    const ai = c.app.get(AiService);
    const j1 = await c.http().post(`/v1/seller/studio/items/${item.id}/background`).set("Cookie", s.cookie).send({ assetId: photoId }).expect(201);
    await ai.processDue();
    const r1 = await c.prisma.aiJob.findUniqueOrThrow({ where: { id: j1.body.id } });
    expect(r1.state).toBe("FAILED");
    expect(r1.attempts).toBe(1);
    expect(r1.error).toMatch(/plain/);
    jest.spyOn(LocalImageAdapter.prototype, "removeBackground").mockRejectedValue(new Error("provider 503"));
    const j2 = await c.http().post(`/v1/seller/studio/items/${item.id}/background`).set("Cookie", s.cookie).send({ assetId: photoId }).expect(201);
    for (let i = 0; i < 3; i++) await ai.processDue();
    const r2 = await c.prisma.aiJob.findUniqueOrThrow({ where: { id: j2.body.id } });
    expect(r2.state).toBe("FAILED");
    expect(r2.attempts).toBe(3);
    expect(r2.error).toBe("The AI provider failed."); // internal detail not leaked
    expect(await c.prisma.mediaAsset.count({ where: { aiLabel: true } })).toBe(0);
    // admin can see and retry failures
    const admin = await f.user(["ADMIN"]); const ac = await f.login(admin.id);
    const ov = await c.http().get("/v1/admin/ai").set("Cookie", ac).expect(200);
    expect(ov.body.failures).toHaveLength(2);
    await c.http().get("/v1/admin/ai").set("Cookie", s.cookie).expect(403);
    jest.restoreAllMocks();
    await c.http().post(`/v1/admin/ai/jobs/${j2.body.id}/retry`).set("Cookie", ac).expect(200);
    expect((await c.prisma.aiJob.findUniqueOrThrow({ where: { id: j2.body.id } })).state).toBe("QUEUED");
  });

  it("listing text uses only facts on the listing and reports what is missing, never invents material or measurements", async () => {
    const s = await f.seller();
    const brand = await f.brand("Carhartt");
    const { item } = await f.item({ sellerId: s.profile.id, categoryId: catId, brandId: brand.id, color: "Brown", size: "L" });
    await c.prisma.item.update({ where: { id: item.id }, data: { material: null, measurements: { chest_cm: 60, length_cm: 72 } } });
    const j = await c.http().post(`/v1/seller/studio/items/${item.id}/text`).set("Cookie", s.cookie).expect(201);
    await c.app.get(AiService).processDue();
    const out = (await c.prisma.aiJob.findUniqueOrThrow({ where: { id: j.body.id } })).output as { title: string; description: string; missing: string[] };
    expect(out.title).toBe("Carhartt Brown Jacket, size L");
    expect(out.description).toContain("chest 60 cm");
    expect(out.description).not.toMatch(/cotton|wool|leather|polyester|genuine|authentic/i);
    expect(out.missing).toEqual(expect.arrayContaining(["measurement: sleeve", "material (check the care label)"]));
    const list = await c.http().get(`/v1/seller/studio/jobs?itemId=${item.id}`).set("Cookie", s.cookie).expect(200);
    expect(list.body.jobs[0].output.title).toBe(out.title);
  });

  it("access: other sellers' and managed pieces are refused; daily quota enforced", async () => {
    const s = await f.seller();
    const other = await f.seller();
    const { item } = await f.item({ sellerId: s.profile.id, categoryId: catId });
    const { item: managed } = await f.item({ sellerId: s.profile.id, categoryId: catId, arrangement: "MANAGED_RESALE" });
    await c.http().post(`/v1/seller/studio/items/${item.id}/text`).set("Cookie", other.cookie).expect(404);
    await c.http().post(`/v1/seller/studio/items/${managed.id}/text`).set("Cookie", s.cookie).expect(409);
    const cust = await f.user(); await c.http().post(`/v1/seller/studio/items/${item.id}/text`).set("Cookie", await f.login(cust.id)).expect(403);
    await c.prisma.aiJob.createMany({ data: Array.from({ length: 40 }, () => ({ userId: s.user.id, kind: "LISTING_TEXT" as const, provider: "template", input: { itemId: item.id }, state: "SUCCEEDED" as const })) });
    const r = await c.http().post(`/v1/seller/studio/items/${item.id}/text`).set("Cookie", s.cookie).expect(429);
    expect(r.body.code).toBe("AI_QUOTA");
  });

  it("3D model: only valid .glb accepted; private until approval; then served on the product page; replacing keeps one model", async () => {
    const s = await f.seller();
    const { item, listing } = await f.item({ sellerId: s.profile.id, categoryId: catId });
    await c.http().post(`/v1/seller/studio/items/${item.id}/model3d`).set("Cookie", s.cookie).attach("file", Buffer.from("not a model at all, sorry"), { filename: "x.glb" }).expect(400);
    const up = await c.http().post(`/v1/seller/studio/items/${item.id}/model3d`).set("Cookie", s.cookie).attach("file", glb(), { filename: "m.glb" }).expect(201);
    await c.http().get(`/v1/media/${up.body.id}`).expect(404);
    expect((await c.http().get(`/v1/listings/${listing!.slug}`).expect(200)).body.item.model3d).toBeNull();
    await c.prisma.listing.update({ where: { id: listing!.id }, data: { state: "PENDING_REVIEW" } });
    await c.app.get(ListingService).approve(listing!.id, (await f.user(["ADMIN"])).id);
    const pub = await c.http().get(`/v1/listings/${listing!.slug}`).expect(200);
    expect(pub.body.item.model3d.url).toContain(up.body.id);
    const file = await c.http().get(`/v1/media/${up.body.id}`).expect(200);
    expect(file.headers["content-type"]).toContain("model/gltf-binary");
    await c.http().post(`/v1/seller/studio/items/${item.id}/model3d`).set("Cookie", s.cookie).attach("file", glb(), { filename: "m2.glb" }).expect(201);
    expect(await c.prisma.mediaAsset.count({ where: { itemId: item.id, kind: "ASSET_3D", deletedAt: null } })).toBe(1);
  });
});
