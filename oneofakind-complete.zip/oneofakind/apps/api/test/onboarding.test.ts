import { OnboardingService } from "../src/modules/onboarding/onboarding.service";
import { type Ctx, fx, makeApp, truncateAll } from "./helpers";

const JPEG = Buffer.concat([Buffer.from([0xff, 0xd8, 0xff, 0xe0]), Buffer.alloc(64, 1)]);

describe("onboarding (self-serve and staff-assisted)", () => {
  let c: Ctx;
  let f: ReturnType<typeof fx>;
  beforeAll(async () => { c = await makeApp(); f = fx(c.prisma); });
  beforeEach(async () => truncateAll(c.prisma));
  afterAll(async () => c.app.close());

  const upload = (cookie: string, path: string, kind: string, buf = JPEG) =>
    c.http().post(path).set("Cookie", cookie).field("kind", kind).attach("file", buf, { filename: "doc.jpg", contentType: "image/jpeg" });

  it("self-serve seller: create, upload required documents, submit; missing docs are reported in plain words", async () => {
    const u = await f.user();
    const cookie = await f.login(u.id);
    const app = (await c.http().post("/v1/onboarding/applications").set("Cookie", cookie).send({ kind: "SELLER" }).expect(201)).body;
    expect(app.reference).toMatch(/^OOAK-S-\d{6}$/);
    expect(app.missing).toEqual(["ID_FRONT", "ID_BACK", "PAYOUT_ACCOUNT_PROOF"]);
    await upload(cookie, `/v1/onboarding/applications/${app.reference}/documents`, "ID_FRONT").expect(201);
    const early = await c.http().post(`/v1/onboarding/applications/${app.reference}/submit`).set("Cookie", cookie).expect(409);
    expect(early.body.code).toBe("DOCUMENTS_MISSING");
    await upload(cookie, `/v1/onboarding/applications/${app.reference}/documents`, "ID_BACK").expect(201);
    await upload(cookie, `/v1/onboarding/applications/${app.reference}/documents`, "PAYOUT_ACCOUNT_PROOF").expect(201);
    const sub = await c.http().post(`/v1/onboarding/applications/${app.reference}/submit`).set("Cookie", cookie).expect(200);
    expect(sub.body.status).toBe("SUBMITTED");
    // the same open application is returned on a second start
    const again = await c.http().post("/v1/onboarding/applications").set("Cookie", cookie).send({ kind: "SELLER" }).expect(201);
    expect(again.body.reference).toBe(app.reference);
  });

  it("rejects non-image uploads by sniffing content, not the declared type", async () => {
    const u = await f.user();
    const cookie = await f.login(u.id);
    const app = (await c.http().post("/v1/onboarding/applications").set("Cookie", cookie).send({ kind: "RESELLER" })).body;
    const r = await upload(cookie, `/v1/onboarding/applications/${app.reference}/documents`, "ID_FRONT", Buffer.from("<script>alert(1)</script>")).expect(400);
    expect(r.body.code).toBe("UNSUPPORTED_FILE");
  });

  it("WhatsApp button creates a reference and a prefilled wa.me link (no personal data needed)", async () => {
    const r = await c.http().post("/v1/onboarding/whatsapp-reference").send({ kind: "SELLER" }).expect(200);
    expect(r.body.reference).toMatch(/^OOAK-S-/);
    expect(r.body.link).toContain("https://wa.me/447513875488?text=");
    expect(decodeURIComponent(r.body.link)).toContain(r.body.reference);
  });

  it("staff-assisted: cannot submit without recorded consent; approval creates an unactivated seller who activates with their own OTP", async () => {
    const agent = await f.user(["SELLER_AGENT"]);
    const cookie = await f.login(agent.id);
    const created = await c.http().post("/v1/admin/onboarding").set("Cookie", cookie).send({ kind: "SELLER", channel: "ASSISTED_WHATSAPP", fullName: "Rukhsana Bibi", phone: "0304 1234567", city: "Gujranwala" }).expect(201);
    const ref = created.body.reference;
    for (const k of ["ID_FRONT", "ID_BACK", "PAYOUT_ACCOUNT_PROOF"]) await upload(cookie, `/v1/admin/onboarding/${ref}/documents`, k).expect(201);
    const noConsent = await c.http().post(`/v1/admin/onboarding/${ref}/submit`).set("Cookie", cookie).expect(409);
    expect(noConsent.body.code).toBe("CONSENT_REQUIRED");
    await c.http().post(`/v1/admin/onboarding/${ref}/consent-evidence`).set("Cookie", cookie).field("method", "WHATSAPP_MESSAGE").attach("file", JPEG, { filename: "c.jpg", contentType: "image/jpeg" }).expect(201);
    await c.http().post(`/v1/admin/onboarding/${ref}/submit`).set("Cookie", cookie).expect(200);
    await c.http().post(`/v1/admin/onboarding/${ref}/approve`).set("Cookie", cookie).send({ cnicLast4: "4321", allowStaffListing: true }).expect(200);

    const user = await c.prisma.user.findUniqueOrThrow({ where: { phone: "+923041234567" }, include: { sellerProfile: true } });
    expect(user.activatedAt).toBeNull();
    expect(user.createdByStaffId).toBe(agent.id);
    expect(user.roles).toContain("SELLER");
    expect(user.sellerProfile?.status).toBe("VERIFIED");
    expect(user.sellerProfile?.cnicLast4).toBe("4321");
    expect(user.sellerProfile?.allowStaffListing).toBe(true);
    const docs = await c.prisma.onboardingDocument.findMany({ where: { application: { reference: ref } } });
    for (const d of docs) expect(d.deleteAfter!.getTime() - Date.now()).toBeGreaterThan(89 * 86_400_000);
    expect(await c.prisma.notification.count({ where: { template: "APPLICATION_APPROVED", body: { contains: "/activate/" } } })).toBe(1);
    // Activation: the person's own OTP + terms
    const otp = (await c.http().post("/v1/auth/otp/request").send({ phone: "03041234567" })).body;
    expect(otp.needsActivation).toBe(true);
    await c.http().post("/v1/auth/otp/verify").send({ phone: "03041234567", code: otp.devCode, acceptTerms: true }).expect(200);
  });

  it("documents are readable only by onboarding/support/admin, and every read is logged", async () => {
    const applicant = await f.user();
    const ac = await f.login(applicant.id);
    const app = (await c.http().post("/v1/onboarding/applications").set("Cookie", ac).send({ kind: "RESELLER" })).body;
    await upload(ac, `/v1/onboarding/applications/${app.reference}/documents`, "ID_FRONT").expect(201);
    const doc = await c.prisma.onboardingDocument.findFirstOrThrow();
    await c.http().get(`/v1/admin/onboarding/documents/${doc.id}`).set("Cookie", ac).expect(403);
    const finance = await f.user(["FINANCE"]);
    await c.http().get(`/v1/admin/onboarding/documents/${doc.id}`).set("Cookie", await f.login(finance.id)).expect(403);
    const mod = await f.user(["MODERATOR"]);
    await c.http().get(`/v1/admin/onboarding/documents/${doc.id}`).set("Cookie", await f.login(mod.id)).expect(403);
    const support = await f.user(["SUPPORT"]);
    const r = await c.http().get(`/v1/admin/onboarding/documents/${doc.id}`).set("Cookie", await f.login(support.id)).expect(200);
    expect(r.headers["cache-control"]).toContain("no-store");
    expect(await c.prisma.auditLog.count({ where: { action: "DOCUMENT_VIEWED", entityId: doc.id, actorId: support.id } })).toBe(1);
  });

  it("reseller approval grants VERIFIED_RESELLER; rejection needs a reason", async () => {
    const applicant = await f.user();
    const ac = await f.login(applicant.id);
    const app = (await c.http().post("/v1/onboarding/applications").set("Cookie", ac).send({ kind: "RESELLER" })).body;
    for (const k of ["ID_FRONT", "ID_BACK", "SHOP_PROOF"]) await upload(ac, `/v1/onboarding/applications/${app.reference}/documents`, k);
    await c.http().post(`/v1/onboarding/applications/${app.reference}/submit`).set("Cookie", ac).expect(200);
    const admin = await f.user(["ADMIN"]);
    const adc = await f.login(admin.id);
    await c.http().post(`/v1/admin/onboarding/${app.reference}/reject`).set("Cookie", adc).send({ reason: "no" }).expect(400);
    await c.http().post(`/v1/admin/onboarding/${app.reference}/approve`).set("Cookie", adc).send({}).expect(200);
    const u = await c.prisma.user.findUniqueOrThrow({ where: { id: applicant.id }, include: { resellerVerification: true } });
    expect(u.roles).toContain("VERIFIED_RESELLER");
    expect(u.resellerVerification?.status).toBe("VERIFIED");
  });

  it("retention job deletes document files after deleteAfter and keeps the record", async () => {
    const applicant = await f.user();
    const ac = await f.login(applicant.id);
    const app = (await c.http().post("/v1/onboarding/applications").set("Cookie", ac).send({ kind: "RESELLER" })).body;
    await upload(ac, `/v1/onboarding/applications/${app.reference}/documents`, "ID_FRONT");
    const doc = await c.prisma.onboardingDocument.findFirstOrThrow();
    await c.prisma.onboardingDocument.update({ where: { id: doc.id }, data: { deleteAfter: new Date(Date.now() - 1000) } });
    const r = await c.app.get(OnboardingService).purgeExpiredDocuments();
    expect(r.documentsDeleted).toBe(1);
    const after = await c.prisma.onboardingDocument.findUniqueOrThrow({ where: { id: doc.id } });
    expect(after.deletedAt).not.toBeNull();
    const support = await f.user(["SUPPORT"]);
    await c.http().get(`/v1/admin/onboarding/documents/${doc.id}`).set("Cookie", await f.login(support.id)).expect(404);
  });

  it("customers cannot reach the staff onboarding queue", async () => {
    const u = await f.user();
    await c.http().get("/v1/admin/onboarding").set("Cookie", await f.login(u.id)).expect(403);
    await c.http().get("/v1/admin/onboarding").expect(401);
  });
});
