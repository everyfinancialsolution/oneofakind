import { randomUUID } from "node:crypto";
import { FulfilmentService } from "../src/modules/commerce/fulfilment.service";
import { type Ctx, fx, makeApp, truncateAll } from "./helpers";

const ADDRESS = { recipient: "Fatima Noor", phone: "0300 1234567", line1: "House 12, Street 4, DHA", city: "Karachi" };

describe("admin: roles, moderation, support cancel, finance statements & payouts", () => {
  let c: Ctx;
  let f: ReturnType<typeof fx>;
  let catId: string;
  beforeAll(async () => { c = await makeApp(); f = fx(c.prisma); });
  beforeEach(async () => {
    await truncateAll(c.prisma);
    catId = (await f.category("jackets")).id;
    await c.prisma.setting.create({ data: { key: "shipping.flatRates", value: { LOCAL: 25_000, NATIONAL: 35_000, localCities: ["Lahore"] } } });
  });
  afterAll(async () => c.app.close());

  const staff = async (...roles: Array<"ADMIN" | "SUPPORT" | "FINANCE" | "MODERATOR" | "WAREHOUSE">) => { const u = await f.user(roles); return { user: u, cookie: await f.login(u.id) }; };

  /** Buyer purchases a seller's item and pays; returns order ref + group. */
  async function paidOrder(sellerId: string, priceMinor = 500_000) {
    const { listing, item } = await f.item({ sellerId, categoryId: catId, priceMinor });
    const u = await f.user(); const cookie = await f.login(u.id);
    await c.http().post("/v1/cart/items").set("Cookie", cookie).send({ listingSlug: listing!.slug }).expect(201);
    const co = (await c.http().post("/v1/checkout").set("Cookie", cookie).set("Idempotency-Key", randomUUID()).send({ address: ADDRESS, paymentMethod: "CARD", acceptTerms: true }).expect(201)).body;
    await c.http().post(`/v1/sandbox/payments/${co.paymentId}/complete`).set("Cookie", cookie).send({ outcome: "success" }).expect(200);
    const order = await c.prisma.order.findUniqueOrThrow({ where: { reference: co.orderRef }, include: { groups: true } });
    return { orderRef: co.orderRef as string, group: order.groups[0]!, item, listing: listing! };
  }

  async function deliver(groupId: string, sellerUserId: string, sellerId: string, daysAgo: number) {
    const fs = c.app.get(FulfilmentService);
    const actor = { actorId: sellerUserId, sellerId };
    await fs.verifyPack(groupId, await fs.expectedCodes(groupId, null), actor);
    const d = await fs.dispatch(groupId, actor, {});
    await fs.handover(d.shipments[0]!.code!, actor);
    const sh = await c.prisma.shipment.findFirstOrThrow({ where: { groupId } });
    await c.prisma.$transaction((tx) => fs.moveShipment(tx, sh.id, "DELIVERED", { test: true }));
    await c.prisma.fulfilmentGroup.update({ where: { id: groupId }, data: { deliveredAt: new Date(Date.now() - daysAgo * 86_400_000) } });
  }

  it("role grants: ADMIN only, audited, no self-demotion; revoking VERIFIED_RESELLER revokes the verification", async () => {
    const admin = await staff("ADMIN");
    const mod = await staff("MODERATOR");
    const target = await f.user(["CUSTOMER", "VERIFIED_RESELLER"]);
    await c.prisma.resellerVerification.create({ data: { userId: target.id, status: "VERIFIED", businessName: "Shop", shopType: "ONLINE" } });
    await c.http().post(`/v1/admin/users/${target.id}/roles`).set("Cookie", mod.cookie).send({ add: ["SELLER_AGENT"] }).expect(403);
    const r = await c.http().post(`/v1/admin/users/${target.id}/roles`).set("Cookie", admin.cookie).send({ add: ["SELLER_AGENT"], remove: ["VERIFIED_RESELLER"] }).expect(200);
    expect(r.body.roles).toEqual(expect.arrayContaining(["CUSTOMER", "SELLER_AGENT"]));
    expect(r.body.roles).not.toContain("VERIFIED_RESELLER");
    expect((await c.prisma.resellerVerification.findUniqueOrThrow({ where: { userId: target.id } })).status).toBe("REVOKED");
    await c.http().post(`/v1/admin/users/${admin.user.id}/roles`).set("Cookie", admin.cookie).send({ remove: ["ADMIN"] }).expect(400);
    expect(await c.prisma.auditLog.count({ where: { action: "ROLES_CHANGED", entityId: target.id } })).toBe(1);
    // disabling revokes sessions
    const tc = await f.login(target.id);
    await c.http().get("/v1/support/tickets").set("Cookie", tc).expect(200);
    await c.http().post(`/v1/admin/users/${target.id}/disable`).set("Cookie", admin.cookie).send({ disabled: true, reason: "Fraud review" }).expect(200);
    expect(await c.prisma.session.count({ where: { userId: target.id, revokedAt: null } })).toBe(0);
    await c.http().get("/v1/support/tickets").set("Cookie", tc).expect(401);
    // customers can't reach admin at all
    const cust = await f.user(); await c.http().get("/v1/admin/dashboard").set("Cookie", await f.login(cust.id)).expect(403);
    await c.http().get("/v1/admin/dashboard").set("Cookie", admin.cookie).expect(200);
  });

  it("moderation: pending listing → changes requested → approve; reports → upheld removes listing → seller appeals", async () => {
    const s = await f.seller();
    const mod = await staff("MODERATOR");
    const { listing } = await f.item({ sellerId: s.profile.id, categoryId: catId });
    await c.prisma.listing.update({ where: { id: listing!.id }, data: { state: "PENDING_REVIEW", publishedAt: null } });
    const q = await c.http().get("/v1/admin/moderation/listings").set("Cookie", mod.cookie).expect(200);
    expect(q.body.listings.map((l: { id: string }) => l.id)).toContain(listing!.id);
    await c.http().post(`/v1/admin/moderation/listings/${listing!.id}/changes`).set("Cookie", mod.cookie).send({ note: "x" }).expect(400);
    await c.http().post(`/v1/admin/moderation/listings/${listing!.id}/changes`).set("Cookie", mod.cookie).send({ note: "Add a photo of the label" }).expect(200);
    expect((await c.prisma.listing.findUniqueOrThrow({ where: { id: listing!.id } })).state).toBe("CHANGES_REQUESTED");
    await c.prisma.listing.update({ where: { id: listing!.id }, data: { state: "PENDING_REVIEW" } });
    await c.http().post(`/v1/admin/moderation/listings/${listing!.id}/approve`).set("Cookie", mod.cookie).expect(200);
    expect((await c.prisma.listing.findUniqueOrThrow({ where: { id: listing!.id } })).state).toBe("PUBLISHED");

    const reporter = await f.user();
    const rep = await c.http().post("/v1/reports").set("Cookie", await f.login(reporter.id)).send({ listingSlug: listing!.slug, reason: "COUNTERFEIT", details: "Logo wrong" }).expect(201);
    await c.http().post(`/v1/seller/reports/${rep.body.id}/appeal`).set("Cookie", s.cookie).send({ note: "This is genuine, receipt attached" }).expect(409);
    await c.http().post(`/v1/admin/moderation/reports/${rep.body.id}/resolve`).set("Cookie", mod.cookie).send({ action: "REMOVE_LISTING", note: "Confirmed counterfeit" }).expect(200);
    expect((await c.prisma.listing.findUniqueOrThrow({ where: { id: listing!.id } })).state).toBe("REMOVED");
    const other = await f.seller();
    await c.http().post(`/v1/seller/reports/${rep.body.id}/appeal`).set("Cookie", other.cookie).send({ note: "Not mine but trying anyway" }).expect(404);
    await c.http().post(`/v1/seller/reports/${rep.body.id}/appeal`).set("Cookie", s.cookie).send({ note: "This is genuine, receipt attached" }).expect(200);
    const mine = await c.http().get("/v1/seller/reports").set("Cookie", s.cookie).expect(200);
    expect(mine.body.reports[0].state).toBe("APPEALED");
  });

  it("support cancel: paid group before dispatch → line + shipping refunded, item back on sale, ledger fully reversed", async () => {
    const s = await f.seller();
    const sup = await staff("SUPPORT");
    const { group, item, listing } = await paidOrder(s.profile.id);
    const fin = await staff("FINANCE");
    await c.http().post(`/v1/admin/groups/${group.id}/cancel`).set("Cookie", fin.cookie).send({ reason: "Seller cannot ship" }).expect(403);
    const r = await c.http().post(`/v1/admin/groups/${group.id}/cancel`).set("Cookie", sup.cookie).send({ reason: "Seller cannot ship" }).expect(200);
    expect(r.body.refunds).toBe(2);
    await c.http().post("/v1/sandbox/refunds/flush").set("Cookie", (await staff("ADMIN")).cookie).expect(200);
    expect(await c.prisma.refund.count({ where: { state: "SUCCEEDED" } })).toBe(2);
    expect((await c.prisma.item.findUniqueOrThrow({ where: { id: item.id } })).stockState).toBe("AVAILABLE");
    expect((await c.prisma.listing.findUniqueOrThrow({ where: { id: listing.id } })).state).toBe("PUBLISHED");
    await c.http().post(`/v1/admin/groups/${group.id}/cancel`).set("Cookie", sup.cookie).send({ reason: "Seller cannot ship" }).expect(409);
    const rec = (await c.http().get("/v1/admin/finance/reconciliation").set("Cookie", fin.cookie).expect(200)).body;
    expect(rec.differenceMinor).toBe(0);
    expect(rec.gatewayNetMinor).toBe(0);
    const payable = rec.accounts.find((a: { type: string; ownerRef: string }) => a.type === "SELLER_PAYABLE" && a.ownerRef === s.profile.id);
    expect(payable).toBeUndefined(); // balance back to zero
  });

  it("finance: statements only include lines delivered ≥7 days with no open claim; PAID needs own-name verification + minimum; never settled twice", async () => {
    const s = await f.seller({ payoutVerified: false });
    const fin = await staff("FINANCE");
    const old = await paidOrder(s.profile.id, 500_000);
    await deliver(old.group.id, s.user.id, s.profile.id, 10);
    const recent = await paidOrder(s.profile.id, 300_000);
    await deliver(recent.group.id, s.user.id, s.profile.id, 2);
    const periodStart = new Date(Date.now() - 30 * 86_400_000).toISOString();
    const periodEnd = new Date().toISOString();
    const gen = await c.http().post("/v1/admin/finance/statements/generate").set("Cookie", fin.cookie).send({ periodStart, periodEnd }).expect(200);
    expect(gen.body.created).toBe(1);
    const st = (await c.http().get(`/v1/admin/finance/statements/${gen.body.ids[0]}`).set("Cookie", fin.cookie).expect(200)).body.statement;
    expect(st.lines).toHaveLength(1);
    expect(st.grossMinor).toBe(500_000);
    expect(st.netMinor).toBe(440_000); // 12% commission
    const csv = await c.http().get(`/v1/admin/finance/statements/${st.id}?format=csv`).set("Cookie", fin.cookie).expect(200);
    expect(csv.headers["content-type"]).toMatch(/text\/csv/);
    expect(csv.text.split("\n")[1]).toContain("4400");
    // regenerating a different period never re-settles the same line
    const again = await c.http().post("/v1/admin/finance/statements/generate").set("Cookie", fin.cookie).send({ periodStart, periodEnd: new Date(Date.now() + 1000).toISOString() }).expect(200);
    expect(again.body.created).toBe(0);
    await c.http().post(`/v1/admin/finance/statements/${st.id}/paid`).set("Cookie", fin.cookie).send({ payoutRef: "IBFT-001" }).expect(409);
    await c.http().post(`/v1/admin/finance/statements/${st.id}/finalize`).set("Cookie", fin.cookie).expect(200);
    const blocked = await c.http().post(`/v1/admin/finance/statements/${st.id}/paid`).set("Cookie", fin.cookie).send({ payoutRef: "IBFT-001" }).expect(409);
    expect(blocked.body.code).toBe("PAYOUT_NOT_VERIFIED");
    // verification queue compares the ID name with the account title
    const queue = (await c.http().get("/v1/admin/finance/payout-verifications").set("Cookie", fin.cookie).expect(200)).body.sellers;
    expect(queue.find((x: { sellerId: string }) => x.sellerId === s.profile.id)).toBeTruthy();
    const sup = await staff("SUPPORT");
    await c.http().post(`/v1/admin/finance/payout-verifications/${s.profile.id}`).set("Cookie", sup.cookie).send({ approve: true }).expect(403);
    await c.http().post(`/v1/admin/finance/payout-verifications/${s.profile.id}`).set("Cookie", fin.cookie).send({ approve: true }).expect(200);
    await c.http().post(`/v1/admin/finance/statements/${st.id}/paid`).set("Cookie", fin.cookie).send({ payoutRef: "IBFT-001" }).expect(200);
    await c.http().post(`/v1/admin/finance/statements/${st.id}/paid`).set("Cookie", fin.cookie).send({ payoutRef: "IBFT-001" }).expect(409);
    const paid = await c.prisma.sellerStatement.findUniqueOrThrow({ where: { id: st.id } });
    expect(paid.state).toBe("PAID");
    // ledger: payable for the paid line cleared, the recent line still owed
    const acct = await c.prisma.ledgerAccount.findFirstOrThrow({ where: { type: "SELLER_PAYABLE", ownerRef: s.profile.id } });
    const agg = await c.prisma.ledgerEntry.aggregate({ where: { accountId: acct.id }, _sum: { debitMinor: true, creditMinor: true } });
    expect((agg._sum.creditMinor ?? 0) - (agg._sum.debitMinor ?? 0)).toBe(264_000);
    const all = await c.prisma.ledgerEntry.aggregate({ _sum: { debitMinor: true, creditMinor: true } });
    expect(all._sum.debitMinor).toBe(all._sum.creditMinor);
    expect(await c.prisma.auditLog.count({ where: { action: "STATEMENT_PAID" } })).toBe(1);
  });

  it("settings and bundle tiers: finance can change settings, only admin changes tiers; CMS blocks publish to the public content API", async () => {
    const admin = await staff("ADMIN");
    const fin = await staff("FINANCE");
    await c.http().put("/v1/admin/settings/shipping.flatRates").set("Cookie", fin.cookie).send({ value: { LOCAL: 20_000, NATIONAL: 30_000, localCities: ["Lahore"] } }).expect(200);
    await c.http().put("/v1/admin/bundle-tiers/10").set("Cookie", fin.cookie).send({ minPriceMinor: 900_000 }).expect(403);
    await c.http().put("/v1/admin/bundle-tiers/10").set("Cookie", admin.cookie).send({ minPriceMinor: 900_000 }).expect(200);
    await c.http().put("/v1/admin/bundle-tiers/7").set("Cookie", admin.cookie).send({ minPriceMinor: 900_000 }).expect(400);
    await c.http().put("/v1/admin/catalog/cms/home.hero").set("Cookie", admin.cookie).send({ title: "Autumn drop", body: "Fresh vintage outerwear", published: true }).expect(200);
    expect(await c.prisma.auditLog.count({ where: { actorId: admin.user.id } })).toBeGreaterThanOrEqual(2);
  });
});
