import { execSync } from "node:child_process";
import { join } from "node:path";

/** Apply migrations (incl. integrity SQL) to the dedicated integration-test database. Non-destructive; tests truncate between cases. */
export default async function globalSetup() {
  const url = process.env.DATABASE_URL_TEST ?? "postgresql://ooak:ooak@localhost:5432/ooak_test?schema=public";
  execSync(`npx prisma migrate deploy --schema ${join(__dirname, "..", "prisma", "schema.prisma")}`, {
    env: { ...process.env, DATABASE_URL: url, CHECKPOINT_DISABLE: "1", PRISMA_HIDE_UPDATE_MESSAGE: "1" }, stdio: "pipe",
  });
}
