import { type Ctx, fx, makeApp, truncateAll } from "./helpers";

/** Database-level rules from the integrity migration (defence in depth behind the services). */
describe("database integrity rules", () => {
  let c: Ctx;
  let f: ReturnType<typeof fx>;
  beforeAll(async () => { c = await makeApp(); f = fx(c.prisma); });
  beforeEach(async () => truncateAll(c.prisma));
  afterAll(async () => c.app.close());

  it("rejects an unbalanced ledger transaction at commit and accepts a balanced one", async () => {
    const a = await c.prisma.ledgerAccount.create({ data: { type: "CASH_PROVIDER" } });
    const b = await c.prisma.ledgerAccount.create({ data: { type: "PLATFORM_REVENUE" } });
    await expect(c.prisma.$transaction([
      c.prisma.ledgerEntry.create({ data: { txnId: "t1", accountId: a.id, debitMinor: 100, refType: "TEST", refId: "1" } }),
      c.prisma.ledgerEntry.create({ data: { txnId: "t1", accountId: b.id, creditMinor: 90, refType: "TEST", refId: "1" } }),
    ])).rejects.toThrow(/unbalanced/);
    await c.prisma.$transaction([
      c.prisma.ledgerEntry.create({ data: { txnId: "t2", accountId: a.id, debitMinor: 100, refType: "TEST", refId: "1" } }),
      c.prisma.ledgerEntry.create({ data: { txnId: "t2", accountId: b.id, creditMinor: 100, refType: "TEST", refId: "1" } }),
    ]);
    expect(await c.prisma.ledgerEntry.count()).toBe(2);
  });

  it("ledger entries, audit logs and scan events are append-only", async () => {
    const a = await c.prisma.ledgerAccount.create({ data: { type: "CASH_PROVIDER" } });
    const b = await c.prisma.ledgerAccount.create({ data: { type: "PLATFORM_REVENUE" } });
    await c.prisma.$transaction([
      c.prisma.ledgerEntry.create({ data: { txnId: "t", accountId: a.id, debitMinor: 5, refType: "TEST", refId: "1" } }),
      c.prisma.ledgerEntry.create({ data: { txnId: "t", accountId: b.id, creditMinor: 5, refType: "TEST", refId: "1" } }),
    ]);
    await expect(c.prisma.ledgerEntry.updateMany({ data: { memo: "x" } })).rejects.toThrow(/append-only/);
    await expect(c.prisma.ledgerEntry.deleteMany({})).rejects.toThrow(/append-only/);
    await c.prisma.auditLog.create({ data: { action: "X", entity: "Y", entityId: "1" } });
    await expect(c.prisma.auditLog.deleteMany({})).rejects.toThrow(/append-only/);
  });

  it("an item can hold only one active reservation and be in only one active bundle", async () => {
    const s = await f.seller();
    const cat = await f.category();
    const { item } = await f.item({ sellerId: s.profile.id, categoryId: cat.id, publish: false, channel: "BUNDLE" });
    await c.prisma.stockReservation.create({ data: { itemId: item.id, expiresAt: new Date(Date.now() + 60_000) } });
    await expect(c.prisma.stockReservation.create({ data: { itemId: item.id, expiresAt: new Date(Date.now() + 60_000) } })).rejects.toThrow();
    const b1 = await f.bundle({ sellerId: s.profile.id, categoryId: cat.id });
    await expect(c.prisma.bundleItem.create({ data: { bundleId: b1.bundle.id, itemId: b1.pieces[0]!.id, refRetailMinor: 1 } })).rejects.toThrow();
  });

  it("a piece with a published retail listing cannot join a bundle", async () => {
    const s = await f.seller();
    const cat = await f.category();
    const { item } = await f.item({ sellerId: s.profile.id, categoryId: cat.id });
    const b = await f.bundle({ sellerId: s.profile.id, categoryId: cat.id });
    await expect(c.prisma.bundleItem.create({ data: { bundleId: b.bundle.id, itemId: item.id, refRetailMinor: 1 } })).rejects.toThrow(/published retail listing/);
  });

  it("publishing a bundle whose piece count differs from its size is refused by the database", async () => {
    const s = await f.seller();
    const cat = await f.category();
    const b = await f.bundle({ sellerId: s.profile.id, categoryId: cat.id, size: 5 });
    await c.prisma.bundle.update({ where: { id: b.bundle.id }, data: { state: "PAUSED" } });
    await c.prisma.bundleItem.updateMany({ where: { bundleId: b.bundle.id, itemId: b.pieces[0]!.id }, data: { releasedAt: new Date() } });
    await expect(c.prisma.bundle.update({ where: { id: b.bundle.id }, data: { state: "PUBLISHED" } })).rejects.toThrow(/active pieces/);
  });

  it("money columns cannot go negative and a cart line is item XOR bundle", async () => {
    const s = await f.seller();
    const cat = await f.category();
    await expect(f.item({ sellerId: s.profile.id, categoryId: cat.id, priceMinor: -1 })).rejects.toThrow();
    const cart = await c.prisma.cart.create({ data: {} });
    await expect(c.prisma.cartItem.create({ data: { cartId: cart.id } })).rejects.toThrow();
  });
});
