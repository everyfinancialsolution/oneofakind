import sharp from "sharp";
import { ListingService } from "../src/modules/seller/listing.service";
import { CodesService } from "../src/modules/codes/codes.service";
import { assertLabelSafe } from "../src/modules/codes/labels";
import { StorageService } from "../src/common/storage.service";
import { type Ctx, fx, makeApp, truncateAll } from "./helpers";

async function jpegWithGps() {
  return sharp({ create: { width: 1200, height: 900, channels: 3, background: "#7a6234" } }).jpeg()
    .withExif({ IFD0: { Make: "TestPhone" }, IFD3: { GPSLatitudeRef: "N", GPSLatitude: "31/1 30/1 0/1" } }).toBuffer();
}

describe("seller portal", () => {
  let c: Ctx;
  let f: ReturnType<typeof fx>;
  let catId: string;
  beforeAll(async () => { c = await makeApp(); f = fx(c.prisma); });
  beforeEach(async () => {
    await truncateAll(c.prisma);
    catId = (await c.prisma.category.create({ data: { slug: "jackets", name: "Jackets", attributeSchema: { measurements: ["chest_cm", "length_cm"] } } })).id;
  });
  afterAll(async () => c.app.close());

  const draft = (over: Record<string, unknown> = {}) => ({ title: "Levi's trucker jacket", categoryId: catId, brandName: "Levi's", size: "M", color: "Blue", conditionGrade: "VERY_GOOD", priceMinor: 650_000, measurements: { chest_cm: 56 }, weightGrams: 900, ...over });

  it("create → photos (EXIF stripped) → readiness → submit → moderator approves → live", async () => {
    const s = await f.seller();
    const created = await c.http().post("/v1/seller/listings").set("Cookie", s.cookie).send(draft()).expect(201);
    const id = created.body.itemId;
    expect(created.body.sku).toMatch(/^OOAK-\d{6}$/);
    const notReady = await c.http().post(`/v1/seller/listings/${id}/submit`).set("Cookie", s.cookie).expect(422);
    expect(notReady.body.errors.problems.join(" ")).toMatch(/photos/);
    expect(notReady.body.errors.problems.join(" ")).toMatch(/length/);
    const img = await jpegWithGps();
    expect((await sharp(img).metadata()).exif).toBeTruthy();
    for (let i = 0; i < 2; i++) await c.http().post(`/v1/seller/listings/${id}/photos`).set("Cookie", s.cookie).attach("file", img, { filename: "p.jpg", contentType: "image/jpeg" }).expect(201);
    const media = await c.prisma.mediaAsset.findFirstOrThrow({ where: { itemId: id } });
    const stored = await c.app.get(StorageService).get(media.storageKey);
    const meta = await sharp(stored!).metadata();
    expect(meta.format).toBe("webp");
    expect(meta.exif).toBeUndefined();
    expect(Math.max(meta.width!, meta.height!)).toBeLessThanOrEqual(1600);
    expect(media.approvedForPublish).toBe(false);
    await c.http().patch(`/v1/seller/listings/${id}`).set("Cookie", s.cookie).send({ measurements: { chest_cm: 56, length_cm: 70 } }).expect(200);
    await c.http().post(`/v1/seller/listings/${id}/submit`).set("Cookie", s.cookie).expect(200);
    const l = await c.prisma.listing.findFirstOrThrow({ where: { itemId: id } });
    expect(l.state).toBe("PENDING_REVIEW");
    await c.http().get(`/v1/listings/${l.slug}`).expect(404);
    const mod = await f.user(["MODERATOR"]);
    await c.app.get(ListingService).approve(l.id, mod.id);
    const pub = await c.http().get(`/v1/listings/${l.slug}`).expect(200);
    expect(pub.body.item.images).toHaveLength(2);
    expect(pub.body.item.availability).toBe("AVAILABLE");
    // Editing grade on a live listing sends it back to review; price edits stay live
    await c.http().patch(`/v1/seller/listings/${id}`).set("Cookie", s.cookie).send({ priceMinor: 600_000 }).expect(200).then((r) => expect(r.body.sentToReview).toBe(false));
    await c.http().patch(`/v1/seller/listings/${id}`).set("Cookie", s.cookie).send({ conditionGrade: "EXCELLENT" }).expect(200).then((r) => expect(r.body.sentToReview).toBe(true));
  });

  it("sellers cannot see or change another seller's items", async () => {
    const a = await f.seller();
    const b = await f.seller();
    const { itemId } = (await c.http().post("/v1/seller/listings").set("Cookie", a.cookie).send(draft())).body;
    await c.http().get(`/v1/seller/listings/${itemId}`).set("Cookie", b.cookie).expect(404);
    await c.http().patch(`/v1/seller/listings/${itemId}`).set("Cookie", b.cookie).send({ priceMinor: 1 }).expect(400);
    await c.http().patch(`/v1/seller/listings/${itemId}`).set("Cookie", b.cookie).send({ priceMinor: 100_000 }).expect(404);
    await c.http().post(`/v1/seller/listings/${itemId}/remove`).set("Cookie", b.cookie).expect(404);
    const list = await c.http().get("/v1/seller/listings").set("Cookie", b.cookie).expect(200);
    expect(list.body.items).toHaveLength(0);
    const customer = await f.user();
    await c.http().get("/v1/seller/listings").set("Cookie", await f.login(customer.id)).expect(403);
  });

  it("labels: idempotent codes, valid PDF, concurrent issue yields one code; label data can't carry prices", async () => {
    const s = await f.seller();
    const { itemId } = (await c.http().post("/v1/seller/listings").set("Cookie", s.cookie).send(draft())).body;
    const r1 = await c.http().post("/v1/seller/labels").set("Cookie", s.cookie).send({ itemIds: [itemId], format: "thermal" }).buffer(true).parse((res, cb) => { const d: Buffer[] = []; res.on("data", (x: Buffer) => d.push(x)); res.on("end", () => cb(null, Buffer.concat(d))); }).expect(200);
    expect(r1.headers["content-type"]).toBe("application/pdf");
    expect((r1.body as Buffer).subarray(0, 5).toString()).toBe("%PDF-");
    await c.http().post("/v1/seller/labels").set("Cookie", s.cookie).send({ itemIds: [itemId], format: "a4" }).expect(200);
    const codes = await c.prisma.scanCode.findMany({ where: { itemId } });
    expect(codes).toHaveLength(1);
    expect(codes[0]!.printCount).toBe(2);
    const events = await c.prisma.scanEvent.findMany({ where: { codeId: codes[0]!.id } });
    expect(events.map((e) => e.action).sort()).toEqual(["GENERATED", "PRINTED", "REPRINTED"]);
    // concurrency
    const other = (await c.http().post("/v1/seller/listings").set("Cookie", s.cookie).send(draft())).body.itemId;
    const svc = c.app.get(CodesService);
    const results = await Promise.all(Array.from({ length: 8 }, () => svc.issue("ITEM_PACK", { itemId: other }, null)));
    expect(new Set(results.map((r) => r.code)).size).toBe(1);
    expect(() => assertLabelSafe({ code: "1", sku: "x", brand: null, size: null, title: "t", priceMinor: 1 }, "ITEM")).toThrow(/forbidden/);
    expect(() => assertLabelSafe({ code: "1", sku: "x", brand: null, size: null, title: "t", phone: "1" }, "ITEM")).toThrow(/forbidden/);
  });

  it("payout details need the seller's own code and reset staff verification", async () => {
    const s = await f.seller();
    const body = { kind: "BANK", provider: "Meezan Bank", accountTitle: s.user.name, accountNumber: "PK36SCBL0000001123456702" };
    await c.http().post("/v1/seller/settings/payout").set("Cookie", s.cookie).send({ ...body, code: "123456" }).expect(400);
    const { devCode } = (await c.http().post("/v1/auth/confirm/request").set("Cookie", s.cookie).expect(200)).body;
    await c.http().post("/v1/seller/settings/payout").set("Cookie", s.cookie).send({ ...body, code: devCode }).expect(200);
    const p = await c.prisma.sellerProfile.findUniqueOrThrow({ where: { id: s.profile.id } });
    expect(p.payoutVerifiedAt).toBeNull();
    expect(JSON.stringify(p.payoutMethod)).toContain("****6702");
    expect(JSON.stringify(p.payoutMethod)).not.toContain("PK36SCBL");
  });

  describe("acting on a seller's behalf", () => {
    it("SELLER_AGENT can create a draft for a consenting approved seller; it is audited with onBehalfOfId", async () => {
      const s = await f.seller({ allowStaffListing: true });
      const agent = await f.user(["SELLER_AGENT"]);
      const ac = await f.login(agent.id);
      const r = await c.http().post(`/v1/admin/sellers/${s.profile.id}/on-behalf/listings`).set("Cookie", ac).send(draft()).expect(201);
      const log = await c.prisma.auditLog.findFirstOrThrow({ where: { action: "LISTING_CREATED", entityId: r.body.itemId } });
      expect(log.actorId).toBe(agent.id);
      expect(log.onBehalfOfId).toBe(s.user.id);
      const feed = await c.http().get("/v1/seller/activity").set("Cookie", s.cookie).expect(200);
      expect(feed.body.events.find((e: { action: string }) => e.action === "LISTING_CREATED").actor).toBe("ONEOFAKIND team");
    });

    it("refuses without consent, for support/finance staff, and for money/ownership actions even for admins", async () => {
      const noConsent = await f.seller({ allowStaffListing: false });
      const agent = await f.user(["SELLER_AGENT"]);
      const ac = await f.login(agent.id);
      const r = await c.http().post(`/v1/admin/sellers/${noConsent.profile.id}/on-behalf/listings`).set("Cookie", ac).send(draft()).expect(403);
      expect(r.body.code).toBe("ON_BEHALF_REFUSED");
      const consenting = await f.seller({ allowStaffListing: true });
      for (const role of ["SUPPORT", "FINANCE", "MODERATOR"] as const) {
        const u = await f.user([role]);
        await c.http().post(`/v1/admin/sellers/${consenting.profile.id}/on-behalf/listings`).set("Cookie", await f.login(u.id)).send(draft()).expect(403);
      }
      const admin = await f.user(["ADMIN"]);
      for (const path of ["payout", "accept-offer", "approve-price", "close-account", "change-phone"])
        await c.http().post(`/v1/admin/sellers/${consenting.profile.id}/on-behalf/${path}`).set("Cookie", await f.login(admin.id)).expect(403);
      const suspended = await f.seller({ allowStaffListing: true, status: "SUSPENDED" });
      await c.http().post(`/v1/admin/sellers/${suspended.profile.id}/on-behalf/listings`).set("Cookie", ac).send(draft()).expect(403);
    });
  });

  describe("bundle builder", () => {
    async function pieces(sellerId: string, n: number, over: Record<string, unknown> = {}) {
      const brand = await f.brand();
      const style = await f.style();
      const ids: string[] = [];
      for (let i = 0; i < n; i++) ids.push((await f.item({ sellerId, categoryId: catId, brandId: brand.id, styleId: style.id, publish: false, stockState: "READY_TO_LIST", priceMinor: 400_000, ...over })).item.id);
      return { brand, style, ids };
    }

    it("builds a valid 5-piece lot; pieces flip to the bundle channel; moderation publishes it", async () => {
      await f.tiers();
      const s = await f.seller();
      const { brand, style, ids } = await pieces(s.profile.id, 5);
      const el = await c.http().get(`/v1/seller/bundles/eligible?brandId=${brand.id}&styleId=${style.id}`).set("Cookie", s.cookie).expect(200);
      expect(el.body.items).toHaveLength(5);
      const r = await c.http().post("/v1/seller/bundles").set("Cookie", s.cookie).send({ brandId: brand.id, styleId: style.id, itemIds: ids, priceMinor: 1_200_000 }).expect(201);
      expect((await c.prisma.item.findMany({ where: { id: { in: ids } } })).every((i) => i.channel === "BUNDLE")).toBe(true);
      await c.http().post(`/v1/seller/bundles/${r.body.id}/submit`).set("Cookie", s.cookie).expect(200);
      const { BundleService } = await import("../src/modules/bundles/bundle.service");
      const mod = await f.user(["MODERATOR"]);
      await c.app.get(BundleService).transition(r.body.id, "PUBLISHED", mod.id);
      const b = await c.prisma.bundle.findUniqueOrThrow({ where: { id: r.body.id } });
      expect(b.state).toBe("PUBLISHED");
      // removing releases the pieces back to retail
      await c.http().post(`/v1/seller/bundles/${r.body.id}/remove`).set("Cookie", s.cookie).expect(200);
      expect((await c.prisma.item.findMany({ where: { id: { in: ids } } })).every((i) => i.channel === "RETAIL")).toBe(true);
    });

    it("rejects wrong sizes, grade C pieces, another seller's pieces, missing weights and too-high prices", async () => {
      await f.tiers();
      const s = await f.seller();
      const other = await f.seller();
      const four = await pieces(s.profile.id, 4);
      const bad1 = await c.http().post("/v1/seller/bundles").set("Cookie", s.cookie).send({ brandId: four.brand.id, styleId: four.style.id, itemIds: four.ids, priceMinor: 900_000 }).expect(422);
      expect(bad1.body.errors.issues.map((i: { code: string }) => i.code)).toContain("SIZE_NOT_ALLOWED");
      const five = await pieces(s.profile.id, 5);
      await c.prisma.item.update({ where: { id: five.ids[0] }, data: { conditionGrade: "GOOD" } });
      await c.prisma.item.update({ where: { id: five.ids[1] }, data: { weightGrams: null } });
      const theirs = await f.item({ sellerId: other.profile.id, categoryId: catId, brandId: five.brand.id, styleId: five.style.id, publish: false });
      const bad2 = await c.http().post("/v1/seller/bundles").set("Cookie", s.cookie).send({ brandId: five.brand.id, styleId: five.style.id, itemIds: [...five.ids.slice(0, 4), theirs.item.id], priceMinor: 2_000_000 }).expect(422);
      const codes = bad2.body.errors.issues.map((i: { code: string }) => i.code);
      expect(codes).toEqual(expect.arrayContaining(["GRADE_NOT_ALLOWED", "SELLER_MISMATCH", "MISSING_WEIGHT", "PRICE_NOT_DISCOUNTED"]));
    });
  });
});
