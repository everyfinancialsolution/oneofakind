# apps/api — NestJS API (to be created in Milestone 3)
Prisma schema is ready in `prisma/schema.prisma`. Scaffold with `@nestjs/cli`, keep modules per `docs/ARCHITECTURE.md`. DB integrity SQL migrations are specified in `docs/DATABASE_SCHEMA.md`.
