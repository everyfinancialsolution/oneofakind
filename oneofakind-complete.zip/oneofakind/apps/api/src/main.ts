import "reflect-metadata";
import { type INestApplication, Logger } from "@nestjs/common";
import { NestFactory } from "@nestjs/core";
import type { NestExpressApplication } from "@nestjs/platform-express";
import cookieParser from "cookie-parser";
import helmet from "helmet";
import { AppModule } from "./app.module";
import { config } from "./config";

/** Shared app configuration (also used by integration tests). */
export function configureApp(app: INestApplication) {
  const c = config();
  const express = app as NestExpressApplication;
  express.set("trust proxy", 1);
  express.disable("x-powered-by");
  app.use(helmet({ crossOriginResourcePolicy: { policy: "same-site" } }));
  app.use(cookieParser());
  app.setGlobalPrefix("v1", { exclude: ["health", "health/ready"] });
  // The web app proxies /v1/* on its own origin, so browsers never need CORS. Allow the web origin for direct calls in dev.
  app.enableCors({ origin: [c.WEB_ORIGIN], credentials: true });
  app.enableShutdownHooks();
  return app;
}

async function bootstrap() {
  const app = await NestFactory.create<NestExpressApplication>(AppModule, { bufferLogs: false, rawBody: true });
  configureApp(app);
  const port = config().PORT;
  await app.listen(port);
  new Logger("Bootstrap").log(`ONEOFAKIND API listening on :${port} (${config().NODE_ENV})`);
}

if (require.main === module) void bootstrap();
