import { Controller, Get, Module } from "@nestjs/common";
import { APP_FILTER, APP_GUARD } from "@nestjs/core";
import { ThrottlerGuard, ThrottlerModule } from "@nestjs/throttler";
import { AuditModule } from "./common/audit.service";
import { SessionGuard } from "./common/auth";
import { NotifierModule } from "./common/notifier.service";
import { PrismaModule, PrismaService } from "./common/prisma.service";
import { ProblemFilter } from "./common/problem";
import { StorageModule } from "./common/storage.service";
import { AuthController } from "./modules/auth/auth.controller";
import { OtpService } from "./modules/auth/otp.service";
import { BundlesPublicController, CatalogController, CollectionsController, ListingsController, SellersController } from "./modules/catalog/catalog.controller";
import { ContentController, MediaController } from "./modules/catalog/content.controller";
import { SearchService } from "./modules/catalog/search.service";
import { OnboardingAdminController, OnboardingController } from "./modules/onboarding/onboarding.controller";
import { OnboardingService } from "./modules/onboarding/onboarding.service";
import { MediaModule } from "./common/media.service";
import { BundleService } from "./modules/bundles/bundle.service";
import { CodesService } from "./modules/codes/codes.service";
import { ListingService } from "./modules/seller/listing.service";
import { OnBehalfController, SellerController } from "./modules/seller/seller.controller";
import { CartService } from "./modules/commerce/cart.service";
import { CheckoutService } from "./modules/commerce/checkout.service";
import { CartController, CheckoutController, OffersWishlistController, OrdersController, SandboxController, SellerOrdersController, WebhooksController } from "./modules/commerce/commerce.controller";
import { FulfilmentService } from "./modules/commerce/fulfilment.service";
import { LedgerService } from "./modules/commerce/ledger.service";
import { courierProviderFactory, paymentProviderFactory } from "./modules/commerce/providers";
import { ReturnsService } from "./modules/commerce/returns.service";
import { JobsService } from "./modules/jobs.service";
import { DirectPurchaseService } from "./modules/ops/direct-purchase.service";
import { ManagedService } from "./modules/ops/managed.service";
import { AdminBuyingController, OpsController, SellerManagedController } from "./modules/ops/ops.controller";
import { FinanceService } from "./modules/admin/finance.service";
import { AdminAiController, StudioController } from "./modules/ai/ai.controller";
import { AiService } from "./modules/ai/ai.service";
import { AdminController, CatalogAdminController, FinanceController, ModerationController, ReportsController, SupportController } from "./modules/admin/admin.controller";

@Controller("health")
class HealthController {
  constructor(private readonly prisma: PrismaService) {}
  @Get() live() { return { ok: true }; }
  @Get("ready") async ready() { await this.prisma.$queryRaw`SELECT 1`; return { ok: true, db: "up" }; }
}

export const coreModules = [PrismaModule, AuditModule, StorageModule, NotifierModule, MediaModule];

@Module({
  imports: [...coreModules, ThrottlerModule.forRoot({ throttlers: [{ name: "default", ttl: 60_000, limit: 600 }], skipIf: () => process.env.NODE_ENV === "test" })],
  controllers: [
    HealthController, AuthController, CatalogController, ListingsController, SellersController, CollectionsController,
    BundlesPublicController, ContentController, MediaController, OnboardingController, OnboardingAdminController,
    SellerController, OnBehalfController,
    CartController, CheckoutController, WebhooksController, SandboxController, OrdersController, SellerOrdersController, OffersWishlistController,
    OpsController, SellerManagedController, AdminBuyingController,
    AdminController, ModerationController, ReportsController, CatalogAdminController, SupportController, FinanceController,
    StudioController, AdminAiController,
  ],
  providers: [
    OtpService, SearchService, OnboardingService, ListingService, BundleService, CodesService,
    CartService, CheckoutService, FulfilmentService, LedgerService, ReturnsService, JobsService, paymentProviderFactory, courierProviderFactory, ManagedService, DirectPurchaseService, FinanceService, AiService,
    { provide: APP_GUARD, useClass: ThrottlerGuard },
    { provide: APP_GUARD, useClass: SessionGuard },
    { provide: APP_FILTER, useClass: ProblemFilter },
  ],
})
export class AppModule {}
