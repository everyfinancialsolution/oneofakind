import { z } from "zod";

const bool = (def: boolean) => z.preprocess((v) => (v === undefined || v === "" ? def : v === "true" || v === "1" || v === true), z.boolean());

const schema = z.object({
  NODE_ENV: z.enum(["development", "test", "staging", "production"]).default("development"),
  PORT: z.coerce.number().default(4000),
  DATABASE_URL: z.string().min(1),
  WEB_ORIGIN: z.string().default("http://localhost:3000"),
  PUBLIC_API_URL: z.string().default("http://localhost:4000"),
  SESSION_COOKIE_NAME: z.string().default("ooak_session"),
  SESSION_TTL_DAYS: z.coerce.number().default(30),
  COOKIE_SECURE: bool(false),
  STORAGE_DRIVER: z.enum(["local", "s3"]).default("local"),
  STORAGE_DIR: z.string().optional(),
  S3_ENDPOINT: z.string().optional(),
  S3_REGION: z.string().default("auto"),
  S3_BUCKET_PRIVATE: z.string().default("ooak-private"),
  S3_ACCESS_KEY: z.string().optional(),
  S3_SECRET_KEY: z.string().optional(),
  REDIS_URL: z.string().optional(),
  JOBS_ENABLED: bool(true),
  PAYMENT_PROVIDER: z.string().default("sandbox"),
  PAYMENT_WEBHOOK_SECRET: z.string().default(""),
  COURIER_PROVIDER: z.string().default("sandbox"),
  COURIER_WEBHOOK_SECRET: z.string().default(""),
  SMS_PROVIDER: z.string().default("console"),
  AI_TEXT_PROVIDER: z.string().default("fake"),
  AI_IMAGE_PROVIDER: z.string().default("fake"),
  AI_TRYON_PROVIDER: z.string().default(""),
  AI_JOB_TIMEOUT_MS: z.coerce.number().default(30_000),
  AI_DAILY_QUOTA: z.coerce.number().default(40), // AI jobs per user per day (staff exempt)
  OTP_DEV_ECHO: bool(true),
  WHATSAPP_BUSINESS_NUMBER: z.string().default("447513875488"),
  MAX_UPLOAD_MB: z.coerce.number().default(10),
});

export type AppConfig = z.infer<typeof schema>;

let cached: AppConfig | null = null;
export function config(): AppConfig {
  if (cached) return cached;
  const parsed = schema.parse(process.env);
  if (parsed.NODE_ENV === "production") {
    // Safety rails: no dev shortcuts and no sandbox secrets in production.
    if (parsed.OTP_DEV_ECHO) throw new Error("OTP_DEV_ECHO must be false in production");
    if (!parsed.COOKIE_SECURE) throw new Error("COOKIE_SECURE must be true in production");
    if (!parsed.PAYMENT_WEBHOOK_SECRET) throw new Error("PAYMENT_WEBHOOK_SECRET is required in production");
  }
  if (!parsed.PAYMENT_WEBHOOK_SECRET) parsed.PAYMENT_WEBHOOK_SECRET = "dev-sandbox-webhook-secret";
  if (!parsed.COURIER_WEBHOOK_SECRET) parsed.COURIER_WEBHOOK_SECRET = "dev-sandbox-courier-secret";
  cached = parsed;
  return parsed;
}

/** Tests flip env between suites. */
export function resetConfigCache() { cached = null; }
export const isProd = () => config().NODE_ENV === "production";
