import { Global, Injectable, Module } from "@nestjs/common";
import type { MediaKind } from "@prisma/client";
import { randomUUID } from "node:crypto";
import sharp from "sharp";
import { PrismaService } from "./prisma.service";
import { badRequest } from "./problem";
import { StorageService } from "./storage.service";
import { requireImage, type UploadedFileT } from "./upload";

const MAX_EDGE = 1600;

/**
 * Photo pipeline: sniff type → auto-rotate → resize (long edge 1600px) → WebP. sharp drops all metadata by default,
 * so EXIF/GPS location from sellers' phones never reaches storage or buyers. Originals (the seller's photo) are never
 * overwritten: AI edits are stored as separate assets pointing back via sourceAssetId.
 */
@Injectable()
export class MediaService {
  constructor(private readonly prisma: PrismaService, private readonly storage: StorageService) {}

  async processImage(buf: Buffer): Promise<{ body: Buffer; width: number; height: number }> {
    try {
      const out = await sharp(buf, { failOn: "error" }).rotate().resize({ width: MAX_EDGE, height: MAX_EDGE, fit: "inside", withoutEnlargement: true }).webp({ quality: 82 }).toBuffer({ resolveWithObject: true });
      return { body: out.data, width: out.info.width, height: out.info.height };
    } catch {
      throw badRequest("We couldn't read that photo. Please upload a JPG, PNG or WEBP.", "UNREADABLE_IMAGE");
    }
  }

  async saveItemPhoto(itemId: string, file: UploadedFileT | undefined, opts: { ownerUserId: string; kind?: MediaKind; position?: number }) {
    requireImage(file);
    const { body, width, height } = await this.processImage(file!.buffer);
    const key = `public/items/${itemId}/${randomUUID()}.webp`;
    await this.storage.put(key, body, "image/webp");
    const position = opts.position ?? (await this.prisma.mediaAsset.count({ where: { itemId, deletedAt: null } }));
    return this.prisma.mediaAsset.create({
      data: { itemId, ownerUserId: opts.ownerUserId, kind: opts.kind ?? "ORIGINAL", visibility: "PRIVATE", storageKey: key, mime: "image/webp", bytes: body.length, width, height, position, approvedForPublish: false },
    });
  }
}

@Global()
@Module({ providers: [MediaService], exports: [MediaService] })
export class MediaModule {}
