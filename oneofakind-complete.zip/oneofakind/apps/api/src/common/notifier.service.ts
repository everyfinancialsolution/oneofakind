import { Global, Injectable, Logger, Module } from "@nestjs/common";
import { config } from "../config";
import { PrismaService } from "./prisma.service";

/**
 * Outbound messages. v1: SMS via an adapter (console in dev; a Pakistani SMS gateway once chosen) and in-app notifications.
 * WhatsApp is a manual staff channel in v1 (no Business API) - staff use wa.me links built with whatsappLink().
 * Every message is recorded in Notification. Message bodies never contain prices of bundles or ID numbers.
 */
export interface SmsProvider { send(to: string, body: string): Promise<void> }

class ConsoleSms implements SmsProvider {
  private readonly log = new Logger("SMS");
  async send(to: string, body: string) { this.log.log(`→ ${to}: ${body}`); }
}

@Injectable()
export class NotifierService {
  private readonly sms: SmsProvider;
  constructor(private readonly prisma: PrismaService) {
    const provider = config().SMS_PROVIDER;
    if (provider !== "console") new Logger("SMS").warn(`SMS provider "${provider}" not implemented yet; using console`);
    this.sms = new ConsoleSms();
  }

  async sendSms(to: string, template: string, body: string, userId?: string | null) {
    const n = await this.prisma.notification.create({ data: { channel: "SMS", to, template, body, userId: userId ?? null } });
    try {
      await this.sms.send(to, body);
      await this.prisma.notification.update({ where: { id: n.id }, data: { sentAt: new Date() } });
    } catch (e) {
      await this.prisma.notification.update({ where: { id: n.id }, data: { error: String(e) } });
    }
  }

  async inApp(userId: string, template: string, body: string) {
    await this.prisma.notification.create({ data: { channel: "IN_APP", userId, template, body, sentAt: new Date() } });
  }
}

@Global()
@Module({ providers: [NotifierService], exports: [NotifierService] })
export class NotifierModule {}
