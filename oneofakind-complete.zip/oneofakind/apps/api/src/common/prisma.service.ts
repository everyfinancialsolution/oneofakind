import { Global, Injectable, Module, type OnModuleDestroy, type OnModuleInit } from "@nestjs/common";
import { Prisma, PrismaClient } from "@prisma/client";

export type Tx = Prisma.TransactionClient;

@Injectable()
export class PrismaService extends PrismaClient implements OnModuleInit, OnModuleDestroy {
  async onModuleInit() { await this.$connect(); }
  async onModuleDestroy() { await this.$disconnect(); }

  /** nextval() on one of the sequences created by the integrity migration. */
  async nextval(seq: SequenceName, tx: Tx | PrismaClient = this): Promise<number> {
    const rows = await tx.$queryRawUnsafe<{ v: bigint }[]>(`SELECT nextval('${seq}') AS v`);
    return Number(rows[0]!.v);
  }

  /** Run fn only if this process wins a Postgres advisory lock (used by periodic sweeps so N instances don't double-run). */
  async withAdvisoryLock<T>(key: number, fn: () => Promise<T>): Promise<T | null> {
    const [{ locked }] = await this.$queryRawUnsafe<{ locked: boolean }[]>(`SELECT pg_try_advisory_lock(${key}) AS locked`);
    if (!locked) return null;
    try { return await fn(); } finally { await this.$queryRawUnsafe(`SELECT pg_advisory_unlock(${key})`); }
  }
}

export type SequenceName =
  | "seq_scan_item_pack" | "seq_scan_bundle_pack" | "seq_scan_order_pack" | "seq_scan_dispatch"
  | "seq_order_ref" | "seq_application_seller" | "seq_application_reseller" | "seq_item_sku" | "seq_bundle_sku";

@Global()
@Module({ providers: [PrismaService], exports: [PrismaService] })
export class PrismaModule {}
