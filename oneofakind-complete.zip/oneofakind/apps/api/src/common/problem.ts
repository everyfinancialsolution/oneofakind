import { HttpException, type ArgumentsHost, Catch, type ExceptionFilter, Logger } from "@nestjs/common";
import { Prisma } from "@prisma/client";
import { InvalidTransitionError } from "@ooak/shared";
import type { Request, Response } from "express";
import { ZodError, type ZodTypeAny, type z } from "zod";

/** RFC 7807 problem details. Never leaks stack traces. */
export interface ProblemBody { type: string; title: string; status: number; detail?: string; code?: string; errors?: unknown }

export class Problem extends HttpException {
  constructor(status: number, code: string, title: string, detail?: string, errors?: unknown) {
    super({ type: `https://oneofakind.pk/problems/${code.toLowerCase().replace(/_/g, "-")}`, title, status, detail, code, errors } satisfies ProblemBody, status);
  }
}

export const badRequest = (detail: string, code = "BAD_REQUEST", errors?: unknown) => new Problem(400, code, "Bad request", detail, errors);
export const unauthorized = (detail = "Please log in.") => new Problem(401, "UNAUTHORIZED", "Unauthorized", detail);
export const forbidden = (detail = "You don't have permission to do this.", code = "FORBIDDEN") => new Problem(403, code, "Forbidden", detail);
export const notFound = (what = "Resource") => new Problem(404, "NOT_FOUND", "Not found", `${what} not found.`);
export const conflict = (detail: string, code = "CONFLICT") => new Problem(409, code, "Conflict", detail);
export const unprocessable = (detail: string, code = "UNPROCESSABLE", errors?: unknown) => new Problem(422, code, "Unprocessable", detail, errors);
export const tooMany = (detail: string, code = "RATE_LIMITED") => new Problem(429, code, "Too many requests", detail);

/** Validate untrusted input with zod; 400 with field errors on failure. */
export function parse<S extends ZodTypeAny>(schema: S, input: unknown): z.infer<S> {
  const r = schema.safeParse(input);
  if (!r.success) throw badRequest("Some fields are missing or invalid.", "VALIDATION", r.error.flatten());
  return r.data;
}

@Catch()
export class ProblemFilter implements ExceptionFilter {
  private readonly log = new Logger("Problem");
  catch(exception: unknown, host: ArgumentsHost) {
    const res = host.switchToHttp().getResponse<Response>();
    const req = host.switchToHttp().getRequest<Request>();
    let body: ProblemBody;
    if (exception instanceof HttpException) {
      const r = exception.getResponse();
      const status = exception.getStatus();
      body = typeof r === "object" && r && "title" in r ? (r as ProblemBody)
        : { type: "about:blank", title: exception.message, status, detail: typeof r === "string" ? r : (r as { message?: string })?.message?.toString() };
    } else if (exception instanceof InvalidTransitionError) {
      body = { type: "https://oneofakind.pk/problems/invalid-transition", title: "Conflict", status: 409, code: "INVALID_TRANSITION", detail: exception.message };
    } else if (exception instanceof ZodError) {
      body = { type: "https://oneofakind.pk/problems/validation", title: "Bad request", status: 400, code: "VALIDATION", errors: exception.flatten() };
    } else if (exception instanceof Prisma.PrismaClientKnownRequestError && exception.code === "P2002") {
      body = { type: "https://oneofakind.pk/problems/conflict", title: "Conflict", status: 409, code: "UNIQUE_VIOLATION", detail: "This already exists." };
    } else if (exception instanceof Prisma.PrismaClientKnownRequestError && exception.code === "P2025") {
      body = { type: "https://oneofakind.pk/problems/not-found", title: "Not found", status: 404, code: "NOT_FOUND", detail: "Resource not found." };
    } else {
      this.log.error(`${req.method} ${req.url}: ${(exception as Error)?.stack ?? exception}`);
      body = { type: "about:blank", title: "Internal server error", status: 500, detail: "Something went wrong. Please try again." };
    }
    res.status(body.status).type("application/problem+json").json(body);
  }
}
