import { Global, Injectable, Module } from "@nestjs/common";
import type { Prisma } from "@prisma/client";
import { PrismaService, type Tx } from "./prisma.service";

export interface AuditInput {
  actorId?: string | null;
  onBehalfOfId?: string | null;
  action: string;
  entity: string;
  entityId: string;
  before?: unknown;
  after?: unknown;
  ip?: string | null;
}

/** Append-only audit trail (the DB rejects UPDATE/DELETE on AuditLog). */
@Injectable()
export class AuditService {
  constructor(private readonly prisma: PrismaService) {}
  async log(input: AuditInput, tx: Tx = this.prisma) {
    await tx.auditLog.create({
      data: {
        actorId: input.actorId ?? null, onBehalfOfId: input.onBehalfOfId ?? null, action: input.action, entity: input.entity,
        entityId: input.entityId, ip: input.ip ?? null,
        before: (input.before ?? undefined) as Prisma.InputJsonValue | undefined, after: (input.after ?? undefined) as Prisma.InputJsonValue | undefined,
      },
    });
  }
}

@Global()
@Module({ providers: [AuditService], exports: [AuditService] })
export class AuditModule {}
