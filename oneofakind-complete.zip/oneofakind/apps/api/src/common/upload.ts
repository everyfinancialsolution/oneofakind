import { FileInterceptor } from "@nestjs/platform-express";
import { memoryStorage } from "multer";
import { config } from "../config";
import { badRequest } from "./problem";
import { isPdf, sniffImage } from "./storage.service";

/** Single-file multipart upload held in memory (size-capped). Content type is sniffed later - never trusted. */
export const SingleUpload = (field = "file") =>
  FileInterceptor(field, { storage: memoryStorage(), limits: { fileSize: config().MAX_UPLOAD_MB * 1024 * 1024, files: 1 } });

export interface UploadedFileT { buffer: Buffer; size: number; originalname: string; mimetype: string }

export function requireImage(file: UploadedFileT | undefined, allowPdf = false): { mime: string; ext: string } {
  if (!file?.buffer?.length) throw badRequest("Please choose a file to upload.", "FILE_REQUIRED");
  const img = sniffImage(file.buffer);
  if (img) return img;
  if (allowPdf && isPdf(file.buffer)) return { mime: "application/pdf", ext: "pdf" };
  throw badRequest(allowPdf ? "Please upload a photo (JPG, PNG, WEBP, HEIC) or a PDF." : "Please upload a photo (JPG, PNG, WEBP or HEIC).", "UNSUPPORTED_FILE");
}
