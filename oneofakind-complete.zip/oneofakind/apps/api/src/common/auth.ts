import { applyDecorators, type CanActivate, createParamDecorator, type ExecutionContext, Injectable, SetMetadata } from "@nestjs/common";
import { Reflector } from "@nestjs/core";
import type { Role } from "@prisma/client";
import type { Viewer as SharedViewer } from "@ooak/shared";
import { createHash, randomBytes } from "node:crypto";
import type { Request } from "express";
import { config } from "../config";
import { PrismaService } from "./prisma.service";
import { forbidden, unauthorized } from "./problem";

export interface Viewer {
  userId: string;
  sessionId: string;
  name: string;
  phone: string | null;
  roles: Role[];
  sellerId: string | null;
  sellerStatus: string | null;
}

export const STAFF_ROLES: Role[] = ["WAREHOUSE", "SUPPORT", "FINANCE", "MODERATOR", "ADMIN", "SELLER_AGENT"];
export const hasRole = (v: Viewer | null | undefined, ...roles: Role[]) => !!v && v.roles.some((r) => roles.includes(r));
export const isStaff = (v: Viewer | null | undefined) => hasRole(v, ...STAFF_ROLES);
export const toSharedViewer = (v: Viewer | null): SharedViewer | null => (v ? { userId: v.userId, roles: v.roles, sellerId: v.sellerId } : null);

export const hashToken = (t: string) => createHash("sha256").update(t).digest("hex");
export const newSessionToken = () => randomBytes(32).toString("base64url");

const AUTH_KEY = "ooak:auth";
interface AuthMeta { roles: Role[] }

/** Require a logged-in user; if roles are given the user must hold at least one of them. */
export const Auth = (...roles: Role[]) => applyDecorators(SetMetadata(AUTH_KEY, { roles } satisfies AuthMeta));

export const CurrentViewer = createParamDecorator((_: unknown, ctx: ExecutionContext): Viewer | null => {
  return (ctx.switchToHttp().getRequest<Request & { viewer?: Viewer | null }>().viewer) ?? null;
});

export function tokenFromRequest(req: Request): string | null {
  const cookie = (req as Request & { cookies?: Record<string, string> }).cookies?.[config().SESSION_COOKIE_NAME];
  if (cookie) return cookie;
  const h = req.headers.authorization;
  return h?.startsWith("Bearer ") ? h.slice(7) : null;
}

/** Global guard: resolves the session (cookie or Bearer) into req.viewer, then enforces @Auth metadata. */
@Injectable()
export class SessionGuard implements CanActivate {
  constructor(private readonly prisma: PrismaService, private readonly reflector: Reflector) {}

  async canActivate(ctx: ExecutionContext): Promise<boolean> {
    const req = ctx.switchToHttp().getRequest<Request & { viewer?: Viewer | null }>();
    if (req.viewer === undefined) req.viewer = await this.resolve(req);
    const meta = this.reflector.getAllAndOverride<AuthMeta | undefined>(AUTH_KEY, [ctx.getHandler(), ctx.getClass()]);
    if (!meta) return true;
    if (!req.viewer) throw unauthorized();
    if (meta.roles.length && !hasRole(req.viewer, ...meta.roles)) throw forbidden();
    return true;
  }

  private async resolve(req: Request): Promise<Viewer | null> {
    const token = tokenFromRequest(req);
    if (!token) return null;
    const session = await this.prisma.session.findUnique({
      where: { refreshHash: hashToken(token) },
      include: { user: { include: { sellerProfile: { select: { id: true, status: true } } } } },
    });
    const now = new Date();
    if (!session || session.revokedAt || session.expiresAt < now || session.user.disabledAt) return null;
    // Sliding expiry, at most one write per day per session
    const ttl = config().SESSION_TTL_DAYS * 86_400_000;
    if (session.expiresAt.getTime() - now.getTime() < ttl - 86_400_000) {
      await this.prisma.session.update({ where: { id: session.id }, data: { expiresAt: new Date(now.getTime() + ttl) } });
    }
    const u = session.user;
    return {
      userId: u.id, sessionId: session.id, name: u.name, phone: u.phone, roles: u.roles,
      sellerId: u.sellerProfile?.id ?? null, sellerStatus: u.sellerProfile?.status ?? null,
    };
  }
}

/** For seller-portal endpoints: the caller's own seller id (never trust a sellerId from the client). */
export function requireSeller(v: Viewer | null): string {
  if (!v) throw unauthorized();
  if (!v.sellerId) throw forbidden("You need an approved seller account for this.", "NOT_A_SELLER");
  if (v.sellerStatus === "SUSPENDED") throw forbidden("Your seller account is suspended. Please contact support.", "SELLER_SUSPENDED");
  return v.sellerId;
}
