import { Global, Injectable, Module } from "@nestjs/common";
import { DeleteObjectCommand, GetObjectCommand, PutObjectCommand, S3Client } from "@aws-sdk/client-s3";
import { mkdir, readFile, rm, writeFile } from "node:fs/promises";
import { dirname, join, resolve, sep } from "node:path";
import { config } from "../config";

/**
 * Object storage. Keys are namespaced:
 *   public/…      item photos and generated media (served only after publish approval, via /v1/media/:id)
 *   private/…     user photos (try-on), unpublished uploads
 *   restricted/…  onboarding ID/bank documents and consent evidence (onboarding/support/admin only, every read logged)
 * Local driver for dev/test; S3-compatible (R2/S3/MinIO) for staging/production. Never a public bucket.
 */
export interface StorageDriver {
  put(key: string, body: Buffer, mime: string): Promise<void>;
  get(key: string): Promise<Buffer | null>;
  delete(key: string): Promise<void>;
}

class LocalDriver implements StorageDriver {
  constructor(private readonly root: string) {}
  private path(key: string) {
    const p = resolve(this.root, key);
    if (!p.startsWith(resolve(this.root) + sep)) throw new Error("invalid storage key");
    return p;
  }
  async put(key: string, body: Buffer) { const p = this.path(key); await mkdir(dirname(p), { recursive: true }); await writeFile(p, body); }
  async get(key: string) { try { return await readFile(this.path(key)); } catch { return null; } }
  async delete(key: string) { await rm(this.path(key), { force: true }); }
}

class S3Driver implements StorageDriver {
  private readonly s3: S3Client;
  private readonly bucket: string;
  constructor() {
    const c = config();
    this.bucket = c.S3_BUCKET_PRIVATE;
    this.s3 = new S3Client({
      region: c.S3_REGION, endpoint: c.S3_ENDPOINT, forcePathStyle: true,
      credentials: c.S3_ACCESS_KEY ? { accessKeyId: c.S3_ACCESS_KEY, secretAccessKey: c.S3_SECRET_KEY ?? "" } : undefined,
    });
  }
  async put(key: string, body: Buffer, mime: string) { await this.s3.send(new PutObjectCommand({ Bucket: this.bucket, Key: key, Body: body, ContentType: mime })); }
  async get(key: string) {
    try {
      const r = await this.s3.send(new GetObjectCommand({ Bucket: this.bucket, Key: key }));
      return r.Body ? Buffer.from(await r.Body.transformToByteArray()) : null;
    } catch { return null; }
  }
  async delete(key: string) { await this.s3.send(new DeleteObjectCommand({ Bucket: this.bucket, Key: key })); }
}

@Injectable()
export class StorageService implements StorageDriver {
  private readonly driver: StorageDriver;
  constructor() {
    const c = config();
    this.driver = c.STORAGE_DRIVER === "s3" ? new S3Driver() : new LocalDriver(c.STORAGE_DIR ?? join(__dirname, "..", "..", "storage"));
  }
  put(key: string, body: Buffer, mime: string) { return this.driver.put(key, body, mime); }
  get(key: string) { return this.driver.get(key); }
  delete(key: string) { return this.driver.delete(key); }
}

/** Sniff the real file type from magic bytes; never trust the client's Content-Type. */
export function sniffImage(buf: Buffer): { mime: string; ext: string } | null {
  if (buf.length < 12) return null;
  if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return { mime: "image/jpeg", ext: "jpg" };
  if (buf.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return { mime: "image/png", ext: "png" };
  if (buf.subarray(0, 4).toString("ascii") === "RIFF" && buf.subarray(8, 12).toString("ascii") === "WEBP") return { mime: "image/webp", ext: "webp" };
  if (buf.subarray(4, 12).toString("ascii").startsWith("ftypheic") || buf.subarray(4, 12).toString("ascii").startsWith("ftypmif1")) return { mime: "image/heic", ext: "heic" };
  return null;
}
export const isPdf = (buf: Buffer) => buf.subarray(0, 5).toString("ascii") === "%PDF-";
export const isGlb = (buf: Buffer) => buf.subarray(0, 4).toString("ascii") === "glTF";

@Global()
@Module({ providers: [StorageService], exports: [StorageService] })
export class StorageModule {}
