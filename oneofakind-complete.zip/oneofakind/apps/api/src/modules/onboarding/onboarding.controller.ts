import { Body, Controller, Get, HttpCode, Param, Post, Patch, Query, Res, UploadedFile, UseInterceptors } from "@nestjs/common";
import { Throttle } from "@nestjs/throttler";
import type { Response } from "express";
import { applyOnWhatsAppMessage, normalizePkPhone, whatsappLink } from "@ooak/shared";
import { z } from "zod";
import { AuditService } from "../../common/audit.service";
import { NotifierService } from "../../common/notifier.service";
import { Auth, CurrentViewer, type Viewer } from "../../common/auth";
import { PrismaService } from "../../common/prisma.service";
import { badRequest, conflict, notFound, parse } from "../../common/problem";
import { StorageService } from "../../common/storage.service";
import { requireImage, SingleUpload, type UploadedFileT } from "../../common/upload";
import { config } from "../../config";
import { OnboardingService, OPEN_STATES } from "./onboarding.service";

const Kind = z.enum(["SELLER", "RESELLER"]);
const DocKind = z.enum(["ID_FRONT", "ID_BACK", "PAYOUT_ACCOUNT_PROOF", "SHOP_PROOF", "BUSINESS_REG", "OTHER"]);
const Details = z.object({
  fullName: z.string().trim().min(2).max(100).optional(),
  email: z.string().email().max(120).nullable().optional(),
  city: z.string().trim().max(60).nullable().optional(),
  businessName: z.string().trim().max(100).nullable().optional(),
  shopLink: z.string().trim().url().max(300).nullable().optional(),
  intendedSellerType: z.enum(["INDIVIDUAL", "RESELLER", "BUSINESS"]).nullable().optional(),
});

/** Self-serve applications (applicant logged in with their own phone OTP). */
@Controller("onboarding")
export class OnboardingController {
  constructor(private readonly prisma: PrismaService, private readonly svc: OnboardingService) {}

  /**
   * "Apply on WhatsApp": create a reference number (no personal data yet) and return the wa.me link with it prefilled.
   * Staff complete the application from the chat in /admin/onboarding.
   */
  @Post("whatsapp-reference")
  @HttpCode(200)
  @Throttle({ default: { limit: 5, ttl: 60_000 } })
  async whatsappReference(@Body() body: unknown, @CurrentViewer() v: Viewer | null) {
    const { kind } = parse(z.object({ kind: Kind }), body);
    const existing = v ? await this.prisma.onboardingApplication.findFirst({ where: { applicantUserId: v.userId, kind, status: { in: [...OPEN_STATES] } } }) : null;
    const reference = existing?.reference ?? (await this.prisma.onboardingApplication.create({
      data: {
        reference: await this.svc.newReference(kind), kind, channel: "ASSISTED_WHATSAPP", fullName: v?.name ?? "", phone: v?.phone ?? "",
        applicantUserId: v?.userId ?? null,
      },
    })).reference;
    return { reference, link: whatsappLink(config().WHATSAPP_BUSINESS_NUMBER, applyOnWhatsAppMessage(kind, reference)) };
  }

  @Post("applications")
  @Auth()
  async start(@CurrentViewer() v: Viewer, @Body() body: unknown) {
    const { kind } = parse(z.object({ kind: Kind }), body);
    if (kind === "SELLER" && v.sellerId) throw conflict("You already have a seller account.", "ALREADY_SELLER");
    if (kind === "RESELLER" && v.roles.includes("VERIFIED_RESELLER")) throw conflict("You are already a verified reseller.", "ALREADY_RESELLER");
    const open = await this.prisma.onboardingApplication.findFirst({ where: { applicantUserId: v.userId, kind, status: { in: [...OPEN_STATES] } }, orderBy: { createdAt: "desc" } });
    const app = open ?? await this.prisma.onboardingApplication.create({
      data: { reference: await this.svc.newReference(kind), kind, channel: "SELF_SERVE", applicantUserId: v.userId, fullName: v.name, phone: v.phone ?? "" },
    });
    return this.svc.applicantView(await this.svc.byRef(app.reference));
  }

  @Get("applications/mine")
  @Auth()
  async mine(@CurrentViewer() v: Viewer) {
    const apps = await this.prisma.onboardingApplication.findMany({ where: { applicantUserId: v.userId }, orderBy: { createdAt: "desc" }, include: { documents: { where: { deletedAt: null } } } });
    return { applications: apps.map((a) => this.svc.applicantView(a)) };
  }

  @Patch("applications/:ref")
  @Auth()
  async update(@CurrentViewer() v: Viewer, @Param("ref") ref: string, @Body() body: unknown) {
    const app = await this.svc.byRef(ref);
    this.svc.assertOwner(app, v);
    if (!["DRAFT", "DOCS_REQUESTED"].includes(app.status)) throw conflict("This application can't be edited now.", "INVALID_STATE");
    await this.prisma.onboardingApplication.update({ where: { id: app.id }, data: parse(Details, body) });
    return this.svc.applicantView(await this.svc.byRef(ref));
  }

  @Post("applications/:ref/documents")
  @Auth()
  @UseInterceptors(SingleUpload())
  async upload(@CurrentViewer() v: Viewer, @Param("ref") ref: string, @Body() body: unknown, @UploadedFile() file: UploadedFileT) {
    const app = await this.svc.byRef(ref);
    this.svc.assertOwner(app, v);
    if (!["DRAFT", "DOCS_REQUESTED"].includes(app.status)) throw conflict("Documents can't be changed now.", "INVALID_STATE");
    const { kind } = parse(z.object({ kind: DocKind }), body);
    const t = requireImage(file, true);
    await this.svc.storeDocument(app.id, app.reference, kind, file.buffer, t.mime, t.ext, "UPLOAD", v.userId);
    return this.svc.applicantView(await this.svc.byRef(ref));
  }

  @Post("applications/:ref/submit")
  @HttpCode(200)
  @Auth()
  async submit(@CurrentViewer() v: Viewer, @Param("ref") ref: string) {
    const app = await this.svc.byRef(ref);
    this.svc.assertOwner(app, v);
    await this.svc.submit(app, v.userId);
    return this.svc.applicantView(await this.svc.byRef(ref));
  }

  @Post("applications/:ref/withdraw")
  @HttpCode(200)
  @Auth()
  async withdraw(@CurrentViewer() v: Viewer, @Param("ref") ref: string) {
    const app = await this.svc.byRef(ref);
    this.svc.assertOwner(app, v);
    await this.svc.transition(app.id, "WITHDRAWN", v.userId);
    return { ok: true };
  }
}

const AssistedCreate = z.object({
  kind: Kind,
  channel: z.enum(["ASSISTED_WHATSAPP", "ASSISTED_PHONE", "ASSISTED_IN_PERSON"]),
  reference: z.string().max(30).optional(), // existing WhatsApp reference, if the applicant tapped the button
  fullName: z.string().trim().min(2).max(100),
  phone: z.string().min(7).max(20),
  city: z.string().trim().max(60).optional(),
  businessName: z.string().trim().max(100).optional(),
  shopLink: z.string().trim().url().max(300).optional().or(z.literal("")),
  intendedSellerType: z.enum(["INDIVIDUAL", "RESELLER", "BUSINESS"]).optional(),
  consentMethod: z.enum(["WHATSAPP_MESSAGE", "PHONE_CALL", "IN_PERSON"]).optional(),
});

/** Staff side: queue, staff-assisted registration (WhatsApp/phone/in person), review decisions, restricted document access. */
@Controller("admin/onboarding")
@Auth("ADMIN", "SUPPORT", "SELLER_AGENT", "MODERATOR")
export class OnboardingAdminController {
  constructor(private readonly prisma: PrismaService, private readonly svc: OnboardingService, private readonly storage: StorageService, private readonly audit: AuditService, private readonly notifier: NotifierService) {}

  @Get()
  async queue(@Query() query: unknown) {
    const q = parse(z.object({ status: z.string().optional(), kind: Kind.optional(), channel: z.string().optional(), mine: z.string().optional(), search: z.string().max(60).optional() }), query);
    const statuses = q.status ? q.status.split(",") : ["SUBMITTED", "UNDER_REVIEW", "DOCS_REQUESTED", "DRAFT"];
    const apps = await this.prisma.onboardingApplication.findMany({
      where: {
        status: { in: statuses as never }, ...(q.kind ? { kind: q.kind } : {}), ...(q.channel ? { channel: q.channel as never } : {}),
        ...(q.search ? { OR: [{ reference: { contains: q.search, mode: "insensitive" } }, { fullName: { contains: q.search, mode: "insensitive" } }, { phone: { contains: q.search.replace(/\D/g, "") || q.search } }] } : {}),
      },
      orderBy: { createdAt: "asc" }, take: 200, include: { documents: { where: { deletedAt: null }, select: { kind: true, rejectedReason: true } } },
    });
    const now = Date.now();
    return {
      applications: apps.map((a) => ({
        reference: a.reference, kind: a.kind, status: a.status, channel: a.channel, fullName: a.fullName || "(details pending)", phone: a.phone, city: a.city,
        businessName: a.businessName, createdAt: a.createdAt, ageHours: Math.round((now - a.createdAt.getTime()) / 3_600_000), assignedToId: a.assignedToId,
        docs: a.documents.length, hasConsent: !!a.consentMethod,
      })),
    };
  }

  @Get(":ref")
  async detail(@Param("ref") ref: string) {
    const app = await this.svc.byRef(ref);
    const [dups, staffNames] = await Promise.all([
      this.svc.duplicates(app),
      this.prisma.user.findMany({ where: { id: { in: [app.registeredById, app.decidedById, app.assignedToId].filter((x): x is string => !!x) } }, select: { id: true, name: true } }),
    ]);
    const name = (id: string | null) => staffNames.find((s) => s.id === id)?.name ?? null;
    return {
      application: { ...this.svc.applicantView(app), consentMethod: app.consentMethod, consentAt: app.consentAt, hasConsentEvidence: !!app.consentEvidenceKey, registeredBy: name(app.registeredById), decidedBy: name(app.decidedById), decidedAt: app.decidedAt, assignedTo: name(app.assignedToId) },
      documents: app.documents.map((d) => ({ id: d.id, kind: d.kind, receivedVia: d.receivedVia, receivedAt: d.receivedAt, verifiedAt: d.verifiedAt, rejectedReason: d.rejectedReason, deleteAfter: d.deleteAfter })),
      duplicates: dups,
    };
  }

  /** Staff-assisted registration. Creates (or completes a WhatsApp-reference draft of) an application on the applicant's behalf. */
  @Post()
  @Auth("ADMIN", "SUPPORT", "SELLER_AGENT")
  async assistedCreate(@CurrentViewer() v: Viewer, @Body() body: unknown) {
    const input = parse(AssistedCreate, body);
    const phone = normalizePkPhone(input.phone);
    if (!phone) throw badRequest("Enter a valid Pakistani mobile number.", "INVALID_PHONE");
    const data = {
      fullName: input.fullName, phone, city: input.city, businessName: input.businessName, shopLink: input.shopLink || null, intendedSellerType: input.intendedSellerType,
      channel: input.channel, registeredById: v.userId, consentMethod: input.consentMethod ?? null, consentAt: input.consentMethod ? new Date() : null,
    };
    let app;
    if (input.reference) {
      const existing = await this.svc.byRef(input.reference);
      if (existing.status !== "DRAFT") throw conflict("That reference is already submitted.", "INVALID_STATE");
      app = await this.prisma.onboardingApplication.update({ where: { id: existing.id }, data });
    } else {
      app = await this.prisma.onboardingApplication.create({ data: { ...data, reference: await this.svc.newReference(input.kind), kind: input.kind } });
    }
    await this.audit.log({ actorId: v.userId, action: "ASSISTED_APPLICATION_CREATED", entity: "OnboardingApplication", entityId: app.id, after: { channel: input.channel } });
    return { reference: app.reference };
  }

  @Patch(":ref")
  @Auth("ADMIN", "SUPPORT", "SELLER_AGENT")
  async staffUpdate(@CurrentViewer() v: Viewer, @Param("ref") ref: string, @Body() body: unknown) {
    const app = await this.svc.byRef(ref);
    const input = parse(Details.extend({ consentMethod: z.enum(["WHATSAPP_MESSAGE", "PHONE_CALL", "IN_PERSON"]).optional(), phone: z.string().optional(), assignToMe: z.boolean().optional() }), body);
    const phone = input.phone ? normalizePkPhone(input.phone) : undefined;
    if (input.phone && !phone) throw badRequest("Enter a valid Pakistani mobile number.", "INVALID_PHONE");
    const { assignToMe, ...rest } = input;
    await this.prisma.onboardingApplication.update({
      where: { id: app.id },
      data: { ...rest, ...(phone ? { phone } : {}), ...(input.consentMethod ? { consentAt: new Date() } : {}), ...(assignToMe ? { assignedToId: v.userId } : {}) },
    });
    return { ok: true };
  }

  @Post(":ref/documents")
  @Auth("ADMIN", "SUPPORT", "SELLER_AGENT")
  @UseInterceptors(SingleUpload())
  async staffUpload(@CurrentViewer() v: Viewer, @Param("ref") ref: string, @Body() body: unknown, @UploadedFile() file: UploadedFileT) {
    const app = await this.svc.byRef(ref);
    const { kind, via } = parse(z.object({ kind: DocKind, via: z.enum(["WHATSAPP", "EMAIL", "IN_PERSON", "UPLOAD"]).default("WHATSAPP") }), body);
    const t = requireImage(file, true);
    await this.svc.storeDocument(app.id, app.reference, kind, file.buffer, t.mime, t.ext, via, v.userId);
    await this.audit.log({ actorId: v.userId, onBehalfOfId: app.applicantUserId, action: "DOCUMENT_UPLOADED_BY_STAFF", entity: "OnboardingApplication", entityId: app.id, after: { kind, via } });
    return { ok: true };
  }

  /** Evidence of how the applicant agreed (chat screenshot / call note photo). Required before an assisted application can be submitted. */
  @Post(":ref/consent-evidence")
  @Auth("ADMIN", "SUPPORT", "SELLER_AGENT")
  @UseInterceptors(SingleUpload())
  async consentEvidence(@CurrentViewer() v: Viewer, @Param("ref") ref: string, @Body() body: unknown, @UploadedFile() file: UploadedFileT) {
    const app = await this.svc.byRef(ref);
    const { method } = parse(z.object({ method: z.enum(["WHATSAPP_MESSAGE", "PHONE_CALL", "IN_PERSON"]) }), body);
    const t = requireImage(file, true);
    const key = `restricted/onboarding/${app.reference}/consent-${Date.now()}.${t.ext}`;
    await this.storage.put(key, file.buffer, t.mime);
    if (app.consentEvidenceKey) await this.storage.delete(app.consentEvidenceKey);
    await this.prisma.onboardingApplication.update({ where: { id: app.id }, data: { consentMethod: method, consentEvidenceKey: key, consentAt: new Date() } });
    await this.audit.log({ actorId: v.userId, action: "CONSENT_RECORDED", entity: "OnboardingApplication", entityId: app.id, after: { method } });
    return { ok: true };
  }

  @Post(":ref/submit")
  @HttpCode(200)
  @Auth("ADMIN", "SUPPORT", "SELLER_AGENT")
  async staffSubmit(@CurrentViewer() v: Viewer, @Param("ref") ref: string) {
    const app = await this.svc.byRef(ref);
    return { status: await this.svc.submit(app, v.userId) };
  }

  @Post(":ref/approve")
  @HttpCode(200)
  @Auth("ADMIN", "SUPPORT", "SELLER_AGENT")
  async approve(@CurrentViewer() v: Viewer, @Param("ref") ref: string, @Body() body: unknown) {
    const input = parse(z.object({ cnicLast4: z.string().regex(/^\d{4}$/).optional(), allowStaffListing: z.boolean().optional(), note: z.string().max(500).optional() }), body);
    return this.svc.approve(ref, v, input);
  }

  @Post(":ref/reject")
  @HttpCode(200)
  @Auth("ADMIN", "SUPPORT", "SELLER_AGENT")
  async reject(@CurrentViewer() v: Viewer, @Param("ref") ref: string, @Body() body: unknown) {
    const { reason } = parse(z.object({ reason: z.string().trim().min(5).max(500) }), body);
    await this.svc.reject(ref, v, reason);
    return { ok: true };
  }

  @Post(":ref/request-documents")
  @HttpCode(200)
  @Auth("ADMIN", "SUPPORT", "SELLER_AGENT")
  async requestDocs(@CurrentViewer() v: Viewer, @Param("ref") ref: string, @Body() body: unknown) {
    const { note, rejectDocumentIds } = parse(z.object({ note: z.string().trim().min(5).max(500), rejectDocumentIds: z.array(z.string()).default([]) }), body);
    await this.svc.requestDocs(ref, v, note, rejectDocumentIds);
    return { ok: true };
  }

  @Post(":ref/resend-activation")
  @HttpCode(200)
  @Auth("ADMIN", "SUPPORT", "SELLER_AGENT")
  async resend(@Param("ref") ref: string) {
    const app = await this.svc.byRef(ref);
    if (app.status !== "APPROVED") throw conflict("Only approved applications have an activation link.", "INVALID_STATE");
    const link = `${config().WEB_ORIGIN}/activate/${app.reference}`;
    await this.notifier.sendSms(app.phone, "ACTIVATION_RESENT", `Activate your ONEOFAKIND account: ${link}`, app.applicantUserId);
    return { link };
  }

  /** Restricted document read: role-checked and every access written to the audit log. */
  @Get("documents/:id")
  async document(@CurrentViewer() v: Viewer, @Param("id") id: string, @Res() res: Response) {
    this.svc.ensureStaffCanSeeDocs(v);
    const d = await this.prisma.onboardingDocument.findUnique({ where: { id } });
    if (!d || d.deletedAt) throw notFound("Document");
    const body = await this.storage.get(d.storageKey);
    if (!body) throw notFound("Document");
    await this.audit.log({ actorId: v.userId, action: "DOCUMENT_VIEWED", entity: "OnboardingDocument", entityId: d.id });
    const ext = d.storageKey.split(".").pop();
    res.setHeader("Cache-Control", "private, no-store");
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("Content-Security-Policy", "default-src 'none'; img-src 'self'; style-src 'unsafe-inline'; sandbox");
    res.type(ext === "pdf" ? "application/pdf" : ext === "svg" ? "image/svg+xml" : `image/${ext === "jpg" ? "jpeg" : ext}`).send(body);
  }

  @Get(":ref/consent-evidence")
  async consentFile(@CurrentViewer() v: Viewer, @Param("ref") ref: string, @Res() res: Response) {
    this.svc.ensureStaffCanSeeDocs(v);
    const app = await this.svc.byRef(ref);
    if (!app.consentEvidenceKey) throw notFound("Consent evidence");
    const body = await this.storage.get(app.consentEvidenceKey);
    if (!body) throw notFound("Consent evidence");
    await this.audit.log({ actorId: v.userId, action: "CONSENT_EVIDENCE_VIEWED", entity: "OnboardingApplication", entityId: app.id });
    const ext = app.consentEvidenceKey.split(".").pop();
    res.setHeader("Cache-Control", "private, no-store");
    res.setHeader("Content-Security-Policy", "default-src 'none'; style-src 'unsafe-inline'; sandbox");
    res.type(ext === "pdf" ? "application/pdf" : ext === "svg" ? "image/svg+xml" : `image/${ext === "jpg" ? "jpeg" : ext}`).send(body);
  }
}
