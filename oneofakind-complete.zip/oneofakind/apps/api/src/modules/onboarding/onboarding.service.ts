import { Injectable } from "@nestjs/common";
import type { OnboardingApplication, OnboardingDocKind, OnboardingKind, Prisma } from "@prisma/client";
import { applicationReference, idDocDeleteAfter, missingDocuments, normalizePkPhone, onboarding as onboardingMachine, type OnboardingState } from "@ooak/shared";
import { randomUUID } from "node:crypto";
import { AuditService } from "../../common/audit.service";
import type { Viewer } from "../../common/auth";
import { NotifierService } from "../../common/notifier.service";
import { PrismaService, type Tx } from "../../common/prisma.service";
import { badRequest, conflict, forbidden, notFound } from "../../common/problem";
import { StorageService } from "../../common/storage.service";
import { config } from "../../config";

export const OPEN_STATES = ["DRAFT", "SUBMITTED", "DOCS_REQUESTED", "UNDER_REVIEW"] as const;
const ASSISTED = new Set(["ASSISTED_WHATSAPP", "ASSISTED_PHONE", "ASSISTED_IN_PERSON"]);

const slugify = (s: string) => s.toLowerCase().replace(/['’]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 50) || "seller";

@Injectable()
export class OnboardingService {
  constructor(
    private readonly prisma: PrismaService, private readonly storage: StorageService,
    private readonly audit: AuditService, private readonly notifier: NotifierService,
  ) {}

  async newReference(kind: OnboardingKind, tx: Tx = this.prisma) {
    return applicationReference(kind, await this.prisma.nextval(kind === "SELLER" ? "seq_application_seller" : "seq_application_reseller", tx));
  }

  async byRef(reference: string) {
    const app = await this.prisma.onboardingApplication.findUnique({ where: { reference }, include: { documents: { where: { deletedAt: null }, orderBy: { receivedAt: "asc" } } } });
    if (!app) throw notFound("Application");
    return app;
  }

  assertOwner(app: OnboardingApplication, v: Viewer) {
    if (app.applicantUserId !== v.userId) throw notFound("Application");
  }

  /** Plain-words view for applicants (never exposes storage keys). */
  applicantView(app: OnboardingApplication & { documents: Array<{ id: string; kind: OnboardingDocKind; verifiedAt: Date | null; rejectedReason: string | null; receivedAt: Date }> }) {
    return {
      reference: app.reference, kind: app.kind, status: app.status, channel: app.channel, fullName: app.fullName, phone: app.phone, email: app.email, city: app.city,
      businessName: app.businessName, shopLink: app.shopLink, intendedSellerType: app.intendedSellerType, decisionNote: app.decisionNote, createdAt: app.createdAt,
      documents: app.documents.map((d) => ({ id: d.id, kind: d.kind, receivedAt: d.receivedAt, verified: !!d.verifiedAt, rejectedReason: d.rejectedReason })),
      missing: missingDocuments(app.kind, app.documents.filter((d) => !d.rejectedReason).map((d) => d.kind)),
    };
  }

  async storeDocument(appId: string, reference: string, kind: OnboardingDocKind, file: Buffer, mime: string, ext: string, via: "UPLOAD" | "WHATSAPP" | "EMAIL" | "IN_PERSON", uploadedById: string) {
    const key = `restricted/onboarding/${reference}/${kind}-${randomUUID()}.${ext}`;
    await this.storage.put(key, file, mime);
    // A re-upload of the same kind replaces the previous file (previous one deleted immediately).
    const prev = await this.prisma.onboardingDocument.findMany({ where: { applicationId: appId, kind, deletedAt: null } });
    for (const p of prev) { await this.storage.delete(p.storageKey); await this.prisma.onboardingDocument.update({ where: { id: p.id }, data: { deletedAt: new Date() } }); }
    return this.prisma.onboardingDocument.create({ data: { applicationId: appId, kind, storageKey: key, receivedVia: via, uploadedById } });
  }

  /** Applicant or staff submits. Assisted applications cannot be submitted without recorded consent. */
  async submit(app: OnboardingApplication & { documents: Array<{ kind: OnboardingDocKind; rejectedReason: string | null }> }, actorId: string) {
    if (!app.fullName.trim() || !normalizePkPhone(app.phone)) throw badRequest("Name and a valid mobile number are required.", "INCOMPLETE");
    if (ASSISTED.has(app.channel) && (!app.consentMethod || !app.consentEvidenceKey))
      throw conflict("Record how the applicant agreed to the terms and to being registered by us (method and evidence) before submitting.", "CONSENT_REQUIRED");
    const missing = missingDocuments(app.kind, app.documents.filter((d) => !d.rejectedReason).map((d) => d.kind));
    if (missing.length) throw conflict(`Missing documents: ${missing.join(", ")}`, "DOCUMENTS_MISSING");
    const to = app.status === "DOCS_REQUESTED" ? "UNDER_REVIEW" : "SUBMITTED";
    onboardingMachine.assert(app.status, to);
    await this.prisma.onboardingApplication.update({ where: { id: app.id }, data: { status: to } });
    await this.audit.log({ actorId, action: "APPLICATION_SUBMITTED", entity: "OnboardingApplication", entityId: app.id, after: { status: to } });
    return to;
  }

  async transition(appId: string, to: OnboardingState, actorId: string, data: Prisma.OnboardingApplicationUpdateInput = {}) {
    const app = await this.prisma.onboardingApplication.findUniqueOrThrow({ where: { id: appId } });
    onboardingMachine.assert(app.status, to);
    const updated = await this.prisma.onboardingApplication.update({ where: { id: appId }, data: { status: to, ...data } });
    await this.audit.log({ actorId, action: `APPLICATION_${to}`, entity: "OnboardingApplication", entityId: appId, before: { status: app.status }, after: { status: to } });
    return updated;
  }

  /**
   * Approve: creates (or reuses) the user, then a VERIFIED SellerProfile or a ResellerVerification + VERIFIED_RESELLER role.
   * Staff-created users stay unactivated until the person confirms their own phone by OTP.
   */
  async approve(reference: string, staff: Viewer, input: { cnicLast4?: string; allowStaffListing?: boolean; note?: string }) {
    const app = await this.byRef(reference);
    if (!["SUBMITTED", "UNDER_REVIEW"].includes(app.status)) throw conflict(`Application is ${app.status}; it can't be approved now.`, "INVALID_STATE");
    if (app.status === "SUBMITTED") await this.transition(app.id, "UNDER_REVIEW", staff.userId, { assignedToId: app.assignedToId ?? staff.userId });
    const phone = normalizePkPhone(app.phone)!;
    const now = new Date();
    const result = await this.prisma.$transaction(async (tx) => {
      let user = app.applicantUserId ? await tx.user.findUniqueOrThrow({ where: { id: app.applicantUserId } }) : await tx.user.findUnique({ where: { phone } });
      if (!user) {
        user = await tx.user.create({ data: { phone, name: app.fullName, email: app.email, roles: ["CUSTOMER"], createdByStaffId: staff.userId } });
      }
      if (app.kind === "SELLER") {
        if (await tx.sellerProfile.findUnique({ where: { userId: user.id } })) throw conflict("This person already has a seller account.", "ALREADY_SELLER");
        let slug = slugify(app.businessName || app.fullName);
        if (await tx.sellerProfile.findUnique({ where: { slug } })) slug = `${slug}-${app.reference.slice(-4)}`;
        await tx.sellerProfile.create({
          data: {
            userId: user.id, slug, displayName: app.businessName || app.fullName, type: app.intendedSellerType ?? "INDIVIDUAL", status: "VERIFIED", city: app.city,
            cnicLast4: input.cnicLast4 ?? null, applicationId: app.id, allowStaffListing: !!input.allowStaffListing && !!app.consentMethod,
          },
        });
        if (!user.roles.includes("SELLER")) await tx.user.update({ where: { id: user.id }, data: { roles: { push: "SELLER" } } });
      } else {
        await tx.resellerVerification.upsert({
          where: { userId: user.id },
          create: { userId: user.id, status: "VERIFIED", businessName: app.businessName || app.fullName, shopType: "BOTH", shopLink: app.shopLink, cnicLast4: input.cnicLast4 ?? null, applicationId: app.id, reviewedById: staff.userId, reviewedAt: now, decisionNote: input.note },
          update: { status: "VERIFIED", applicationId: app.id, reviewedById: staff.userId, reviewedAt: now, decisionNote: input.note, cnicLast4: input.cnicLast4 ?? undefined },
        });
        if (!user.roles.includes("VERIFIED_RESELLER")) await tx.user.update({ where: { id: user.id }, data: { roles: { push: "VERIFIED_RESELLER" } } });
      }
      onboardingMachine.assert("UNDER_REVIEW", "APPROVED");
      await tx.onboardingApplication.update({ where: { id: app.id }, data: { status: "APPROVED", applicantUserId: user.id, decidedById: staff.userId, decidedAt: now, decisionNote: input.note } });
      await tx.onboardingDocument.updateMany({ where: { applicationId: app.id, deletedAt: null }, data: { deleteAfter: idDocDeleteAfter(now), verifiedAt: now, verifiedById: staff.userId } });
      await this.audit.log({ actorId: staff.userId, onBehalfOfId: user.id, action: "APPLICATION_APPROVED", entity: "OnboardingApplication", entityId: app.id, after: { kind: app.kind } }, tx);
      return user;
    });
    const activateLink = `${config().WEB_ORIGIN}/activate/${app.reference}`;
    await this.notifier.sendSms(phone, "APPLICATION_APPROVED",
      result.activatedAt
        ? `Good news: your ONEOFAKIND ${app.kind === "SELLER" ? "seller" : "reseller"} application ${app.reference} is approved. Log in with your phone number.`
        : `Good news: your ONEOFAKIND ${app.kind === "SELLER" ? "seller" : "reseller"} application ${app.reference} is approved. Activate your account: ${activateLink}`, result.id);
    return { userId: result.id };
  }

  async reject(reference: string, staff: Viewer, reason: string) {
    const app = await this.byRef(reference);
    const now = new Date();
    await this.transition(app.id, "REJECTED", staff.userId, { decidedById: staff.userId, decidedAt: now, decisionNote: reason });
    await this.prisma.onboardingDocument.updateMany({ where: { applicationId: app.id, deletedAt: null }, data: { deleteAfter: idDocDeleteAfter(now) } });
    if (normalizePkPhone(app.phone)) await this.notifier.sendSms(app.phone, "APPLICATION_REJECTED", `Your ONEOFAKIND application ${app.reference} was not approved: ${reason}. You can apply again or message us on WhatsApp.`, app.applicantUserId);
  }

  /** Plain-words request for documents; applicant is told exactly which ones. */
  async requestDocs(reference: string, staff: Viewer, note: string, rejectDocIds: string[]) {
    const app = await this.byRef(reference);
    for (const id of rejectDocIds) {
      const d = app.documents.find((x) => x.id === id);
      if (d) await this.prisma.onboardingDocument.update({ where: { id }, data: { rejectedReason: "Unreadable or not accepted" } });
    }
    if (app.status === "SUBMITTED") await this.transition(app.id, "UNDER_REVIEW", staff.userId);
    await this.transition(app.id, "DOCS_REQUESTED", staff.userId, { decisionNote: note });
    if (normalizePkPhone(app.phone)) await this.notifier.sendSms(app.phone, "DOCS_REQUESTED", `ONEOFAKIND application ${app.reference}: ${note} Please upload them or send them on WhatsApp quoting your reference.`, app.applicantUserId);
  }

  /** Nightly retention: hard-delete document files past deleteAfter; keep the row (kind, outcome, dates) and last-4 on the profile. */
  async purgeExpiredDocuments(now = new Date()) {
    const due = await this.prisma.onboardingDocument.findMany({ where: { deleteAfter: { lte: now }, deletedAt: null } });
    for (const d of due) {
      await this.storage.delete(d.storageKey);
      await this.prisma.onboardingDocument.update({ where: { id: d.id }, data: { deletedAt: now } });
    }
    const consent = await this.prisma.onboardingApplication.findMany({ where: { consentEvidenceKey: { not: null }, decidedAt: { lte: new Date(now.getTime() - 90 * 86_400_000) } } });
    for (const a of consent) { await this.storage.delete(a.consentEvidenceKey!); await this.prisma.onboardingApplication.update({ where: { id: a.id }, data: { consentEvidenceKey: null } }); }
    return { documentsDeleted: due.length, consentEvidenceDeleted: consent.length };
  }

  /** Duplicate hints for reviewers: same phone across users/applications, same ID last-4. */
  async duplicates(app: OnboardingApplication) {
    const [apps, users] = await Promise.all([
      this.prisma.onboardingApplication.findMany({ where: { phone: app.phone, id: { not: app.id } }, select: { reference: true, status: true, kind: true } }),
      this.prisma.user.findMany({ where: { phone: app.phone, ...(app.applicantUserId ? { id: { not: app.applicantUserId } } : {}) }, select: { id: true, name: true, roles: true, disabledAt: true } }),
    ]);
    return { otherApplications: apps, existingUsers: users };
  }

  ensureStaffCanSeeDocs(v: Viewer) {
    if (!v.roles.some((r) => ["SUPPORT", "ADMIN", "SELLER_AGENT"].includes(r))) throw forbidden("Only onboarding, support and admin staff can open documents.");
  }
}
