import { Injectable, Logger, type OnApplicationBootstrap, type OnApplicationShutdown } from "@nestjs/common";
import { PrismaService } from "../common/prisma.service";
import { config } from "../config";
import { CheckoutService } from "./commerce/checkout.service";
import { FulfilmentService } from "./commerce/fulfilment.service";
import { OnboardingService } from "./onboarding/onboarding.service";
import { AiService } from "./ai/ai.service";

/**
 * Periodic sweeps. Each run takes a Postgres advisory lock, so any number of API instances can run this safely.
 * Disabled in tests (JOBS_ENABLED=false); tests call the service methods directly.
 */
@Injectable()
export class JobsService implements OnApplicationBootstrap, OnApplicationShutdown {
  private readonly log = new Logger("Jobs");
  private timers: NodeJS.Timeout[] = [];
  private lastPurgeDay = "";
  constructor(private readonly prisma: PrismaService, private readonly checkout: CheckoutService, private readonly fulfilment: FulfilmentService, private readonly onboarding: OnboardingService, private readonly ai: AiService) {}

  onApplicationBootstrap() {
    if (!config().JOBS_ENABLED) return;
    this.every(60_000, 7001, "reservations", () => this.checkout.expireReservations());
    this.every(5 * 60_000, 7002, "offers", () => this.expireOffers());
    this.every(10 * 60_000, 7003, "complete-delivered", () => this.fulfilment.completeDelivered());
    this.every(15_000, 7005, "ai-jobs", () => this.ai.processDue(5));
    this.every(60 * 60_000, 7004, "document-retention", async () => {
      const day = new Date().toISOString().slice(0, 10);
      if (day === this.lastPurgeDay) return 0;
      this.lastPurgeDay = day;
      const r = await this.onboarding.purgeExpiredDocuments();
      return r.documentsDeleted + r.consentEvidenceDeleted;
    });
  }
  onApplicationShutdown() { this.timers.forEach(clearInterval); }

  private every(ms: number, lockKey: number, name: string, fn: () => Promise<number>) {
    const run = async () => {
      try {
        const n = await this.prisma.withAdvisoryLock(lockKey, fn);
        if (n) this.log.log(`${name}: ${n}`);
      } catch (e) { this.log.error(`${name} failed: ${(e as Error).message}`); }
    };
    setTimeout(run, 2_000);
    this.timers.push(setInterval(run, ms));
  }

  async expireOffers(now = new Date()) {
    const r = await this.prisma.buyerOffer.updateMany({ where: { state: { in: ["PENDING", "ACCEPTED"] }, expiresAt: { lt: now } }, data: { state: "EXPIRED" } });
    const dp = await this.prisma.directPurchase.updateMany({ where: { state: "OFFER_MADE", offerExpiresAt: { lt: now } }, data: { state: "EXPIRED" } });
    return r.count + dp.count;
  }
}
