import { Injectable } from "@nestjs/common";
import type { ConditionGrade, Prisma } from "@prisma/client";
import { GRADE_LETTER, itemStock, listing as listingMachine, type ItemStockState, type ListingState } from "@ooak/shared";
import { z } from "zod";
import { AuditService } from "../../common/audit.service";
import { NotifierService } from "../../common/notifier.service";
import { PrismaService, type Tx } from "../../common/prisma.service";
import { badRequest, conflict, notFound, unprocessable } from "../../common/problem";
import { mediaUrl } from "../catalog/presenters";

export interface ActorCtx { actorId: string; sellerId: string; onBehalfOfId?: string | null }

const Defect = z.object({ type: z.string().trim().min(2).max(60), location: z.string().trim().min(2).max(60), severity: z.enum(["minor", "moderate", "major"]) });
export const ListingInput = z.object({
  title: z.string().trim().min(3).max(120),
  categoryId: z.string().min(1),
  brandName: z.string().trim().max(60).nullable().optional(),
  styleId: z.string().nullable().optional(),
  size: z.string().trim().max(30).nullable().optional(),
  color: z.string().trim().max(30).nullable().optional(),
  material: z.string().trim().max(120).nullable().optional(),
  measurements: z.record(z.string().max(30), z.number().positive().max(500)).optional(),
  conditionGrade: z.enum(["NEW_WITH_TAGS", "EXCELLENT", "VERY_GOOD", "GOOD", "FAIR"]),
  defects: z.array(Defect).max(12).optional(),
  description: z.string().trim().max(2000).nullable().optional(),
  priceMinor: z.number().int().min(10_000, "Minimum price is PKR 100").max(100_000_000),
  weightGrams: z.number().int().min(10).max(30_000).nullable().optional(),
});
export const ListingUpdate = ListingInput.partial();
export type ListingInputT = z.infer<typeof ListingInput>;

/** Fields whose change on a live listing sends it back to review (price/description edits stay live). */
const REVIEW_FIELDS = ["title", "categoryId", "brandName", "size", "color", "material", "measurements", "conditionGrade", "defects"] as const;
const MIN_PHOTOS = 2;
const slugify = (s: string) => s.toLowerCase().replace(/['’]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 70);

@Injectable()
export class ListingService {
  constructor(private readonly prisma: PrismaService, private readonly audit: AuditService, private readonly notifier: NotifierService) {}

  async brandId(name: string | null | undefined, tx: Tx = this.prisma): Promise<string | null> {
    if (!name) return null;
    const existing = await tx.brand.findFirst({ where: { name: { equals: name, mode: "insensitive" } } });
    if (existing) return existing.id;
    let slug = slugify(name) || "brand";
    if (await tx.brand.findUnique({ where: { slug } })) slug = `${slug}-${Date.now().toString(36)}`;
    return (await tx.brand.create({ data: { name, slug, verifiedBrand: false } })).id;
  }

  async newSku(tx: Tx = this.prisma) { return `OOAK-${String(await this.prisma.nextval("seq_item_sku", tx)).padStart(6, "0")}`; }

  private async ownedItem(itemId: string, sellerId: string) {
    const item = await this.prisma.item.findUnique({ where: { id: itemId }, include: { listings: { orderBy: { createdAt: "desc" }, take: 1 }, category: true } });
    if (!item || item.sellerId !== sellerId) throw notFound("Listing");
    return item;
  }

  async create(ctx: ActorCtx, input: ListingInputT) {
    const cat = await this.prisma.category.findUnique({ where: { id: input.categoryId } });
    if (!cat || !cat.enabled) throw badRequest("Choose a category.", "INVALID_CATEGORY");
    return this.prisma.$transaction(async (tx) => {
      const sku = await this.newSku(tx);
      const item = await tx.item.create({
        data: {
          sku, sellerId: ctx.sellerId, categoryId: input.categoryId, brandId: await this.brandId(input.brandName, tx), styleId: input.styleId ?? null,
          arrangement: "SELF_MANAGED", ownerType: "SELLER", stockState: "READY_TO_LIST", conditionGrade: input.conditionGrade, title: input.title,
          description: input.description ?? null, size: input.size ?? null, color: input.color ?? null, material: input.material ?? null,
          measurements: input.measurements ?? {}, priceMinor: input.priceMinor, weightGrams: input.weightGrams ?? null,
        },
      });
      await tx.conditionReport.create({ data: { itemId: item.id, grade: input.conditionGrade, defects: input.defects ?? [], source: "SELLER" } });
      const l = await tx.listing.create({ data: { itemId: item.id, sellerId: ctx.sellerId, slug: `${slugify(input.title)}-${sku.slice(5)}`, state: "DRAFT" } });
      await this.audit.log({ actorId: ctx.actorId, onBehalfOfId: ctx.onBehalfOfId, action: "LISTING_CREATED", entity: "Item", entityId: item.id, after: { sku } }, tx);
      return { itemId: item.id, listingId: l.id, sku };
    });
  }

  async update(ctx: ActorCtx, itemId: string, input: z.infer<typeof ListingUpdate>) {
    const item = await this.ownedItem(itemId, ctx.sellerId);
    const l = item.listings[0];
    if (!l || l.state === "REMOVED" || l.state === "SOLD_OUT") throw conflict("This listing can't be edited.", "NOT_EDITABLE");
    if (["RESERVED", "SOLD", "PACKED", "DISPATCHED", "DELIVERED"].includes(item.stockState)) throw conflict("A buyer is checking out or has bought this piece; it can't be edited now.", "ITEM_LOCKED");
    if (item.arrangement !== "SELF_MANAGED" && (input.measurements || input.conditionGrade || input.defects))
      throw conflict("Grade and measurements of managed pieces are set by our inspectors.", "MANAGED_FIELDS");
    const sendsToReview = l.state === "PUBLISHED" && REVIEW_FIELDS.some((f) => input[f] !== undefined);
    await this.prisma.$transaction(async (tx) => {
      const newBrandId = input.brandName !== undefined ? await this.brandId(input.brandName, tx) : undefined;
      const data: Prisma.ItemUpdateInput = {
        ...(input.title !== undefined ? { title: input.title } : {}), ...(input.description !== undefined ? { description: input.description } : {}),
        ...(input.size !== undefined ? { size: input.size } : {}), ...(input.color !== undefined ? { color: input.color } : {}),
        ...(input.material !== undefined ? { material: input.material } : {}), ...(input.measurements !== undefined ? { measurements: input.measurements } : {}),
        ...(input.conditionGrade !== undefined ? { conditionGrade: input.conditionGrade } : {}), ...(input.priceMinor !== undefined ? { priceMinor: input.priceMinor } : {}),
        ...(input.weightGrams !== undefined ? { weightGrams: input.weightGrams } : {}), ...(input.styleId !== undefined ? { style: input.styleId ? { connect: { id: input.styleId } } : { disconnect: true } } : {}),
        ...(input.categoryId !== undefined ? { category: { connect: { id: input.categoryId } } } : {}),
        ...(newBrandId !== undefined ? (newBrandId ? { brand: { connect: { id: newBrandId } } } : { brand: { disconnect: true } }) : {}),
        version: { increment: 1 },
      };
      await tx.item.update({ where: { id: itemId }, data });
      if (input.conditionGrade !== undefined || input.defects !== undefined) {
        await tx.conditionReport.create({ data: { itemId, grade: input.conditionGrade ?? item.conditionGrade!, defects: input.defects ?? [], source: "SELLER" } });
      }
      if (sendsToReview) { listingMachine.assert(l.state as ListingState, "PENDING_REVIEW"); await tx.listing.update({ where: { id: l.id }, data: { state: "PENDING_REVIEW" } }); }
      await this.audit.log({ actorId: ctx.actorId, onBehalfOfId: ctx.onBehalfOfId, action: "LISTING_EDITED", entity: "Item", entityId: itemId, before: { priceMinor: item.priceMinor }, after: input }, tx);
    });
    return { sentToReview: sendsToReview };
  }

  /** Readiness check shown in the UI and enforced on submit. */
  async readiness(itemId: string) {
    const item = await this.prisma.item.findUniqueOrThrow({ where: { id: itemId }, include: { category: true, media: { where: { deletedAt: null, kind: { in: ["ORIGINAL", "EDITED", "BACKGROUND_REMOVED"] } } }, conditionReports: { orderBy: { createdAt: "desc" }, take: 1 } } });
    const problems: string[] = [];
    if (item.media.length < MIN_PHOTOS) problems.push(`Add at least ${MIN_PHOTOS} photos (4 is best: front, back, label, any marks).`);
    const required = ((item.category.attributeSchema as { measurements?: string[] } | null)?.measurements ?? []);
    const m = (item.measurements ?? {}) as Record<string, number>;
    const missing = required.filter((k) => typeof m[k] !== "number");
    if (missing.length) problems.push(`Add measurements: ${missing.map((k) => k.replace(/_cm$/, "").replace(/_/g, " ")).join(", ")}.`);
    if (!item.conditionGrade) problems.push("Choose a condition grade.");
    const letter = item.conditionGrade ? GRADE_LETTER[item.conditionGrade] : null;
    const defects = (item.conditionReports[0]?.defects as unknown[] | null) ?? [];
    if ((letter === "C" || letter === "D") && !defects.length) problems.push("Grade C and D pieces must list their flaws.");
    if (item.priceMinor <= 0) problems.push("Set a price.");
    return problems;
  }

  async submit(ctx: ActorCtx, itemId: string) {
    const item = await this.ownedItem(itemId, ctx.sellerId);
    const l = item.listings[0];
    if (!l) throw notFound("Listing");
    const problems = await this.readiness(itemId);
    if (problems.length) throw unprocessable(problems.join(" "), "NOT_READY", { problems });
    listingMachine.assert(l.state as ListingState, "PENDING_REVIEW");
    await this.prisma.listing.update({ where: { id: l.id }, data: { state: "PENDING_REVIEW" } });
    await this.audit.log({ actorId: ctx.actorId, onBehalfOfId: ctx.onBehalfOfId, action: "LISTING_SUBMITTED", entity: "Listing", entityId: l.id });
  }

  async setState(ctx: ActorCtx, itemId: string, to: "PAUSED" | "PUBLISHED" | "REMOVED") {
    const item = await this.ownedItem(itemId, ctx.sellerId);
    const l = item.listings[0];
    if (!l) throw notFound("Listing");
    if (to === "PUBLISHED" && l.state !== "PAUSED") throw conflict("Only paused listings can be resumed. New listings go through review.", "INVALID_STATE");
    if (["RESERVED", "SOLD", "PACKED", "DISPATCHED", "DELIVERED"].includes(item.stockState)) throw conflict("A buyer is checking out or has bought this piece.", "ITEM_LOCKED");
    listingMachine.assert(l.state as ListingState, to);
    await this.prisma.$transaction(async (tx) => {
      await tx.listing.update({ where: { id: l.id }, data: { state: to } });
      if (to === "REMOVED" && ["AVAILABLE", "READY_TO_LIST"].includes(item.stockState)) {
        itemStock.assert(item.stockState as ItemStockState, "WITHDRAWN");
        await tx.item.update({ where: { id: itemId }, data: { stockState: "WITHDRAWN", version: { increment: 1 } } });
      }
      await this.audit.log({ actorId: ctx.actorId, onBehalfOfId: ctx.onBehalfOfId, action: `LISTING_${to}`, entity: "Listing", entityId: l.id, before: { state: l.state } }, tx);
    });
  }

  // ── Moderation (staff) ──
  async approve(listingId: string, moderatorId: string, note?: string) {
    const l = await this.prisma.listing.findUnique({ where: { id: listingId }, include: { item: true, seller: true } });
    if (!l) throw notFound("Listing");
    listingMachine.assert(l.state as ListingState, "PUBLISHED");
    await this.prisma.$transaction(async (tx) => {
      if (l.item.stockState === "READY_TO_LIST") { itemStock.assert("READY_TO_LIST", "AVAILABLE"); await tx.item.update({ where: { id: l.itemId }, data: { stockState: "AVAILABLE", version: { increment: 1 } } }); }
      else if (l.item.stockState !== "AVAILABLE") throw conflict(`Item is ${l.item.stockState}; it can't be published.`, "ITEM_NOT_LISTABLE");
      if (l.item.channel !== "RETAIL") throw conflict("This piece is reserved for a bundle.", "CHANNEL_CONFLICT");
      if (l.item.arrangement === "DIRECT_PURCHASE" && l.item.ownerType !== "PLATFORM") throw conflict("A direct-purchase piece can only be listed after ownership transfer.", "NOT_TRANSFERRED");
      await tx.mediaAsset.updateMany({ where: { itemId: l.itemId, deletedAt: null, useInListing: true, kind: { in: ["ORIGINAL", "EDITED", "BACKGROUND_REMOVED", "ASSET_3D"] } }, data: { approvedForPublish: true, visibility: "PUBLIC" } });
      await tx.listing.update({ where: { id: listingId }, data: { state: "PUBLISHED", publishedAt: l.publishedAt ?? new Date(), moderatedById: moderatorId, moderationNote: note ?? null } });
      await this.audit.log({ actorId: moderatorId, action: "LISTING_APPROVED", entity: "Listing", entityId: listingId }, tx);
    });
    await this.notifier.inApp(l.seller.userId, "LISTING_APPROVED", `“${l.item.title}” is now live.`);
  }

  async requestChanges(listingId: string, moderatorId: string, note: string) {
    const l = await this.prisma.listing.findUnique({ where: { id: listingId }, include: { item: true, seller: true } });
    if (!l) throw notFound("Listing");
    listingMachine.assert(l.state as ListingState, "CHANGES_REQUESTED");
    await this.prisma.listing.update({ where: { id: listingId }, data: { state: "CHANGES_REQUESTED", moderatedById: moderatorId, moderationNote: note } });
    await this.audit.log({ actorId: moderatorId, action: "LISTING_CHANGES_REQUESTED", entity: "Listing", entityId: listingId, after: { note } });
    await this.notifier.inApp(l.seller.userId, "LISTING_CHANGES", `“${l.item.title}” needs changes: ${note}`);
  }

  async moderatorRemove(listingId: string, moderatorId: string, note: string) {
    const l = await this.prisma.listing.findUnique({ where: { id: listingId }, include: { item: true, seller: true } });
    if (!l) throw notFound("Listing");
    if (["RESERVED", "SOLD", "PACKED", "DISPATCHED", "DELIVERED"].includes(l.item.stockState)) throw conflict("This piece is in an order; handle it through the order.", "ITEM_LOCKED");
    listingMachine.assert(l.state as ListingState, "REMOVED");
    await this.prisma.$transaction(async (tx) => {
      await tx.listing.update({ where: { id: listingId }, data: { state: "REMOVED", moderatedById: moderatorId, moderationNote: note } });
      if (l.item.stockState === "AVAILABLE" || l.item.stockState === "READY_TO_LIST") await tx.item.update({ where: { id: l.itemId }, data: { stockState: "WITHDRAWN" } });
      await this.audit.log({ actorId: moderatorId, action: "LISTING_REMOVED_BY_MODERATOR", entity: "Listing", entityId: listingId, after: { note } }, tx);
    });
    await this.notifier.inApp(l.seller.userId, "LISTING_REMOVED", `“${l.item.title}” was removed: ${note}`);
  }

  /** Seller-portal view of one item (any state), including private photos. */
  async sellerView(itemId: string, sellerId: string) {
    const item = await this.prisma.item.findUnique({
      where: { id: itemId },
      include: {
        listings: { orderBy: { createdAt: "desc" }, take: 1 }, brand: true, category: true, style: true, location: true,
        media: { where: { deletedAt: null }, orderBy: [{ position: "asc" }, { createdAt: "asc" }] },
        conditionReports: { orderBy: { createdAt: "desc" }, take: 1 },
        bundleLinks: { where: { releasedAt: null }, include: { bundle: { select: { slug: true, title: true, state: true } } } },
        custodyEvents: { orderBy: { createdAt: "asc" } },
        scanCodes: { where: { voidedAt: null }, select: { code: true, kind: true } },
      },
    });
    if (!item || item.sellerId !== sellerId) throw notFound("Listing");
    const l = item.listings[0];
    return {
      id: item.id, sku: item.sku, title: item.title, description: item.description, size: item.size, color: item.color, material: item.material,
      measurements: item.measurements, conditionGrade: item.conditionGrade as ConditionGrade | null, defects: item.conditionReports[0]?.defects ?? [],
      priceMinor: item.priceMinor, weightGrams: item.weightGrams, arrangement: item.arrangement, ownerType: item.ownerType, stockState: item.stockState, channel: item.channel,
      category: { id: item.category.id, name: item.category.name, slug: item.category.slug, attributeSchema: item.category.attributeSchema },
      brandName: item.brand?.name ?? null, styleId: item.styleId, location: item.location?.code ?? null,
      listing: l ? { id: l.id, slug: l.slug, state: l.state, moderationNote: l.moderationNote, publishedAt: l.publishedAt } : null,
      photos: item.media.map((m) => ({ id: m.id, url: mediaUrl(m.id), kind: m.kind, aiLabel: m.aiLabel, approved: m.approvedForPublish, position: m.position, sourceAssetId: m.sourceAssetId })),
      bundle: item.bundleLinks[0]?.bundle ?? null, custody: item.custodyEvents, labelCode: item.scanCodes.find((s) => s.kind === "ITEM_PACK")?.code ?? null,
      readiness: l && ["DRAFT", "CHANGES_REQUESTED"].includes(l.state) ? await this.readiness(item.id) : [],
    };
  }
}
