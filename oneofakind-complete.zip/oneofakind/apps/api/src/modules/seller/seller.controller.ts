import { Body, Controller, Delete, Get, HttpCode, Param, Patch, Post, Put, Query, Res, UploadedFile, UseInterceptors } from "@nestjs/common";
import type { Response } from "express";
import { canActOnBehalf, type OnBehalfAction, type ViewerRole } from "@ooak/shared";
import { z } from "zod";
import { AuditService } from "../../common/audit.service";
import { Auth, CurrentViewer, requireSeller, type Viewer } from "../../common/auth";
import { MediaService } from "../../common/media.service";
import { NotifierService } from "../../common/notifier.service";
import { PrismaService } from "../../common/prisma.service";
import { conflict, forbidden, notFound, parse } from "../../common/problem";
import { SingleUpload, type UploadedFileT } from "../../common/upload";
import { OtpService } from "../auth/otp.service";
import { BundleInput, BundleService } from "../bundles/bundle.service";
import { mediaUrl } from "../catalog/presenters";
import { CodesService } from "../codes/codes.service";
import { itemLabelsPdf } from "../codes/labels";
import { type ActorCtx, ListingInput, ListingService, ListingUpdate } from "./listing.service";

const MAX_PHOTOS = 12;

/** Shared helpers between the seller's own portal and staff acting on their behalf. */
export async function photosUpload(prisma: PrismaService, media: MediaService, itemId: string, sellerId: string, file: UploadedFileT, ownerUserId: string) {
  const item = await prisma.item.findUnique({ where: { id: itemId }, include: { _count: { select: { media: { where: { deletedAt: null } } } } } });
  if (!item || item.sellerId !== sellerId) throw notFound("Listing");
  if (item._count.media >= MAX_PHOTOS) throw conflict(`Up to ${MAX_PHOTOS} photos per piece.`, "TOO_MANY_PHOTOS");
  if (item.arrangement !== "SELF_MANAGED" && item.stockState !== "EXPECTED") throw conflict("Photos of managed pieces are taken by our studio.", "MANAGED_FIELDS");
  const m = await media.saveItemPhoto(itemId, file, { ownerUserId });
  // A new photo on a live listing needs moderation before it becomes public (it stays private until approved).
  return { id: m.id, url: mediaUrl(m.id), approved: false };
}

export async function labelsPdf(prisma: PrismaService, codes: CodesService, sellerId: string | null, itemIds: string[], format: "thermal" | "a4", actorId: string) {
  const items = await prisma.item.findMany({ where: { id: { in: itemIds }, ...(sellerId ? { sellerId } : {}) }, include: { brand: true } });
  if (items.length !== new Set(itemIds).size) throw notFound("Some items");
  const issued = [];
  for (const it of items) issued.push({ it, code: await codes.issue("ITEM_PACK", { itemId: it.id }, actorId) });
  await codes.markPrinted(issued.map((x) => x.code), actorId);
  return itemLabelsPdf(issued.map(({ it, code }) => ({ code: code.code, sku: it.sku, brand: it.brand?.name ?? null, size: it.size, title: it.title })), format);
}

const ListQuery = z.object({
  state: z.string().max(40).optional(), q: z.string().max(80).optional(), arrangement: z.enum(["SELF_MANAGED", "MANAGED_RESALE", "DIRECT_PURCHASE"]).optional(),
  cursor: z.string().optional(), limit: z.coerce.number().int().min(1).max(100).default(50),
});

@Controller("seller")
@Auth("SELLER")
export class SellerController {
  constructor(
    private readonly prisma: PrismaService, private readonly listings: ListingService, private readonly media: MediaService, private readonly codes: CodesService,
    private readonly bundles: BundleService, private readonly otp: OtpService, private readonly audit: AuditService, private readonly notifier: NotifierService,
  ) {}

  private ctx(v: Viewer): ActorCtx { return { actorId: v.userId, sellerId: requireSeller(v) }; }

  @Get("dashboard")
  async dashboard(@CurrentViewer() v: Viewer) {
    const sellerId = requireSeller(v);
    const monthStart = new Date(new Date().getFullYear(), new Date().getMonth(), 1);
    const [byListing, toShip, soldMonth, payable, profile, notes, offers] = await Promise.all([
      this.prisma.listing.groupBy({ by: ["state"], where: { sellerId }, _count: true }),
      this.prisma.fulfilmentGroup.count({ where: { sellerId, state: { in: ["PAID", "PROCESSING"] }, mode: "SELLER_ARRANGED" } }),
      this.prisma.orderItem.aggregate({ where: { group: { sellerId, order: { paidAt: { gte: monthStart } } } }, _sum: { priceMinor: true }, _count: true }),
      this.prisma.ledgerAccount.findFirst({ where: { type: "SELLER_PAYABLE", ownerRef: sellerId }, include: { entries: { select: { debitMinor: true, creditMinor: true } } } }),
      this.prisma.sellerProfile.findUniqueOrThrow({ where: { id: sellerId } }),
      this.prisma.notification.findMany({ where: { userId: v.userId, channel: "IN_APP" }, orderBy: { createdAt: "desc" }, take: 8 }),
      this.prisma.buyerOffer.count({ where: { item: { sellerId }, state: "PENDING", expiresAt: { gt: new Date() } } }),
    ]);
    const count = (s: string) => byListing.find((x) => x.state === s)?._count ?? 0;
    const balance = payable ? payable.entries.reduce((a, e) => a + e.creditMinor - e.debitMinor, 0) : 0;
    return {
      seller: { displayName: profile.displayName, slug: profile.slug, status: profile.status, payoutVerified: !!profile.payoutVerifiedAt, allowStaffListing: profile.allowStaffListing },
      listings: { live: count("PUBLISHED"), drafts: count("DRAFT") + count("CHANGES_REQUESTED"), inReview: count("PENDING_REVIEW"), changesRequested: count("CHANGES_REQUESTED"), paused: count("PAUSED") },
      ordersToShip: toShip, pendingOffers: offers, soldThisMonth: { count: soldMonth._count, grossMinor: soldMonth._sum.priceMinor ?? 0 }, payableBalanceMinor: balance,
      notifications: notes.map((n) => ({ id: n.id, body: n.body, createdAt: n.createdAt, read: !!n.readAt })),
    };
  }

  @Get("listings")
  async list(@CurrentViewer() v: Viewer, @Query() query: unknown) {
    const sellerId = requireSeller(v);
    const q = parse(ListQuery, query);
    const rows = await this.prisma.item.findMany({
      where: {
        sellerId, ...(q.arrangement ? { arrangement: q.arrangement } : {}),
        ...(q.state ? (q.state === "BUNDLED" ? { channel: "BUNDLE" } : { listings: { some: { state: q.state as never } } }) : {}),
        ...(q.q ? { OR: [{ title: { contains: q.q, mode: "insensitive" } }, { sku: { contains: q.q, mode: "insensitive" } }] } : {}),
      },
      orderBy: [{ createdAt: "desc" }, { id: "desc" }], take: q.limit + 1, ...(q.cursor ? { cursor: { id: q.cursor }, skip: 1 } : {}),
      include: { listings: { orderBy: { createdAt: "desc" }, take: 1 }, media: { where: { deletedAt: null }, orderBy: { position: "asc" }, take: 1 }, brand: true, category: true, scanCodes: { where: { kind: "ITEM_PACK", voidedAt: null }, select: { code: true } } },
    });
    const page = rows.slice(0, q.limit);
    return {
      items: page.map((i) => ({
        id: i.id, sku: i.sku, title: i.title, brand: i.brand?.name ?? null, category: i.category.name, size: i.size, priceMinor: i.priceMinor, arrangement: i.arrangement, ownerType: i.ownerType,
        stockState: i.stockState, channel: i.channel, listingState: i.listings[0]?.state ?? null, listingSlug: i.listings[0]?.slug ?? null, moderationNote: i.listings[0]?.moderationNote ?? null,
        photo: i.media[0] ? mediaUrl(i.media[0].id) : null, labelCode: i.scanCodes[0]?.code ?? null, createdAt: i.createdAt,
      })),
      nextCursor: rows.length > q.limit ? page[page.length - 1]!.id : null,
    };
  }

  @Post("listings")
  create(@CurrentViewer() v: Viewer, @Body() body: unknown) { return this.listings.create(this.ctx(v), parse(ListingInput, body)); }

  @Get("listings/:id")
  get(@CurrentViewer() v: Viewer, @Param("id") id: string) { return this.listings.sellerView(id, requireSeller(v)); }

  @Patch("listings/:id")
  update(@CurrentViewer() v: Viewer, @Param("id") id: string, @Body() body: unknown) { return this.listings.update(this.ctx(v), id, parse(ListingUpdate, body)); }

  @Post("listings/:id/submit") @HttpCode(200)
  async submit(@CurrentViewer() v: Viewer, @Param("id") id: string) { await this.listings.submit(this.ctx(v), id); return this.listings.sellerView(id, v.sellerId!); }

  @Post("listings/:id/pause") @HttpCode(200)
  async pause(@CurrentViewer() v: Viewer, @Param("id") id: string) { await this.listings.setState(this.ctx(v), id, "PAUSED"); return { ok: true }; }

  @Post("listings/:id/resume") @HttpCode(200)
  async resume(@CurrentViewer() v: Viewer, @Param("id") id: string) { await this.listings.setState(this.ctx(v), id, "PUBLISHED"); return { ok: true }; }

  @Post("listings/:id/remove") @HttpCode(200)
  async remove(@CurrentViewer() v: Viewer, @Param("id") id: string) { await this.listings.setState(this.ctx(v), id, "REMOVED"); return { ok: true }; }

  @Post("listings/:id/photos")
  @UseInterceptors(SingleUpload())
  photo(@CurrentViewer() v: Viewer, @Param("id") id: string, @UploadedFile() file: UploadedFileT) { return photosUpload(this.prisma, this.media, id, requireSeller(v), file, v.userId); }

  @Delete("listings/:id/photos/:mediaId")
  async deletePhoto(@CurrentViewer() v: Viewer, @Param("id") id: string, @Param("mediaId") mediaId: string) {
    const sellerId = requireSeller(v);
    const m = await this.prisma.mediaAsset.findUnique({ where: { id: mediaId }, include: { item: true } });
    if (!m || m.itemId !== id || m.item?.sellerId !== sellerId) throw notFound("Photo");
    if (m.item.arrangement !== "SELF_MANAGED") throw conflict("Photos of managed pieces are managed by our studio.", "MANAGED_FIELDS");
    await this.prisma.mediaAsset.update({ where: { id: mediaId }, data: { deletedAt: new Date() } });
    return { ok: true };
  }

  @Put("listings/:id/photos/order")
  async reorder(@CurrentViewer() v: Viewer, @Param("id") id: string, @Body() body: unknown) {
    const sellerId = requireSeller(v);
    const { ids } = parse(z.object({ ids: z.array(z.string()).max(MAX_PHOTOS) }), body);
    const item = await this.prisma.item.findUnique({ where: { id } });
    if (!item || item.sellerId !== sellerId) throw notFound("Listing");
    await this.prisma.$transaction(ids.map((mid, i) => this.prisma.mediaAsset.updateMany({ where: { id: mid, itemId: id }, data: { position: i } })));
    return { ok: true };
  }

  @Get("inventory")
  async inventory(@CurrentViewer() v: Viewer, @Query() query: unknown, @Res({ passthrough: true }) res: Response) {
    const sellerId = requireSeller(v);
    const { format, arrangement } = parse(z.object({ format: z.enum(["json", "csv"]).default("json"), arrangement: z.string().optional() }), query);
    const items = await this.prisma.item.findMany({
      where: { sellerId, ...(arrangement ? { arrangement: arrangement as never } : {}) }, orderBy: { createdAt: "desc" },
      include: { location: true, brand: true, category: true, listings: { orderBy: { createdAt: "desc" }, take: 1 } },
    });
    const rows = items.map((i) => ({ sku: i.sku, title: i.title, brand: i.brand?.name ?? "", category: i.category.name, size: i.size ?? "", arrangement: i.arrangement, owner: i.ownerType, stockState: i.stockState, listing: i.listings[0]?.state ?? "", channel: i.channel, priceMinor: i.priceMinor, location: i.location?.code ?? "", createdAt: i.createdAt.toISOString() }));
    if (format === "csv") {
      res.setHeader("Content-Type", "text/csv; charset=utf-8");
      res.setHeader("Content-Disposition", `attachment; filename="inventory.csv"`);
      const esc = (x: unknown) => `"${String(x).replace(/"/g, '""')}"`;
      const head = Object.keys(rows[0] ?? { sku: "" });
      return [head.join(","), ...rows.map((r) => head.map((h) => esc((r as Record<string, unknown>)[h])).join(","))].join("\n");
    }
    const summary = items.reduce<Record<string, number>>((a, i) => { a[i.stockState] = (a[i.stockState] ?? 0) + 1; return a; }, {});
    return { items: rows, summary };
  }

  /** Item labels (barcode + QR) - thermal 50×30 mm or an A4 sheet. Idempotent: same item ⇒ same code. */
  @Post("labels") @HttpCode(200)
  async labels(@CurrentViewer() v: Viewer, @Body() body: unknown, @Res() res: Response) {
    const { itemIds, format } = parse(z.object({ itemIds: z.array(z.string()).min(1).max(240), format: z.enum(["thermal", "a4"]).default("thermal") }), body);
    const pdf = await labelsPdf(this.prisma, this.codes, requireSeller(v), itemIds, format, v.userId);
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", `inline; filename="labels-${format}.pdf"`);
    res.setHeader("Cache-Control", "no-store");
    res.send(Buffer.from(pdf));
  }

  @Get("storefront")
  async storefront(@CurrentViewer() v: Viewer) {
    const s = await this.prisma.sellerProfile.findUniqueOrThrow({ where: { id: requireSeller(v) } });
    return { slug: s.slug, displayName: s.displayName, bio: s.bio, city: s.city, type: s.type };
  }

  @Patch("storefront")
  async updateStorefront(@CurrentViewer() v: Viewer, @Body() body: unknown) {
    const input = parse(z.object({ displayName: z.string().trim().min(2).max(60).optional(), bio: z.string().trim().max(600).nullable().optional(), city: z.string().trim().max(60).optional() }), body);
    await this.prisma.sellerProfile.update({ where: { id: requireSeller(v) }, data: input });
    await this.audit.log({ actorId: v.userId, action: "STOREFRONT_UPDATED", entity: "SellerProfile", entityId: v.sellerId!, after: input });
    return this.storefront(v);
  }

  @Get("settings")
  async settings(@CurrentViewer() v: Viewer) {
    const s = await this.prisma.sellerProfile.findUniqueOrThrow({ where: { id: requireSeller(v) } });
    return { payoutMethod: s.payoutMethod, payoutAccountTitle: s.payoutAccountTitle, payoutVerifiedAt: s.payoutVerifiedAt, allowStaffListing: s.allowStaffListing, cnicLast4: s.cnicLast4 };
  }

  /** Payout details: the seller's OWN confirmation code is required, and staff must re-verify the own-name account before any payout. */
  @Post("settings/payout") @HttpCode(200)
  async payout(@CurrentViewer() v: Viewer, @Body() body: unknown) {
    const sellerId = requireSeller(v);
    const input = parse(z.object({
      code: z.string().length(6), kind: z.enum(["BANK", "WALLET"]), provider: z.string().trim().min(2).max(60),
      accountTitle: z.string().trim().min(3).max(100), accountNumber: z.string().trim().regex(/^[A-Z0-9 ]{6,34}$/i, "Enter a valid account number or IBAN"),
    }), body);
    await this.otp.confirmOwnAction(v.phone, input.code);
    const masked = `****${input.accountNumber.replace(/\s/g, "").slice(-4)}`;
    await this.prisma.sellerProfile.update({ where: { id: sellerId }, data: { payoutMethod: { kind: input.kind, bank: input.provider, accountMasked: masked }, payoutAccountTitle: input.accountTitle, payoutVerifiedAt: null, payoutVerifiedById: null } });
    await this.audit.log({ actorId: v.userId, action: "PAYOUT_DETAILS_CHANGED", entity: "SellerProfile", entityId: sellerId, after: { kind: input.kind, provider: input.provider, accountMasked: masked } });
    return { ok: true, payoutVerified: false, message: "Saved. Our team will check that the account is in your own name before your next payout." };
  }

  @Patch("settings")
  async updateSettings(@CurrentViewer() v: Viewer, @Body() body: unknown) {
    const { allowStaffListing } = parse(z.object({ allowStaffListing: z.boolean() }), body);
    await this.prisma.sellerProfile.update({ where: { id: requireSeller(v) }, data: { allowStaffListing } });
    await this.audit.log({ actorId: v.userId, action: allowStaffListing ? "STAFF_LISTING_CONSENT_GIVEN" : "STAFF_LISTING_CONSENT_WITHDRAWN", entity: "SellerProfile", entityId: v.sellerId! });
    return { allowStaffListing };
  }

  /** Activity feed, including everything our team did on the seller's behalf ("Created by ONEOFAKIND team for you"). */
  @Get("activity")
  async activity(@CurrentViewer() v: Viewer) {
    const sellerId = requireSeller(v);
    const itemIds = (await this.prisma.item.findMany({ where: { sellerId }, select: { id: true } })).map((i) => i.id);
    const logs = await this.prisma.auditLog.findMany({
      where: { OR: [{ onBehalfOfId: v.userId }, { actorId: v.userId }, { entity: "Item", entityId: { in: itemIds } }] },
      orderBy: { createdAt: "desc" }, take: 100, include: { actor: { select: { name: true } } },
    });
    return { events: logs.map((l) => ({ id: l.id, action: l.action, entity: l.entity, entityId: l.entityId, at: l.createdAt, byTeam: !!l.onBehalfOfId && l.actorId !== v.userId, actor: l.actorId === v.userId ? "You" : l.onBehalfOfId ? "ONEOFAKIND team" : l.actor?.name ?? "System" })) };
  }

  @Post("notifications/read") @HttpCode(200)
  async read(@CurrentViewer() v: Viewer) {
    await this.prisma.notification.updateMany({ where: { userId: v.userId, readAt: null }, data: { readAt: new Date() } });
    return { ok: true };
  }

  // ── Bundles builder ──
  @Get("bundles") bundlesList(@CurrentViewer() v: Viewer) { return this.bundles.listForSeller(requireSeller(v)).then((bundles) => ({ bundles })); }

  @Get("bundles/eligible")
  async eligible(@CurrentViewer() v: Viewer, @Query() query: unknown) {
    const { brandId, styleId } = parse(z.object({ brandId: z.string(), styleId: z.string() }), query);
    const tiers = await this.prisma.bundleTier.findMany({ where: { active: true }, orderBy: { size: "asc" } });
    return { items: await this.bundles.eligible(requireSeller(v), brandId, styleId), sizes: tiers.map((t) => t.size) };
  }

  /** Brand/style combinations where this seller has enough eligible pieces. */
  @Get("bundles/options")
  async options(@CurrentViewer() v: Viewer) {
    const sellerId = requireSeller(v);
    const rows = await this.prisma.item.groupBy({
      by: ["brandId", "styleId"],
      where: { sellerId, ownerType: "SELLER", brandId: { not: null }, styleId: { not: null }, stockState: { in: ["READY_TO_LIST", "AVAILABLE"] }, conditionGrade: { in: ["NEW_WITH_TAGS", "EXCELLENT", "VERY_GOOD"] }, bundleLinks: { none: { releasedAt: null } }, listings: { none: { state: "PUBLISHED" } } },
      _count: true,
    });
    const [brands, styles] = await Promise.all([
      this.prisma.brand.findMany({ where: { id: { in: rows.map((r) => r.brandId!) } } }),
      this.prisma.styleTag.findMany({ where: { id: { in: rows.map((r) => r.styleId!) } } }),
    ]);
    return { options: rows.map((r) => ({ brandId: r.brandId, styleId: r.styleId, brand: brands.find((b) => b.id === r.brandId)?.name, style: styles.find((s) => s.id === r.styleId)?.name, eligibleCount: r._count })).sort((a, b) => b.eligibleCount - a.eligibleCount) };
  }

  @Post("bundles")
  createBundle(@CurrentViewer() v: Viewer, @Body() body: unknown) { return this.bundles.create({ actorId: v.userId, sellerId: requireSeller(v) }, parse(BundleInput, body)); }

  @Post("bundles/:id/submit") @HttpCode(200)
  bundleSubmit(@CurrentViewer() v: Viewer, @Param("id") id: string) { return this.bundleState(v, id, "submit"); }
  @Post("bundles/:id/pause") @HttpCode(200)
  bundlePause(@CurrentViewer() v: Viewer, @Param("id") id: string) { return this.bundleState(v, id, "pause"); }
  @Post("bundles/:id/resume") @HttpCode(200)
  bundleResume(@CurrentViewer() v: Viewer, @Param("id") id: string) { return this.bundleState(v, id, "resume"); }
  @Post("bundles/:id/remove") @HttpCode(200)
  bundleRemove(@CurrentViewer() v: Viewer, @Param("id") id: string) { return this.bundleState(v, id, "remove"); }

  private async bundleState(v: Viewer, id: string, action: string) {
    const b = await this.prisma.bundle.findUnique({ where: { id } });
    const to = action === "submit" ? "PENDING_REVIEW" : action === "pause" ? "PAUSED" : action === "resume" ? "PUBLISHED" : "REMOVED";
    if (action === "resume" && b?.state !== "PAUSED") throw conflict("Only paused lots can be resumed.", "INVALID_STATE");
    await this.bundles.transition(id, to, v.userId, { sellerId: requireSeller(v) });
    return { ok: true };
  }

  /** Earnings from the ledger: what's payable now (past the 7-day hold after delivery), what's still on hold, and payouts. */
  @Get("earnings")
  async earnings(@CurrentViewer() v: Viewer) {
    const sellerId = requireSeller(v);
    const acct = await this.prisma.ledgerAccount.findFirst({ where: { type: "SELLER_PAYABLE", ownerRef: sellerId } });
    const entries = acct ? await this.prisma.ledgerEntry.findMany({ where: { accountId: acct.id }, orderBy: { createdAt: "desc" }, take: 300 }) : [];
    const orderItemIds = entries.filter((e) => e.refType === "ORDER_ITEM").map((e) => e.refId);
    const lines = await this.prisma.orderItem.findMany({ where: { id: { in: orderItemIds } }, include: { item: { select: { title: true, sku: true } }, group: { include: { order: { select: { reference: true } } } } } });
    const settled = new Set((await this.prisma.statementLine.findMany({ where: { orderItemId: { in: orderItemIds } }, select: { orderItemId: true } })).map((x) => x.orderItemId));
    const now = Date.now();
    const holdMs = 7 * 86_400_000;
    let eligible = 0, onHold = 0;
    const rows = entries.map((e) => {
      const l = lines.find((x) => x.id === e.refId);
      const amount = e.creditMinor - e.debitMinor;
      const releaseAt = l?.group.deliveredAt ? new Date(l.group.deliveredAt.getTime() + holdMs) : null;
      const status = e.refType === "SETTLEMENT" ? "PAID_OUT" : e.refType === "REFUND" ? "REFUND" : l && settled.has(l.id) ? "SETTLED" : releaseAt && releaseAt.getTime() <= now ? "PAYABLE" : "ON_HOLD";
      if (e.refType === "ORDER_ITEM" && status === "PAYABLE") eligible += amount;
      if (e.refType === "ORDER_ITEM" && status === "ON_HOLD") onHold += amount;
      if (e.refType === "REFUND") eligible += amount;
      return { id: e.id, at: e.createdAt, amountMinor: amount, refType: e.refType, memo: e.memo, status, orderRef: l?.group.order.reference ?? null, item: l ? `${l.item.title} (${l.item.sku})` : null, grossMinor: l?.priceMinor ?? null, commissionBps: l?.commissionBps ?? null, releaseAt };
    });
    const statements = await this.prisma.sellerStatement.findMany({ where: { sellerId }, orderBy: { periodEnd: "desc" }, take: 24 });
    const profile = await this.prisma.sellerProfile.findUniqueOrThrow({ where: { id: sellerId } });
    return {
      balanceMinor: entries.reduce((a, e) => a + e.creditMinor - e.debitMinor, 0), payableNowMinor: Math.max(0, eligible), onHoldMinor: onHold, payoutVerified: !!profile.payoutVerifiedAt,
      entries: rows, statements: statements.map((st) => ({ id: st.id, periodStart: st.periodStart, periodEnd: st.periodEnd, state: st.state, netMinor: st.netMinor, grossMinor: st.grossMinor, commissionMinor: st.commissionMinor, paidAt: st.paidAt, payoutRef: st.payoutRef })),
    };
  }

  @Get("analytics")
  async analytics(@CurrentViewer() v: Viewer) {
    const sellerId = requireSeller(v);
    const sold = await this.prisma.orderItem.findMany({
      where: { group: { sellerId, order: { paidAt: { not: null } } } }, include: { item: { include: { category: true, listings: { take: 1, orderBy: { createdAt: "asc" } } } }, group: { include: { order: { select: { paidAt: true } } } } },
    });
    const live = await this.prisma.listing.count({ where: { sellerId, state: "PUBLISHED" } });
    const byMonth: Record<string, { count: number; grossMinor: number }> = {};
    const byCategory: Record<string, number> = {};
    let daysTotal = 0, daysN = 0;
    for (const s of sold) {
      const paid = s.group.order.paidAt!;
      const k = `${paid.getFullYear()}-${String(paid.getMonth() + 1).padStart(2, "0")}`;
      byMonth[k] = { count: (byMonth[k]?.count ?? 0) + 1, grossMinor: (byMonth[k]?.grossMinor ?? 0) + s.priceMinor };
      byCategory[s.item.category.name] = (byCategory[s.item.category.name] ?? 0) + 1;
      const pub = s.item.listings[0]?.publishedAt;
      if (pub) { daysTotal += (paid.getTime() - pub.getTime()) / 86_400_000; daysN++; }
    }
    return {
      soldCount: sold.length, liveCount: live, grossMinor: sold.reduce((a, s) => a + s.priceMinor, 0),
      sellThroughPct: sold.length + live ? Math.round((sold.length / (sold.length + live)) * 100) : 0,
      avgDaysToSell: daysN ? Math.round((daysTotal / daysN) * 10) / 10 : null,
      byMonth: Object.entries(byMonth).sort().map(([month, v2]) => ({ month, ...v2 })), byCategory: Object.entries(byCategory).map(([name, count]) => ({ name, count })).sort((a, b) => b.count - a.count),
    };
  }
}

/**
 * Staff acting FOR a seller who asked us to (never impersonation). Only SELLER_AGENT/ADMIN, only for approved sellers who consented.
 * Every call writes AuditLog.onBehalfOfId. Money/ownership/security actions have no endpoint here at all.
 */
@Controller("admin/sellers/:sellerId/on-behalf")
@Auth("SELLER_AGENT", "ADMIN")
export class OnBehalfController {
  constructor(private readonly prisma: PrismaService, private readonly listings: ListingService, private readonly media: MediaService, private readonly codes: CodesService, private readonly bundles: BundleService) {}

  private async guard(v: Viewer, sellerId: string, action: OnBehalfAction) {
    const s = await this.prisma.sellerProfile.findUnique({ where: { id: sellerId } });
    if (!s) throw notFound("Seller");
    const r = canActOnBehalf(v.roles as ViewerRole[], action, { sellerApproved: s.status === "VERIFIED", sellerAllowsStaffListing: s.allowStaffListing });
    if (!r.ok) throw forbidden(`Not allowed: ${r.reason}.`, "ON_BEHALF_REFUSED");
    return { actorId: v.userId, sellerId, onBehalfOfId: s.userId } satisfies ActorCtx;
  }

  @Get("listings")
  async list(@CurrentViewer() v: Viewer, @Param("sellerId") sellerId: string) {
    await this.guard(v, sellerId, "EDIT_DRAFT_LISTING");
    const items = await this.prisma.item.findMany({ where: { sellerId }, orderBy: { createdAt: "desc" }, take: 100, include: { listings: { take: 1, orderBy: { createdAt: "desc" } } } });
    return { items: items.map((i) => ({ id: i.id, sku: i.sku, title: i.title, stockState: i.stockState, listingState: i.listings[0]?.state ?? null })) };
  }

  @Post("listings")
  async create(@CurrentViewer() v: Viewer, @Param("sellerId") sellerId: string, @Body() body: unknown) {
    return this.listings.create(await this.guard(v, sellerId, "CREATE_DRAFT_LISTING"), parse(ListingInput, body));
  }

  @Patch("listings/:id")
  async update(@CurrentViewer() v: Viewer, @Param("sellerId") sellerId: string, @Param("id") id: string, @Body() body: unknown) {
    const ctx = await this.guard(v, sellerId, "EDIT_DRAFT_LISTING");
    const l = await this.prisma.listing.findFirst({ where: { itemId: id }, orderBy: { createdAt: "desc" } });
    if (l && !["DRAFT", "CHANGES_REQUESTED"].includes(l.state)) throw forbidden("Staff can only edit draft listings.", "ON_BEHALF_REFUSED");
    const input = parse(ListingUpdate, body);
    if (input.priceMinor !== undefined && l?.state !== "DRAFT") throw forbidden("Price changes need the seller.", "ON_BEHALF_REFUSED");
    return this.listings.update(ctx, id, input);
  }

  @Post("listings/:id/photos")
  @UseInterceptors(SingleUpload())
  async photo(@CurrentViewer() v: Viewer, @Param("sellerId") sellerId: string, @Param("id") id: string, @UploadedFile() file: UploadedFileT) {
    const ctx = await this.guard(v, sellerId, "UPLOAD_PHOTOS");
    const r = await photosUpload(this.prisma, this.media, id, sellerId, file, v.userId);
    await this.prisma.auditLog.create({ data: { actorId: v.userId, onBehalfOfId: ctx.onBehalfOfId, action: "PHOTO_UPLOADED", entity: "Item", entityId: id } });
    return r;
  }

  @Post("listings/:id/submit") @HttpCode(200)
  async submit(@CurrentViewer() v: Viewer, @Param("sellerId") sellerId: string, @Param("id") id: string) {
    await this.listings.submit(await this.guard(v, sellerId, "SUBMIT_FOR_REVIEW"), id);
    return { ok: true };
  }

  @Post("labels") @HttpCode(200)
  async labels(@CurrentViewer() v: Viewer, @Param("sellerId") sellerId: string, @Body() body: unknown, @Res() res: Response) {
    const ctx = await this.guard(v, sellerId, "REQUEST_LABEL");
    const { itemIds, format } = parse(z.object({ itemIds: z.array(z.string()).min(1).max(240), format: z.enum(["thermal", "a4"]).default("thermal") }), body);
    const pdf = await labelsPdf(this.prisma, this.codes, sellerId, itemIds, format, v.userId);
    await this.prisma.auditLog.create({ data: { actorId: v.userId, onBehalfOfId: ctx.onBehalfOfId, action: "LABELS_PRINTED", entity: "SellerProfile", entityId: sellerId } });
    res.setHeader("Content-Type", "application/pdf");
    res.send(Buffer.from(pdf));
  }

  @Post("bundles")
  async bundle(@CurrentViewer() v: Viewer, @Param("sellerId") sellerId: string, @Body() body: unknown) {
    const ctx = await this.guard(v, sellerId, "CREATE_BUNDLE_DRAFT");
    return this.bundles.create({ actorId: v.userId, sellerId, onBehalfOfId: ctx.onBehalfOfId }, parse(BundleInput, body));
  }

  /** Explicitly refused: these always need the seller's own OTP in their own account. */
  @Post("payout") payout() { return this.refused("Changing payout details"); }
  @Post("accept-offer") acceptOffer() { return this.refused("Accepting an offer"); }
  @Post("approve-price") approvePrice() { return this.refused("Approving a price"); }
  @Post("close-account") closeAccount() { return this.refused("Closing the account"); }
  @Post("change-phone") changePhone() { return this.refused("Changing the phone number"); }
  private refused(what: string): never { throw forbidden(`${what} requires the seller's own confirmation and can't be done by staff.`, "ON_BEHALF_REFUSED"); }
}
