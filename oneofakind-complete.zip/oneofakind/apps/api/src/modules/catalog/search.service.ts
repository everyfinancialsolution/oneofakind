import { Injectable } from "@nestjs/common";
import { Prisma, type ConditionGrade } from "@prisma/client";
import { z } from "zod";
import { PrismaService } from "../../common/prisma.service";
import { itemCard, publicItemInclude } from "./presenters";

const csv = z.preprocess((v) => (typeof v === "string" && v.length ? v.split(",").map((s) => s.trim()).filter(Boolean) : undefined), z.array(z.string().max(60)).max(30).optional());

export const SearchQuery = z.object({
  q: z.string().trim().max(100).optional(),
  category: z.string().max(60).optional(),
  brand: csv, size: csv, color: csv,
  grade: z.preprocess((v) => (typeof v === "string" && v.length ? v.split(",") : undefined), z.array(z.enum(["A", "B", "C", "D"])).optional()),
  minPrice: z.coerce.number().int().nonnegative().optional(),
  maxPrice: z.coerce.number().int().nonnegative().optional(),
  seller: z.string().max(80).optional(),
  city: z.string().max(60).optional(),
  managed: z.enum(["true", "false"]).optional(),
  sort: z.enum(["newest", "price_asc", "price_desc", "relevance"]).optional(),
  cursor: z.string().max(100).optional(),
  limit: z.coerce.number().int().min(1).max(60).default(24),
});
export type SearchQuery = z.infer<typeof SearchQuery>;

const LETTER_GRADES: Record<string, ConditionGrade[]> = { A: ["NEW_WITH_TAGS", "EXCELLENT"], B: ["VERY_GOOD"], C: ["GOOD"], D: ["FAIR"] };
export const FTS_EXPR = `to_tsvector('simple', coalesce(i."title",'') || ' ' || coalesce(i."description",'') || ' ' || coalesce(i."color",'') || ' ' || coalesce(i."size",''))`;

@Injectable()
export class SearchService {
  constructor(private readonly prisma: PrismaService) {}

  /** Item ids matching a free-text query, best first. Postgres FTS with prefix matching + trigram similarity for typos. */
  async matchIds(q: string): Promise<string[]> {
    const tokens = q.toLowerCase().normalize("NFKD").replace(/[^a-z0-9\s]/g, " ").split(/\s+/).filter((t) => t.length > 0).slice(0, 8);
    if (!tokens.length) return [];
    const tsq = tokens.map((t) => `${t}:*`).join(" & ");
    const rows = await this.prisma.$queryRawUnsafe<{ id: string }[]>(
      `SELECT i."id" FROM "Item" i LEFT JOIN "Brand" b ON b."id" = i."brandId"
       WHERE ${FTS_EXPR} @@ to_tsquery('simple', $1) OR $2 <% i."title" OR $2 <% b."name" OR b."name" ILIKE '%' || $2 || '%'
       ORDER BY ts_rank(${FTS_EXPR}, to_tsquery('simple', $1)) + word_similarity($2, i."title") DESC LIMIT 1000`,
      tsq, q,
    );
    return rows.map((r) => r.id);
  }

  async categoryIds(slug: string): Promise<string[] | null> {
    const cat = await this.prisma.category.findUnique({ where: { slug }, include: { children: { select: { id: true } } } });
    if (!cat) return null;
    return [cat.id, ...cat.children.map((c) => c.id)];
  }

  async buildWhere(q: SearchQuery): Promise<{ where: Prisma.ListingWhereInput; matchOrder: string[] | null } | null> {
    const item: Prisma.ItemWhereInput = { stockState: { in: ["AVAILABLE", "RESERVED"] }, channel: "RETAIL" };
    let matchOrder: string[] | null = null;
    if (q.q) {
      matchOrder = await this.matchIds(q.q);
      item.id = { in: matchOrder };
    }
    if (q.category) {
      const ids = await this.categoryIds(q.category);
      if (!ids) return null;
      item.categoryId = { in: ids };
    }
    if (q.brand) item.brand = { slug: { in: q.brand } };
    if (q.size) item.size = { in: q.size };
    if (q.color) item.color = { in: q.color };
    if (q.grade) item.conditionGrade = { in: q.grade.flatMap((l) => LETTER_GRADES[l]!) };
    if (q.minPrice !== undefined || q.maxPrice !== undefined) item.priceMinor = { gte: q.minPrice, lte: q.maxPrice };
    if (q.managed) item.arrangement = q.managed === "true" ? { not: "SELF_MANAGED" } : "SELF_MANAGED";
    if (q.seller || q.city) item.seller = { ...(q.seller ? { slug: q.seller } : {}), ...(q.city ? { city: { equals: q.city, mode: "insensitive" } } : {}) };
    return { where: { state: "PUBLISHED", item }, matchOrder };
  }

  async search(q: SearchQuery) {
    const built = await this.buildWhere(q);
    if (!built) return { items: [], nextCursor: null, total: 0 };
    const { where, matchOrder } = built;
    const sort = q.sort ?? (q.q ? "relevance" : "newest");
    const total = await this.prisma.listing.count({ where });
    if (sort === "relevance" && matchOrder) {
      // Offset cursor over the relevance ranking (bounded to 1000 matches)
      const offset = q.cursor ? Math.max(0, Number(q.cursor) || 0) : 0;
      const rows = await this.prisma.listing.findMany({ where, include: { item: { include: publicItemInclude } } });
      const rank = new Map(matchOrder.map((id, i) => [id, i]));
      rows.sort((a, b) => (rank.get(a.itemId) ?? 1e9) - (rank.get(b.itemId) ?? 1e9));
      const page = rows.slice(offset, offset + q.limit);
      return { items: page.map((l) => itemCard(l.item, l.slug, l.publishedAt)), nextCursor: offset + q.limit < rows.length ? String(offset + q.limit) : null, total };
    }
    const orderBy: Prisma.ListingOrderByWithRelationInput[] =
      sort === "price_asc" ? [{ item: { priceMinor: "asc" } }, { id: "asc" }]
        : sort === "price_desc" ? [{ item: { priceMinor: "desc" } }, { id: "desc" }]
          : [{ publishedAt: "desc" }, { id: "desc" }];
    const rows = await this.prisma.listing.findMany({
      where, orderBy, take: q.limit + 1, ...(q.cursor ? { cursor: { id: q.cursor }, skip: 1 } : {}),
      include: { item: { include: publicItemInclude } },
    });
    const hasMore = rows.length > q.limit;
    const page = rows.slice(0, q.limit);
    return { items: page.map((l) => itemCard(l.item, l.slug, l.publishedAt)), nextCursor: hasMore ? page[page.length - 1]!.id : null, total };
  }

  /** Filter options available for the current category/query (only values that have live stock). */
  async facets(q: SearchQuery) {
    const built = await this.buildWhere({ ...q, brand: undefined, size: undefined, grade: undefined, color: undefined, minPrice: undefined, maxPrice: undefined });
    if (!built) return { brands: [], sizes: [], grades: [], colors: [], price: null };
    const itemWhere: Prisma.ItemWhereInput = { ...(built.where.item as Prisma.ItemWhereInput), listings: { some: { state: "PUBLISHED" } } };
    const [brands, sizes, grades, colors, price] = await Promise.all([
      this.prisma.item.groupBy({ by: ["brandId"], where: itemWhere, _count: true }),
      this.prisma.item.groupBy({ by: ["size"], where: itemWhere, _count: true }),
      this.prisma.item.groupBy({ by: ["conditionGrade"], where: itemWhere, _count: true }),
      this.prisma.item.groupBy({ by: ["color"], where: itemWhere, _count: true }),
      this.prisma.item.aggregate({ where: itemWhere, _min: { priceMinor: true }, _max: { priceMinor: true } }),
    ]);
    const brandRows = await this.prisma.brand.findMany({ where: { id: { in: brands.map((b) => b.brandId).filter((x): x is string => !!x) } } });
    const letterCount: Record<string, number> = {};
    for (const g of grades) if (g.conditionGrade) {
      const l = Object.entries(LETTER_GRADES).find(([, gs]) => gs.includes(g.conditionGrade!))![0];
      letterCount[l] = (letterCount[l] ?? 0) + g._count;
    }
    return {
      brands: brands.filter((b) => b.brandId).map((b) => ({ slug: brandRows.find((r) => r.id === b.brandId)!.slug, name: brandRows.find((r) => r.id === b.brandId)!.name, count: b._count })).sort((a, b) => a.name.localeCompare(b.name)),
      sizes: sizes.filter((s) => s.size).map((s) => ({ value: s.size!, count: s._count })).sort((a, b) => a.value.localeCompare(b.value, undefined, { numeric: true })),
      grades: ["A", "B", "C", "D"].filter((l) => letterCount[l]).map((l) => ({ value: l, count: letterCount[l]! })),
      colors: colors.filter((c) => c.color).map((c) => ({ value: c.color!, count: c._count })).sort((a, b) => b.count - a.count),
      price: price._min.priceMinor === null ? null : { minMinor: price._min.priceMinor, maxMinor: price._max.priceMinor },
    };
  }
}
