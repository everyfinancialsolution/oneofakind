import { Controller, Get, Header, NotFoundException, Param, Req, Res } from "@nestjs/common";
import type { Request, Response } from "express";
import { canViewBundlePrices, redactBundlePrices, whatsappLink } from "@ooak/shared";
import { CurrentViewer, isStaff, toSharedViewer, type Viewer } from "../../common/auth";
import { PrismaService } from "../../common/prisma.service";
import { StorageService } from "../../common/storage.service";
import { config } from "../../config";
import { bundleView, itemCard, mediaUrl, publicBundleInclude, publicItemInclude } from "./presenters";

@Controller("content")
export class ContentController {
  constructor(private readonly prisma: PrismaService) {}

  /** Everything the editorial home page needs in one request. Bundle teasers are redacted per viewer. */
  @Get("home")
  async home(@CurrentViewer() v: Viewer | null, @Res({ passthrough: true }) res: Response) {
    res.setHeader("Cache-Control", v ? "private, no-store" : "public, max-age=0, s-maxage=60, stale-while-revalidate=300");
    const live = { state: "PUBLISHED" as const, item: { stockState: "AVAILABLE" as const, channel: "RETAIL" as const } };
    const [blocks, arrivals, managed, collections, sellers, bundles, categories] = await Promise.all([
      this.prisma.contentBlock.findMany({ where: { published: true }, orderBy: { position: "asc" } }),
      this.prisma.listing.findMany({ where: live, orderBy: [{ publishedAt: "desc" }, { id: "desc" }], take: 12, include: { item: { include: publicItemInclude } } }),
      this.prisma.listing.findMany({ where: { ...live, item: { ...live.item, arrangement: { not: "SELF_MANAGED" } } }, orderBy: { publishedAt: "desc" }, take: 8, include: { item: { include: publicItemInclude } } }),
      this.prisma.collection.findMany({ where: { approved: true, isEditorial: true }, take: 3, include: { items: { orderBy: { position: "asc" }, take: 3, include: { item: { include: publicItemInclude } } } } }),
      this.prisma.sellerProfile.findMany({ where: { status: "VERIFIED" }, orderBy: [{ ratingAvg: "desc" }], take: 4, include: { _count: { select: { listings: { where: { state: "PUBLISHED" } } } } } }),
      this.prisma.bundle.findMany({ where: { state: "PUBLISHED" }, orderBy: { publishedAt: "desc" }, take: 3, include: publicBundleInclude }),
      this.prisma.category.findMany({ where: { enabled: true, parentId: null }, orderBy: { sortOrder: "asc" }, include: { children: { where: { enabled: true }, orderBy: { sortOrder: "asc" } } } }),
    ]);
    const viewer = toSharedViewer(v);
    return {
      blocks: blocks.map((b) => ({ key: b.key, title: b.title, body: b.body, linkHref: b.linkHref, linkLabel: b.linkLabel, image: b.imageKey ? `/v1/media/key/${encodeURIComponent(b.imageKey)}` : null })),
      newArrivals: arrivals.map((l) => itemCard(l.item, l.slug, l.publishedAt)),
      inspected: managed.map((l) => itemCard(l.item, l.slug, l.publishedAt)),
      collections: collections.map((c) => ({ slug: c.slug, title: c.title, description: c.description, covers: c.items.map((ci) => itemCard(ci.item, "", null).image) })),
      sellers: sellers.map((s) => ({ slug: s.slug, displayName: s.displayName, city: s.city, type: s.type, ratingAvg: s.ratingAvg, ratingCount: s.ratingCount, liveListings: s._count.listings, bio: s.bio })),
      bundles: bundles.map((b) => redactBundlePrices(bundleView(b, false), canViewBundlePrices(viewer, b.sellerId))),
      categories: categories.map((c) => ({ slug: c.slug, name: c.name, children: c.children.map((k) => ({ slug: k.slug, name: k.name })) })),
    };
  }

  /** Public configuration the web app needs (never secrets). */
  @Get("config")
  @Header("Cache-Control", "public, max-age=300")
  async publicConfig() {
    const features = await this.prisma.setting.findUnique({ where: { key: "features" } });
    const number = config().WHATSAPP_BUSINESS_NUMBER;
    return { whatsappNumber: number, whatsappHelpLink: whatsappLink(number, "Hello ONEOFAKIND, I need help."), features: features?.value ?? {} };
  }
}

const SVG_CSP = "default-src 'none'; style-src 'unsafe-inline'; sandbox";

@Controller("media")
export class MediaController {
  constructor(private readonly prisma: PrismaService, private readonly storage: StorageService) {}

  /** Serves a MediaAsset. Public only when approved for publishing; otherwise only the owner and staff. Try-on images are never public. */
  @Get(":id")
  async serve(@Param("id") id: string, @CurrentViewer() v: Viewer | null, @Req() req: Request, @Res() res: Response) {
    const m = await this.prisma.mediaAsset.findUnique({ where: { id }, include: { item: { select: { seller: { select: { userId: true } } } } } });
    if (!m || m.deletedAt) throw new NotFoundException();
    const isPublic = m.approvedForPublish && m.kind !== "GENERATED_TRYON";
    const isOwner = !!v && (m.ownerUserId === v.userId || m.item?.seller.userId === v.userId);
    if (!isPublic && !isOwner && !isStaff(v)) throw new NotFoundException();
    const etag = `"${m.id}"`;
    if (req.headers["if-none-match"] === etag) { res.status(304).end(); return; }
    const body = await this.storage.get(m.storageKey);
    if (!body) throw new NotFoundException();
    res.setHeader("Content-Type", m.mime);
    res.setHeader("ETag", etag);
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("Cache-Control", isPublic ? "public, max-age=31536000, immutable" : "private, no-store");
    if (m.mime === "image/svg+xml") res.setHeader("Content-Security-Policy", SVG_CSP);
    res.send(body);
  }

  /** CMS images stored under public/cms/ only. */
  @Get("key/:key")
  async byKey(@Param("key") key: string, @Res() res: Response) {
    if (!key.startsWith("public/cms/")) throw new NotFoundException();
    const body = await this.storage.get(key);
    if (!body) throw new NotFoundException();
    res.setHeader("Cache-Control", "public, max-age=3600");
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.type(key.split(".").pop() ?? "bin").send(body);
  }
}

export { mediaUrl };
