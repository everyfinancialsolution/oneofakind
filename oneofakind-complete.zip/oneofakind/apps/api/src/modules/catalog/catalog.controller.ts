import { Controller, Get, Header, Param, Query, Res } from "@nestjs/common";
import type { Response } from "express";
import { allowedBundleSorts, canViewBundlePrices, redactBundlePrices } from "@ooak/shared";
import { z } from "zod";
import { CurrentViewer, isStaff, toSharedViewer, type Viewer } from "../../common/auth";
import { PrismaService } from "../../common/prisma.service";
import { badRequest, notFound, parse } from "../../common/problem";
import { bundleView, itemCard, itemDetail, publicBundleInclude, publicItemInclude } from "./presenters";
import { SearchQuery, SearchService } from "./search.service";

const PUBLIC_CACHE = "public, max-age=0, s-maxage=60, stale-while-revalidate=300";

/** Cache rules for anything that may carry bundle prices: anonymous = shared cache without prices; signed-in = never cached. */
function bundleCache(res: Response, viewer: Viewer | null) {
  res.setHeader("Cache-Control", viewer ? "private, no-store" : PUBLIC_CACHE);
  res.setHeader("Vary", "Cookie, Authorization");
}

@Controller("catalog")
export class CatalogController {
  constructor(private readonly prisma: PrismaService, private readonly search: SearchService) {}

  @Get("categories")
  @Header("Cache-Control", PUBLIC_CACHE)
  async categories() {
    const cats = await this.prisma.category.findMany({ where: { enabled: true }, orderBy: { sortOrder: "asc" } });
    const counts = await this.prisma.item.groupBy({ by: ["categoryId"], where: { stockState: "AVAILABLE", channel: "RETAIL", listings: { some: { state: "PUBLISHED" } } }, _count: true });
    const count = (id: string) => counts.find((c) => c.categoryId === id)?._count ?? 0;
    const view = (c: (typeof cats)[number]) => ({ id: c.id, slug: c.slug, name: c.name, parentId: c.parentId, attributeSchema: c.attributeSchema, liveCount: count(c.id) + cats.filter((x) => x.parentId === c.id).reduce((a, x) => a + count(x.id), 0) });
    return { categories: cats.map(view) };
  }

  @Get("brands")
  @Header("Cache-Control", PUBLIC_CACHE)
  async brands() {
    return { brands: await this.prisma.brand.findMany({ orderBy: { name: "asc" }, select: { slug: true, name: true, verifiedBrand: true } }) };
  }

  @Get("styles")
  @Header("Cache-Control", PUBLIC_CACHE)
  async styles() {
    return { styles: await this.prisma.styleTag.findMany({ where: { enabled: true }, orderBy: { name: "asc" }, select: { id: true, slug: true, name: true, categoryId: true } }) };
  }
}

@Controller("listings")
export class ListingsController {
  constructor(private readonly prisma: PrismaService, private readonly search: SearchService) {}

  @Get()
  @Header("Cache-Control", PUBLIC_CACHE)
  list(@Query() query: unknown) { return this.search.search(parse(SearchQuery, query)); }

  @Get("facets")
  @Header("Cache-Control", PUBLIC_CACHE)
  facets(@Query() query: unknown) { return this.search.facets(parse(SearchQuery, query)); }

  @Get(":slug")
  async detail(@Param("slug") slug: string, @CurrentViewer() v: Viewer | null, @Res({ passthrough: true }) res: Response) {
    const l = await this.prisma.listing.findUnique({ where: { slug }, include: { item: { include: publicItemInclude } } });
    if (!l) throw notFound("Listing");
    const owner = !!v?.sellerId && v.sellerId === l.sellerId;
    const publicState = l.state === "PUBLISHED" || l.state === "SOLD_OUT";
    if (!publicState && !owner && !isStaff(v)) throw notFound("Listing");
    res.setHeader("Cache-Control", publicState && !owner ? PUBLIC_CACHE : "private, no-store");
    const similar = await this.prisma.listing.findMany({
      where: { state: "PUBLISHED", id: { not: l.id }, item: { stockState: "AVAILABLE", channel: "RETAIL", OR: [{ categoryId: l.item.categoryId }, { brandId: l.item.brandId ?? undefined }] } },
      include: { item: { include: publicItemInclude } }, orderBy: { publishedAt: "desc" }, take: 8,
    });
    return { item: itemDetail(l.item, l), similar: similar.map((s) => itemCard(s.item, s.slug, s.publishedAt)), preview: !publicState };
  }

  /** Live, uncached stock check used by product pages (ISR) before add-to-cart. */
  @Get(":slug/availability")
  @Header("Cache-Control", "no-store")
  async availability(@Param("slug") slug: string) {
    const l = await this.prisma.listing.findUnique({ where: { slug }, select: { state: true, item: { select: { stockState: true, priceMinor: true, currency: true } } } });
    if (!l) throw notFound("Listing");
    const s = l.item.stockState;
    return { availability: l.state === "PUBLISHED" && s === "AVAILABLE" ? "AVAILABLE" : s === "RESERVED" ? "RESERVED" : "SOLD", priceMinor: l.item.priceMinor, currency: l.item.currency };
  }
}

@Controller("sellers")
export class SellersController {
  constructor(private readonly prisma: PrismaService) {}

  @Get()
  @Header("Cache-Control", PUBLIC_CACHE)
  async featured() {
    const sellers = await this.prisma.sellerProfile.findMany({
      where: { status: "VERIFIED" }, orderBy: [{ ratingAvg: "desc" }, { ratingCount: "desc" }], take: 12,
      include: { _count: { select: { listings: { where: { state: "PUBLISHED" } } } }, items: { where: { listings: { some: { state: "PUBLISHED" } }, stockState: "AVAILABLE" }, take: 3, orderBy: { createdAt: "desc" }, include: publicItemInclude } },
    });
    return {
      sellers: sellers.map((s) => ({
        slug: s.slug, displayName: s.displayName, city: s.city, type: s.type, bio: s.bio, ratingAvg: s.ratingAvg, ratingCount: s.ratingCount,
        liveListings: s._count.listings, preview: s.items.map((i) => itemCard(i, "", null).image),
      })),
    };
  }

  @Get(":slug")
  @Header("Cache-Control", PUBLIC_CACHE)
  async storefront(@Param("slug") slug: string, @Query() query: unknown) {
    const { cursor, limit, sort } = parse(z.object({ cursor: z.string().optional(), limit: z.coerce.number().int().min(1).max(60).default(24), sort: z.enum(["newest", "price_asc", "price_desc"]).default("newest") }), query);
    const s = await this.prisma.sellerProfile.findUnique({ where: { slug } });
    if (!s || s.status !== "VERIFIED") throw notFound("Seller");
    const where = { sellerId: s.id, state: "PUBLISHED" as const, item: { ownerType: "SELLER" as const, stockState: { in: ["AVAILABLE" as const, "RESERVED" as const] } } };
    const orderBy = sort === "newest" ? [{ publishedAt: "desc" as const }, { id: "desc" as const }] : [{ item: { priceMinor: sort === "price_asc" ? "asc" as const : "desc" as const } }, { id: "asc" as const }];
    const [rows, live, sold, bundles] = await Promise.all([
      this.prisma.listing.findMany({ where, orderBy, take: limit + 1, ...(cursor ? { cursor: { id: cursor }, skip: 1 } : {}), include: { item: { include: publicItemInclude } } }),
      this.prisma.listing.count({ where }),
      this.prisma.item.count({ where: { sellerId: s.id, stockState: { in: ["SOLD", "PACKED", "DISPATCHED", "DELIVERED"] } } }),
      this.prisma.bundle.count({ where: { sellerId: s.id, state: "PUBLISHED" } }),
    ]);
    const page = rows.slice(0, limit);
    return {
      seller: { slug: s.slug, displayName: s.displayName, type: s.type, city: s.city, bio: s.bio, ratingAvg: s.ratingAvg, ratingCount: s.ratingCount, memberSince: s.createdAt, liveListings: live, soldCount: sold, liveBundles: bundles },
      items: page.map((l) => itemCard(l.item, l.slug, l.publishedAt)), nextCursor: rows.length > limit ? page[page.length - 1]!.id : null,
    };
  }
}

@Controller("collections")
export class CollectionsController {
  constructor(private readonly prisma: PrismaService) {}

  private active() { const now = new Date(); return { approved: true, AND: [{ OR: [{ startsAt: null }, { startsAt: { lte: now } }] }, { OR: [{ endsAt: null }, { endsAt: { gt: now } }] }] }; }

  @Get()
  @Header("Cache-Control", PUBLIC_CACHE)
  async list() {
    const cols = await this.prisma.collection.findMany({
      where: this.active(), orderBy: { title: "asc" },
      include: { items: { orderBy: { position: "asc" }, take: 4, include: { item: { include: publicItemInclude } } }, _count: { select: { items: true } } },
    });
    return { collections: cols.map((c) => ({ slug: c.slug, title: c.title, description: c.description, isEditorial: c.isEditorial, count: c._count.items, covers: c.items.map((ci) => itemCard(ci.item, "", null).image) })) };
  }

  @Get(":slug")
  @Header("Cache-Control", PUBLIC_CACHE)
  async detail(@Param("slug") slug: string) {
    const c = await this.prisma.collection.findFirst({
      where: { slug, ...this.active() },
      include: { items: { orderBy: { position: "asc" }, include: { item: { include: { ...publicItemInclude, listings: { where: { state: "PUBLISHED" }, take: 1 } } } } } },
    });
    if (!c) throw notFound("Collection");
    const items = c.items.filter((ci) => ci.item.listings[0] && ["AVAILABLE", "RESERVED"].includes(ci.item.stockState));
    return { collection: { slug: c.slug, title: c.title, description: c.description }, items: items.map((ci) => itemCard(ci.item, ci.item.listings[0]!.slug, ci.item.listings[0]!.publishedAt)) };
  }
}

const BundleQuery = z.object({
  size: z.coerce.number().int().optional(),
  brand: z.string().max(60).optional(),
  style: z.string().max(60).optional(),
  sort: z.string().max(20).optional(),
  minPrice: z.coerce.number().int().optional(),
  maxPrice: z.coerce.number().int().optional(),
  cursor: z.string().max(100).optional(),
  limit: z.coerce.number().int().min(1).max(48).default(24),
});

@Controller("bundles")
export class BundlesPublicController {
  constructor(private readonly prisma: PrismaService) {}

  /** Bundle storefront. Prices are redacted server-side unless the viewer may see them; price sort/filter only for those viewers. */
  @Get()
  async list(@Query() query: unknown, @CurrentViewer() v: Viewer | null, @Res({ passthrough: true }) res: Response) {
    const q = parse(BundleQuery, query);
    const viewer = toSharedViewer(v);
    const seesPrices = canViewBundlePrices(viewer, null);
    const sort = q.sort ?? "newest";
    if (!allowedBundleSorts(seesPrices).includes(sort)) throw badRequest("This sort option is only available to verified resellers.", "SORT_NOT_ALLOWED");
    if (!seesPrices && (q.minPrice !== undefined || q.maxPrice !== undefined)) throw badRequest("Price filters are only available to verified resellers.", "FILTER_NOT_ALLOWED");
    bundleCache(res, v);
    const where = {
      state: "PUBLISHED" as const,
      ...(q.size ? { size: q.size } : {}),
      ...(q.brand ? { brand: { slug: q.brand } } : {}),
      ...(q.style ? { style: { slug: q.style } } : {}),
      ...(q.minPrice !== undefined || q.maxPrice !== undefined ? { priceMinor: { gte: q.minPrice, lte: q.maxPrice } } : {}),
    };
    const orderBy = sort === "price_asc" ? [{ priceMinor: "asc" as const }, { id: "asc" as const }]
      : sort === "price_desc" ? [{ priceMinor: "desc" as const }, { id: "desc" as const }]
        : sort === "size" ? [{ size: "desc" as const }, { id: "desc" as const }]
          : sort === "brand" ? [{ brand: { name: "asc" as const } }, { id: "asc" as const }]
            : [{ publishedAt: "desc" as const }, { id: "desc" as const }];
    let rows = await this.prisma.bundle.findMany({ where, orderBy, take: sort === "savings" ? 500 : q.limit + 1, ...(q.cursor && sort !== "savings" ? { cursor: { id: q.cursor }, skip: 1 } : {}), include: publicBundleInclude });
    if (sort === "savings") rows = rows.sort((a, b) => (b.retailValueMinor - b.priceMinor) / b.retailValueMinor - (a.retailValueMinor - a.priceMinor) / a.retailValueMinor).slice(0, q.limit + 1);
    const page = rows.slice(0, q.limit);
    const [brands, styles] = await Promise.all([
      this.prisma.brand.findMany({ where: { bundles: { some: { state: "PUBLISHED" } } }, select: { slug: true, name: true }, orderBy: { name: "asc" } }),
      this.prisma.styleTag.findMany({ where: { bundles: { some: { state: "PUBLISHED" } } }, select: { slug: true, name: true }, orderBy: { name: "asc" } }),
    ]);
    // Per-bundle redaction: a seller sees prices of their own lots only.
    const bundles = page.map((b) => redactBundlePrices(bundleView(b, false), canViewBundlePrices(viewer, b.sellerId)));
    return { bundles, nextCursor: rows.length > q.limit && sort !== "savings" ? page[page.length - 1]!.id : null, canSeePrices: seesPrices, sorts: allowedBundleSorts(seesPrices), facets: { brands, styles, sizes: [5, 10, 15] } };
  }

  @Get(":slug")
  async detail(@Param("slug") slug: string, @CurrentViewer() v: Viewer | null, @Res({ passthrough: true }) res: Response) {
    const b = await this.prisma.bundle.findUnique({ where: { slug }, include: publicBundleInclude });
    const owner = !!v?.sellerId && v.sellerId === b?.sellerId;
    if (!b || (!["PUBLISHED", "RESERVED", "SOLD"].includes(b.state) && !owner && !isStaff(v))) throw notFound("Bundle");
    bundleCache(res, v);
    const viewer = toSharedViewer(v);
    const canSee = canViewBundlePrices(viewer, b.sellerId);
    return { bundle: redactBundlePrices(bundleView(b, true), canSee), canSeePrices: canSee, canPurchase: !!v?.roles.includes("VERIFIED_RESELLER") };
  }
}
