import type { Prisma } from "@prisma/client";
import { GRADE_CRITERIA, GRADE_LETTER, summarizeBundle, pricePerPiece, savingsBps, money, DAMAGE_CLAIM_WINDOW_HOURS } from "@ooak/shared";

export const mediaUrl = (id: string) => `/v1/media/${id}`;

/** Prisma include for everything a public item card/plate needs. Only approved media is ever selected for public payloads. */
export const publicItemInclude = {
  brand: { select: { name: true, slug: true } },
  category: { select: { name: true, slug: true } },
  style: { select: { name: true, slug: true } },
  seller: { select: { slug: true, displayName: true, city: true, ratingAvg: true, ratingCount: true, type: true, status: true } },
  media: { where: { approvedForPublish: true, deletedAt: null, kind: { in: ["ORIGINAL", "BACKGROUND_REMOVED", "EDITED", "GENERATED_MODEL", "ASSET_3D"] } }, orderBy: [{ position: "asc" }, { createdAt: "asc" }] },
  conditionReports: { orderBy: { createdAt: "desc" }, take: 1 },
} satisfies Prisma.ItemInclude;
export type PublicItemRow = Prisma.ItemGetPayload<{ include: typeof publicItemInclude }>;

export function gradeView(grade: string | null) {
  if (!grade) return null;
  const letter = GRADE_LETTER[grade as keyof typeof GRADE_LETTER];
  const c = GRADE_CRITERIA[letter];
  return { code: grade, letter, label: c.label, rule: c.rule, bundleEligible: c.bundleEligible };
}

export function sellerView(row: PublicItemRow) {
  if (row.ownerType === "PLATFORM") return { slug: null, displayName: "ONEOFAKIND", city: "Lahore", ratingAvg: null, ratingCount: 0, type: "PLATFORM" as const };
  return row.seller;
}

export function fulfilmentView(row: { arrangement: string; ownerType: string; seller: { city: string | null } }) {
  const warehouse = row.arrangement !== "SELF_MANAGED";
  return {
    shipsFrom: warehouse ? "ONEOFAKIND warehouse, Lahore" : `${row.seller.city ?? "Pakistan"} (seller ships)`,
    handledBy: row.ownerType === "PLATFORM" ? "Sold by ONEOFAKIND" : warehouse ? "Managed by ONEOFAKIND" : "Ships from the seller",
    deliveryEstimate: warehouse ? "2-4 working days" : "3-6 working days",
    returns: `Returns only if the item arrives damaged or with a flaw that wasn't disclosed. Claim within ${DAMAGE_CLAIM_WINDOW_HOURS} hours of delivery.`,
    payment: "Prepaid only (card, wallet or bank transfer). No cash on delivery.",
  };
}

function availability(stockState: string) {
  return stockState === "AVAILABLE" ? "AVAILABLE" : stockState === "RESERVED" ? "RESERVED" : "SOLD";
}

export function imagesView(row: PublicItemRow, title: string) {
  return row.media.filter((m) => m.kind !== "ASSET_3D").map((m, i) => ({
    id: m.id, url: mediaUrl(m.id), width: m.width, height: m.height, kind: m.kind,
    aiLabel: m.aiLabel, alt: m.aiLabel ? `${title}, AI-generated image` : `${title}, photo ${i + 1}`,
  }));
}

/** Card payload for grids (search, home, storefront, collections). */
export function itemCard(row: PublicItemRow, slug: string, publishedAt?: Date | null) {
  const images = imagesView(row, row.title);
  return {
    slug, sku: row.sku, title: row.title, brand: row.brand, category: row.category, size: row.size, color: row.color,
    grade: gradeView(row.conditionGrade), priceMinor: row.priceMinor, currency: row.currency,
    image: images[0] ?? null, hoverImage: images[1] ?? null, seller: sellerView(row),
    availability: availability(row.stockState), managed: row.arrangement !== "SELF_MANAGED", publishedAt: publishedAt ?? null,
  };
}

/** Full product plate payload. Measurements/material only ever come from seller/inspector input (never AI). */
export function itemDetail(row: PublicItemRow, listing: { slug: string; publishedAt: Date | null; state: string }) {
  const report = row.conditionReports[0];
  const asset3d = row.media.find((m) => m.kind === "ASSET_3D");
  return {
    ...itemCard(row, listing.slug, listing.publishedAt),
    description: row.description, material: row.material, measurements: row.measurements, style: row.style,
    images: imagesView(row, row.title),
    model3d: asset3d ? { url: mediaUrl(asset3d.id) } : null,
    condition: report ? { grade: gradeView(report.grade), defects: report.defects ?? [], notes: report.notes, inspectedBy: report.source === "WAREHOUSE" ? "ONEOFAKIND inspection team" : "Seller" } : null,
    fulfilment: fulfilmentView(row), listingState: listing.state, arrangement: row.arrangement,
  };
}

export const publicBundleInclude = {
  brand: { select: { name: true, slug: true } },
  style: { select: { name: true, slug: true } },
  category: { select: { name: true, slug: true } },
  seller: { select: { slug: true, displayName: true, city: true, ratingAvg: true, ratingCount: true, type: true } },
  items: {
    where: { releasedAt: null }, orderBy: { position: "asc" },
    include: { item: { include: publicItemInclude } },
  },
} satisfies Prisma.BundleInclude;
export type PublicBundleRow = Prisma.BundleGetPayload<{ include: typeof publicBundleInclude }>;

/**
 * Bundle payload INCLUDING price fields. Callers MUST pass it through redactBundlePrices(payload, canViewBundlePrices(...))
 * before sending it anywhere (API response, cache, OG data). Every piece is listed: no carousel hides pieces.
 */
export function bundleView(b: PublicBundleRow, detail: boolean) {
  const pieces = b.items.map((bi) => bi.item);
  const weightGrams = pieces.reduce((a, p) => a + (p.weightGrams ?? 0), 0);
  const cover = pieces[0] ? imagesView(pieces[0], pieces[0].title)[0] ?? null : null;
  const base = {
    slug: b.slug, sku: b.sku, title: b.title, size: b.size, brand: b.brand, style: b.style, category: b.category,
    seller: b.ownerType === "PLATFORM" || !b.seller ? { slug: null, displayName: "ONEOFAKIND", city: "Lahore", type: "PLATFORM" } : b.seller,
    availability: b.state === "PUBLISHED" ? "AVAILABLE" : b.state === "RESERVED" ? "RESERVED" : "SOLD",
    cover, thumbnails: pieces.slice(0, 6).map((p) => imagesView(p, p.title)[0] ?? null),
    breakdown: summarizeBundle(pieces), weightGrams, publishedAt: b.publishedAt,
    priceMinor: b.priceMinor, retailValueMinor: b.retailValueMinor, currency: b.currency,
    pricePerPieceMinor: pricePerPiece(money(b.priceMinor), b.size).amountMinor,
    savingsBps: savingsBps(b.priceMinor, b.retailValueMinor),
  };
  if (!detail) return base;
  return {
    ...base, description: b.description, managed: b.arrangement !== "SELF_MANAGED",
    pieces: pieces.map((p, i) => ({
      position: i + 1, sku: p.sku, title: p.title, size: p.size, color: p.color, grade: gradeView(p.conditionGrade),
      measurements: p.measurements, images: imagesView(p, p.title), defects: p.conditionReports[0]?.defects ?? [],
      refRetailMinor: b.items[i]!.refRetailMinor,
    })),
    fulfilment: {
      shipsFrom: b.arrangement === "SELF_MANAGED" ? `${b.seller?.city ?? "Pakistan"} (seller ships)` : "ONEOFAKIND warehouse, Lahore",
      shipping: `Weight-based courier rate (lot weight ${(weightGrams / 1000).toFixed(1)} kg), shown at checkout.`,
      returns: `Damaged-only claims, per piece, within ${DAMAGE_CLAIM_WINDOW_HOURS} hours of delivery. Refund = that piece's share of the lot price.`,
      buyers: "Verified resellers only.",
    },
  };
}
