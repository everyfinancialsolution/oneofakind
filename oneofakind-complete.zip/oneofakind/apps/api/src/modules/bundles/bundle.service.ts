import { Injectable } from "@nestjs/common";
import type { Prisma } from "@prisma/client";
import { bundle as bundleMachine, GRADE_LETTER, BUNDLE_ALLOWED_LETTERS, itemStock, validateBundleComposition, type BundleState } from "@ooak/shared";
import { z } from "zod";
import { AuditService } from "../../common/audit.service";
import { NotifierService } from "../../common/notifier.service";
import { PrismaService } from "../../common/prisma.service";
import { conflict, notFound, unprocessable } from "../../common/problem";
import { mediaUrl } from "../catalog/presenters";

export const BundleInput = z.object({
  brandId: z.string().min(1),
  styleId: z.string().min(1),
  itemIds: z.array(z.string().min(1)).min(1).max(30),
  priceMinor: z.number().int().positive(),
  title: z.string().trim().min(3).max(120).optional(),
  description: z.string().trim().max(1000).optional(),
});
export interface BundleActor { actorId: string; sellerId: string | null; onBehalfOfId?: string | null }

const slugify = (s: string) => s.toLowerCase().replace(/['’×]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 70);
const LOCKED = ["RESERVED", "SOLD"];

@Injectable()
export class BundleService {
  constructor(private readonly prisma: PrismaService, private readonly audit: AuditService, private readonly notifier: NotifierService) {}

  private ownerWhere(sellerId: string | null): Prisma.ItemWhereInput {
    return sellerId ? { sellerId, ownerType: "SELLER" } : { ownerType: "PLATFORM" };
  }

  /** Pieces that may go into a new lot for this brand + style (grade A/B, not bundled, not live as retail, has weight). */
  async eligible(sellerId: string | null, brandId: string, styleId: string) {
    const items = await this.prisma.item.findMany({
      where: {
        ...this.ownerWhere(sellerId), brandId, styleId, stockState: { in: ["READY_TO_LIST", "AVAILABLE"] },
        conditionGrade: { in: ["NEW_WITH_TAGS", "EXCELLENT", "VERY_GOOD"] }, bundleLinks: { none: { releasedAt: null } }, listings: { none: { state: "PUBLISHED" } },
      },
      include: { media: { where: { deletedAt: null }, orderBy: { position: "asc" }, take: 1 } },
      orderBy: { createdAt: "asc" },
    });
    return items.map((i) => ({
      id: i.id, sku: i.sku, title: i.title, size: i.size, color: i.color, grade: i.conditionGrade ? GRADE_LETTER[i.conditionGrade] : null, priceMinor: i.priceMinor,
      arrangement: i.arrangement, weightGrams: i.weightGrams, photo: i.media[0] ? mediaUrl(i.media[0].id) : null, missingWeight: !i.weightGrams,
    }));
  }

  async create(actor: BundleActor, input: z.infer<typeof BundleInput>) {
    const items = await this.prisma.item.findMany({
      where: { id: { in: input.itemIds } },
      include: { bundleLinks: { where: { releasedAt: null } }, listings: { where: { state: "PUBLISHED" }, select: { id: true } } },
    });
    if (items.length !== new Set(input.itemIds).size) throw unprocessable("Some pieces were not found.", "ITEMS_NOT_FOUND");
    const tiers = (await this.prisma.bundleTier.findMany({ where: { active: true } })).map((t) => t.size);
    const first = items[0]!;
    const ownerType = actor.sellerId ? "SELLER" : "PLATFORM";
    const draft = { size: input.itemIds.length, brandId: input.brandId, styleId: input.styleId, sellerId: actor.sellerId, ownerType, arrangement: first.arrangement, priceMinor: input.priceMinor, currency: "PKR" } as const;
    const issues = validateBundleComposition(draft, items.map((i) => ({
      id: i.id, brandId: i.brandId, styleId: i.styleId, sellerId: i.sellerId, ownerType: i.ownerType, arrangement: i.arrangement, stockState: i.stockState,
      conditionGrade: i.conditionGrade, size: i.size, color: i.color, channel: i.channel, currency: i.currency, refRetailMinor: i.priceMinor,
      activeBundleId: i.bundleLinks[0]?.bundleId ?? null, hasPublishedRetailListing: i.listings.length > 0,
    })), tiers.length ? tiers : undefined);
    const noWeight = items.filter((i) => !i.weightGrams);
    if (noWeight.length) issues.push(...noWeight.map((i) => ({ code: "MISSING_WEIGHT" as never, itemId: i.id, message: "Pieces without a recorded weight cannot enter a bundle (courier price is weight-based)." })));
    if (issues.length) throw unprocessable("This lot doesn't meet the bundle rules.", "BUNDLE_INVALID", { issues });

    const [brand, style] = await Promise.all([this.prisma.brand.findUniqueOrThrow({ where: { id: input.brandId } }), this.prisma.styleTag.findUniqueOrThrow({ where: { id: input.styleId } })]);
    const retailValue = items.reduce((a, i) => a + i.priceMinor, 0);
    return this.prisma.$transaction(async (tx) => {
      const sku = `OOAK-L-${String(await this.prisma.nextval("seq_bundle_sku", tx)).padStart(6, "0")}`;
      const title = input.title ?? `${draft.size} × ${brand.name} ${style.name.toLowerCase()}`;
      const ordered = input.itemIds.map((id) => items.find((i) => i.id === id)!);
      const b = await tx.bundle.create({
        data: {
          sku, slug: `${slugify(title)}-${sku.slice(7)}`, title, description: input.description ?? null, sellerId: actor.sellerId, ownerType, arrangement: first.arrangement,
          brandId: input.brandId, styleId: input.styleId, categoryId: first.categoryId, size: draft.size, priceMinor: input.priceMinor, retailValueMinor: retailValue, state: "DRAFT",
          items: { create: ordered.map((i, idx) => ({ itemId: i.id, position: idx, refRetailMinor: i.priceMinor })) },
        },
      });
      await tx.item.updateMany({ where: { id: { in: input.itemIds } }, data: { channel: "BUNDLE", version: { increment: 1 } } });
      await this.audit.log({ actorId: actor.actorId, onBehalfOfId: actor.onBehalfOfId, action: "BUNDLE_CREATED", entity: "Bundle", entityId: b.id, after: { size: draft.size, priceMinor: input.priceMinor } }, tx);
      return { id: b.id, sku, slug: b.slug };
    });
  }

  private async load(id: string, sellerId?: string | null) {
    const b = await this.prisma.bundle.findUnique({ where: { id }, include: { items: { where: { releasedAt: null }, include: { item: true } }, seller: true } });
    if (!b || (sellerId !== undefined && b.sellerId !== sellerId)) throw notFound("Bundle");
    return b;
  }

  async transition(id: string, to: BundleState, actorId: string, opts: { sellerId?: string | null; note?: string; onBehalfOfId?: string | null } = {}) {
    const b = await this.load(id, opts.sellerId);
    bundleMachine.assert(b.state as BundleState, to);
    if (to === "REMOVED" && b.items.some((bi) => LOCKED.includes(bi.item.stockState))) throw conflict("A piece of this lot is reserved or sold.", "ITEM_LOCKED");
    await this.prisma.$transaction(async (tx) => {
      if (to === "PUBLISHED" && b.state === "PENDING_REVIEW") {
        for (const bi of b.items) {
          if (!["READY_TO_LIST", "AVAILABLE"].includes(bi.item.stockState)) throw conflict(`Piece ${bi.item.sku} is ${bi.item.stockState}.`, "ITEM_NOT_LISTABLE");
          if (!bi.item.conditionGrade || !BUNDLE_ALLOWED_LETTERS.includes(GRADE_LETTER[bi.item.conditionGrade])) throw conflict(`Piece ${bi.item.sku} is not grade A/B.`, "GRADE_NOT_ALLOWED");
          if (bi.item.stockState === "READY_TO_LIST") { itemStock.assert("READY_TO_LIST", "AVAILABLE"); await tx.item.update({ where: { id: bi.itemId }, data: { stockState: "AVAILABLE" } }); }
        }
        await tx.mediaAsset.updateMany({ where: { itemId: { in: b.items.map((x) => x.itemId) }, deletedAt: null, useInListing: true, kind: { in: ["ORIGINAL", "EDITED", "BACKGROUND_REMOVED", "ASSET_3D"] } }, data: { approvedForPublish: true, visibility: "PUBLIC" } });
      }
      await tx.bundle.update({ where: { id }, data: { state: to, ...(to === "PUBLISHED" && !b.publishedAt ? { publishedAt: new Date(), moderatedById: actorId } : {}) } });
      if (to === "REMOVED") {
        await tx.bundleItem.updateMany({ where: { bundleId: id, releasedAt: null }, data: { releasedAt: new Date() } });
        await tx.item.updateMany({ where: { id: { in: b.items.map((x) => x.itemId) } }, data: { channel: "RETAIL" } });
      }
      await this.audit.log({ actorId, onBehalfOfId: opts.onBehalfOfId, action: `BUNDLE_${to}`, entity: "Bundle", entityId: id, before: { state: b.state }, after: { note: opts.note } }, tx);
    });
    if (b.seller && (to === "PUBLISHED" || to === "CHANGES_REQUESTED") && opts.sellerId === undefined)
      await this.notifier.inApp(b.seller.userId, `BUNDLE_${to}`, to === "PUBLISHED" ? `Your lot “${b.title}” is live.` : `Your lot “${b.title}” needs changes: ${opts.note ?? ""}`);
  }

  async listForSeller(sellerId: string | null) {
    const rows = await this.prisma.bundle.findMany({
      where: sellerId ? { sellerId } : { ownerType: "PLATFORM" }, orderBy: { createdAt: "desc" },
      include: { brand: true, style: true, items: { where: { releasedAt: null }, include: { item: { include: { media: { where: { deletedAt: null }, take: 1, orderBy: { position: "asc" } } } } } } },
    });
    return rows.map((b) => ({
      id: b.id, sku: b.sku, slug: b.slug, title: b.title, state: b.state, size: b.size, priceMinor: b.priceMinor, retailValueMinor: b.retailValueMinor,
      brand: b.brand.name, style: b.style.name, arrangement: b.arrangement, createdAt: b.createdAt,
      thumbs: b.items.slice(0, 5).map((bi) => (bi.item.media[0] ? mediaUrl(bi.item.media[0].id) : null)),
    }));
  }
}
