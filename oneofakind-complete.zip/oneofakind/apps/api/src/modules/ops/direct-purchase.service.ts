import { Injectable } from "@nestjs/common";
import { allocate, directPurchase as dpMachine, directPurchaseOfferRange, itemStock, money, type DirectPurchaseState } from "@ooak/shared";
import { z } from "zod";
import { AuditService } from "../../common/audit.service";
import { NotifierService } from "../../common/notifier.service";
import { PrismaService } from "../../common/prisma.service";
import { badRequest, conflict, notFound, unprocessable } from "../../common/problem";
import { LedgerService } from "../commerce/ledger.service";
import { ListingService } from "../seller/listing.service";

export const DirectPurchaseInput = z.object({
  title: z.string().trim().min(3).max(120),
  description: z.string().trim().min(5).max(2000),
  sellerAskMinor: z.number().int().positive().optional(),
  pieces: z.array(z.object({ title: z.string().trim().min(3).max(120), categoryId: z.string(), brandName: z.string().trim().max(60).optional().nullable(), size: z.string().trim().max(30).optional().nullable(), color: z.string().trim().max(30).optional().nullable(), expectedRetailMinor: z.number().int().positive().optional() })).min(1).max(100),
});
export const OfferInput = z.object({ offerMinor: z.number().int().positive(), budgetCode: z.string().min(2), expiresHours: z.number().int().min(1).max(168).default(72), note: z.string().max(500).optional(), expectedRetailMinor: z.number().int().positive().optional() });

/** Statuses committed against a budget: the money is promised (accepted) or spent (transferred). */
const COMMITTED: DirectPurchaseState[] = ["ACCEPTED", "AWAITING_HANDOVER", "AWAITING_PAYMENT", "TRANSFERRED"];

/**
 * Direct purchase: ONEOFAKIND buys pieces outright. TRANSFERRED is the ONLY state meaning ownership moved; before it, copy says
 * "offer accepted - awaiting handover/payment", never "sold/purchased", and the pieces cannot be listed or sold.
 */
@Injectable()
export class DirectPurchaseService {
  constructor(private readonly prisma: PrismaService, private readonly ledger: LedgerService, private readonly listings: ListingService, private readonly audit: AuditService, private readonly notifier: NotifierService) {}

  async submit(sellerId: string, userId: string, input: z.infer<typeof DirectPurchaseInput>) {
    return this.prisma.$transaction(async (tx) => {
      const dp = await tx.directPurchase.create({ data: { sellerId, title: input.title, description: input.description, sellerAskMinor: input.sellerAskMinor ?? null, expectedRetailMinor: input.pieces.reduce((a, p) => a + (p.expectedRetailMinor ?? 0), 0) || null } });
      for (const p of input.pieces) {
        await tx.item.create({ data: { sku: await this.listings.newSku(tx), sellerId, categoryId: p.categoryId, brandId: await this.listings.brandId(p.brandName, tx), arrangement: "DIRECT_PURCHASE", ownerType: "SELLER", stockState: "EXPECTED", title: p.title, size: p.size ?? null, color: p.color ?? null, priceMinor: p.expectedRetailMinor ?? 100_000, directPurchaseId: dp.id } });
      }
      await this.audit.log({ actorId: userId, action: "DIRECT_PURCHASE_SUBMITTED", entity: "DirectPurchase", entityId: dp.id }, tx);
      return dp;
    });
  }

  async load(id: string, sellerId?: string) {
    const dp = await this.prisma.directPurchase.findUnique({ where: { id }, include: { items: { include: { media: { where: { deletedAt: null }, orderBy: { position: "asc" } }, category: true } }, transfers: true, seller: true } });
    if (!dp || (sellerId && dp.sellerId !== sellerId)) throw notFound("Submission");
    return dp;
  }

  private async move(id: string, to: DirectPurchaseState, actorId: string, data: Record<string, unknown> = {}) {
    const dp = await this.load(id);
    dpMachine.assert(dp.state as DirectPurchaseState, to);
    await this.prisma.directPurchase.update({ where: { id }, data: { state: to, ...data } });
    await this.audit.log({ actorId, action: `DIRECT_PURCHASE_${to}`, entity: "DirectPurchase", entityId: id, before: { state: dp.state }, after: data });
    return dp;
  }

  async budgetRemaining(code: string) {
    const b = await this.prisma.buyingBudget.findUnique({ where: { code } });
    if (!b || !b.active) return null;
    const committed = await this.prisma.directPurchase.aggregate({ where: { budgetCode: code, state: { in: COMMITTED } }, _sum: { offerMinor: true } });
    return { budget: b, remainingMinor: b.limitMinor - (committed._sum.offerMinor ?? 0) };
  }

  // ── Buying team ──
  async review(id: string, actorId: string) { await this.move(id, "UNDER_REVIEW", actorId); }

  async offer(id: string, actorId: string, input: z.infer<typeof OfferInput>) {
    const dp = await this.load(id);
    if (dp.state === "SUBMITTED") await this.move(id, "UNDER_REVIEW", actorId);
    const b = await this.budgetRemaining(input.budgetCode);
    if (!b) throw badRequest("Unknown or inactive budget.", "UNKNOWN_BUDGET");
    if (input.offerMinor > b.remainingMinor) throw conflict(`Over budget: PKR ${(b.remainingMinor / 100).toLocaleString("en-PK")} left in ${input.budgetCode}.`, "OVER_BUDGET");
    const expected = input.expectedRetailMinor ?? dp.expectedRetailMinor ?? null;
    const range = expected ? directPurchaseOfferRange(expected) : null;
    if (range && (input.offerMinor < range.min.amountMinor || input.offerMinor > range.max.amountMinor) && !input.note)
      throw unprocessable(`Offer is outside the 35-45% guide (${range.min.amountMinor / 100}-${range.max.amountMinor / 100} PKR). Add a note explaining why.`, "OUTSIDE_RANGE");
    await this.move(id, "OFFER_MADE", actorId, { offerMinor: input.offerMinor, budgetCode: input.budgetCode, approvedById: actorId, offerExpiresAt: new Date(Date.now() + input.expiresHours * 3_600_000), expectedRetailMinor: expected, decisionNote: input.note ?? null });
    await this.notifier.inApp(dp.seller.userId, "DP_OFFER", `Offer for “${dp.title}”: PKR ${(input.offerMinor / 100).toLocaleString("en-PK")}. It's valid for ${input.expiresHours} hours. Nothing is sold until you accept, hand over the pieces and we pay you.`);
    if (dp.seller) { const u = await this.prisma.user.findUnique({ where: { id: dp.seller.userId } }); if (u?.phone) await this.notifier.sendSms(u.phone, "DP_OFFER", `ONEOFAKIND made an offer for "${dp.title}". Open your seller hub to accept or decline.`, u.id); }
  }

  async decline(id: string, actorId: string, note: string) {
    await this.move(id, "REJECTED_BY_BUYER_TEAM", actorId, { decisionNote: note });
    const dp = await this.load(id);
    await this.notifier.inApp(dp.seller.userId, "DP_DECLINED", `We won't make an offer for “${dp.title}” this time: ${note}`);
  }

  // ── Seller (own confirmation) ──
  async respond(id: string, sellerId: string, userId: string, accept: boolean) {
    const dp = await this.load(id, sellerId);
    if (dp.state !== "OFFER_MADE") throw conflict("There's no open offer.", "NO_OFFER");
    if (dp.offerExpiresAt && dp.offerExpiresAt < new Date()) { await this.move(id, "EXPIRED", userId); throw conflict("This offer has expired.", "OFFER_EXPIRED"); }
    if (!accept) { await this.move(id, "REJECTED_BY_SELLER", userId); return { state: "REJECTED_BY_SELLER" }; }
    const b = await this.budgetRemaining(dp.budgetCode!);
    if (!b || b.remainingMinor < (dp.offerMinor ?? 0)) throw conflict("This offer can no longer be honoured. Our team will contact you.", "OVER_BUDGET");
    await this.move(id, "ACCEPTED", userId);
    await this.move(id, "AWAITING_HANDOVER", userId);
    return { state: "AWAITING_HANDOVER" };
  }

  // ── Warehouse: every piece received and checked ⇒ AWAITING_PAYMENT ──
  async receive(id: string, actorId: string, itemIds: string[]) {
    const dp = await this.load(id);
    if (dp.state !== "AWAITING_HANDOVER") throw conflict(`Submission is ${dp.state}.`, "INVALID_STATE");
    await this.prisma.$transaction(async (tx) => {
      for (const it of dp.items) {
        if (!itemIds.includes(it.id)) continue;
        if (it.stockState !== "EXPECTED") continue;
        itemStock.assert("EXPECTED", "RECEIVED");
        await tx.item.update({ where: { id: it.id }, data: { stockState: "RECEIVED" } });
        await tx.custodyEvent.create({ data: { itemId: it.id, fromParty: "SELLER", toParty: "WAREHOUSE:LHR", actorId, note: "Direct purchase handover (seller still owns until payment)" } });
      }
      const missing = dp.items.filter((i) => !itemIds.includes(i.id) && i.stockState === "EXPECTED");
      for (const m of missing) { itemStock.assert("EXPECTED", "WITHDRAWN"); await tx.item.update({ where: { id: m.id }, data: { stockState: "WITHDRAWN" } }); }
    });
    await this.move(id, "AWAITING_PAYMENT", actorId);
  }

  /** Finance pays the seller (payment reference required) ⇒ TRANSFERRED: ownership moves, cost allocated per piece, ledger posted. */
  async transfer(id: string, actorId: string, paymentRef: string) {
    const dp = await this.load(id);
    if (dp.state !== "AWAITING_PAYMENT") throw conflict("Pieces must be received and checked before payment.", "INVALID_STATE");
    if (!paymentRef.trim()) throw badRequest("Payment reference required.", "PAYMENT_REF_REQUIRED");
    const received = dp.items.filter((i) => !["EXPECTED", "WITHDRAWN"].includes(i.stockState));
    if (!received.length) throw conflict("No pieces were received.", "NOTHING_RECEIVED");
    const handoverBy = (await this.prisma.custodyEvent.findFirst({ where: { itemId: received[0]!.id, toParty: "WAREHOUSE:LHR" }, orderBy: { createdAt: "desc" } }))?.actorId ?? actorId;
    const costs = allocate(money(dp.offerMinor!), received.map((i) => Math.max(1, i.priceMinor)));
    await this.prisma.$transaction(async (tx) => {
      dpMachine.assert("AWAITING_PAYMENT", "TRANSFERRED");
      for (const [idx, it] of received.entries()) {
        const cost = costs[idx]!.amountMinor;
        await tx.item.update({ where: { id: it.id }, data: { ownerType: "PLATFORM", costMinor: cost } });
        const t = await tx.ownershipTransfer.create({ data: { directPurchaseId: id, itemId: it.id, priceMinor: cost, paymentRef, handoverVerifiedById: handoverBy } });
        await this.ledger.postTransfer(tx, t.id, cost);
      }
      await tx.directPurchase.update({ where: { id }, data: { state: "TRANSFERRED", paymentRef } });
      await this.audit.log({ actorId, action: "DIRECT_PURCHASE_TRANSFERRED", entity: "DirectPurchase", entityId: id, after: { paymentRef, pieces: received.length, offerMinor: dp.offerMinor } }, tx);
    });
    await this.notifier.inApp(dp.seller.userId, "DP_TRANSFERRED", `Payment of PKR ${(dp.offerMinor! / 100).toLocaleString("en-PK")} sent for “${dp.title}” (ref ${paymentRef}). The pieces now belong to ONEOFAKIND. Thank you!`);
  }

  async cancel(id: string, actorId: string, note: string) { await this.move(id, "CANCELLED", actorId, { decisionNote: note }); }
}
