import { Body, Controller, Delete, Get, HttpCode, Param, Post, Query, Res, UploadedFile, UseInterceptors } from "@nestjs/common";
import type { Response } from "express";
import { GRADE_LETTER, itemStock, parseScan, type ItemStockState } from "@ooak/shared";

/** Moves from → target through the given ordered path, asserting each hop with the item state machine. */
function walk(from: ItemStockState, target: ItemStockState, path: ItemStockState[]): ItemStockState {
  let cur = from;
  for (const next of path) {
    if (cur === target) break;
    if (itemStock.can(cur, next)) { itemStock.assert(cur, next); cur = next; }
  }
  if (cur !== target) throw new Error(`no valid path ${from} → ${target}`);
  return cur;
}
import { z } from "zod";
import { AuditService } from "../../common/audit.service";
import { Auth, CurrentViewer, requireSeller, type Viewer } from "../../common/auth";
import { MediaService } from "../../common/media.service";
import { PrismaService } from "../../common/prisma.service";
import { badRequest, conflict, notFound, parse } from "../../common/problem";
import { SingleUpload, type UploadedFileT } from "../../common/upload";
import { OtpService } from "../auth/otp.service";
import { BundleInput, BundleService } from "../bundles/bundle.service";
import { mediaUrl } from "../catalog/presenters";
import { CodesService } from "../codes/codes.service";
import { itemLabelsPdf, lotLabelPdf } from "../codes/labels";
import { FulfilmentService } from "../commerce/fulfilment.service";
import { ReturnsService } from "../commerce/returns.service";
import { DirectPurchaseInput, DirectPurchaseService, OfferInput } from "./direct-purchase.service";
import { CatalogueInput, InspectInput, ManagedService, ManifestInput } from "./managed.service";

const pdf = (res: Response, bytes: Uint8Array, name: string) => { res.type("application/pdf").setHeader("Content-Disposition", `inline; filename="${name}"`); res.setHeader("Cache-Control", "no-store"); res.send(Buffer.from(bytes)); };

/** Warehouse (Lahore). Tablet/handheld-first; every physical handover writes a custody event; every scan is logged. */
@Controller("ops")
@Auth("WAREHOUSE", "ADMIN")
export class OpsController {
  constructor(
    private readonly prisma: PrismaService, private readonly managed: ManagedService, private readonly media: MediaService, private readonly codes: CodesService,
    private readonly fulfilment: FulfilmentService, private readonly returns: ReturnsService, private readonly bundles: BundleService, private readonly dp: DirectPurchaseService,
    private readonly audit: AuditService,
  ) {}
  private actor(v: Viewer) { return { actorId: v.userId, warehouse: true }; }

  @Get("overview")
  async overview() {
    const [inTransit, receiving, toInspect, toCatalogue, toPack, toHandover, returnsDue, priceWaiting, dpHandover, unsealed] = await Promise.all([
      this.prisma.intakeManifest.count({ where: { state: { in: ["APPROVED", "IN_TRANSIT"] } } }),
      this.prisma.intakeManifest.count({ where: { state: "RECEIVING" } }),
      this.prisma.item.count({ where: { stockState: { in: ["RECEIVED", "RETURNED_TO_STOCK"] } } }),
      this.prisma.item.count({ where: { stockState: "READY_TO_LIST", arrangement: { not: "SELF_MANAGED" }, channel: "RETAIL", listings: { none: { state: { in: ["PENDING_REVIEW", "PUBLISHED", "DRAFT"] } } } } }),
      this.prisma.fulfilmentGroup.count({ where: { mode: "WAREHOUSE", state: { in: ["PAID", "PROCESSING"] } } }),
      this.prisma.shipment.count({ where: { state: "READY", group: { mode: "WAREHOUSE" } } }),
      this.prisma.returnRequest.count({ where: { state: { in: ["APPROVED", "IN_TRANSIT"] } } }),
      this.prisma.item.count({ where: { proposedPriceMinor: { not: null } } }),
      this.prisma.directPurchase.count({ where: { state: "AWAITING_HANDOVER" } }),
      this.prisma.bundle.count({ where: { arrangement: { not: "SELF_MANAGED" }, state: { in: ["PUBLISHED", "SOLD"] }, scanCodes: { none: { kind: "BUNDLE_PACK", voidedAt: null } } } }),
    ]);
    return { inTransit, receiving, toInspect, toCatalogue, toPack, toHandover, returnsDue, priceWaiting, dpHandover, unsealed };
  }

  // ── Receiving ──
  @Get("manifests")
  async manifests(@Query() q: unknown) {
    const { state } = parse(z.object({ state: z.string().optional() }), q);
    const rows = await this.prisma.intakeManifest.findMany({ where: { state: { in: (state?.split(",") ?? ["SUBMITTED", "APPROVED", "IN_TRANSIT", "RECEIVING"]) as never } }, orderBy: { createdAt: "asc" }, include: { seller: true, lines: { select: { state: true } } } });
    return { manifests: rows.map((m) => ({ id: m.id, state: m.state, seller: m.seller.displayName, expectedCount: m.expectedCount, received: m.lines.filter((l) => l.state === "RECEIVED").length, open: m.lines.filter((l) => l.state === "EXPECTED").length, courier: m.courier, trackingNo: m.trackingNo, createdAt: m.createdAt })) };
  }

  @Get("manifests/:id")
  async manifest(@Param("id") id: string) {
    const m = await this.prisma.intakeManifest.findUnique({ where: { id }, include: { seller: true, agreement: true, lines: { include: { item: { include: { scanCodes: { where: { kind: "ITEM_PACK", voidedAt: null } } } } } } } });
    if (!m) throw notFound("Manifest");
    return { manifest: { id: m.id, state: m.state, seller: m.seller.displayName, notes: m.notes, courier: m.courier, trackingNo: m.trackingNo, agreement: { commissionBps: m.agreement.commissionBps, requiresPriceApproval: m.agreement.requiresPriceApproval }, lines: m.lines.map((l) => ({ id: l.id, description: l.description, brandName: l.brandName, expectedPriceMinor: l.expectedPriceMinor, state: l.state, note: l.discrepancyNote, itemId: l.itemId, sku: l.item?.sku, code: l.item?.scanCodes[0]?.code ?? null })) } };
  }

  @Post("manifests/:id/approve") @HttpCode(200)
  async approveManifest(@CurrentViewer() v: Viewer, @Param("id") id: string) { await this.managed.manifestTransition(id, "APPROVED", v.userId); return { ok: true }; }

  @Post("manifests/:id/lines/:lineId") @HttpCode(200)
  receiveLine(@CurrentViewer() v: Viewer, @Param("id") id: string, @Param("lineId") lineId: string, @Body() body: unknown) {
    const { outcome, note } = parse(z.object({ outcome: z.enum(["RECEIVED", "MISSING", "DECLINED", "DISPUTED"]), note: z.string().max(300).optional() }), body);
    return this.managed.receiveLine(id, lineId, outcome, v.userId, note);
  }

  @Post("manifests/:id/reconcile") @HttpCode(200)
  async reconcile(@CurrentViewer() v: Viewer, @Param("id") id: string) { await this.managed.reconcile(id, v.userId); return { ok: true }; }

  // ── Inspection / photography / catalogue ──
  @Get("queue/:name")
  async queue(@Param("name") name: string) {
    const where =
      name === "inspection" ? { stockState: { in: ["RECEIVED", "RETURNED_TO_STOCK"] } }
        : name === "photography" ? { stockState: "READY_TO_LIST", arrangement: { not: "SELF_MANAGED" }, channel: "RETAIL", listings: { none: { state: { in: ["PENDING_REVIEW", "PUBLISHED", "DRAFT"] } } } }
          : name === "rejected" ? { stockState: { in: ["REJECTED", "WITHDRAWN"] }, arrangement: { not: "SELF_MANAGED" }, locationId: { not: null } }
            : name === "price-approval" ? { proposedPriceMinor: { not: null } }
              : null;
    if (!where) throw notFound("Queue");
    const items = await this.prisma.item.findMany({ where: where as never, orderBy: { updatedAt: "asc" }, take: 200, include: { seller: true, category: true, location: true, media: { where: { deletedAt: null }, take: 1, orderBy: { position: "asc" } }, scanCodes: { where: { kind: "ITEM_PACK", voidedAt: null } } } });
    return { items: items.map((i) => ({ id: i.id, sku: i.sku, title: i.title, seller: i.ownerType === "PLATFORM" ? "ONEOFAKIND" : i.seller.displayName, category: i.category.name, arrangement: i.arrangement, ownerType: i.ownerType, stockState: i.stockState, location: i.location?.code ?? null, code: i.scanCodes[0]?.code ?? null, photo: i.media[0] ? mediaUrl(i.media[0].id) : null, proposedPriceMinor: i.proposedPriceMinor, priceMinor: i.priceMinor })) };
  }

  @Get("items/:id")
  async item(@Param("id") id: string) {
    const i = await this.prisma.item.findUnique({ where: { id }, include: { seller: true, category: true, brand: true, location: true, style: true, media: { where: { deletedAt: null }, orderBy: { position: "asc" } }, conditionReports: { orderBy: { createdAt: "desc" }, take: 1 }, custodyEvents: { orderBy: { createdAt: "asc" } }, scanCodes: { where: { voidedAt: null } }, listings: { orderBy: { createdAt: "desc" }, take: 1 }, directPurchase: { select: { state: true, title: true } } } });
    if (!i) throw notFound("Item");
    return {
      item: {
        id: i.id, sku: i.sku, title: i.title, description: i.description, seller: i.seller.displayName, category: { name: i.category.name, measurements: (i.category.attributeSchema as { measurements?: string[] } | null)?.measurements ?? [] },
        brand: i.brand?.name ?? null, styleId: i.styleId, size: i.size, color: i.color, material: i.material, measurements: i.measurements, weightGrams: i.weightGrams, priceMinor: i.priceMinor, proposedPriceMinor: i.proposedPriceMinor,
        arrangement: i.arrangement, ownerType: i.ownerType, stockState: i.stockState, channel: i.channel, location: i.location?.code ?? null, grade: i.conditionGrade, gradeLetter: i.conditionGrade ? GRADE_LETTER[i.conditionGrade] : null,
        defects: i.conditionReports[0]?.defects ?? [], photos: i.media.map((m) => ({ id: m.id, url: mediaUrl(m.id), approved: m.approvedForPublish, kind: m.kind })),
        custody: i.custodyEvents, codes: i.scanCodes.map((c) => ({ code: c.code, kind: c.kind })), listing: i.listings[0] ? { state: i.listings[0].state, slug: i.listings[0].slug } : null, directPurchase: i.directPurchase,
      },
    };
  }

  @Post("items/:id/inspect") @HttpCode(200)
  async inspect(@CurrentViewer() v: Viewer, @Param("id") id: string, @Body() body: unknown) { await this.managed.inspect(id, v.userId, parse(InspectInput, body)); return { ok: true }; }

  @Post("items/:id/photos")
  @UseInterceptors(SingleUpload())
  async photo(@CurrentViewer() v: Viewer, @Param("id") id: string, @UploadedFile() file: UploadedFileT) {
    const i = await this.prisma.item.findUnique({ where: { id } });
    if (!i) throw notFound("Item");
    if (i.arrangement === "SELF_MANAGED") throw conflict("Self-managed sellers photograph their own pieces.", "NOT_WAREHOUSE_ITEM");
    const m = await this.media.saveItemPhoto(id, file, { ownerUserId: v.userId });
    return { id: m.id, url: mediaUrl(m.id) };
  }

  @Delete("items/:id/photos/:mediaId")
  async deletePhoto(@Param("id") id: string, @Param("mediaId") mid: string) {
    await this.prisma.mediaAsset.updateMany({ where: { id: mid, itemId: id }, data: { deletedAt: new Date() } });
    return { ok: true };
  }

  @Post("items/:id/catalogue") @HttpCode(200)
  catalogue(@CurrentViewer() v: Viewer, @Param("id") id: string, @Body() body: unknown) { return this.managed.catalogue(id, v.userId, parse(CatalogueInput, body)); }

  @Post("items/:id/move") @HttpCode(200)
  async move(@CurrentViewer() v: Viewer, @Param("id") id: string, @Body() body: unknown) { await this.managed.moveLocation(id, parse(z.object({ code: z.string().max(30) }), body).code, v.userId); return { ok: true }; }

  @Post("items/:id/return-to-seller") @HttpCode(200)
  async returnToSeller(@CurrentViewer() v: Viewer, @Param("id") id: string, @Body() body: unknown) { await this.managed.returnToSeller(id, v.userId, parse(z.object({ trackingNo: z.string().max(40).optional() }), body).trackingNo); return { ok: true }; }

  @Get("locations")
  async locations() {
    const locs = await this.prisma.storageLocation.findMany({ orderBy: { code: "asc" }, include: { _count: { select: { items: true } } } });
    return { locations: locs.map((l) => ({ id: l.id, code: l.code, label: l.label, active: l.active, items: l._count.items })) };
  }

  @Post("locations")
  async addLocation(@CurrentViewer() v: Viewer, @Body() body: unknown) {
    const { code, label } = parse(z.object({ code: z.string().trim().regex(/^[A-Z0-9-]{3,30}$/, "Use capitals, digits and dashes, e.g. LHR-C-01-2"), label: z.string().max(80).optional() }), body);
    const l = await this.prisma.storageLocation.create({ data: { code, label } });
    await this.audit.log({ actorId: v.userId, action: "LOCATION_CREATED", entity: "StorageLocation", entityId: l.id });
    return l;
  }

  @Get("movements")
  async movements() {
    const ev = await this.prisma.custodyEvent.findMany({ orderBy: { createdAt: "desc" }, take: 200, include: { item: { select: { sku: true, title: true } } } });
    return { events: ev.map((e) => ({ id: e.id, at: e.createdAt, sku: e.item.sku, title: e.item.title, from: e.fromParty, to: e.toParty, note: e.note })) };
  }

  /** Unified scan: resolves any code (role-scoped) so the UI can route to receive/inspect/pack/dispatch. */
  @Get("scan/:raw")
  scan(@CurrentViewer() v: Viewer, @Param("raw") raw: string) { return this.codes.resolve(decodeURIComponent(raw), v); }

  @Post("labels")
  async labels(@CurrentViewer() v: Viewer, @Body() body: unknown, @Res() res: Response) {
    const { itemIds, format } = parse(z.object({ itemIds: z.array(z.string()).min(1).max(240), format: z.enum(["thermal", "a4"]).default("thermal") }), body);
    const items = await this.prisma.item.findMany({ where: { id: { in: itemIds } }, include: { brand: true } });
    const issued = [];
    for (const it of items) issued.push({ it, code: await this.codes.issue("ITEM_PACK", { itemId: it.id }, v.userId) });
    await this.codes.markPrinted(issued.map((x) => x.code), v.userId);
    pdf(res, await itemLabelsPdf(issued.map(({ it, code }) => ({ code: code.code, sku: it.sku, brand: it.brand?.name ?? null, size: it.size, title: it.title })), format), "labels.pdf");
  }

  @Get("labels/queue")
  async labelQueue() {
    const codes = await this.prisma.scanCode.findMany({ where: { kind: "ITEM_PACK", voidedAt: null, printCount: 0, item: { arrangement: { not: "SELF_MANAGED" } } }, include: { item: { select: { id: true, sku: true, title: true } } }, take: 200 });
    return { pending: codes.map((c) => ({ code: c.code, itemId: c.item!.id, sku: c.item!.sku, title: c.item!.title })) };
  }

  @Post("labels/:code/void") @HttpCode(200)
  async voidCode(@CurrentViewer() v: Viewer, @Param("code") code: string, @Body() body: unknown) {
    const { reason } = parse(z.object({ reason: z.string().trim().min(3).max(200) }), body);
    const c = await this.codes.voidAndReissue(code, reason, v.userId);
    return { code: c.code };
  }

  // ── Pick / pack / dispatch (warehouse groups) ──
  @Get("packing")
  async packing() {
    const groups = await this.prisma.fulfilmentGroup.findMany({ where: { mode: "WAREHOUSE", state: { in: ["PAID", "PROCESSING"] } }, orderBy: { order: { paidAt: "asc" } }, include: { order: true, items: { where: { voidedAt: null }, include: { item: { include: { location: true } } } }, shipments: true } });
    return { groups: groups.map((g) => ({ id: g.id, orderRef: g.order.reference, state: g.state, paidAt: g.order.paidAt, packVerified: !!g.packVerifiedAt, city: (g.order.shippingAddress as { city: string }).city, picks: g.items.map((i) => ({ sku: i.item.sku, title: i.item.title, location: i.item.location?.code ?? "-" })), shipments: g.shipments.map((s) => ({ id: s.id, state: s.state, trackingNo: s.trackingNo })) })) };
  }

  @Get("groups/:id")
  async group(@CurrentViewer() v: Viewer, @Param("id") id: string) {
    const g = await this.fulfilment.group(id, this.actor(v));
    const expected = ["PAID", "PROCESSING"].includes(g.state) ? await this.fulfilment.expectedCodes(id, v.userId) : [];
    const addr = g.order.shippingAddress as Record<string, string>;
    return { group: { id, orderRef: g.order.reference, state: g.state, packVerifiedAt: g.packVerifiedAt, shipTo: { recipient: addr.recipient, city: addr.city, line1: addr.line1, phone: addr.phone }, expectedCodes: expected,
      items: g.items.map((i) => ({ id: i.id, sku: i.item.sku, title: i.item.title, location: i.item.location?.code ?? null, code: i.item.scanCodes[0]?.code ?? null, photo: i.item.media[0] ? mediaUrl(i.item.media[0].id) : null, bundleLineId: i.bundleLineId })),
      bundles: g.bundleLines.map((b) => ({ id: b.id, bundleId: b.bundleId, sealedCode: b.bundle.scanCodes[0]?.code ?? null })),
      shipments: g.shipments.map((s) => ({ id: s.id, courier: s.courier, trackingNo: s.trackingNo, state: s.state, code: s.scanCodes.find((c) => c.kind === "DISPATCH")?.code ?? null })) } };
  }

  @Get("groups/:id/pack-slip")
  async slip(@CurrentViewer() v: Viewer, @Param("id") id: string, @Res() res: Response) { pdf(res, await this.fulfilment.packSlip(id, this.actor(v)), "pack-slip.pdf"); }

  @Post("groups/:id/pack") @HttpCode(200)
  pack(@CurrentViewer() v: Viewer, @Param("id") id: string, @Body() body: unknown) { return this.fulfilment.verifyPack(id, parse(z.object({ scans: z.array(z.string().max(40)).max(400) }), body).scans, this.actor(v)); }

  @Post("groups/:id/dispatch") @HttpCode(200)
  dispatch(@CurrentViewer() v: Viewer, @Param("id") id: string, @Body() body: unknown) { return this.fulfilment.dispatch(id, this.actor(v), parse(z.object({ parcels: z.number().int().min(1).max(10).optional() }), body)); }

  @Get("shipments/:id/label")
  async label(@CurrentViewer() v: Viewer, @Param("id") id: string, @Res() res: Response) { pdf(res, await this.fulfilment.dispatchLabel(id, this.actor(v)), "dispatch.pdf"); }

  @Post("handover") @HttpCode(200)
  handover(@CurrentViewer() v: Viewer, @Body() body: unknown) { return this.fulfilment.handover(parse(z.object({ code: z.string().max(40) }), body).code, this.actor(v)); }

  // ── Bundling: seal lots (scan exactly the right N pieces), swap a damaged piece ──
  @Get("bundling")
  async bundling() {
    const rows = await this.prisma.bundle.findMany({ where: { arrangement: { not: "SELF_MANAGED" }, state: { in: ["PUBLISHED", "RESERVED", "SOLD", "PENDING_REVIEW"] } }, orderBy: { createdAt: "desc" }, include: { brand: true, style: true, scanCodes: { where: { kind: "BUNDLE_PACK", voidedAt: null } }, items: { where: { releasedAt: null }, include: { item: { include: { location: true, scanCodes: { where: { kind: "ITEM_PACK", voidedAt: null } } } } } } } });
    return { bundles: rows.map((b) => ({ id: b.id, sku: b.sku, title: b.title, state: b.state, size: b.size, sealedCode: b.scanCodes[0]?.code ?? null, pieces: b.items.map((bi) => ({ itemId: bi.itemId, sku: bi.item.sku, title: bi.item.title, size: bi.item.size, location: bi.item.location?.code ?? null, code: bi.item.scanCodes[0]?.code ?? null, stockState: bi.item.stockState })) })) };
  }

  @Post("bundles/:id/seal") @HttpCode(200)
  async seal(@CurrentViewer() v: Viewer, @Param("id") id: string, @Body() body: unknown) {
    const { scans } = parse(z.object({ scans: z.array(z.string().max(40)).max(30) }), body);
    const b = await this.prisma.bundle.findUnique({ where: { id }, include: { items: { where: { releasedAt: null } } } });
    if (!b) throw notFound("Bundle");
    const expected: string[] = [];
    for (const bi of b.items) expected.push((await this.codes.issue("ITEM_PACK", { itemId: bi.itemId }, v.userId)).code);
    const got = new Set(scans.map((s) => parseScan(s)).filter((p) => p.ok).map((p) => (p as { code: string }).code));
    const missing = expected.filter((c) => !got.has(c));
    const extra = [...got].filter((c) => !expected.includes(c));
    if (missing.length || extra.length || scans.length !== b.size) return { sealed: false, missing, extra, need: b.size, scanned: scans.length };
    const code = await this.codes.issue("BUNDLE_PACK", { bundleId: id }, v.userId);
    for (const c of expected) { const sc = await this.prisma.scanCode.findUnique({ where: { code: c } }); if (sc) await this.codes.log(sc.id, "SCANNED_BUNDLING", v.userId); }
    await this.audit.log({ actorId: v.userId, action: "LOT_SEALED", entity: "Bundle", entityId: id, after: { code: code.code } });
    return { sealed: true, code: code.code };
  }

  @Get("bundles/:id/lot-label")
  async lotLabel(@CurrentViewer() v: Viewer, @Param("id") id: string, @Res() res: Response) {
    const b = await this.prisma.bundle.findUnique({ where: { id }, include: { brand: true, style: true, scanCodes: { where: { kind: "BUNDLE_PACK", voidedAt: null } } } });
    if (!b?.scanCodes[0]) throw conflict("Seal the lot first.", "NOT_SEALED");
    await this.codes.markPrinted([b.scanCodes[0]], v.userId);
    pdf(res, await lotLabelPdf({ code: b.scanCodes[0].code, lotSku: b.sku, brand: b.brand.name, style: b.style.name, pieceCount: b.size }), "lot.pdf");
  }

  /** Swap a damaged/missing lot piece for an equivalent (same brand + style, grade ≥ original). Never ship a partial lot. */
  @Post("bundles/:id/swap") @HttpCode(200)
  async swap(@CurrentViewer() v: Viewer, @Param("id") id: string, @Body() body: unknown) {
    const { outItemId, inItemId, reason } = parse(z.object({ outItemId: z.string(), inItemId: z.string(), reason: z.string().trim().min(3).max(300) }), body);
    const b = await this.prisma.bundle.findUnique({ where: { id }, include: { items: { where: { releasedAt: null }, include: { item: true } } } });
    if (!b) throw notFound("Bundle");
    const out = b.items.find((x) => x.itemId === outItemId);
    const inc = await this.prisma.item.findUnique({ where: { id: inItemId }, include: { bundleLinks: { where: { releasedAt: null } }, listings: { where: { state: "PUBLISHED" } } } });
    if (!out || !inc) throw notFound("Piece");
    const rank = { NEW_WITH_TAGS: 0, EXCELLENT: 1, VERY_GOOD: 2, GOOD: 3, FAIR: 4 } as const;
    if (inc.brandId !== b.brandId || inc.styleId !== b.styleId) throw badRequest("Replacement must be the same brand and style.", "SWAP_MISMATCH");
    if (!inc.conditionGrade || rank[inc.conditionGrade] > rank[out.item.conditionGrade ?? "FAIR"]) throw badRequest("Replacement must be the same grade or better.", "SWAP_GRADE");
    if (inc.ownerType !== out.item.ownerType || inc.arrangement !== out.item.arrangement || inc.sellerId !== out.item.sellerId) throw badRequest("Replacement must have the same owner and arrangement.", "SWAP_OWNER");
    if (inc.bundleLinks.length || inc.listings.length || !["READY_TO_LIST", "AVAILABLE"].includes(inc.stockState)) throw conflict("Replacement isn't free to use.", "SWAP_UNAVAILABLE");
    await this.prisma.$transaction(async (tx) => {
      const pos = out.position;
      await tx.bundleItem.update({ where: { id: out.id }, data: { releasedAt: new Date() } });
      await tx.item.update({ where: { id: outItemId }, data: { channel: "RETAIL" } });
      await tx.bundleItem.create({ data: { bundleId: id, itemId: inItemId, position: pos, refRetailMinor: out.refRetailMinor } });
      // The replacement takes the lot's place: walk it through valid states up to the outgoing piece's state (e.g. SOLD for a sold lot);
      // the outgoing piece leaves the lot as damaged/missing. Every step is a legal state-machine transition.
      await tx.item.update({ where: { id: inItemId }, data: { channel: "BUNDLE", stockState: walk(inc.stockState as ItemStockState, out.item.stockState as ItemStockState, ["AVAILABLE", "RESERVED", "SOLD", "PACKED"]) } });
      await tx.item.update({ where: { id: outItemId }, data: { stockState: walk(out.item.stockState as ItemStockState, "LOST_OR_DAMAGED", ["SOLD", "AVAILABLE", "LOST_OR_DAMAGED"]) } });
      const oi = await tx.orderItem.findFirst({ where: { itemId: outItemId, voidedAt: null, bundleLine: { bundleId: id } } });
      if (oi) { await tx.orderItem.update({ where: { id: oi.id }, data: { voidedAt: new Date() } }); await tx.orderItem.create({ data: { groupId: oi.groupId, itemId: inItemId, bundleLineId: oi.bundleLineId, priceMinor: oi.priceMinor, arrangement: oi.arrangement, ownerType: oi.ownerType, commissionBps: oi.commissionBps } }); }
      await tx.scanCode.updateMany({ where: { bundleId: id, kind: "BUNDLE_PACK", voidedAt: null }, data: { voidedAt: new Date(), voidReason: `Piece swapped: ${reason}` } });
      await tx.custodyEvent.create({ data: { itemId: outItemId, fromParty: `LOT:${b.sku}`, toParty: "WAREHOUSE:LHR", actorId: v.userId, note: `Swapped out: ${reason}` } });
      await tx.custodyEvent.create({ data: { itemId: inItemId, fromParty: "WAREHOUSE:LHR", toParty: `LOT:${b.sku}`, actorId: v.userId, note: `Swapped in for ${out.item.sku}` } });
      await this.audit.log({ actorId: v.userId, action: "LOT_PIECE_SWAPPED", entity: "Bundle", entityId: id, after: { outItemId, inItemId, reason } }, tx);
    });
    return { ok: true, resealRequired: true };
  }

  @Post("bundles")
  createPlatformBundle(@CurrentViewer() v: Viewer, @Body() body: unknown) { return this.bundles.create({ actorId: v.userId, sellerId: null }, parse(BundleInput, body)); }

  @Get("bundles/eligible")
  async eligible(@Query() q: unknown) { const { brandId, styleId } = parse(z.object({ brandId: z.string(), styleId: z.string() }), q); return { items: await this.bundles.eligible(null, brandId, styleId) }; }

  // ── Returns & unsold ──
  @Get("returns")
  async returnsQueue() {
    const r = await this.prisma.returnRequest.findMany({ where: { state: { in: ["APPROVED", "IN_TRANSIT"] } }, include: { order: true } });
    const items = await this.prisma.orderItem.findMany({ where: { id: { in: r.map((x) => x.orderItemId) } }, include: { item: true } });
    return { returns: r.map((x) => ({ id: x.id, state: x.state, orderRef: x.order.reference, item: items.find((i) => i.id === x.orderItemId)?.item.title, sku: items.find((i) => i.id === x.orderItemId)?.item.sku })) };
  }
  @Post("returns/:id/in-transit") @HttpCode(200)
  async inTransit(@CurrentViewer() v: Viewer, @Param("id") id: string) { await this.returns.markInTransit(v.userId, id); return { ok: true }; }
  @Post("returns/:id/received") @HttpCode(200)
  async received(@CurrentViewer() v: Viewer, @Param("id") id: string) { await this.returns.markReceived(v.userId, id); return { ok: true }; }

  @Get("unsold")
  async unsold() { return { items: await this.managed.unsold() }; }

  // ── Direct purchase handover ──
  @Get("direct-purchases")
  async dpQueue() {
    const rows = await this.prisma.directPurchase.findMany({ where: { state: "AWAITING_HANDOVER" }, include: { seller: true, items: { select: { id: true, sku: true, title: true, stockState: true } } } });
    return { submissions: rows.map((d) => ({ id: d.id, title: d.title, seller: d.seller.displayName, offerMinor: d.offerMinor, items: d.items })) };
  }
  @Post("direct-purchases/:id/receive") @HttpCode(200)
  async dpReceive(@CurrentViewer() v: Viewer, @Param("id") id: string, @Body() body: unknown) { await this.dp.receive(id, v.userId, parse(z.object({ itemIds: z.array(z.string()).min(1) }), body).itemIds); return { ok: true }; }
}

/** Seller side of managed resale and direct purchase. Accepting a buying offer needs the seller's own confirmation code. */
@Controller("seller")
@Auth("SELLER")
export class SellerManagedController {
  constructor(private readonly prisma: PrismaService, private readonly managed: ManagedService, private readonly dp: DirectPurchaseService, private readonly media: MediaService, private readonly otp: OtpService) {}

  @Get("managed-resale")
  async overview(@CurrentViewer() v: Viewer) {
    const sellerId = requireSeller(v);
    const [agreements, manifests, items, proposals, unsold] = await Promise.all([
      this.prisma.managedResaleAgreement.findMany({ where: { sellerId }, orderBy: { createdAt: "desc" } }),
      this.prisma.intakeManifest.findMany({ where: { sellerId }, orderBy: { createdAt: "desc" }, include: { lines: { include: { item: { select: { sku: true, stockState: true } } } } } }),
      this.prisma.item.groupBy({ by: ["stockState"], where: { sellerId, arrangement: "MANAGED_RESALE" }, _count: true }),
      this.prisma.item.findMany({ where: { sellerId, proposedPriceMinor: { not: null } }, include: { media: { where: { deletedAt: null }, take: 1, orderBy: { position: "asc" } }, conditionReports: { orderBy: { createdAt: "desc" }, take: 1 } } }),
      this.managed.unsold(sellerId),
    ]);
    return {
      agreements: agreements.map((a) => ({ id: a.id, status: a.status, commissionBps: a.commissionBps, requiresPriceApproval: a.requiresPriceApproval, storageDays: a.storageDays, unsoldPolicy: a.unsoldPolicy, requestNote: a.requestNote, createdAt: a.createdAt })),
      manifests: manifests.map((m) => ({ id: m.id, state: m.state, expectedCount: m.expectedCount, createdAt: m.createdAt, trackingNo: m.trackingNo, lines: m.lines.map((l) => ({ id: l.id, description: l.description, state: l.state, note: l.discrepancyNote, sku: l.item?.sku, itemState: l.item?.stockState, expectedPriceMinor: l.expectedPriceMinor })) })),
      itemsByState: items.map((i) => ({ state: i.stockState, count: i._count })),
      priceProposals: proposals.map((p) => ({ id: p.id, sku: p.sku, title: p.title, proposedPriceMinor: p.proposedPriceMinor, photo: p.media[0] ? mediaUrl(p.media[0].id) : null, grade: p.conditionGrade })),
      unsold,
    };
  }

  @Post("managed-resale/request")
  request(@CurrentViewer() v: Viewer, @Body() body: unknown) { return this.managed.request(requireSeller(v), v.userId, parse(z.object({ note: z.string().max(500).optional() }), body).note); }

  @Post("managed-resale/manifests")
  manifest(@CurrentViewer() v: Viewer, @Body() body: unknown) { return this.managed.createManifest(requireSeller(v), v.userId, parse(ManifestInput, body)); }

  @Post("managed-resale/manifests/:id/submit") @HttpCode(200)
  async submit(@CurrentViewer() v: Viewer, @Param("id") id: string) { await this.managed.manifestTransition(id, "SUBMITTED", v.userId, requireSeller(v)); return { ok: true }; }

  @Post("managed-resale/manifests/:id/ship") @HttpCode(200)
  async ship(@CurrentViewer() v: Viewer, @Param("id") id: string, @Body() body: unknown) {
    const { courier, trackingNo } = parse(z.object({ courier: z.string().trim().max(60).optional(), trackingNo: z.string().trim().max(40).optional() }), body);
    await this.managed.manifestTransition(id, "IN_TRANSIT", v.userId, requireSeller(v), { courier: courier ?? "Drop-off", trackingNo: trackingNo ?? null });
    return { ok: true };
  }

  @Post("managed-resale/manifests/:id/cancel") @HttpCode(200)
  async cancel(@CurrentViewer() v: Viewer, @Param("id") id: string) { await this.managed.manifestTransition(id, "CANCELLED", v.userId, requireSeller(v)); return { ok: true }; }

  @Post("managed-resale/items/:id/price") @HttpCode(200)
  price(@CurrentViewer() v: Viewer, @Param("id") id: string, @Body() body: unknown) {
    const { approve, counterMinor } = parse(z.object({ approve: z.boolean(), counterMinor: z.number().int().positive().optional() }), body);
    return this.managed.approvePrice(requireSeller(v), v.userId, id, approve, counterMinor);
  }

  /** Unsold managed piece: reprice (seller's decision) or ask for it back. */
  @Post("managed-resale/items/:id/unsold") @HttpCode(200)
  async unsoldAction(@CurrentViewer() v: Viewer, @Param("id") id: string, @Body() body: unknown) {
    const sellerId = requireSeller(v);
    const input = parse(z.object({ action: z.enum(["REPRICE", "RETURN"]), priceMinor: z.number().int().min(200_000).optional() }), body);
    const item = await this.prisma.item.findUnique({ where: { id } });
    if (!item || item.sellerId !== sellerId || item.arrangement !== "MANAGED_RESALE") throw notFound("Item");
    if (input.action === "REPRICE") {
      if (!input.priceMinor) throw badRequest("Enter the new price.");
      await this.prisma.item.update({ where: { id }, data: { priceMinor: input.priceMinor } });
      await this.prisma.auditLog.create({ data: { actorId: v.userId, action: "UNSOLD_REPRICED", entity: "Item", entityId: id, after: { priceMinor: input.priceMinor } } });
      return { ok: true };
    }
    await this.prisma.auditLog.create({ data: { actorId: v.userId, action: "UNSOLD_RETURN_REQUESTED", entity: "Item", entityId: id } });
    await this.prisma.listing.updateMany({ where: { itemId: id, state: "PUBLISHED" }, data: { state: "PAUSED" } });
    return { ok: true, message: "We'll pack it and send it back to you. The courier fee is deducted from your next payout." };
  }

  // ── Direct purchase (sell to us) ──
  @Get("direct-purchase")
  async dpList(@CurrentViewer() v: Viewer) {
    const rows = await this.prisma.directPurchase.findMany({ where: { sellerId: requireSeller(v) }, orderBy: { createdAt: "desc" }, include: { items: { select: { id: true } } } });
    return { submissions: rows.map((d) => ({ id: d.id, title: d.title, state: d.state, pieces: d.items.length, sellerAskMinor: d.sellerAskMinor, offerMinor: d.state === "SUBMITTED" || d.state === "UNDER_REVIEW" ? null : d.offerMinor, offerExpiresAt: d.offerExpiresAt, createdAt: d.createdAt })) };
  }

  @Get("direct-purchase/:id")
  async dpGet(@CurrentViewer() v: Viewer, @Param("id") id: string) {
    const d = await this.dp.load(id, requireSeller(v));
    return { submission: { id: d.id, title: d.title, description: d.description, state: d.state, sellerAskMinor: d.sellerAskMinor, offerMinor: ["SUBMITTED", "UNDER_REVIEW"].includes(d.state) ? null : d.offerMinor, offerExpiresAt: d.offerExpiresAt, decisionNote: d.decisionNote, paymentRef: d.state === "TRANSFERRED" ? d.paymentRef : null,
      pieces: d.items.map((i) => ({ id: i.id, sku: i.sku, title: i.title, category: i.category.name, size: i.size, stockState: i.stockState, photos: i.media.map((m) => ({ id: m.id, url: mediaUrl(m.id) })) })) } };
  }

  @Post("direct-purchase")
  dpSubmit(@CurrentViewer() v: Viewer, @Body() body: unknown) { return this.dp.submit(requireSeller(v), v.userId, parse(DirectPurchaseInput, body)); }

  @Post("direct-purchase/:id/items/:itemId/photos")
  @UseInterceptors(SingleUpload())
  async dpPhoto(@CurrentViewer() v: Viewer, @Param("id") id: string, @Param("itemId") itemId: string, @UploadedFile() file: UploadedFileT) {
    const d = await this.dp.load(id, requireSeller(v));
    if (!d.items.some((i) => i.id === itemId)) throw notFound("Piece");
    if (!["SUBMITTED", "UNDER_REVIEW"].includes(d.state)) throw conflict("Photos can't be changed now.", "INVALID_STATE");
    const m = await this.media.saveItemPhoto(itemId, file, { ownerUserId: v.userId });
    return { id: m.id, url: mediaUrl(m.id) };
  }

  @Post("direct-purchase/:id/respond") @HttpCode(200)
  async dpRespond(@CurrentViewer() v: Viewer, @Param("id") id: string, @Body() body: unknown) {
    const { accept, code } = parse(z.object({ accept: z.boolean(), code: z.string().length(6).optional() }), body);
    if (accept) await this.otp.confirmOwnAction(v.phone, code); // money + ownership: the seller's own confirmation
    return this.dp.respond(id, requireSeller(v), v.userId, accept);
  }
}

/** Buying team & agreements (admin/finance). */
@Controller("admin")
@Auth("ADMIN", "FINANCE")
export class AdminBuyingController {
  constructor(private readonly prisma: PrismaService, private readonly dp: DirectPurchaseService, private readonly audit: AuditService) {}

  @Get("agreements")
  async agreements() {
    const rows = await this.prisma.managedResaleAgreement.findMany({ orderBy: { createdAt: "desc" }, include: { seller: true, _count: { select: { manifests: true } } } });
    return { agreements: rows.map((a) => ({ id: a.id, status: a.status, seller: a.seller.displayName, sellerId: a.sellerId, commissionBps: a.commissionBps, requiresPriceApproval: a.requiresPriceApproval, storageDays: a.storageDays, unsoldPolicy: a.unsoldPolicy, requestNote: a.requestNote, manifests: a._count.manifests, createdAt: a.createdAt })) };
  }

  @Post("agreements/:id/approve") @HttpCode(200)
  async approve(@CurrentViewer() v: Viewer, @Param("id") id: string, @Body() body: unknown) {
    const input = parse(z.object({ commissionBps: z.number().int().min(0).max(6000).default(3000), requiresPriceApproval: z.boolean().default(true), storageDays: z.number().int().min(30).max(365).default(90), unsoldPolicy: z.enum(["RETURN", "REPRICE", "DONATE"]).default("RETURN") }), body);
    const a = await this.prisma.managedResaleAgreement.findUnique({ where: { id } });
    if (!a || a.status !== "REQUESTED") throw conflict("Only requested agreements can be approved.", "INVALID_STATE");
    await this.prisma.managedResaleAgreement.update({ where: { id }, data: { ...input, status: "ACTIVE", approvedById: v.userId, approvedAt: new Date(), effectiveFrom: new Date() } });
    await this.audit.log({ actorId: v.userId, action: "AGREEMENT_APPROVED", entity: "ManagedResaleAgreement", entityId: id, after: input });
    return { ok: true };
  }

  @Post("agreements/:id/decline") @HttpCode(200)
  async declineAgreement(@CurrentViewer() v: Viewer, @Param("id") id: string) {
    await this.prisma.managedResaleAgreement.update({ where: { id }, data: { status: "DECLINED" } });
    await this.audit.log({ actorId: v.userId, action: "AGREEMENT_DECLINED", entity: "ManagedResaleAgreement", entityId: id });
    return { ok: true };
  }

  @Get("direct-purchases")
  async dps(@Query() q: unknown) {
    const { state } = parse(z.object({ state: z.string().optional() }), q);
    const rows = await this.prisma.directPurchase.findMany({ where: state ? { state: { in: state.split(",") as never } } : {}, orderBy: { createdAt: "desc" }, include: { seller: true, items: { select: { id: true, priceMinor: true } } } });
    return { submissions: rows.map((d) => ({ id: d.id, title: d.title, seller: d.seller.displayName, state: d.state, pieces: d.items.length, sellerAskMinor: d.sellerAskMinor, expectedRetailMinor: d.expectedRetailMinor, offerMinor: d.offerMinor, budgetCode: d.budgetCode, createdAt: d.createdAt, offerExpiresAt: d.offerExpiresAt })) };
  }

  @Get("direct-purchases/:id")
  async dpGet(@Param("id") id: string) {
    const d = await this.dp.load(id);
    return { submission: { ...d, seller: { displayName: d.seller.displayName, city: d.seller.city }, items: d.items.map((i) => ({ id: i.id, sku: i.sku, title: i.title, category: i.category.name, size: i.size, priceMinor: i.priceMinor, stockState: i.stockState, ownerType: i.ownerType, costMinor: i.costMinor, photos: i.media.map((m) => mediaUrl(m.id)) })) } };
  }

  @Post("direct-purchases/:id/review") @HttpCode(200)
  async review(@CurrentViewer() v: Viewer, @Param("id") id: string) { await this.dp.review(id, v.userId); return { ok: true }; }
  @Post("direct-purchases/:id/offer") @HttpCode(200)
  async offer(@CurrentViewer() v: Viewer, @Param("id") id: string, @Body() body: unknown) { await this.dp.offer(id, v.userId, parse(OfferInput, body)); return { ok: true }; }
  @Post("direct-purchases/:id/decline") @HttpCode(200)
  async decline(@CurrentViewer() v: Viewer, @Param("id") id: string, @Body() body: unknown) { await this.dp.decline(id, v.userId, parse(z.object({ note: z.string().min(3).max(500) }), body).note); return { ok: true }; }
  @Post("direct-purchases/:id/transfer") @HttpCode(200)
  @Auth("FINANCE", "ADMIN")
  async transfer(@CurrentViewer() v: Viewer, @Param("id") id: string, @Body() body: unknown) { await this.dp.transfer(id, v.userId, parse(z.object({ paymentRef: z.string().trim().min(3).max(80) }), body).paymentRef); return { ok: true }; }
  @Post("direct-purchases/:id/cancel") @HttpCode(200)
  async cancelDp(@CurrentViewer() v: Viewer, @Param("id") id: string, @Body() body: unknown) { await this.dp.cancel(id, v.userId, parse(z.object({ note: z.string().min(3).max(500) }), body).note); return { ok: true }; }

  @Get("budgets")
  async budgets() {
    const rows = await this.prisma.buyingBudget.findMany({ orderBy: { periodStart: "desc" } });
    return { budgets: await Promise.all(rows.map(async (b) => ({ ...b, remainingMinor: (await this.dp.budgetRemaining(b.code))?.remainingMinor ?? 0 }))) };
  }

  @Post("budgets")
  async addBudget(@CurrentViewer() v: Viewer, @Body() body: unknown) {
    const input = parse(z.object({ code: z.string().trim().regex(/^[A-Z0-9-]{3,30}$/), label: z.string().max(80), limitMinor: z.number().int().positive(), periodStart: z.coerce.date(), periodEnd: z.coerce.date() }), body);
    const b = await this.prisma.buyingBudget.create({ data: input });
    await this.audit.log({ actorId: v.userId, action: "BUDGET_CREATED", entity: "BuyingBudget", entityId: b.id, after: input });
    return b;
  }
}
