import { Injectable } from "@nestjs/common";
import type { ConditionGrade, ManifestLineState } from "@prisma/client";
import { itemStock, manifest as manifestMachine, MANAGED_MARKDOWNS, MANAGED_MIN_ITEM_PRICE_MINOR, type ItemStockState, type ManifestState } from "@ooak/shared";
import { z } from "zod";
import { AuditService } from "../../common/audit.service";
import { NotifierService } from "../../common/notifier.service";
import { PrismaService, type Tx } from "../../common/prisma.service";
import { badRequest, conflict, notFound, unprocessable } from "../../common/problem";
import { CodesService } from "../codes/codes.service";
import { ListingService } from "../seller/listing.service";

export const ManifestInput = z.object({
  notes: z.string().trim().max(500).optional(),
  lines: z.array(z.object({
    description: z.string().trim().min(3).max(200), categoryId: z.string().min(1), brandName: z.string().trim().max(60).optional().nullable(),
    expectedPriceMinor: z.number().int().min(MANAGED_MIN_ITEM_PRICE_MINOR, `Managed resale minimum is PKR ${MANAGED_MIN_ITEM_PRICE_MINOR / 100}`).max(100_000_000),
  })).min(1).max(200),
});
export const InspectInput = z.object({
  pass: z.boolean(),
  grade: z.enum(["NEW_WITH_TAGS", "EXCELLENT", "VERY_GOOD", "GOOD", "FAIR"]).optional(),
  defects: z.array(z.object({ type: z.string().min(2).max(60), location: z.string().min(2).max(60), severity: z.enum(["minor", "moderate", "major"]) })).max(12).default([]),
  measurements: z.record(z.string().max(30), z.number().positive().max(500)).optional(),
  size: z.string().trim().max(30).optional(), color: z.string().trim().max(30).optional(), material: z.string().trim().max(120).optional(),
  weightGrams: z.number().int().min(10).max(30_000).optional(), styleId: z.string().optional().nullable(), notes: z.string().trim().max(500).optional(),
  locationCode: z.string().trim().max(30).optional(), rejectReason: z.string().trim().max(300).optional(),
});
export const CatalogueInput = z.object({ title: z.string().trim().min(3).max(120), description: z.string().trim().max(2000).optional(), priceMinor: z.number().int().min(10_000).max(100_000_000) });

const slugify = (s: string) => s.toLowerCase().replace(/['’]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 70);

/** Managed resale (consignment): request → agreement → manifest → receiving → inspection → photos/catalogue → (seller price approval) → listing → sale or unsold handling. */
@Injectable()
export class ManagedService {
  constructor(
    private readonly prisma: PrismaService, private readonly audit: AuditService, private readonly notifier: NotifierService,
    private readonly codes: CodesService, private readonly listings: ListingService,
  ) {}

  private async moveItem(tx: Tx, itemId: string, from: ItemStockState, to: ItemStockState) {
    itemStock.assert(from, to);
    const n = await tx.item.updateMany({ where: { id: itemId, stockState: from }, data: { stockState: to, version: { increment: 1 } } });
    if (n.count !== 1) throw conflict(`Item is no longer ${from}.`, "ITEM_STATE");
  }

  // ── Seller side ──
  async request(sellerId: string, userId: string, note: string | undefined) {
    const open = await this.prisma.managedResaleAgreement.findFirst({ where: { sellerId, status: { in: ["REQUESTED", "ACTIVE"] } } });
    if (open) throw conflict(open.status === "ACTIVE" ? "You already have managed resale." : "Your request is being reviewed.", "ALREADY_REQUESTED");
    const a = await this.prisma.managedResaleAgreement.create({ data: { sellerId, status: "REQUESTED", commissionBps: 3000, unsoldPolicy: "RETURN", effectiveFrom: new Date(), requestNote: note ?? null } });
    await this.audit.log({ actorId: userId, action: "MANAGED_RESALE_REQUESTED", entity: "ManagedResaleAgreement", entityId: a.id });
    return a;
  }

  async createManifest(sellerId: string, userId: string, input: z.infer<typeof ManifestInput>) {
    const agreement = await this.prisma.managedResaleAgreement.findFirst({ where: { sellerId, status: "ACTIVE" } });
    if (!agreement) throw conflict("Managed resale isn't active for your account yet.", "NO_AGREEMENT");
    return this.prisma.$transaction(async (tx) => {
      const m = await tx.intakeManifest.create({ data: { sellerId, agreementId: agreement.id, expectedCount: input.lines.length, notes: input.notes } });
      for (const l of input.lines) {
        const sku = await this.listings.newSku(tx);
        const item = await tx.item.create({
          data: { sku, sellerId, categoryId: l.categoryId, brandId: await this.listings.brandId(l.brandName, tx), arrangement: "MANAGED_RESALE", stockState: "EXPECTED", title: l.description.slice(0, 120), priceMinor: l.expectedPriceMinor },
        });
        await tx.intakeManifestLine.create({ data: { manifestId: m.id, itemId: item.id, description: l.description, categoryId: l.categoryId, brandName: l.brandName ?? null, expectedPriceMinor: l.expectedPriceMinor } });
      }
      await this.audit.log({ actorId: userId, action: "MANIFEST_CREATED", entity: "IntakeManifest", entityId: m.id, after: { lines: input.lines.length } }, tx);
      return m;
    });
  }

  async manifestTransition(id: string, to: ManifestState, actorId: string, sellerId?: string, extra: Record<string, unknown> = {}) {
    const m = await this.prisma.intakeManifest.findUnique({ where: { id }, include: { lines: true } });
    if (!m || (sellerId && m.sellerId !== sellerId)) throw notFound("Manifest");
    manifestMachine.assert(m.state as ManifestState, to);
    await this.prisma.$transaction(async (tx) => {
      await tx.intakeManifest.update({ where: { id }, data: { state: to, ...extra } });
      if (to === "CANCELLED") {
        for (const l of m.lines) if (l.itemId) { const it = await tx.item.findUniqueOrThrow({ where: { id: l.itemId } }); if (it.stockState === "EXPECTED") await this.moveItem(tx, it.id, "EXPECTED", "WITHDRAWN"); }
      }
      if (to === "IN_TRANSIT") for (const l of m.lines) if (l.itemId) await tx.custodyEvent.create({ data: { itemId: l.itemId, fromParty: "SELLER", toParty: `COURIER:${(extra.trackingNo as string) ?? "drop-off"}`, actorId, note: "Sent to warehouse" } });
      await this.audit.log({ actorId, action: `MANIFEST_${to}`, entity: "IntakeManifest", entityId: id, before: { state: m.state } }, tx);
    });
  }

  /** Seller's own approval of the price our team proposed (needs the seller; never on-behalf). */
  async approvePrice(sellerId: string, userId: string, itemId: string, approve: boolean, counterMinor?: number) {
    const item = await this.prisma.item.findUnique({ where: { id: itemId }, include: { listings: { orderBy: { createdAt: "desc" }, take: 1 } } });
    if (!item || item.sellerId !== sellerId || item.proposedPriceMinor === null) throw notFound("Price proposal");
    if (!approve) {
      if (!counterMinor || counterMinor < MANAGED_MIN_ITEM_PRICE_MINOR) throw badRequest(`Suggest a price of at least PKR ${MANAGED_MIN_ITEM_PRICE_MINOR / 100}.`, "COUNTER_REQUIRED");
      await this.prisma.item.update({ where: { id: itemId }, data: { proposedPriceMinor: counterMinor } });
      await this.audit.log({ actorId: userId, action: "PRICE_COUNTERED", entity: "Item", entityId: itemId, after: { counterMinor } });
      return { status: "COUNTERED" };
    }
    await this.prisma.$transaction(async (tx) => {
      await tx.item.update({ where: { id: itemId }, data: { priceMinor: item.proposedPriceMinor!, proposedPriceMinor: null, priceApprovedAt: new Date() } });
      const l = item.listings[0];
      if (l && l.state === "DRAFT") await tx.listing.update({ where: { id: l.id }, data: { state: "PENDING_REVIEW" } });
      await this.audit.log({ actorId: userId, action: "PRICE_APPROVED_BY_SELLER", entity: "Item", entityId: itemId, after: { priceMinor: item.proposedPriceMinor } }, tx);
    });
    return { status: "APPROVED" };
  }

  // ── Warehouse ──
  async receiveLine(manifestId: string, lineId: string, outcome: ManifestLineState, actorId: string, note?: string) {
    const m = await this.prisma.intakeManifest.findUnique({ where: { id: manifestId }, include: { lines: true } });
    if (!m) throw notFound("Manifest");
    if (m.state === "IN_TRANSIT") await this.manifestTransition(manifestId, "RECEIVING", actorId, undefined, { receivedAt: new Date() });
    else if (m.state !== "RECEIVING") throw conflict(`Manifest is ${m.state}.`, "INVALID_STATE");
    const line = m.lines.find((l) => l.id === lineId);
    if (!line || !line.itemId) throw notFound("Line");
    if (line.state !== "EXPECTED") throw conflict("This line was already processed.", "ALREADY_PROCESSED");
    if (!["RECEIVED", "MISSING", "DECLINED", "DISPUTED"].includes(outcome)) throw badRequest("Invalid outcome.");
    const code = await this.prisma.$transaction(async (tx) => {
      await tx.intakeManifestLine.update({ where: { id: lineId }, data: { state: outcome, discrepancyNote: note ?? null } });
      if (outcome === "RECEIVED") {
        await this.moveItem(tx, line.itemId!, "EXPECTED", "RECEIVED");
        await tx.custodyEvent.create({ data: { itemId: line.itemId!, fromParty: m.trackingNo ? `COURIER:${m.trackingNo}` : "SELLER", toParty: "WAREHOUSE:LHR", actorId, note: "Received against manifest" } });
        return this.codes.issue("ITEM_PACK", { itemId: line.itemId! }, actorId, tx); // warehouse items get a label at receiving
      }
      if (outcome === "MISSING" || outcome === "DECLINED") await this.moveItem(tx, line.itemId!, "EXPECTED", "WITHDRAWN");
      return null;
    });
    if (code) await this.codes.log(code.id, "SCANNED_RECEIVE", actorId);
    await this.audit.log({ actorId, action: `MANIFEST_LINE_${outcome}`, entity: "IntakeManifestLine", entityId: lineId, after: { note } });
    return { code: code?.code ?? null };
  }

  async reconcile(manifestId: string, actorId: string) {
    const m = await this.prisma.intakeManifest.findUnique({ where: { id: manifestId }, include: { lines: true, seller: true } });
    if (!m) throw notFound("Manifest");
    const open = m.lines.filter((l) => l.state === "EXPECTED");
    if (open.length) throw conflict(`${open.length} line(s) still need an outcome.`, "LINES_OPEN");
    await this.manifestTransition(manifestId, "RECONCILED", actorId, undefined, { reconciledAt: new Date() });
    const count = (s: string) => m.lines.filter((l) => l.state === s).length;
    await this.notifier.inApp(m.seller.userId, "MANIFEST_RECONCILED", `We received your parcel: ${count("RECEIVED")} received, ${count("MISSING")} missing, ${count("DECLINED")} declined, ${count("DISPUTED")} to discuss.`);
  }

  async inspect(itemId: string, actorId: string, input: z.infer<typeof InspectInput>) {
    const item = await this.prisma.item.findUnique({ where: { id: itemId }, include: { category: true } });
    if (!item) throw notFound("Item");
    if (!["RECEIVED", "RETURNED_TO_STOCK"].includes(item.stockState)) throw conflict(`Item is ${item.stockState}; only received items can be inspected.`, "ITEM_STATE");
    if (input.pass) {
      if (!input.grade) throw badRequest("Choose a grade.", "GRADE_REQUIRED");
      const required = ((item.category.attributeSchema as { measurements?: string[] } | null)?.measurements ?? []);
      const missing = required.filter((k) => typeof input.measurements?.[k] !== "number");
      if (missing.length) throw unprocessable(`Measure: ${missing.join(", ")}`, "MEASUREMENTS_REQUIRED");
      if (["GOOD", "FAIR"].includes(input.grade) && !input.defects.length) throw unprocessable("Grade C/D needs the flaws listed.", "DEFECTS_REQUIRED");
    }
    const loc = input.locationCode ? await this.prisma.storageLocation.findUnique({ where: { code: input.locationCode } }) : null;
    if (input.locationCode && !loc) throw badRequest("Unknown shelf location.", "UNKNOWN_LOCATION");
    await this.prisma.$transaction(async (tx) => {
      await this.moveItem(tx, itemId, item.stockState as ItemStockState, "IN_INSPECTION");
      if (input.pass) {
        await tx.item.update({ where: { id: itemId }, data: { conditionGrade: input.grade as ConditionGrade, measurements: input.measurements ?? {}, size: input.size ?? item.size, color: input.color ?? item.color, material: input.material ?? item.material, weightGrams: input.weightGrams ?? item.weightGrams, styleId: input.styleId === undefined ? item.styleId : input.styleId, locationId: loc?.id ?? item.locationId } });
        await tx.conditionReport.create({ data: { itemId, grade: input.grade as ConditionGrade, defects: input.defects, notes: input.notes, inspectedById: actorId, source: "WAREHOUSE" } });
        await this.moveItem(tx, itemId, "IN_INSPECTION", "READY_TO_LIST");
        if (loc) await tx.custodyEvent.create({ data: { itemId, fromParty: "WAREHOUSE:LHR", toParty: "WAREHOUSE:LHR", locationId: loc.id, actorId, note: `Shelved at ${loc.code}` } });
      } else {
        await tx.conditionReport.create({ data: { itemId, grade: (input.grade ?? "FAIR") as ConditionGrade, defects: input.defects, notes: input.rejectReason ?? input.notes, inspectedById: actorId, source: "WAREHOUSE" } });
        await this.moveItem(tx, itemId, "IN_INSPECTION", "REJECTED");
      }
      await this.audit.log({ actorId, action: input.pass ? "ITEM_INSPECTED_PASS" : "ITEM_INSPECTED_REJECTED", entity: "Item", entityId: itemId, after: { grade: input.grade, reason: input.rejectReason } }, tx);
    });
    if (!input.pass) {
      const s = await this.prisma.sellerProfile.findUniqueOrThrow({ where: { id: item.sellerId } });
      await this.notifier.inApp(s.userId, "ITEM_REJECTED", `“${item.title}” didn't pass inspection: ${input.rejectReason ?? "see condition report"}. We'll return it to you.`);
    }
  }

  /** Photos + copy + price by our team. If the agreement requires it, the seller must approve the price before review. */
  async catalogue(itemId: string, actorId: string, input: z.infer<typeof CatalogueInput>) {
    const item = await this.prisma.item.findUnique({ where: { id: itemId }, include: { media: { where: { deletedAt: null } }, listings: true, seller: { include: { agreements: { where: { status: "ACTIVE" } } } } } });
    if (!item) throw notFound("Item");
    if (item.stockState !== "READY_TO_LIST") throw conflict(`Item is ${item.stockState}.`, "ITEM_STATE");
    if (item.media.length < 2) throw unprocessable("Add at least 2 studio photos first.", "PHOTOS_REQUIRED");
    if (item.arrangement === "DIRECT_PURCHASE" && item.ownerType !== "PLATFORM") throw conflict("Can't list a direct-purchase piece before ownership transfer.", "NOT_TRANSFERRED");
    const needsApproval = item.arrangement === "MANAGED_RESALE" && !!item.seller.agreements[0]?.requiresPriceApproval;
    await this.prisma.$transaction(async (tx) => {
      await tx.item.update({ where: { id: itemId }, data: { title: input.title, description: input.description ?? item.description, ...(needsApproval ? { proposedPriceMinor: input.priceMinor } : { priceMinor: input.priceMinor }) } });
      const existing = item.listings.find((l) => l.state !== "REMOVED");
      const state = needsApproval ? "DRAFT" : "PENDING_REVIEW";
      if (existing) await tx.listing.update({ where: { id: existing.id }, data: { state } });
      else await tx.listing.create({ data: { itemId, sellerId: item.sellerId, slug: `${slugify(input.title)}-${item.sku.slice(5)}`, state } });
      await this.audit.log({ actorId, action: "ITEM_CATALOGUED", entity: "Item", entityId: itemId, after: { priceMinor: input.priceMinor, needsApproval } }, tx);
    });
    if (needsApproval) await this.notifier.inApp(item.seller.userId, "PRICE_APPROVAL", `Please approve the price for “${input.title}”: PKR ${(input.priceMinor / 100).toLocaleString("en-PK")}.`);
    return { needsSellerApproval: needsApproval };
  }

  async moveLocation(itemId: string, code: string, actorId: string) {
    const loc = await this.prisma.storageLocation.findUnique({ where: { code } });
    if (!loc || !loc.active) throw badRequest("Unknown shelf location.", "UNKNOWN_LOCATION");
    const item = await this.prisma.item.findUnique({ where: { id: itemId }, include: { location: true } });
    if (!item) throw notFound("Item");
    await this.prisma.$transaction([
      this.prisma.item.update({ where: { id: itemId }, data: { locationId: loc.id } }),
      this.prisma.custodyEvent.create({ data: { itemId, fromParty: `WAREHOUSE:${item.location?.code ?? "LHR"}`, toParty: `WAREHOUSE:${loc.code}`, locationId: loc.id, actorId, note: "Moved" } }),
    ]);
  }

  /** Rejected/withdrawn/unsold pieces going back to the seller (custody recorded). */
  async returnToSeller(itemId: string, actorId: string, trackingNo?: string) {
    const item = await this.prisma.item.findUnique({ where: { id: itemId }, include: { listings: { where: { state: { in: ["PUBLISHED", "PAUSED", "PENDING_REVIEW", "DRAFT"] } } } } });
    if (!item) throw notFound("Item");
    await this.prisma.$transaction(async (tx) => {
      if (item.stockState === "AVAILABLE" || item.stockState === "READY_TO_LIST") await this.moveItem(tx, itemId, item.stockState as ItemStockState, "WITHDRAWN");
      const now = (await tx.item.findUniqueOrThrow({ where: { id: itemId } })).stockState as ItemStockState;
      await this.moveItem(tx, itemId, now, "RETURNED_TO_SELLER");
      for (const l of item.listings) await tx.listing.update({ where: { id: l.id }, data: { state: "REMOVED" } });
      await tx.item.update({ where: { id: itemId }, data: { locationId: null } });
      await tx.custodyEvent.create({ data: { itemId, fromParty: "WAREHOUSE:LHR", toParty: trackingNo ? `COURIER:${trackingNo}` : "SELLER", actorId, note: "Returned to seller" } });
      await this.audit.log({ actorId, action: "RETURNED_TO_SELLER", entity: "Item", entityId: itemId }, tx);
    });
  }

  /** Managed pieces live longer than the markdown/storage milestones (COMMERCIAL_POLICY §4). */
  async unsold(sellerId?: string) {
    const items = await this.prisma.item.findMany({
      where: { arrangement: "MANAGED_RESALE", stockState: "AVAILABLE", ...(sellerId ? { sellerId } : {}), listings: { some: { state: "PUBLISHED" } } },
      include: { listings: { where: { state: "PUBLISHED" }, take: 1 }, seller: { include: { agreements: { where: { status: "ACTIVE" }, take: 1 } } }, location: true },
    });
    const now = Date.now();
    return items.map((i) => {
      const since = i.listings[0]?.publishedAt ?? i.createdAt;
      const days = Math.floor((now - since.getTime()) / 86_400_000);
      const storageDays = i.seller.agreements[0]?.storageDays ?? 90;
      const markdown = [...MANAGED_MARKDOWNS].reverse().find((m) => days >= m.day);
      return { id: i.id, sku: i.sku, title: i.title, priceMinor: i.priceMinor, daysListed: days, storageDays, location: i.location?.code ?? null, seller: i.seller.displayName,
        suggestion: days >= storageDays ? "DECIDE" : markdown ? `MARKDOWN_${markdown.percentOff}` : null };
    }).filter((x) => x.suggestion);
  }
}
