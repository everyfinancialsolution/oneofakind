import { Injectable } from "@nestjs/common";
import { canPurchaseBundle, RESERVATION_MINUTES } from "@ooak/shared";
import { randomBytes } from "node:crypto";
import type { Request, Response } from "express";
import { toSharedViewer, type Viewer } from "../../common/auth";
import { PrismaService } from "../../common/prisma.service";
import { badRequest, conflict, forbidden, notFound } from "../../common/problem";
import { config } from "../../config";
import { gradeView, mediaUrl } from "../catalog/presenters";

export const CART_COOKIE = "ooak_cart";
export const PLATFORM_GROUP = "PLATFORM";

/** Fulfilment group key: platform-owned stock ships from our warehouse as ONEOFAKIND; managed stock from our warehouse for the seller; self-managed from the seller. */
export function groupKeyFor(i: { sellerId: string; ownerType: string; arrangement: string }) {
  if (i.ownerType === "PLATFORM") return { sellerId: PLATFORM_GROUP, mode: "WAREHOUSE" as const };
  return { sellerId: i.sellerId, mode: i.arrangement === "SELF_MANAGED" ? ("SELLER_ARRANGED" as const) : ("WAREHOUSE" as const) };
}

@Injectable()
export class CartService {
  constructor(private readonly prisma: PrismaService) {}

  /** Finds (or creates) the cart for this request. Guest carts live in a cookie and merge into the user's cart on login. */
  async cartFor(req: Request, res: Response | null, v: Viewer | null, create: boolean) {
    const guestToken = (req as Request & { cookies?: Record<string, string> }).cookies?.[CART_COOKIE];
    if (v) {
      let cart = await this.prisma.cart.findFirst({ where: { userId: v.userId }, orderBy: { createdAt: "asc" } });
      if (!cart && create) cart = await this.prisma.cart.create({ data: { userId: v.userId } });
      if (guestToken) {
        const guest = await this.prisma.cart.findUnique({ where: { guestToken }, include: { items: true } });
        if (guest && guest.userId === null) {
          if (!cart) cart = await this.prisma.cart.create({ data: { userId: v.userId } });
          for (const it of guest.items) {
            const exists = await this.prisma.cartItem.findFirst({ where: { cartId: cart.id, itemId: it.itemId, bundleId: it.bundleId } });
            if (!exists) await this.prisma.cartItem.create({ data: { cartId: cart.id, itemId: it.itemId, bundleId: it.bundleId } });
          }
          await this.prisma.cart.delete({ where: { id: guest.id } });
        }
        res?.clearCookie(CART_COOKIE, { path: "/" });
      }
      return cart;
    }
    if (guestToken) {
      const c = await this.prisma.cart.findUnique({ where: { guestToken } });
      if (c && !c.userId) return c;
    }
    if (!create) return null;
    const token = randomBytes(24).toString("base64url");
    res?.cookie(CART_COOKIE, token, { httpOnly: true, sameSite: "lax", secure: config().COOKIE_SECURE, path: "/", maxAge: 30 * 86_400_000 });
    return this.prisma.cart.create({ data: { guestToken: token } });
  }

  async add(cartId: string, v: Viewer | null, input: { listingSlug?: string; bundleSlug?: string }) {
    if (input.listingSlug) {
      const l = await this.prisma.listing.findUnique({ where: { slug: input.listingSlug }, include: { item: true } });
      if (!l || l.state !== "PUBLISHED") throw notFound("Listing");
      if (l.item.stockState !== "AVAILABLE") throw conflict(l.item.stockState === "RESERVED" ? "Someone is checking out with this piece right now." : "Sorry, this piece has sold.", "UNAVAILABLE");
      if (v?.sellerId && v.sellerId === l.sellerId && l.item.ownerType === "SELLER") throw badRequest("You can't buy your own item.", "OWN_ITEM");
      const exists = await this.prisma.cartItem.findFirst({ where: { cartId, itemId: l.itemId } });
      if (!exists) await this.prisma.cartItem.create({ data: { cartId, itemId: l.itemId } });
      return;
    }
    if (input.bundleSlug) {
      // Reseller-only gate enforced in the API (not just the UI).
      if (!canPurchaseBundle(toSharedViewer(v))) throw forbidden("Bundles can be bought by verified resellers only.", "RESELLER_ONLY");
      const b = await this.prisma.bundle.findUnique({ where: { slug: input.bundleSlug } });
      if (!b || b.state !== "PUBLISHED") throw conflict("This lot is no longer available.", "UNAVAILABLE");
      if (v?.sellerId && b.sellerId === v.sellerId) throw badRequest("You can't buy your own lot.", "OWN_ITEM");
      const exists = await this.prisma.cartItem.findFirst({ where: { cartId, bundleId: b.id } });
      if (!exists) await this.prisma.cartItem.create({ data: { cartId, bundleId: b.id } });
      return;
    }
    throw badRequest("Choose an item or a lot.", "NOTHING_TO_ADD");
  }

  /** Cart lines grouped per fulfilment group, with live availability and any accepted-offer price for this buyer. */
  async view(cartId: string | null, v: Viewer | null) {
    if (!cartId) return { lines: [], groups: [], subtotalMinor: 0, hasBundles: false, reservationMinutes: RESERVATION_MINUTES };
    const items = await this.prisma.cartItem.findMany({ where: { cartId }, orderBy: { addedAt: "asc" } });
    const itemRows = await this.prisma.item.findMany({
      where: { id: { in: items.map((i) => i.itemId).filter((x): x is string => !!x) } },
      include: { brand: true, seller: true, listings: { where: { state: { in: ["PUBLISHED", "SOLD_OUT", "PAUSED", "REMOVED"] } }, orderBy: { createdAt: "desc" }, take: 1 }, media: { where: { approvedForPublish: true, deletedAt: null }, orderBy: { position: "asc" }, take: 1 } },
    });
    const bundleRows = await this.prisma.bundle.findMany({
      where: { id: { in: items.map((i) => i.bundleId).filter((x): x is string => !!x) } },
      include: { seller: true, brand: true, items: { where: { releasedAt: null }, include: { item: { include: { media: { where: { approvedForPublish: true, deletedAt: null }, take: 1, orderBy: { position: "asc" } } } } } } },
    });
    const offers = v ? await this.prisma.buyerOffer.findMany({ where: { buyerId: v.userId, state: "ACCEPTED", expiresAt: { gt: new Date() }, itemId: { in: itemRows.map((i) => i.id) } } }) : [];
    const canBuyBundles = canPurchaseBundle(toSharedViewer(v));
    const lines = items.map((ci) => {
      if (ci.itemId) {
        const it = itemRows.find((x) => x.id === ci.itemId)!;
        const offer = offers.find((o) => o.itemId === it.id);
        const g = groupKeyFor(it);
        return {
          id: ci.id, kind: "ITEM" as const, slug: it.listings[0]?.slug ?? null, title: it.title, brand: it.brand?.name ?? null, size: it.size, grade: gradeView(it.conditionGrade),
          image: it.media[0] ? mediaUrl(it.media[0].id) : null, priceMinor: offer?.amountMinor ?? it.priceMinor, listPriceMinor: it.priceMinor, offerApplied: !!offer,
          available: it.stockState === "AVAILABLE" && it.listings[0]?.state === "PUBLISHED" && it.channel === "RETAIL",
          availability: it.stockState === "AVAILABLE" ? "AVAILABLE" : it.stockState === "RESERVED" ? "RESERVED" : "SOLD",
          groupKey: `${g.sellerId}:${g.mode}`, sellerName: it.ownerType === "PLATFORM" ? "ONEOFAKIND" : it.seller.displayName, shipsFrom: g.mode === "WAREHOUSE" ? "ONEOFAKIND warehouse, Lahore" : it.seller.city ?? "Pakistan",
          weightGrams: it.weightGrams ?? 500,
        };
      }
      const b = bundleRows.find((x) => x.id === ci.bundleId)!;
      const first = b.items[0]?.item;
      const g = first ? groupKeyFor(first) : { sellerId: PLATFORM_GROUP, mode: "WAREHOUSE" as const };
      return {
        id: ci.id, kind: "BUNDLE" as const, slug: b.slug, title: b.title, brand: b.brand.name, size: `${b.size} pieces`, grade: null,
        image: first?.media[0] ? mediaUrl(first.media[0].id) : null, priceMinor: canBuyBundles ? b.priceMinor : 0, listPriceMinor: canBuyBundles ? b.priceMinor : 0, offerApplied: false,
        available: b.state === "PUBLISHED" && canBuyBundles && b.items.every((bi) => bi.item.stockState === "AVAILABLE"),
        availability: b.state === "PUBLISHED" ? "AVAILABLE" : b.state === "RESERVED" ? "RESERVED" : "SOLD",
        groupKey: `${g.sellerId}:${g.mode}`, sellerName: b.ownerType === "PLATFORM" || !b.seller ? "ONEOFAKIND" : b.seller.displayName, shipsFrom: g.mode === "WAREHOUSE" ? "ONEOFAKIND warehouse, Lahore" : b.seller?.city ?? "Pakistan",
        weightGrams: b.items.reduce((a, bi) => a + (bi.item.weightGrams ?? 0), 0),
      };
    });
    const groups = [...new Set(lines.map((l) => l.groupKey))].map((k) => ({ key: k, sellerName: lines.find((l) => l.groupKey === k)!.sellerName, shipsFrom: lines.find((l) => l.groupKey === k)!.shipsFrom, lineIds: lines.filter((l) => l.groupKey === k).map((l) => l.id) }));
    return {
      lines, groups, subtotalMinor: lines.filter((l) => l.available).reduce((a, l) => a + l.priceMinor, 0),
      hasBundles: lines.some((l) => l.kind === "BUNDLE"), reservationMinutes: RESERVATION_MINUTES,
    };
  }
}
