import { Inject, Injectable } from "@nestjs/common";
import { Prisma } from "@prisma/client";
import { canIssueDispatch, order as orderMachine, shipment as shipmentMachine, verifyPackScan, type OrderState, type ShipmentState } from "@ooak/shared";
import { AuditService } from "../../common/audit.service";
import { NotifierService } from "../../common/notifier.service";
import { PrismaService, type Tx } from "../../common/prisma.service";
import { badRequest, conflict, notFound } from "../../common/problem";
import { CodesService } from "../codes/codes.service";
import { dispatchLabelPdf, orderPackLabelPdf } from "../codes/labels";
import { COURIER_PROVIDER, type CourierEvent, type CourierProvider } from "./providers";

/** Who is allowed to work a group: the seller for their own self-shipped groups, the warehouse for warehouse groups. */
export interface FulfilActor { actorId: string; sellerId?: string | null; warehouse?: boolean }

@Injectable()
export class FulfilmentService {
  constructor(
    private readonly prisma: PrismaService, private readonly codes: CodesService, private readonly audit: AuditService,
    private readonly notifier: NotifierService, @Inject(COURIER_PROVIDER) private readonly courier: CourierProvider,
  ) {}

  async group(groupId: string, actor: FulfilActor) {
    const g = await this.prisma.fulfilmentGroup.findUnique({
      where: { id: groupId },
      include: {
        order: { include: { user: { select: { name: true } } } },
        items: { where: { voidedAt: null }, include: { item: { include: { brand: true, location: true, media: { where: { deletedAt: null }, take: 1, orderBy: { position: "asc" } }, scanCodes: { where: { voidedAt: null, kind: "ITEM_PACK" } } } } } },
        bundleLines: { where: { voidedAt: null }, include: { bundle: { include: { scanCodes: { where: { voidedAt: null, kind: "BUNDLE_PACK" } } } } } },
        shipments: { include: { scanCodes: { where: { voidedAt: null } }, events: { orderBy: { occurredAt: "asc" } } }, orderBy: { parcelIndex: "asc" } },
        scanCodes: { where: { voidedAt: null, kind: "ORDER_PACK" } },
      },
    });
    if (!g) throw notFound("Order");
    const allowed = actor.warehouse ? g.mode === "WAREHOUSE" : !!actor.sellerId && g.sellerId === actor.sellerId && g.mode === "SELLER_ARRANGED";
    if (!allowed) throw notFound("Order");
    if (["PENDING_PAYMENT", "CANCELLED"].includes(g.state)) throw conflict("This order isn't paid.", "NOT_PAID");
    return g;
  }

  /** Expected pack codes: each retail piece's ITEM_PACK; a sealed lot's BUNDLE_PACK, otherwise each lot piece's ITEM_PACK. */
  async expectedCodes(groupId: string, actorId: string | null) {
    const g = await this.prisma.fulfilmentGroup.findUniqueOrThrow({ where: { id: groupId }, include: { items: { where: { voidedAt: null } }, bundleLines: { where: { voidedAt: null }, include: { bundle: { include: { scanCodes: { where: { voidedAt: null, kind: "BUNDLE_PACK" } } } } } } } });
    const sealed = new Map(g.bundleLines.filter((b) => b.bundle.scanCodes[0]).map((b) => [b.id, b.bundle.scanCodes[0]!.code]));
    const codes: string[] = [];
    for (const [, code] of sealed) codes.push(code);
    for (const oi of g.items) {
      if (oi.bundleLineId && sealed.has(oi.bundleLineId)) continue;
      codes.push((await this.codes.issue("ITEM_PACK", { itemId: oi.itemId }, actorId)).code);
    }
    return codes;
  }

  async packSlip(groupId: string, actor: FulfilActor) {
    const g = await this.group(groupId, actor);
    const expected = await this.expectedCodes(groupId, actor.actorId);
    const orderCode = g.scanCodes[0] ?? (await this.codes.issue("ORDER_PACK", { groupId }, actor.actorId));
    await this.codes.markPrinted([orderCode], actor.actorId);
    const addr = g.order.shippingAddress as { recipient: string; city: string };
    return orderPackLabelPdf({ code: orderCode.code, orderRef: g.order.reference, expectedPieces: expected, shipToName: addr.recipient, shipToCity: addr.city });
  }

  /** Scan the pieces into the parcel. COMPLETE ⇒ packed (and dispatch may be issued); MISMATCH blocks dispatch. Every scan is logged. */
  async verifyPack(groupId: string, scans: string[], actor: FulfilActor) {
    const g = await this.group(groupId, actor);
    if (g.packVerifiedAt) return { status: "COMPLETE" as const, missing: [], unexpected: [], duplicates: [], invalid: [], alreadyVerified: true };
    const expected = await this.expectedCodes(groupId, actor.actorId);
    const check = verifyPackScan(expected, scans);
    const known = await this.prisma.scanCode.findMany({ where: { code: { in: scans.map((s) => s.replace(/^OOAK1:/, "").trim()) } } });
    for (const k of known) await this.codes.log(k.id, check.unexpected.includes(k.code) ? "MISMATCH" : "SCANNED_PACK", actor.actorId, { ok: !check.unexpected.includes(k.code) });
    if (!canIssueDispatch(check)) return check;
    await this.prisma.$transaction(async (tx) => {
      orderMachine.assert(g.state as OrderState, "PROCESSING");
      await tx.fulfilmentGroup.update({ where: { id: groupId }, data: { packVerifiedAt: new Date(), packVerifiedById: actor.actorId, state: "PROCESSING" } });
      const n = await tx.item.updateMany({ where: { id: { in: g.items.map((i) => i.itemId) }, stockState: "SOLD" }, data: { stockState: "PACKED" } });
      if (n.count !== g.items.length) throw conflict("Some pieces are not in a packable state.", "ITEM_STATE");
      const o = await tx.order.findUniqueOrThrow({ where: { id: g.orderId } });
      if (o.state === "PAID") await tx.order.update({ where: { id: o.id }, data: { state: "PROCESSING" } });
      await this.audit.log({ actorId: actor.actorId, action: "PACK_VERIFIED", entity: "FulfilmentGroup", entityId: groupId }, tx);
    });
    return check;
  }

  /** Book the courier (or record a seller-arranged courier) and issue one DISPATCH code per parcel. Only after a COMPLETE pack. */
  async dispatch(groupId: string, actor: FulfilActor, input: { parcels?: number; manual?: { courier: string; trackingNo: string } }) {
    const g = await this.group(groupId, actor);
    if (!g.packVerifiedAt) throw conflict("Scan every piece into the parcel first (pack verification).", "PACK_NOT_VERIFIED");
    if (g.shipments.length) return { shipments: g.shipments.map((s) => ({ id: s.id, trackingNo: s.trackingNo, courier: s.courier, code: s.scanCodes[0]?.code ?? null })) };
    const parcels = Math.min(Math.max(input.parcels ?? 1, 1), 10);
    const addr = g.order.shippingAddress as { recipient: string; city: string };
    const weight = (await this.prisma.item.findMany({ where: { id: { in: g.items.map((i) => i.itemId) } }, select: { weightGrams: true } })).reduce((a, i) => a + (i.weightGrams ?? 500), 0);
    const orderCode = g.scanCodes[0] ?? (await this.codes.issue("ORDER_PACK", { groupId }, actor.actorId));
    const out = [];
    for (let p = 1; p <= parcels; p++) {
      const booked = input.manual ?? { courier: this.courier.name, trackingNo: (await this.courier.book({ shipmentId: `${groupId}-${p}`, weightGrams: Math.ceil(weight / parcels), toCity: addr.city, toName: addr.recipient, pieces: g.items.length })).trackingNo };
      const s = await this.prisma.$transaction(async (tx) => {
        const sh = await tx.shipment.create({ data: { groupId, courier: booked.courier, trackingNo: booked.trackingNo, parcelIndex: p, parcelCount: parcels, state: "LABEL_PENDING" } });
        shipmentMachine.assert("LABEL_PENDING", "READY");
        await tx.shipment.update({ where: { id: sh.id }, data: { state: "READY" } });
        const code = await this.codes.issue("DISPATCH", { shipmentId: sh.id, groupId, parentId: orderCode.id }, actor.actorId, tx);
        return { sh, code };
      });
      out.push({ id: s.sh.id, trackingNo: booked.trackingNo, courier: booked.courier, code: s.code.code });
    }
    await this.audit.log({ actorId: actor.actorId, action: "DISPATCH_ISSUED", entity: "FulfilmentGroup", entityId: groupId, after: { parcels } });
    return { shipments: out };
  }

  async dispatchLabel(shipmentId: string, actor: FulfilActor) {
    const sh = await this.prisma.shipment.findUnique({ where: { id: shipmentId }, include: { scanCodes: { where: { voidedAt: null, kind: "DISPATCH" } } } });
    if (!sh) throw notFound("Shipment");
    const g = await this.group(sh.groupId, actor);
    const addr = g.order.shippingAddress as { recipient: string; city: string };
    const code = sh.scanCodes[0]!;
    await this.codes.markPrinted([code], actor.actorId);
    return dispatchLabelPdf({ code: code.code, orderRef: g.order.reference, courier: sh.courier, trackingNo: sh.trackingNo, shipToName: addr.recipient, shipToCity: addr.city, pieceCount: g.items.length, parcelIndexOfCount: `${sh.parcelIndex} of ${sh.parcelCount}` });
  }

  /** Courier handover scan of a DISPATCH code: parcel picked up, pieces dispatched. Rejected before COMPLETE pack or when scanned twice. */
  async handover(raw: string, actor: FulfilActor) {
    const code = raw.replace(/^OOAK1:/, "").trim();
    const sc = await this.prisma.scanCode.findUnique({ where: { code }, include: { shipment: true } });
    if (!sc || sc.kind !== "DISPATCH" || !sc.shipment) throw badRequest("That isn't a dispatch code.", "NOT_A_DISPATCH_CODE");
    const g = await this.group(sc.shipment.groupId, actor);
    if (sc.voidedAt || !g.packVerifiedAt || sc.shipment.state !== "READY") {
      await this.codes.log(sc.id, "MISMATCH", actor.actorId, { ok: false, note: sc.voidedAt ? "voided" : !g.packVerifiedAt ? "pack not verified" : `shipment ${sc.shipment.state}` });
      throw conflict(sc.shipment.state !== "READY" ? "This parcel was already handed over." : "This parcel can't be handed over yet.", "HANDOVER_REJECTED");
    }
    await this.prisma.$transaction(async (tx) => {
      await this.moveShipment(tx, sc.shipment!.id, "PICKED_UP", { source: "handover-scan" });
      await this.codes.log(sc.id, "SCANNED_DISPATCH", actor.actorId, { shipmentId: sc.shipment!.id }, tx);
    });
    return { ok: true, orderRef: g.order.reference, parcel: `${sc.shipment.parcelIndex} of ${sc.shipment.parcelCount}` };
  }

  /** Applies a shipment status and its consequences (items + group + order). Idempotent; invalid jumps are recorded but not applied. */
  async moveShipment(tx: Tx, shipmentId: string, to: ShipmentState, raw: unknown, occurredAt = new Date()) {
    const sh = await tx.shipment.findUniqueOrThrow({ where: { id: shipmentId }, include: { group: { include: { shipments: true, items: { where: { voidedAt: null } } } } } });
    await tx.shipmentEvent.create({ data: { shipmentId, status: to, raw: raw as Prisma.InputJsonValue, occurredAt } });
    if (sh.state === to || !shipmentMachine.can(sh.state as ShipmentState, to)) return false;
    await tx.shipment.update({ where: { id: shipmentId }, data: { state: to } });
    const g = sh.group;
    const all = g.shipments.map((s) => (s.id === shipmentId ? to : s.state));
    const itemIds = g.items.map((i) => i.itemId);
    if (to === "PICKED_UP" && all.every((s) => s !== "READY" && s !== "LABEL_PENDING")) {
      await tx.item.updateMany({ where: { id: { in: itemIds }, stockState: "PACKED" }, data: { stockState: "DISPATCHED" } });
      if (orderMachine.can(g.state as OrderState, "FULFILLED")) await tx.fulfilmentGroup.update({ where: { id: g.id }, data: { state: "FULFILLED" } });
      const groups = await tx.fulfilmentGroup.findMany({ where: { orderId: g.orderId } });
      const o = await tx.order.findUniqueOrThrow({ where: { id: g.orderId } });
      const live = groups.filter((x) => x.state !== "CANCELLED");
      const target: OrderState = live.every((x) => (x.id === g.id ? true : x.state === "FULFILLED" || x.state === "COMPLETED")) ? "FULFILLED" : "PARTIALLY_FULFILLED";
      if (o.state !== target && orderMachine.can(o.state as OrderState, target)) await tx.order.update({ where: { id: o.id }, data: { state: target } });
      else if (o.state === "PAID" && target === "PARTIALLY_FULFILLED") await tx.order.update({ where: { id: o.id }, data: { state: "PROCESSING" } });
    }
    if (to === "DELIVERED" && all.every((s) => s === "DELIVERED")) {
      await tx.item.updateMany({ where: { id: { in: itemIds }, stockState: "DISPATCHED" }, data: { stockState: "DELIVERED" } });
      await tx.fulfilmentGroup.update({ where: { id: g.id }, data: { deliveredAt: occurredAt } });
    }
    return true;
  }

  async courierWebhook(provider: string, raw: Buffer, headers: Record<string, string | string[] | undefined>) {
    if (provider !== this.courier.name) throw notFound("Courier");
    let e: CourierEvent;
    try { e = this.courier.verifyWebhook(raw, headers); } catch { throw badRequest("Invalid webhook signature.", "BAD_SIGNATURE"); }
    const sh = await this.prisma.shipment.findFirst({ where: { courier: provider, trackingNo: e.trackingNo }, include: { group: { include: { order: { include: { user: true } } } } } });
    if (!sh) return { ignored: true };
    const dup = await this.prisma.shipmentEvent.findFirst({ where: { shipmentId: sh.id, raw: { path: ["eventId"], equals: e.eventId } } });
    if (dup) return { duplicate: true };
    const applied = await this.prisma.$transaction((tx) => this.moveShipment(tx, sh.id, e.status, e, new Date(e.occurredAt)));
    if (applied && e.status === "DELIVERED" && sh.group.order.user.phone) {
      await this.notifier.sendSms(sh.group.order.user.phone, "DELIVERED", `Order ${sh.group.order.reference} was delivered. If anything arrived damaged, report it within 48 hours from your order page.`, sh.group.order.userId);
    }
    return { applied };
  }

  /** Sweep: groups delivered more than the claim window ago with no open claim become COMPLETED; orders follow. */
  async completeDelivered(now = new Date(), windowHours = 48) {
    const cutoff = new Date(now.getTime() - windowHours * 3_600_000);
    const groups = await this.prisma.fulfilmentGroup.findMany({ where: { deliveredAt: { lte: cutoff }, state: "FULFILLED" }, include: { order: { include: { returns: { where: { state: { in: ["REQUESTED", "APPROVED", "IN_TRANSIT", "RECEIVED"] } } } } } } });
    let n = 0;
    for (const g of groups) {
      if (g.order.returns.length) continue;
      await this.prisma.$transaction(async (tx) => {
        await tx.fulfilmentGroup.update({ where: { id: g.id }, data: { state: "COMPLETED" } });
        const siblings = await tx.fulfilmentGroup.findMany({ where: { orderId: g.orderId, state: { not: "CANCELLED" } } });
        if (siblings.every((s) => s.state === "COMPLETED") && orderMachine.can(g.order.state as OrderState, "COMPLETED")) await tx.order.update({ where: { id: g.orderId }, data: { state: "COMPLETED" } });
      });
      n++;
    }
    return n;
  }
}
