import { Injectable } from "@nestjs/common";
import { createHmac, randomBytes, timingSafeEqual } from "node:crypto";
import { config } from "../../config";

/**
 * Provider adapters. The real Pakistani gateway and courier are not chosen yet (docs/OPEN_QUESTIONS.md #1-2), so only the
 * sandbox adapters exist. They behave like real providers: hosted payment page, asynchronous SIGNED webhooks, refunds,
 * tracking numbers and courier status webhooks. Swapping in a real provider = implementing these two interfaces.
 */
export interface VerifiedPaymentEvent { eventId: string; type: "payment.succeeded" | "payment.failed" | "refund.succeeded" | "refund.failed"; providerRef: string; amountMinor: number; refundRef?: string }
export interface PaymentProvider {
  readonly name: string;
  createPayment(input: { paymentId: string; amountMinor: number; currency: string; orderRef: string }): Promise<{ providerRef: string; checkoutUrl: string }>;
  /** Must throw if the signature is invalid. Uses the RAW request body. */
  verifyWebhook(raw: Buffer, headers: Record<string, string | string[] | undefined>): VerifiedPaymentEvent;
  refund(input: { providerRef: string; amountMinor: number; refundId: string }): Promise<{ refundRef: string }>;
}

export interface CourierEvent { eventId: string; trackingNo: string; status: "PICKED_UP" | "IN_TRANSIT" | "OUT_FOR_DELIVERY" | "DELIVERED" | "FAILED_DELIVERY" | "RETURNING" | "RETURNED"; occurredAt: string }
export interface CourierProvider {
  readonly name: string;
  book(input: { shipmentId: string; weightGrams: number; toCity: string; toName: string; pieces: number }): Promise<{ trackingNo: string }>;
  verifyWebhook(raw: Buffer, headers: Record<string, string | string[] | undefined>): CourierEvent;
}

export const SIG_HEADER = "x-sandbox-signature";
export const sign = (secret: string, body: string | Buffer) => createHmac("sha256", secret).update(body).digest("hex");
function verifySig(secret: string, raw: Buffer, headers: Record<string, string | string[] | undefined>) {
  const got = String(headers[SIG_HEADER] ?? "");
  const want = sign(secret, raw);
  if (got.length !== want.length || !timingSafeEqual(Buffer.from(got), Buffer.from(want))) throw new Error("invalid webhook signature");
}

@Injectable()
export class SandboxPayments implements PaymentProvider {
  readonly name = "sandbox";
  async createPayment(input: { paymentId: string }) {
    return { providerRef: `SBXPAY-${randomBytes(8).toString("hex")}`, checkoutUrl: `${config().WEB_ORIGIN}/checkout/pay/${input.paymentId}` };
  }
  verifyWebhook(raw: Buffer, headers: Record<string, string | string[] | undefined>): VerifiedPaymentEvent {
    verifySig(config().PAYMENT_WEBHOOK_SECRET, raw, headers);
    const e = JSON.parse(raw.toString("utf8")) as VerifiedPaymentEvent;
    if (!e.eventId || !e.type || !e.providerRef || !Number.isSafeInteger(e.amountMinor)) throw new Error("malformed event");
    return e;
  }
  async refund(input: { refundId: string }) { return { refundRef: `SBXREF-${input.refundId.slice(-10)}` }; }
}

@Injectable()
export class SandboxCourier implements CourierProvider {
  readonly name = "sandbox-courier";
  async book() { return { trackingNo: `SBX${Date.now().toString().slice(-9)}${randomBytes(2).toString("hex").toUpperCase()}` }; }
  verifyWebhook(raw: Buffer, headers: Record<string, string | string[] | undefined>): CourierEvent {
    verifySig(config().COURIER_WEBHOOK_SECRET, raw, headers);
    const e = JSON.parse(raw.toString("utf8")) as CourierEvent;
    if (!e.eventId || !e.trackingNo || !e.status) throw new Error("malformed event");
    return e;
  }
}

export const PAYMENT_PROVIDER = Symbol("PAYMENT_PROVIDER");
export const COURIER_PROVIDER = Symbol("COURIER_PROVIDER");
export const paymentProviderFactory = { provide: PAYMENT_PROVIDER, useFactory: () => { const p = config().PAYMENT_PROVIDER; if (p !== "sandbox") throw new Error(`Payment provider "${p}" not implemented yet`); return new SandboxPayments(); } };
export const courierProviderFactory = { provide: COURIER_PROVIDER, useFactory: () => { const p = config().COURIER_PROVIDER; if (p !== "sandbox") throw new Error(`Courier provider "${p}" not implemented yet`); return new SandboxCourier(); } };
