import { Inject, Injectable, Logger } from "@nestjs/common";
import { Prisma, type PaymentMethod } from "@prisma/client";
import { allocateBundlePrice, commissionBps, money, normalizePkPhone, payment as paymentMachine, RESERVATION_MINUTES } from "@ooak/shared";
import { z } from "zod";
import { AuditService } from "../../common/audit.service";
import type { Viewer } from "../../common/auth";
import { NotifierService } from "../../common/notifier.service";
import { PrismaService, type Tx } from "../../common/prisma.service";
import { badRequest, conflict, forbidden, notFound } from "../../common/problem";
import { CodesService } from "../codes/codes.service";
import { groupKeyFor, PLATFORM_GROUP } from "./cart.service";
import { LedgerService } from "./ledger.service";
import { PAYMENT_PROVIDER, type PaymentProvider, type VerifiedPaymentEvent } from "./providers";

export const AddressInput = z.object({
  recipient: z.string().trim().min(2).max(80), phone: z.string().min(7).max(20), line1: z.string().trim().min(3).max(160), line2: z.string().trim().max(160).optional().nullable(),
  city: z.string().trim().min(2).max(60), province: z.string().trim().max(60).optional().nullable(), postalCode: z.string().trim().max(12).optional().nullable(),
});
export const CheckoutInput = z.object({
  addressId: z.string().optional(), address: AddressInput.optional(), saveAddress: z.boolean().optional(),
  paymentMethod: z.enum(["CARD", "WALLET", "BANK_TRANSFER"]),
  acceptTerms: z.literal(true, { errorMap: () => ({ message: "Please confirm you've read the damage-only returns policy." }) }),
});

interface ShipRates { LOCAL: number; NATIONAL: number; localCities: string[] }
interface LockedItem { id: string; stockState: string; channel: string; sellerId: string; ownerType: string; arrangement: string; priceMinor: number; weightGrams: number | null }

@Injectable()
export class CheckoutService {
  private readonly log = new Logger("Checkout");
  constructor(
    private readonly prisma: PrismaService, private readonly ledger: LedgerService, private readonly codes: CodesService,
    private readonly notifier: NotifierService, private readonly audit: AuditService, @Inject(PAYMENT_PROVIDER) private readonly payments: PaymentProvider,
  ) {}

  async rates(): Promise<{ flat: ShipRates; perKg: number }> {
    const [flat, perKg] = await Promise.all([this.prisma.setting.findUnique({ where: { key: "shipping.flatRates" } }), this.prisma.setting.findUnique({ where: { key: "shipping.bundleRatePerKgMinor" } })]);
    return { flat: (flat?.value as unknown as ShipRates) ?? { LOCAL: 25_000, NATIONAL: 35_000, localCities: ["Lahore"] }, perKg: (perKg?.value as number) ?? 12_000 };
  }

  /** Flat rate per parcel (local vs national); bundle lots are weight-based. */
  shippingForGroup(r: { flat: ShipRates; perKg: number }, originCity: string, destCity: string, retailCount: number, bundleWeights: number[]) {
    const local = originCity.trim().toLowerCase() === destCity.trim().toLowerCase();
    let total = retailCount > 0 ? (local ? r.flat.LOCAL : r.flat.NATIONAL) : 0;
    for (const w of bundleWeights) total += Math.max(r.flat.NATIONAL, Math.ceil(w / 1000) * r.perKg);
    return total;
  }

  private async resolveAddress(v: Viewer, input: z.infer<typeof CheckoutInput>) {
    if (input.addressId) {
      const a = await this.prisma.address.findUnique({ where: { id: input.addressId } });
      if (!a || a.userId !== v.userId) throw notFound("Address");
      return { recipient: a.recipient, phone: a.phone, line1: a.line1, line2: a.line2, city: a.city, province: a.province, postalCode: a.postalCode, country: "PK" };
    }
    if (!input.address) throw badRequest("Add a delivery address.", "ADDRESS_REQUIRED");
    const phone = normalizePkPhone(input.address.phone);
    if (!phone) throw badRequest("Enter a valid mobile number for the courier.", "INVALID_PHONE");
    const snap = { ...input.address, phone, line2: input.address.line2 ?? null, province: input.address.province ?? null, postalCode: input.address.postalCode ?? null, country: "PK" };
    if (input.saveAddress) await this.prisma.address.create({ data: { userId: v.userId, recipient: snap.recipient, phone, line1: snap.line1, line2: snap.line2, city: snap.city, province: snap.province, postalCode: snap.postalCode } });
    return snap;
  }

  /**
   * Checkout: in ONE transaction, lock every bundle and item row in a fixed order (by id), require each to be available,
   * reserve them (15 min; 30 min if the order contains a lot), create the order + fulfilment groups + lines + payment.
   * All-or-nothing. N concurrent buyers of one item ⇒ exactly one succeeds. Duplicate submits with the same idempotency key
   * return the same order.
   */
  async checkout(v: Viewer, idempotencyKey: string, cartId: string, inputRaw: unknown) {
    if (!/^[\w-]{8,100}$/.test(idempotencyKey)) throw badRequest("Missing or invalid Idempotency-Key header.", "IDEMPOTENCY_KEY_REQUIRED");
    const scopedKey = `${v.userId}:${idempotencyKey}`;
    const prior = await this.prisma.order.findUnique({ where: { idempotencyKey: scopedKey }, include: { payments: true } });
    if (prior) return { orderRef: prior.reference, paymentId: prior.payments[0]?.id, checkoutUrl: prior.payments[0]?.checkoutUrl, duplicate: true };
    const input = CheckoutInput.parse(inputRaw);
    const address = await this.resolveAddress(v, input);
    const cartLines = await this.prisma.cartItem.findMany({ where: { cartId } });
    if (!cartLines.length) throw conflict("Your cart is empty.", "CART_EMPTY");
    const retailIds = cartLines.map((l) => l.itemId).filter((x): x is string => !!x);
    const bundleIds = cartLines.map((l) => l.bundleId).filter((x): x is string => !!x);
    if (bundleIds.length && !v.roles.includes("VERIFIED_RESELLER")) throw forbidden("Bundles can be bought by verified resellers only.", "RESELLER_ONLY");
    const r = await this.rates();
    const offers = await this.prisma.buyerOffer.findMany({ where: { buyerId: v.userId, state: "ACCEPTED", expiresAt: { gt: new Date() }, itemId: { in: retailIds } } });

    let created: { orderId: string; reference: string; paymentId: string; total: number };
    try {
      created = await this.prisma.$transaction(async (tx) => {
        const bundles = bundleIds.length ? await tx.bundle.findMany({ where: { id: { in: bundleIds } }, include: { items: { where: { releasedAt: null }, orderBy: { position: "asc" } } } }) : [];
        const pieceIds = bundles.flatMap((b) => b.items.map((bi) => bi.itemId));
        const allIds = [...new Set([...retailIds, ...pieceIds])].sort();
        // Fixed lock order: bundles, then items, each sorted by id (no deadlocks between concurrent checkouts).
        const lockedBundles = bundleIds.length ? await tx.$queryRaw<Array<{ id: string; state: string }>>`SELECT id, state::text AS state FROM "Bundle" WHERE id = ANY(${[...bundleIds].sort()}) ORDER BY id FOR UPDATE` : [];
        const locked = await tx.$queryRaw<LockedItem[]>`SELECT id, "stockState"::text AS "stockState", channel::text AS channel, "sellerId", "ownerType"::text AS "ownerType", arrangement::text AS arrangement, "priceMinor", "weightGrams" FROM "Item" WHERE id = ANY(${allIds}) ORDER BY id FOR UPDATE`;
        const byId = new Map(locked.map((i) => [i.id, i]));
        const liveListings = new Set((await tx.listing.findMany({ where: { itemId: { in: retailIds }, state: "PUBLISHED" }, select: { itemId: true } })).map((l) => l.itemId));
        const unavailable: string[] = [];
        for (const id of retailIds) {
          const it = byId.get(id);
          if (!it || it.stockState !== "AVAILABLE" || it.channel !== "RETAIL" || !liveListings.has(id) || (it.arrangement === "DIRECT_PURCHASE" && it.ownerType !== "PLATFORM")) unavailable.push(id);
          if (it && v.sellerId && it.sellerId === v.sellerId && it.ownerType === "SELLER") unavailable.push(id);
        }
        for (const b of bundles) {
          const lb = lockedBundles.find((x) => x.id === b.id);
          if (!lb || lb.state !== "PUBLISHED" || b.items.length !== b.size || b.items.some((bi) => byId.get(bi.itemId)?.stockState !== "AVAILABLE" || byId.get(bi.itemId)?.channel !== "BUNDLE")) unavailable.push(b.id);
        }
        if (unavailable.length) throw conflict("Some pieces in your cart are no longer available. We've marked them. Remove them to continue.", "ITEMS_UNAVAILABLE");

        // Group lines per fulfilment group (seller / platform × seller-ships / warehouse)
        type Grp = { sellerId: string; mode: "SELLER_ARRANGED" | "WAREHOUSE"; retail: string[]; bundles: typeof bundles; subtotal: number };
        const groups = new Map<string, Grp>();
        const g = (k: { sellerId: string; mode: "SELLER_ARRANGED" | "WAREHOUSE" }) => { const key = `${k.sellerId}:${k.mode}`; if (!groups.has(key)) groups.set(key, { ...k, retail: [], bundles: [], subtotal: 0 }); return groups.get(key)!; };
        const priceOf = (id: string) => offers.find((o) => o.itemId === id)?.amountMinor ?? byId.get(id)!.priceMinor;
        for (const id of retailIds) { const grp = g(groupKeyFor(byId.get(id)!)); grp.retail.push(id); grp.subtotal += priceOf(id); }
        for (const b of bundles) { const grp = g(groupKeyFor(byId.get(b.items[0]!.itemId)!)); grp.bundles.push(b); grp.subtotal += b.priceMinor; }
        const sellerCities = new Map((await tx.sellerProfile.findMany({ where: { id: { in: [...groups.values()].map((x) => x.sellerId).filter((s) => s !== PLATFORM_GROUP) } }, select: { id: true, city: true } })).map((s) => [s.id, s.city ?? ""]));
        let shippingTotal = 0;
        const shipping = new Map<string, number>();
        for (const [key, grp] of groups) {
          const origin = grp.mode === "WAREHOUSE" ? "Lahore" : sellerCities.get(grp.sellerId) ?? "";
          const s = this.shippingForGroup(r, origin, address.city, grp.retail.length, grp.bundles.map((b) => b.items.reduce((a, bi) => a + (byId.get(bi.itemId)!.weightGrams ?? 0), 0)));
          shipping.set(key, s); shippingTotal += s;
        }
        const subtotal = [...groups.values()].reduce((a, x) => a + x.subtotal, 0);
        const reference = `OOAK-${new Date().getFullYear()}-${String(await this.prisma.nextval("seq_order_ref", tx)).padStart(6, "0")}`;
        const expiresAt = new Date(Date.now() + (bundles.length ? RESERVATION_MINUTES.BUNDLE : RESERVATION_MINUTES.RETAIL) * 60_000);
        const order = await tx.order.create({ data: { reference, userId: v.userId, subtotalMinor: subtotal, shippingMinor: shippingTotal, totalMinor: subtotal + shippingTotal, shippingAddress: address, idempotencyKey: scopedKey } });
        for (const [key, grp] of groups) {
          const fg = await tx.fulfilmentGroup.create({ data: { orderId: order.id, sellerId: grp.sellerId, mode: grp.mode, subtotalMinor: grp.subtotal, shippingMinor: shipping.get(key)! } });
          for (const id of grp.retail) {
            const it = byId.get(id)!;
            const price = priceOf(id);
            await tx.orderItem.create({ data: { groupId: fg.id, itemId: id, priceMinor: price, arrangement: it.arrangement as never, ownerType: it.ownerType as never, commissionBps: commissionBps("RETAIL", it.arrangement as never, price) } });
          }
          for (const b of grp.bundles) {
            const bps = commissionBps("BUNDLE", b.arrangement, b.priceMinor);
            const line = await tx.orderBundleLine.create({ data: { groupId: fg.id, bundleId: b.id, priceMinor: b.priceMinor, commissionBps: bps } });
            const shares = allocateBundlePrice(money(b.priceMinor), b.items.map((bi) => ({ id: bi.itemId, refRetailMinor: bi.refRetailMinor })));
            for (const s of shares) {
              const it = byId.get(s.id)!;
              await tx.orderItem.create({ data: { groupId: fg.id, itemId: s.id, bundleLineId: line.id, priceMinor: s.share.amountMinor, arrangement: it.arrangement as never, ownerType: it.ownerType as never, commissionBps: bps } });
            }
          }
        }
        const reserveIds = [...retailIds, ...pieceIds];
        const n = await tx.item.updateMany({ where: { id: { in: reserveIds }, stockState: "AVAILABLE" }, data: { stockState: "RESERVED", version: { increment: 1 } } });
        if (n.count !== reserveIds.length) throw conflict("Some pieces were just taken by another buyer.", "ITEMS_UNAVAILABLE");
        if (bundleIds.length) {
          const nb = await tx.bundle.updateMany({ where: { id: { in: bundleIds }, state: "PUBLISHED" }, data: { state: "RESERVED", version: { increment: 1 } } });
          if (nb.count !== bundleIds.length) throw conflict("A lot was just taken by another buyer.", "ITEMS_UNAVAILABLE");
        }
        const pieceBundle = new Map(bundles.flatMap((b) => b.items.map((bi) => [bi.itemId, b.id] as const)));
        await tx.stockReservation.createMany({ data: reserveIds.map((id) => ({ itemId: id, orderId: order.id, cartId, bundleId: pieceBundle.get(id) ?? null, expiresAt })) });
        const pay = await tx.payment.create({ data: { orderId: order.id, provider: this.payments.name, method: input.paymentMethod as PaymentMethod, amountMinor: order.totalMinor } });
        await this.audit.log({ actorId: v.userId, action: "ORDER_PLACED", entity: "Order", entityId: order.id, after: { reference, totalMinor: order.totalMinor } }, tx);
        return { orderId: order.id, reference, paymentId: pay.id, total: order.totalMinor };
      }, { timeout: 20_000, maxWait: 10_000 });
    } catch (e) {
      // Race on the partial unique indexes (reservation / live order line / idempotency) ⇒ someone else won.
      if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === "P2002") {
        const again = await this.prisma.order.findUnique({ where: { idempotencyKey: scopedKey }, include: { payments: true } });
        if (again) return { orderRef: again.reference, paymentId: again.payments[0]?.id, checkoutUrl: again.payments[0]?.checkoutUrl, duplicate: true };
        throw conflict("Some pieces were just taken by another buyer.", "ITEMS_UNAVAILABLE");
      }
      throw e;
    }
    const p = await this.payments.createPayment({ paymentId: created.paymentId, amountMinor: created.total, currency: "PKR", orderRef: created.reference });
    await this.prisma.payment.update({ where: { id: created.paymentId }, data: { providerRef: p.providerRef, checkoutUrl: p.checkoutUrl } });
    await this.prisma.cartItem.deleteMany({ where: { cartId } });
    return { orderRef: created.reference, paymentId: created.paymentId, checkoutUrl: p.checkoutUrl, duplicate: false };
  }

  /** Verified webhook entry point. Stores the raw event (idempotent on provider+eventId) and processes it once. */
  async handleWebhook(provider: string, raw: Buffer, headers: Record<string, string | string[] | undefined>) {
    if (provider !== this.payments.name) throw notFound("Provider");
    let event: VerifiedPaymentEvent;
    try { event = this.payments.verifyWebhook(raw, headers); } catch (e) {
      this.log.warn(`Rejected ${provider} webhook: ${(e as Error).message}`);
      throw badRequest("Invalid webhook signature.", "BAD_SIGNATURE");
    }
    try {
      await this.prisma.paymentEvent.create({ data: { provider, eventId: event.eventId, type: event.type, payload: JSON.parse(raw.toString("utf8")), signatureVerified: true } });
    } catch (e) {
      if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === "P2002") return { duplicate: true };
      throw e;
    }
    const followUps = await this.process(provider, event);
    await this.prisma.paymentEvent.update({ where: { provider_eventId: { provider, eventId: event.eventId } }, data: { processedAt: new Date() } });
    for (const f of followUps) await f();
    return { ok: true };
  }

  private async process(provider: string, e: VerifiedPaymentEvent): Promise<Array<() => Promise<void>>> {
    const after: Array<() => Promise<void>> = [];
    if (e.type === "refund.succeeded" || e.type === "refund.failed") {
      await this.prisma.$transaction(async (tx) => {
        const refund = await tx.refund.findFirst({ where: { providerRef: e.refundRef ?? "" } });
        if (!refund || refund.state !== "PENDING") return;
        if (e.type === "refund.failed") { await tx.refund.update({ where: { id: refund.id }, data: { state: "FAILED" } }); return; }
        await tx.refund.update({ where: { id: refund.id }, data: { state: "SUCCEEDED" } });
        await this.postRefundLedger(tx, refund.id);
        const pay = await tx.payment.findUniqueOrThrow({ where: { id: refund.paymentId }, include: { refunds: true } });
        const refunded = pay.refunds.filter((r) => r.state === "SUCCEEDED").reduce((a, r) => a + r.amountMinor, 0);
        const to = refunded >= pay.amountMinor ? "REFUNDED" : "PARTIALLY_REFUNDED";
        if (pay.state !== to || to === "PARTIALLY_REFUNDED") { paymentMachine.assert(pay.state, to); await tx.payment.update({ where: { id: pay.id }, data: { state: to } }); }
      });
      return after;
    }
    await this.prisma.$transaction(async (tx) => {
      const [locked] = await tx.$queryRaw<Array<{ id: string }>>`SELECT id FROM "Payment" WHERE "providerRef" = ${e.providerRef} AND provider = ${provider} FOR UPDATE`;
      if (!locked) { this.log.warn(`Payment event for unknown providerRef ${e.providerRef}`); return; }
      const pay = await tx.payment.findUniqueOrThrow({ where: { id: locked.id }, include: { order: true } });
      await tx.paymentEvent.update({ where: { provider_eventId: { provider, eventId: e.eventId } }, data: { paymentId: pay.id } });
      if (e.type === "payment.failed") {
        if (pay.state !== "INITIATED" && pay.state !== "AUTHORIZED") return; // out-of-order: a failure after capture is ignored
        paymentMachine.assert(pay.state, "FAILED");
        await tx.payment.update({ where: { id: pay.id }, data: { state: "FAILED" } });
        await this.releaseOrder(tx, pay.orderId, "PAYMENT_FAILED");
        return;
      }
      // payment.succeeded
      if (pay.state === "CAPTURED" || pay.state === "REFUNDED" || pay.state === "PARTIALLY_REFUNDED") return;
      const lateOrWrong = pay.order.state !== "PENDING_PAYMENT" || e.amountMinor !== pay.amountMinor;
      paymentMachine.assert(pay.state === "CANCELLED" || pay.state === "FAILED" ? "INITIATED" : pay.state, "CAPTURED");
      await tx.payment.update({ where: { id: pay.id }, data: { state: "CAPTURED" } });
      if (lateOrWrong) {
        // Money arrived for an order we already released (or the amount is wrong): refund it in full, never fulfil.
        await this.ledger.post(tx, [
          { account: "CASH_PROVIDER", debit: e.amountMinor, refType: "PAYMENT", refId: pay.id, memo: "Late/mismatched payment received" },
          { account: "REFUNDS_PAYABLE", credit: e.amountMinor, refType: "PAYMENT", refId: pay.id },
        ]);
        const refund = await tx.refund.create({ data: { paymentId: pay.id, amountMinor: e.amountMinor, reason: pay.order.state !== "PENDING_PAYMENT" ? "Payment arrived after the reservation expired" : "Paid amount did not match the order total", mode: "LATE_PAYMENT" } });
        await this.audit.log({ action: "LATE_PAYMENT_REFUNDED", entity: "Payment", entityId: pay.id, after: { amountMinor: e.amountMinor } }, tx);
        after.push(async () => { await this.sendRefund(refund.id); });
        return;
      }
      await this.capture(tx, pay.orderId);
      after.push(() => this.notifyPaid(pay.orderId));
    }, { timeout: 20_000 });
    return after;
  }

  /** Paid: reservations become sales; lines, listings and lots are closed; pack codes issued; ledger posted. */
  private async capture(tx: Tx, orderId: string) {
    const order = await tx.order.findUniqueOrThrow({ where: { id: orderId }, include: { groups: { include: { items: true, bundleLines: true } } } });
    const now = new Date();
    await tx.order.update({ where: { id: orderId }, data: { state: "PAID", paidAt: now } });
    await tx.fulfilmentGroup.updateMany({ where: { orderId }, data: { state: "PAID" } });
    const itemIds = order.groups.flatMap((g) => g.items.map((i) => i.itemId));
    const n = await tx.item.updateMany({ where: { id: { in: itemIds }, stockState: "RESERVED" }, data: { stockState: "SOLD", version: { increment: 1 } } });
    if (n.count !== itemIds.length) throw new Error(`capture: expected ${itemIds.length} reserved items, got ${n.count}`);
    const bundleIds = order.groups.flatMap((g) => g.bundleLines.map((b) => b.bundleId));
    if (bundleIds.length) await tx.bundle.updateMany({ where: { id: { in: bundleIds }, state: "RESERVED" }, data: { state: "SOLD" } });
    await tx.stockReservation.updateMany({ where: { orderId, releasedAt: null }, data: { releasedAt: now } });
    await tx.listing.updateMany({ where: { itemId: { in: itemIds }, state: "PUBLISHED" }, data: { state: "SOLD_OUT" } });
    for (const g of order.groups) await this.codes.issue("ORDER_PACK", { groupId: g.id }, null, tx);
    await this.ledger.postOrderPaid(tx, orderId);
    await this.audit.log({ action: "ORDER_PAID", entity: "Order", entityId: orderId }, tx);
  }

  /** Releases an unpaid order: items/lots back on sale, lines voided (history kept), payment cancelled. */
  async releaseOrder(tx: Tx, orderId: string, reason: "PAYMENT_FAILED" | "EXPIRED" | "BUYER_CANCELLED") {
    const [o] = await tx.$queryRaw<Array<{ state: string }>>`SELECT state::text AS state FROM "Order" WHERE id = ${orderId} FOR UPDATE`;
    if (!o || o.state !== "PENDING_PAYMENT") return false;
    const now = new Date();
    await tx.order.update({ where: { id: orderId }, data: { state: "CANCELLED" } });
    await tx.fulfilmentGroup.updateMany({ where: { orderId }, data: { state: "CANCELLED" } });
    await tx.payment.updateMany({ where: { orderId, state: { in: ["INITIATED", "AUTHORIZED"] } }, data: { state: "CANCELLED" } });
    const res = await tx.stockReservation.findMany({ where: { orderId, releasedAt: null } });
    await tx.item.updateMany({ where: { id: { in: res.map((r) => r.itemId) }, stockState: "RESERVED" }, data: { stockState: "AVAILABLE", version: { increment: 1 } } });
    const bundleIds = [...new Set(res.map((r) => r.bundleId).filter((x): x is string => !!x))];
    if (bundleIds.length) await tx.bundle.updateMany({ where: { id: { in: bundleIds }, state: "RESERVED" }, data: { state: "PUBLISHED" } });
    await tx.stockReservation.updateMany({ where: { orderId, releasedAt: null }, data: { releasedAt: now } });
    await tx.orderItem.updateMany({ where: { group: { orderId } }, data: { voidedAt: now } });
    await tx.orderBundleLine.updateMany({ where: { group: { orderId } }, data: { voidedAt: now } });
    await this.audit.log({ action: `ORDER_RELEASED_${reason}`, entity: "Order", entityId: orderId }, tx);
    return true;
  }

  /** Sweep: release orders whose reservation expired without a verified payment. */
  async expireReservations(now = new Date()) {
    const due = await this.prisma.stockReservation.findMany({ where: { releasedAt: null, expiresAt: { lt: now }, orderId: { not: null } }, select: { orderId: true }, distinct: ["orderId"] });
    let released = 0;
    for (const d of due) if (await this.prisma.$transaction((tx) => this.releaseOrder(tx, d.orderId!, "EXPIRED"))) released++;
    return released;
  }

  async cancelByBuyer(v: Viewer, reference: string) {
    const o = await this.prisma.order.findUnique({ where: { reference } });
    if (!o || o.userId !== v.userId) throw notFound("Order");
    if (o.state !== "PENDING_PAYMENT") throw conflict("Paid orders can't be cancelled here. Contact support if something is wrong.", "NOT_CANCELLABLE");
    await this.prisma.$transaction((tx) => this.releaseOrder(tx, o.id, "BUYER_CANCELLED"));
  }

  /** Calls the provider for a PENDING refund; success arrives by verified webhook (refund.succeeded). */
  async sendRefund(refundId: string) {
    const r = await this.prisma.refund.findUniqueOrThrow({ where: { id: refundId }, include: { payment: true } });
    const res = await this.payments.refund({ providerRef: r.payment.providerRef!, amountMinor: r.amountMinor, refundId: r.id });
    await this.prisma.refund.update({ where: { id: r.id }, data: { providerRef: res.refundRef } });
    return res.refundRef;
  }

  async postRefundLedger(tx: Tx, refundId: string) {
    const r = await tx.refund.findUniqueOrThrow({ where: { id: refundId } });
    if (r.mode === "LATE_PAYMENT") {
      await this.ledger.post(tx, [
        { account: "REFUNDS_PAYABLE", debit: r.amountMinor, refType: "REFUND", refId: r.id, memo: "Late payment returned" },
        { account: "CASH_PROVIDER", credit: r.amountMinor, refType: "REFUND", refId: r.id },
      ]);
    } else if (r.mode === "SHIPPING") {
      const p = await tx.payment.findUniqueOrThrow({ where: { id: r.paymentId } });
      await this.ledger.postShippingRefund(tx, p.orderId, r.amountMinor, r.id);
    } else if (r.orderItemId) {
      await this.ledger.postLineRefund(tx, r.orderItemId, r.amountMinor, r.mode as "CANCEL" | "DAMAGE", r.id);
    }
  }

  private async notifyPaid(orderId: string) {
    const o = await this.prisma.order.findUniqueOrThrow({ where: { id: orderId }, include: { user: true, groups: true } });
    if (o.user.phone) await this.notifier.sendSms(o.user.phone, "ORDER_PAID", `Thank you! Order ${o.reference} is paid. We'll send a tracking link when it ships.`, o.userId);
    const sellers = await this.prisma.sellerProfile.findMany({ where: { id: { in: o.groups.filter((g) => g.sellerId !== PLATFORM_GROUP).map((g) => g.sellerId) } } });
    for (const s of sellers) {
      const g = o.groups.find((x) => x.sellerId === s.id)!;
      await this.notifier.inApp(s.userId, "ORDER_TO_SHIP", g.mode === "SELLER_ARRANGED" ? `New order ${o.reference}. Please pack and send it within 2 working days.` : `Sold: order ${o.reference}. Our warehouse is packing it.`);
    }
  }
}
