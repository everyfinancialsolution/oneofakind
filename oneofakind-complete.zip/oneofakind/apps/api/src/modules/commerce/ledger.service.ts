import { Injectable } from "@nestjs/common";
import type { LedgerAccountType } from "@prisma/client";
import { allocate, applyBps, money, saleAccounting } from "@ooak/shared";
import { randomUUID } from "node:crypto";
import { PrismaService, type Tx } from "../../common/prisma.service";

export const PLATFORM_REF = "PLATFORM";

interface Line { account: LedgerAccountType; ownerRef?: string | null; debit?: number; credit?: number; refType: string; refId: string; memo?: string }

/**
 * Double-entry ledger (append-only; the DB rejects UPDATE/DELETE and checks every txn balances at COMMIT).
 * Treatment (docs/WORKFLOWS.md §6):
 *  - Agent sale (self-managed / managed): Dr CASH_PROVIDER P · Cr SELLER_PAYABLE P−c · Cr COMMISSION_REVENUE c
 *  - Principal sale (platform-owned): Dr CASH_PROVIDER P · Cr PLATFORM_REVENUE P · Dr COGS K · Cr INVENTORY_ASSET K
 *  - Shipping collected: Dr CASH_PROVIDER S · Cr PLATFORM_REVENUE S
 *  - Ownership transfer: Dr INVENTORY_ASSET K · Cr CASH_PROVIDER K
 *  - Payout: Dr SELLER_PAYABLE · Cr CASH_PROVIDER
 */
@Injectable()
export class LedgerService {
  constructor(private readonly prisma: PrismaService) {}

  /** Platform accounts use ownerRef "PLATFORM" (never NULL, so the (type, ownerRef, currency) unique index applies). */
  private async account(tx: Tx, type: LedgerAccountType, ownerRef: string | null) {
    const ref = ownerRef ?? PLATFORM_REF;
    return (await tx.ledgerAccount.upsert({ where: { type_ownerRef_currency: { type, ownerRef: ref, currency: "PKR" } }, update: {}, create: { type, ownerRef: ref, currency: "PKR" } })).id;
  }

  /** Writes one balanced transaction. Throws (and the DB would too) if debits ≠ credits. */
  async post(tx: Tx, lines: Line[]): Promise<string> {
    const nonZero = lines.filter((l) => (l.debit ?? 0) > 0 || (l.credit ?? 0) > 0);
    const d = nonZero.reduce((a, l) => a + (l.debit ?? 0), 0);
    const c = nonZero.reduce((a, l) => a + (l.credit ?? 0), 0);
    if (d !== c) throw new Error(`unbalanced ledger txn: ${d} != ${c}`);
    const txnId = randomUUID();
    for (const l of nonZero) {
      await tx.ledgerEntry.create({ data: { txnId, accountId: await this.account(tx, l.account, l.ownerRef ?? null), debitMinor: l.debit ?? 0, creditMinor: l.credit ?? 0, refType: l.refType, refId: l.refId, memo: l.memo } });
    }
    return txnId;
  }

  /** Posts the sale of every line of a paid order + shipping, as one transaction. */
  async postOrderPaid(tx: Tx, orderId: string) {
    const order = await tx.order.findUniqueOrThrow({ where: { id: orderId }, include: { groups: { include: { items: { include: { item: true } } } } } });
    const lines: Line[] = [];
    for (const g of order.groups) {
      for (const oi of g.items) {
        const kind = saleAccounting(oi.arrangement, oi.ownerType);
        if (kind === "PRINCIPAL_SALE") {
          const cost = oi.item.costMinor ?? 0;
          lines.push({ account: "CASH_PROVIDER", debit: oi.priceMinor, refType: "ORDER_ITEM", refId: oi.id, memo: `Sale ${oi.item.sku}` });
          lines.push({ account: "PLATFORM_REVENUE", credit: oi.priceMinor, refType: "ORDER_ITEM", refId: oi.id });
          if (cost > 0) {
            lines.push({ account: "COGS", debit: cost, refType: "ORDER_ITEM", refId: oi.id, memo: `COGS ${oi.item.sku}` });
            lines.push({ account: "INVENTORY_ASSET", credit: cost, refType: "ORDER_ITEM", refId: oi.id });
          }
        } else {
          const commission = applyBps(money(oi.priceMinor), oi.commissionBps ?? 0).amountMinor;
          lines.push({ account: "CASH_PROVIDER", debit: oi.priceMinor, refType: "ORDER_ITEM", refId: oi.id, memo: `Sale ${oi.item.sku}` });
          lines.push({ account: "SELLER_PAYABLE", ownerRef: g.sellerId, credit: oi.priceMinor - commission, refType: "ORDER_ITEM", refId: oi.id });
          lines.push({ account: "COMMISSION_REVENUE", credit: commission, refType: "ORDER_ITEM", refId: oi.id });
        }
      }
    }
    if (order.shippingMinor > 0) {
      lines.push({ account: "CASH_PROVIDER", debit: order.shippingMinor, refType: "ORDER", refId: order.id, memo: "Shipping collected" });
      lines.push({ account: "PLATFORM_REVENUE", credit: order.shippingMinor, refType: "ORDER", refId: order.id, memo: "Shipping" });
    }
    return this.post(tx, lines);
  }

  /**
   * Refund of `amount` against one order line.
   *  - mode CANCEL (before dispatch, or a broken lot): fully reverse the sale incl. the seller's payable.
   *  - mode DAMAGE (approved damage claim): self-managed → seller bears it; managed → platform bears it (expense);
   *    platform-owned → revenue reversed. (COMMERCIAL_POLICY §3)
   */
  async postLineRefund(tx: Tx, orderItemId: string, amount: number, mode: "CANCEL" | "DAMAGE", refundId: string) {
    const oi = await tx.orderItem.findUniqueOrThrow({ where: { id: orderItemId }, include: { group: true } });
    const lines: Line[] = [{ account: "CASH_PROVIDER", credit: amount, refType: "REFUND", refId: refundId, memo: `Refund (${mode.toLowerCase()})` }];
    const kind = saleAccounting(oi.arrangement, oi.ownerType);
    if (kind === "PRINCIPAL_SALE") lines.push({ account: "PLATFORM_REVENUE", debit: amount, refType: "REFUND", refId: refundId });
    else if (mode === "DAMAGE" && oi.arrangement === "MANAGED_RESALE") lines.push({ account: "FEES_EXPENSE", debit: amount, refType: "REFUND", refId: refundId, memo: "Damage claim borne by platform (managed)" });
    else {
      // Reverse proportionally: seller payable share and commission share of the refunded amount.
      const commission = applyBps(money(oi.priceMinor), oi.commissionBps ?? 0).amountMinor;
      const [sellerPart, commissionPart] = allocate(money(amount), [oi.priceMinor - commission, commission].map((x) => Math.max(0, x))).map((m) => m.amountMinor);
      lines.push({ account: "SELLER_PAYABLE", ownerRef: oi.group.sellerId, debit: sellerPart!, refType: "REFUND", refId: refundId });
      lines.push({ account: "COMMISSION_REVENUE", debit: commissionPart!, refType: "REFUND", refId: refundId });
    }
    return this.post(tx, lines);
  }

  async postShippingRefund(tx: Tx, orderId: string, amount: number, refundId: string) {
    return this.post(tx, [
      { account: "PLATFORM_REVENUE", debit: amount, refType: "REFUND", refId: refundId, memo: `Shipping refund ${orderId}` },
      { account: "CASH_PROVIDER", credit: amount, refType: "REFUND", refId: refundId },
    ]);
  }

  async postTransfer(tx: Tx, transferId: string, cost: number) {
    return this.post(tx, [
      { account: "INVENTORY_ASSET", debit: cost, refType: "OWNERSHIP_TRANSFER", refId: transferId, memo: "Direct purchase: inventory acquired" },
      { account: "CASH_PROVIDER", credit: cost, refType: "OWNERSHIP_TRANSFER", refId: transferId, memo: "Direct purchase: paid seller" },
    ]);
  }

  async postPayout(tx: Tx, sellerId: string, amount: number, statementId: string) {
    return this.post(tx, [
      { account: "SELLER_PAYABLE", ownerRef: sellerId, debit: amount, refType: "SETTLEMENT", refId: statementId, memo: "Payout" },
      { account: "CASH_PROVIDER", credit: amount, refType: "SETTLEMENT", refId: statementId },
    ]);
  }

  async balance(type: LedgerAccountType, ownerRef: string | null = null) {
    const acct = await this.prisma.ledgerAccount.findFirst({ where: { type, ownerRef: ownerRef ?? PLATFORM_REF } });
    if (!acct) return 0;
    const agg = await this.prisma.ledgerEntry.aggregate({ where: { accountId: acct.id }, _sum: { debitMinor: true, creditMinor: true } });
    return (agg._sum.creditMinor ?? 0) - (agg._sum.debitMinor ?? 0);
  }
}
