import { Injectable } from "@nestjs/common";
import { DAMAGE_CLAIM_WINDOW_HOURS, returnRequest as returnMachine, type ReturnState } from "@ooak/shared";
import { randomUUID } from "node:crypto";
import { AuditService } from "../../common/audit.service";
import type { Viewer } from "../../common/auth";
import { MediaService } from "../../common/media.service";
import { NotifierService } from "../../common/notifier.service";
import { PrismaService } from "../../common/prisma.service";
import { badRequest, conflict, notFound } from "../../common/problem";
import { StorageService } from "../../common/storage.service";
import type { UploadedFileT } from "../../common/upload";
import { CheckoutService } from "./checkout.service";

export const CLAIM_REASONS = ["DAMAGED_IN_TRANSIT", "UNDISCLOSED_DEFECT"] as const;
const OPEN = ["REQUESTED", "APPROVED", "IN_TRANSIT", "RECEIVED"];

/** Damaged-only returns (decided: no change-of-mind or fit returns). Claims are per piece, within 48 h of delivery, with photos. */
@Injectable()
export class ReturnsService {
  constructor(
    private readonly prisma: PrismaService, private readonly media: MediaService, private readonly storage: StorageService,
    private readonly checkout: CheckoutService, private readonly audit: AuditService, private readonly notifier: NotifierService,
  ) {}

  async eligibility(orderItemId: string, now = new Date()) {
    const oi = await this.prisma.orderItem.findUnique({ where: { id: orderItemId }, include: { item: true, group: true } });
    if (!oi) return { eligible: false, reason: "Not found" };
    if (oi.voidedAt) return { eligible: false, reason: "This line was cancelled." };
    if (oi.item.stockState !== "DELIVERED" || !oi.group.deliveredAt) return { eligible: false, reason: "You can report damage once the parcel is delivered." };
    const deadline = new Date(oi.group.deliveredAt.getTime() + DAMAGE_CLAIM_WINDOW_HOURS * 3_600_000);
    if (now > deadline) return { eligible: false, reason: `Claims must be made within ${DAMAGE_CLAIM_WINDOW_HOURS} hours of delivery.`, deadline };
    const open = await this.prisma.returnRequest.findFirst({ where: { orderItemId, state: { in: OPEN as never } } });
    if (open) return { eligible: false, reason: "There is already a claim for this piece." };
    return { eligible: true, deadline };
  }

  async create(v: Viewer, orderRef: string, input: { orderItemId: string; reason: (typeof CLAIM_REASONS)[number]; description: string }, files: UploadedFileT[]) {
    const order = await this.prisma.order.findUnique({ where: { reference: orderRef }, include: { groups: { include: { items: true } } } });
    if (!order || order.userId !== v.userId) throw notFound("Order");
    if (!order.groups.some((g) => g.items.some((i) => i.id === input.orderItemId))) throw notFound("Order line");
    const el = await this.eligibility(input.orderItemId);
    if (!el.eligible) throw conflict(el.reason!, "NOT_ELIGIBLE");
    if (!files.length) throw badRequest("Please add at least one photo showing the damage.", "PHOTOS_REQUIRED");
    const keys: string[] = [];
    for (const f of files.slice(0, 6)) {
      const { body } = await this.media.processImage(f.buffer);
      const key = `private/claims/${order.id}/${randomUUID()}.webp`;
      await this.storage.put(key, body, "image/webp");
      keys.push(key);
    }
    const r = await this.prisma.returnRequest.create({ data: { orderId: order.id, orderItemId: input.orderItemId, reason: `${input.reason}: ${input.description}`, evidenceKeys: keys } });
    await this.audit.log({ actorId: v.userId, action: "DAMAGE_CLAIM_OPENED", entity: "ReturnRequest", entityId: r.id });
    return r;
  }

  private async load(id: string) {
    const r = await this.prisma.returnRequest.findUnique({ where: { id }, include: { order: { include: { user: true, payments: true } } } });
    if (!r) throw notFound("Claim");
    return r;
  }

  private async transition(id: string, to: ReturnState, actorId: string, data: Record<string, unknown> = {}) {
    const r = await this.load(id);
    returnMachine.assert(r.state as ReturnState, to);
    await this.prisma.returnRequest.update({ where: { id }, data: { state: to, ...data } });
    await this.audit.log({ actorId, action: `CLAIM_${to}`, entity: "ReturnRequest", entityId: id, before: { state: r.state }, after: data });
    return r;
  }

  /** Staff decision. Approve ⇒ the piece comes back (platform-paid return) or, for low value, refund without return. */
  async decide(staffId: string, id: string, input: { approve: boolean; note: string; refundWithoutReturn?: boolean }) {
    const r = await this.load(id);
    if (!input.approve) {
      await this.transition(id, "REJECTED", staffId, { decisionNote: input.note });
      if (r.order.user.phone) await this.notifier.sendSms(r.order.user.phone, "CLAIM_REJECTED", `Your claim for order ${r.order.reference} was not approved: ${input.note}`, r.order.userId);
      return;
    }
    await this.transition(id, "APPROVED", staffId, { decisionNote: input.note });
    await this.prisma.item.updateMany({ where: { orderItems: { some: { id: r.orderItemId } }, stockState: "DELIVERED" }, data: { stockState: "RETURN_PENDING" } });
    if (input.refundWithoutReturn) await this.refund(staffId, id, true);
    else if (r.order.user.phone) await this.notifier.sendSms(r.order.user.phone, "CLAIM_APPROVED", `Your claim for order ${r.order.reference} is approved. Our courier will collect the piece; your refund is sent when it arrives.`, r.order.userId);
  }

  async markInTransit(staffId: string, id: string) { await this.transition(id, "IN_TRANSIT", staffId); }

  /** Warehouse received the returned piece: back to stock for inspection, the old order line is voided, refund issued. */
  async markReceived(staffId: string, id: string) {
    const r = await this.transition(id, "RECEIVED", staffId);
    await this.prisma.$transaction(async (tx) => {
      const oi = await tx.orderItem.findUniqueOrThrow({ where: { id: r.orderItemId } });
      await tx.item.updateMany({ where: { id: oi.itemId, stockState: "RETURN_PENDING" }, data: { stockState: "RETURNED_TO_STOCK" } });
      await tx.orderItem.update({ where: { id: oi.id }, data: { voidedAt: new Date() } }); // the piece can be inspected and sold again
      await tx.custodyEvent.create({ data: { itemId: oi.itemId, fromParty: "BUYER", toParty: "WAREHOUSE:LHR", actorId: staffId, note: `Damage claim return ${r.order.reference}` } });
    });
    await this.refund(staffId, id, false);
  }

  /** Refund = the line's price (for a lot piece: its allocated share). Ledger posts when the provider confirms (webhook). */
  async refund(staffId: string, id: string, withoutReturn: boolean) {
    const r = await this.load(id);
    const oi = await this.prisma.orderItem.findUniqueOrThrow({ where: { id: r.orderItemId } });
    const pay = r.order.payments.find((p) => p.state === "CAPTURED" || p.state === "PARTIALLY_REFUNDED");
    if (!pay) throw conflict("No captured payment to refund.", "NO_PAYMENT");
    const already = await this.prisma.refund.aggregate({ where: { orderItemId: oi.id, state: { in: ["PENDING", "SUCCEEDED"] } }, _sum: { amountMinor: true } });
    const amount = oi.priceMinor - (already._sum.amountMinor ?? 0);
    if (amount <= 0) throw conflict("This piece has already been refunded.", "ALREADY_REFUNDED");
    const refund = await this.prisma.refund.create({ data: { paymentId: pay.id, returnId: r.id, orderItemId: oi.id, amountMinor: amount, reason: withoutReturn ? "Damage claim (refund without return)" : "Damage claim", mode: "DAMAGE" } });
    // Refund without return: the piece stays with the buyer and is written off.
    if (withoutReturn) await this.prisma.item.updateMany({ where: { id: oi.itemId, stockState: "RETURN_PENDING" }, data: { stockState: "LOST_OR_DAMAGED" } });
    await this.transition(id, "REFUNDED", staffId, { refundMinor: amount });
    await this.checkout.sendRefund(refund.id);
    if (r.order.user.phone) await this.notifier.sendSms(r.order.user.phone, "REFUND_SENT", `Refund of PKR ${(amount / 100).toLocaleString("en-PK")} for order ${r.order.reference} is on its way to your original payment method.`, r.order.userId);
    return refund;
  }
}
