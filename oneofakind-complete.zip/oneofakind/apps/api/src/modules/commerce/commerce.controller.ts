import { Body, Controller, Delete, Get, Headers, HttpCode, Param, Post, Put, Query, Req, Res, UploadedFiles, UseInterceptors } from "@nestjs/common";
import { FilesInterceptor } from "@nestjs/platform-express";
import type { Request, Response } from "express";
import { memoryStorage } from "multer";
import { DAMAGE_CLAIM_WINDOW_HOURS, normalizePkPhone } from "@ooak/shared";
import { randomUUID } from "node:crypto";
import { z } from "zod";
import { AuditService } from "../../common/audit.service";
import { Auth, CurrentViewer, hasRole, requireSeller, type Viewer } from "../../common/auth";
import { NotifierService } from "../../common/notifier.service";
import { PrismaService } from "../../common/prisma.service";
import { badRequest, conflict, notFound, parse } from "../../common/problem";
import { config, isProd } from "../../config";
import { gradeView, mediaUrl } from "../catalog/presenters";
import { CartService } from "./cart.service";
import { AddressInput, CheckoutService } from "./checkout.service";
import { FulfilmentService } from "./fulfilment.service";
import { SIG_HEADER, sign } from "./providers";
import { CLAIM_REASONS, ReturnsService } from "./returns.service";

type RawReq = Request & { rawBody?: Buffer };

@Controller("cart")
export class CartController {
  constructor(private readonly cart: CartService, private readonly checkout: CheckoutService, private readonly prisma: PrismaService) {}

  @Get()
  async get(@Req() req: Request, @Res({ passthrough: true }) res: Response, @CurrentViewer() v: Viewer | null) {
    res.setHeader("Cache-Control", "no-store");
    const c = await this.cart.cartFor(req, res, v, false);
    return this.cart.view(c?.id ?? null, v);
  }

  @Post("items")
  async add(@Req() req: Request, @Res({ passthrough: true }) res: Response, @CurrentViewer() v: Viewer | null, @Body() body: unknown) {
    const input = parse(z.object({ listingSlug: z.string().max(200).optional(), bundleSlug: z.string().max(200).optional() }), body);
    const c = (await this.cart.cartFor(req, res, v, true))!;
    await this.cart.add(c.id, v, input);
    return this.cart.view(c.id, v);
  }

  @Delete("items/:id")
  async remove(@Req() req: Request, @Res({ passthrough: true }) res: Response, @CurrentViewer() v: Viewer | null, @Param("id") id: string) {
    const c = await this.cart.cartFor(req, res, v, false);
    if (c) await this.prisma.cartItem.deleteMany({ where: { id, cartId: c.id } });
    return this.cart.view(c?.id ?? null, v);
  }

  /** Delivery quote for the cart to a destination city (flat per parcel; bundles by weight). */
  @Post("quote")
  @HttpCode(200)
  async quote(@Req() req: Request, @CurrentViewer() v: Viewer | null, @Body() body: unknown) {
    const { city } = parse(z.object({ city: z.string().trim().min(2).max(60) }), body);
    const c = await this.cart.cartFor(req, null, v, false);
    const view = await this.cart.view(c?.id ?? null, v);
    const r = await this.checkout.rates();
    const groups = view.groups.map((g) => {
      const lines = view.lines.filter((l) => l.groupKey === g.key && l.available);
      const origin = g.key.endsWith(":WAREHOUSE") ? "Lahore" : g.shipsFrom;
      return { key: g.key, shippingMinor: lines.length ? this.checkout.shippingForGroup(r, origin, city, lines.filter((l) => l.kind === "ITEM").length, lines.filter((l) => l.kind === "BUNDLE").map((l) => l.weightGrams)) : 0 };
    });
    const shippingMinor = groups.reduce((a, g) => a + g.shippingMinor, 0);
    return { groups, subtotalMinor: view.subtotalMinor, shippingMinor, totalMinor: view.subtotalMinor + shippingMinor };
  }
}

@Controller("checkout")
export class CheckoutController {
  constructor(private readonly cart: CartService, private readonly checkout: CheckoutService) {}

  /** Requires an Idempotency-Key header; the same key returns the same order. Prepaid only (no COD). */
  @Post()
  @Auth()
  async create(@Req() req: Request, @Res({ passthrough: true }) res: Response, @CurrentViewer() v: Viewer, @Headers("idempotency-key") key: string | undefined, @Body() body: unknown) {
    const c = await this.cart.cartFor(req, res, v, false);
    if (!c) throw conflict("Your cart is empty.", "CART_EMPTY");
    try { return await this.checkout.checkout(v, key ?? "", c.id, body); }
    catch (e) { if (e instanceof z.ZodError) throw badRequest("Some fields are missing or invalid.", "VALIDATION", e.flatten()); throw e; }
  }
}

@Controller("webhooks")
export class WebhooksController {
  constructor(private readonly checkout: CheckoutService, private readonly fulfilment: FulfilmentService) {}

  @Post("payments/:provider")
  @HttpCode(200)
  payments(@Param("provider") provider: string, @Req() req: RawReq) {
    if (!req.rawBody) throw badRequest("Raw body required.");
    return this.checkout.handleWebhook(provider, req.rawBody, req.headers);
  }

  @Post("courier/:provider")
  @HttpCode(200)
  courier(@Param("provider") provider: string, @Req() req: RawReq) {
    if (!req.rawBody) throw badRequest("Raw body required.");
    return this.fulfilment.courierWebhook(provider, req.rawBody, req.headers);
  }
}

/**
 * Sandbox simulators (never in production): play the role of the gateway's hosted payment page and the courier's tracking
 * system by sending SIGNED webhooks through the same verification path real providers use.
 */
@Controller("sandbox")
export class SandboxController {
  constructor(private readonly prisma: PrismaService, private readonly checkout: CheckoutService, private readonly fulfilment: FulfilmentService) {}
  private guard() { if (isProd() || config().PAYMENT_PROVIDER !== "sandbox") throw notFound(); }

  @Get("payments/:paymentId")
  @Auth()
  async payment(@CurrentViewer() v: Viewer, @Param("paymentId") id: string) {
    this.guard();
    const p = await this.prisma.payment.findUnique({ where: { id }, include: { order: true } });
    if (!p || p.order.userId !== v.userId) throw notFound("Payment");
    return { paymentId: p.id, orderRef: p.order.reference, amountMinor: p.amountMinor, method: p.method, state: p.state, orderState: p.order.state };
  }

  @Post("payments/:paymentId/complete")
  @HttpCode(200)
  @Auth()
  async complete(@CurrentViewer() v: Viewer, @Param("paymentId") id: string, @Body() body: unknown) {
    this.guard();
    const { outcome } = parse(z.object({ outcome: z.enum(["success", "fail"]) }), body);
    const p = await this.prisma.payment.findUnique({ where: { id }, include: { order: true } });
    if (!p || p.order.userId !== v.userId || !p.providerRef) throw notFound("Payment");
    const event = { eventId: `evt_${randomUUID()}`, type: outcome === "success" ? "payment.succeeded" : "payment.failed", providerRef: p.providerRef, amountMinor: p.amountMinor };
    const raw = Buffer.from(JSON.stringify(event));
    await this.checkout.handleWebhook("sandbox", raw, { [SIG_HEADER]: sign(config().PAYMENT_WEBHOOK_SECRET, raw) });
    await this.flushRefunds();
    return { orderRef: p.order.reference };
  }

  /** Sandbox gateway confirms pending refunds asynchronously (here: immediately, via signed webhook). */
  async flushRefunds() {
    const pending = await this.prisma.refund.findMany({ where: { state: "PENDING", providerRef: { not: null } }, include: { payment: true } });
    for (const r of pending) {
      const raw = Buffer.from(JSON.stringify({ eventId: `evt_${randomUUID()}`, type: "refund.succeeded", providerRef: r.payment.providerRef, refundRef: r.providerRef, amountMinor: r.amountMinor }));
      await this.checkout.handleWebhook("sandbox", raw, { [SIG_HEADER]: sign(config().PAYMENT_WEBHOOK_SECRET, raw) });
    }
    return pending.length;
  }

  @Post("refunds/flush")
  @HttpCode(200)
  @Auth("ADMIN", "FINANCE", "SUPPORT")
  async flush() { this.guard(); return { confirmed: await this.flushRefunds() }; }

  @Post("courier/:trackingNo/advance")
  @HttpCode(200)
  @Auth("ADMIN", "WAREHOUSE", "SUPPORT")
  async advance(@Param("trackingNo") trackingNo: string, @Body() body: unknown) {
    this.guard();
    const { status } = parse(z.object({ status: z.enum(["IN_TRANSIT", "OUT_FOR_DELIVERY", "DELIVERED", "FAILED_DELIVERY", "RETURNING", "RETURNED", "PICKED_UP"]) }), body);
    const sh = await this.prisma.shipment.findFirst({ where: { trackingNo } });
    if (!sh) throw notFound("Shipment");
    const raw = Buffer.from(JSON.stringify({ eventId: `cev_${randomUUID()}`, trackingNo, status, occurredAt: new Date().toISOString() }));
    return this.fulfilment.courierWebhook(sh.courier, raw, { [SIG_HEADER]: sign(config().COURIER_WEBHOOK_SECRET, raw) });
  }
}

const claimUpload = FilesInterceptor("photos", 6, { storage: memoryStorage(), limits: { fileSize: 10 * 1024 * 1024 } });

@Controller("orders")
@Auth()
export class OrdersController {
  constructor(private readonly prisma: PrismaService, private readonly checkout: CheckoutService, private readonly returns: ReturnsService) {}

  @Get()
  async list(@CurrentViewer() v: Viewer) {
    const orders = await this.prisma.order.findMany({
      where: { userId: v.userId }, orderBy: { createdAt: "desc" }, take: 100,
      include: { groups: { include: { items: { include: { item: { include: { media: { where: { approvedForPublish: true, deletedAt: null }, take: 1, orderBy: { position: "asc" } } } } } } } } },
    });
    return {
      orders: orders.map((o) => ({
        reference: o.reference, state: o.state, totalMinor: o.totalMinor, createdAt: o.createdAt, paidAt: o.paidAt,
        pieces: o.groups.reduce((a, g) => a + g.items.length, 0), thumbs: o.groups.flatMap((g) => g.items).slice(0, 4).map((i) => (i.item.media[0] ? mediaUrl(i.item.media[0].id) : null)),
      })),
    };
  }

  @Get(":ref")
  async detail(@CurrentViewer() v: Viewer, @Param("ref") ref: string) {
    const o = await this.prisma.order.findUnique({
      where: { reference: ref },
      include: {
        payments: { include: { refunds: true } }, returns: true,
        groups: {
          include: {
            items: { include: { item: { include: { brand: true, listings: { take: 1, orderBy: { createdAt: "desc" } }, media: { where: { approvedForPublish: true, deletedAt: null }, take: 1, orderBy: { position: "asc" } } } } } },
            bundleLines: { include: { bundle: { select: { title: true, slug: true, size: true } } } },
            shipments: { include: { events: { orderBy: { occurredAt: "asc" } } }, orderBy: { parcelIndex: "asc" } },
          },
        },
      },
    });
    if (!o || (o.userId !== v.userId && !hasRole(v, "SUPPORT", "ADMIN", "FINANCE"))) throw notFound("Order");
    const sellerNames = new Map((await this.prisma.sellerProfile.findMany({ where: { id: { in: o.groups.map((g) => g.sellerId) } }, select: { id: true, displayName: true } })).map((s) => [s.id, s.displayName]));
    const now = new Date();
    return {
      order: {
        reference: o.reference, state: o.state, createdAt: o.createdAt, paidAt: o.paidAt, subtotalMinor: o.subtotalMinor, shippingMinor: o.shippingMinor, totalMinor: o.totalMinor,
        shippingAddress: o.shippingAddress, payment: o.payments[0] ? { id: o.payments[0].id, state: o.payments[0].state, method: o.payments[0].method, checkoutUrl: o.payments[0].checkoutUrl, refunds: o.payments[0].refunds.map((r) => ({ amountMinor: r.amountMinor, state: r.state, reason: r.reason, createdAt: r.createdAt })) } : null,
        reservationExpiresAt: o.state === "PENDING_PAYMENT" ? (await this.prisma.stockReservation.findFirst({ where: { orderId: o.id, releasedAt: null }, orderBy: { expiresAt: "asc" } }))?.expiresAt ?? null : null,
        groups: o.groups.map((g) => ({
          id: g.id, state: g.state, seller: g.sellerId === "PLATFORM" ? "ONEOFAKIND" : sellerNames.get(g.sellerId) ?? "Seller", mode: g.mode, shippingMinor: g.shippingMinor, deliveredAt: g.deliveredAt,
          claimDeadline: g.deliveredAt ? new Date(g.deliveredAt.getTime() + DAMAGE_CLAIM_WINDOW_HOURS * 3_600_000) : null,
          bundles: g.bundleLines.map((b) => ({ id: b.id, title: b.bundle.title, slug: b.bundle.slug, size: b.bundle.size, priceMinor: b.priceMinor })),
          items: g.items.map((i) => ({
            id: i.id, title: i.item.title, brand: i.item.brand?.name ?? null, size: i.item.size, grade: gradeView(i.item.conditionGrade), priceMinor: i.priceMinor, bundleLineId: i.bundleLineId,
            slug: i.item.listings[0]?.slug ?? null, image: i.item.media[0] ? mediaUrl(i.item.media[0].id) : null, stockState: i.item.stockState, voided: !!i.voidedAt,
            canClaim: i.item.stockState === "DELIVERED" && !!g.deliveredAt && now.getTime() < g.deliveredAt.getTime() + DAMAGE_CLAIM_WINDOW_HOURS * 3_600_000 && !o.returns.some((r) => r.orderItemId === i.id && !["REJECTED", "CLOSED"].includes(r.state)),
          })),
          shipments: g.shipments.map((s) => ({ id: s.id, courier: s.courier, trackingNo: s.trackingNo, state: s.state, parcel: `${s.parcelIndex}/${s.parcelCount}`, events: s.events.map((e) => ({ status: e.status, at: e.occurredAt })) })),
        })),
        claims: o.returns.map((r) => ({ id: r.id, orderItemId: r.orderItemId, state: r.state, reason: r.reason, decisionNote: r.decisionNote, refundMinor: r.refundMinor, createdAt: r.createdAt })),
      },
    };
  }

  @Post(":ref/cancel")
  @HttpCode(200)
  async cancel(@CurrentViewer() v: Viewer, @Param("ref") ref: string) { await this.checkout.cancelByBuyer(v, ref); return { ok: true }; }

  @Post(":ref/claims")
  @UseInterceptors(claimUpload)
  async claim(@CurrentViewer() v: Viewer, @Param("ref") ref: string, @Body() body: unknown, @UploadedFiles() files: Express.Multer.File[]) {
    const input = parse(z.object({ orderItemId: z.string(), reason: z.enum(CLAIM_REASONS), description: z.string().trim().min(10, "Please describe the damage").max(1000) }), body);
    const r = await this.returns.create(v, ref, input, files ?? []);
    return { id: r.id, state: r.state };
  }
}

const PackBody = z.object({ scans: z.array(z.string().max(40)).max(200) });
const DispatchBody = z.object({ parcels: z.number().int().min(1).max(10).optional(), manual: z.object({ courier: z.string().trim().min(2).max(60), trackingNo: z.string().trim().min(4).max(40) }).optional() });

/** Seller-arranged fulfilment: pack slip → scan pieces → book courier / enter tracking → hand over. */
@Controller("seller/orders")
@Auth("SELLER")
export class SellerOrdersController {
  constructor(private readonly prisma: PrismaService, private readonly fulfilment: FulfilmentService) {}

  @Get()
  async list(@CurrentViewer() v: Viewer, @Query() q: unknown) {
    const sellerId = requireSeller(v);
    const { tab } = parse(z.object({ tab: z.enum(["to-send", "sent", "all"]).default("to-send") }), q);
    const states = tab === "to-send" ? ["PAID", "PROCESSING"] : tab === "sent" ? ["FULFILLED", "COMPLETED"] : ["PAID", "PROCESSING", "FULFILLED", "COMPLETED", "REFUND_PENDING", "REFUNDED"];
    const groups = await this.prisma.fulfilmentGroup.findMany({
      where: { sellerId, state: { in: states as never } }, orderBy: { order: { paidAt: "asc" } },
      include: { order: true, items: { where: { voidedAt: null }, include: { item: { include: { media: { where: { deletedAt: null }, take: 1, orderBy: { position: "asc" } } } } } }, shipments: true },
    });
    return {
      orders: groups.map((g) => ({
        groupId: g.id, orderRef: g.order.reference, state: g.state, mode: g.mode, paidAt: g.order.paidAt, packVerified: !!g.packVerifiedAt, deliveredAt: g.deliveredAt,
        city: (g.order.shippingAddress as { city: string }).city, subtotalMinor: g.subtotalMinor, pieces: g.items.length,
        thumbs: g.items.slice(0, 4).map((i) => (i.item.media[0] ? mediaUrl(i.item.media[0].id) : null)), tracking: g.shipments.map((s) => s.trackingNo),
        youShip: g.mode === "SELLER_ARRANGED",
      })),
    };
  }

  @Get(":groupId")
  async detail(@CurrentViewer() v: Viewer, @Param("groupId") id: string) {
    const sellerId = requireSeller(v);
    const g = await this.prisma.fulfilmentGroup.findUnique({ where: { id }, select: { sellerId: true, mode: true } });
    if (!g || g.sellerId !== sellerId) throw notFound("Order");
    if (g.mode !== "SELLER_ARRANGED") {
      const full = await this.prisma.fulfilmentGroup.findUniqueOrThrow({ where: { id }, include: { order: true, items: { include: { item: true } }, shipments: true } });
      return { group: { id, orderRef: full.order.reference, state: full.state, mode: full.mode, items: full.items.map((i) => ({ title: i.item.title, sku: i.item.sku, priceMinor: i.priceMinor })), shipments: full.shipments.map((s) => ({ trackingNo: s.trackingNo, state: s.state })), warehouseHandles: true } };
    }
    const full = await this.fulfilment.group(id, { actorId: v.userId, sellerId });
    const expected = full.state === "PAID" || full.state === "PROCESSING" ? await this.fulfilment.expectedCodes(id, v.userId) : [];
    const addr = full.order.shippingAddress as Record<string, string | null>;
    return {
      group: {
        id, orderRef: full.order.reference, state: full.state, mode: full.mode, paidAt: full.order.paidAt, packVerifiedAt: full.packVerifiedAt,
        shipTo: { recipient: addr.recipient, phone: addr.phone, line1: addr.line1, line2: addr.line2, city: addr.city, province: addr.province, postalCode: addr.postalCode },
        items: full.items.map((i) => ({ id: i.id, itemId: i.itemId, title: i.item.title, sku: i.item.sku, size: i.item.size, priceMinor: i.priceMinor, code: i.item.scanCodes[0]?.code ?? null, photo: i.item.media[0] ? mediaUrl(i.item.media[0].id) : null })),
        expectedCodes: expected,
        shipments: full.shipments.map((s) => ({ id: s.id, courier: s.courier, trackingNo: s.trackingNo, state: s.state, code: s.scanCodes.find((c) => c.kind === "DISPATCH")?.code ?? null, events: s.events.map((e) => ({ status: e.status, at: e.occurredAt })) })),
      },
    };
  }

  @Get(":groupId/pack-slip")
  async slip(@CurrentViewer() v: Viewer, @Param("groupId") id: string, @Res() res: Response) {
    const pdf = await this.fulfilment.packSlip(id, { actorId: v.userId, sellerId: requireSeller(v) });
    res.type("application/pdf").setHeader("Cache-Control", "no-store"); res.send(Buffer.from(pdf));
  }

  @Post(":groupId/pack")
  @HttpCode(200)
  pack(@CurrentViewer() v: Viewer, @Param("groupId") id: string, @Body() body: unknown) {
    return this.fulfilment.verifyPack(id, parse(PackBody, body).scans, { actorId: v.userId, sellerId: requireSeller(v) });
  }

  @Post(":groupId/dispatch")
  @HttpCode(200)
  dispatch(@CurrentViewer() v: Viewer, @Param("groupId") id: string, @Body() body: unknown) {
    return this.fulfilment.dispatch(id, { actorId: v.userId, sellerId: requireSeller(v) }, parse(DispatchBody, body));
  }

  @Get("shipments/:shipmentId/label")
  async label(@CurrentViewer() v: Viewer, @Param("shipmentId") id: string, @Res() res: Response) {
    const pdf = await this.fulfilment.dispatchLabel(id, { actorId: v.userId, sellerId: requireSeller(v) });
    res.type("application/pdf").setHeader("Cache-Control", "no-store"); res.send(Buffer.from(pdf));
  }

  @Post("handover")
  @HttpCode(200)
  handover(@CurrentViewer() v: Viewer, @Body() body: unknown) {
    const { code } = parse(z.object({ code: z.string().max(40) }), body);
    return this.fulfilment.handover(code, { actorId: v.userId, sellerId: requireSeller(v) });
  }
}

@Controller()
export class OffersWishlistController {
  constructor(private readonly prisma: PrismaService, private readonly notifier: NotifierService, private readonly audit: AuditService) {}

  /** Make-an-offer on a single piece. Expires in 24 h. An accepted offer is used as the price at checkout for that buyer. */
  @Post("listings/:slug/offers")
  @Auth()
  async makeOffer(@CurrentViewer() v: Viewer, @Param("slug") slug: string, @Body() body: unknown) {
    const { amountMinor } = parse(z.object({ amountMinor: z.number().int().positive() }), body);
    const l = await this.prisma.listing.findUnique({ where: { slug }, include: { item: true, seller: true } });
    if (!l || l.state !== "PUBLISHED" || l.item.stockState !== "AVAILABLE") throw notFound("Listing");
    if (l.item.ownerType !== "SELLER") throw badRequest("Offers aren't available on ONEOFAKIND-owned pieces.", "OFFERS_DISABLED");
    if (v.sellerId === l.sellerId) throw badRequest("You can't make an offer on your own item.", "OWN_ITEM");
    if (amountMinor >= l.item.priceMinor) throw badRequest("Your offer must be below the price. Or just buy it.", "OFFER_TOO_HIGH");
    if (amountMinor < Math.round(l.item.priceMinor * 0.5)) throw badRequest("Offers must be at least half the price.", "OFFER_TOO_LOW");
    const open = await this.prisma.buyerOffer.count({ where: { buyerId: v.userId, itemId: l.itemId, state: "PENDING", expiresAt: { gt: new Date() } } });
    if (open) throw conflict("You already have an offer waiting on this piece.", "OFFER_EXISTS");
    const o = await this.prisma.buyerOffer.create({ data: { itemId: l.itemId, buyerId: v.userId, amountMinor, expiresAt: new Date(Date.now() + 24 * 3_600_000) } });
    await this.notifier.inApp(l.seller.userId, "OFFER_RECEIVED", `New offer of PKR ${(amountMinor / 100).toLocaleString("en-PK")} on “${l.item.title}”. It expires in 24 hours.`);
    return { id: o.id, state: o.state, expiresAt: o.expiresAt };
  }

  @Get("offers/mine")
  @Auth()
  async mine(@CurrentViewer() v: Viewer) {
    const offers = await this.prisma.buyerOffer.findMany({ where: { buyerId: v.userId }, orderBy: { createdAt: "desc" }, take: 50, include: { item: { include: { listings: { take: 1, orderBy: { createdAt: "desc" } } } } } });
    return { offers: offers.map((o) => ({ id: o.id, state: o.state, amountMinor: o.amountMinor, expiresAt: o.expiresAt, title: o.item.title, slug: o.item.listings[0]?.slug, listPriceMinor: o.item.priceMinor })) };
  }

  @Get("seller/offers")
  @Auth("SELLER")
  async sellerOffers(@CurrentViewer() v: Viewer) {
    const offers = await this.prisma.buyerOffer.findMany({ where: { item: { sellerId: requireSeller(v) } }, orderBy: { createdAt: "desc" }, take: 100, include: { item: true, buyer: { select: { name: true } } } });
    return { offers: offers.map((o) => ({ id: o.id, state: o.state === "PENDING" && o.expiresAt < new Date() ? "EXPIRED" : o.state, amountMinor: o.amountMinor, listPriceMinor: o.item.priceMinor, title: o.item.title, sku: o.item.sku, buyer: o.buyer.name.split(" ")[0], expiresAt: o.expiresAt, createdAt: o.createdAt })) };
  }

  @Post("seller/offers/:id/accept")
  @HttpCode(200)
  @Auth("SELLER")
  accept(@CurrentViewer() v: Viewer, @Param("id") id: string) { return this.decide(v, id, "ACCEPTED"); }

  @Post("seller/offers/:id/decline")
  @HttpCode(200)
  @Auth("SELLER")
  decline(@CurrentViewer() v: Viewer, @Param("id") id: string) { return this.decide(v, id, "DECLINED"); }

  private async decide(v: Viewer, id: string, to: "ACCEPTED" | "DECLINED") {
    const sellerId = requireSeller(v);
    const o = await this.prisma.buyerOffer.findUnique({ where: { id }, include: { item: true } });
    if (!o || o.item.sellerId !== sellerId) throw notFound("Offer");
    if (o.state !== "PENDING" || o.expiresAt < new Date()) throw conflict("This offer is no longer open.", "OFFER_CLOSED");
    await this.prisma.buyerOffer.update({ where: { id }, data: { state: to, ...(to === "ACCEPTED" ? { expiresAt: new Date(Date.now() + 24 * 3_600_000) } : {}) } });
    await this.audit.log({ actorId: v.userId, action: `OFFER_${to}`, entity: "BuyerOffer", entityId: id });
    await this.notifier.inApp(o.buyerId, `OFFER_${to}`, to === "ACCEPTED" ? `Your offer on “${o.item.title}” was accepted. Check out within 24 hours to get it at your price. First to pay wins.` : `Your offer on “${o.item.title}” was declined.`);
    return { ok: true };
  }

  @Get("wishlist")
  @Auth()
  async wishlist(@CurrentViewer() v: Viewer) {
    const rows = await this.prisma.wishlistItem.findMany({ where: { userId: v.userId }, orderBy: { addedAt: "desc" }, include: { item: { include: { brand: true, listings: { take: 1, orderBy: { createdAt: "desc" } }, media: { where: { approvedForPublish: true, deletedAt: null }, take: 1, orderBy: { position: "asc" } } } } } });
    return {
      items: rows.map((r) => ({ slug: r.item.listings[0]?.slug ?? null, title: r.item.title, brand: r.item.brand?.name ?? null, size: r.item.size, priceMinor: r.item.priceMinor, grade: gradeView(r.item.conditionGrade), image: r.item.media[0] ? mediaUrl(r.item.media[0].id) : null, availability: r.item.stockState === "AVAILABLE" && r.item.listings[0]?.state === "PUBLISHED" ? "AVAILABLE" : r.item.stockState === "RESERVED" ? "RESERVED" : "SOLD" })),
    };
  }

  @Get("wishlist/slugs")
  @Auth()
  async slugs(@CurrentViewer() v: Viewer) {
    const rows = await this.prisma.wishlistItem.findMany({ where: { userId: v.userId }, include: { item: { include: { listings: { take: 1, orderBy: { createdAt: "desc" }, select: { slug: true } } } } } });
    return { slugs: rows.map((r) => r.item.listings[0]?.slug).filter(Boolean) };
  }

  @Put("wishlist/:slug")
  @Auth()
  async save(@CurrentViewer() v: Viewer, @Param("slug") slug: string) {
    const l = await this.prisma.listing.findUnique({ where: { slug } });
    if (!l) throw notFound("Listing");
    await this.prisma.wishlistItem.upsert({ where: { userId_itemId: { userId: v.userId, itemId: l.itemId } }, update: {}, create: { userId: v.userId, itemId: l.itemId } });
    return { ok: true };
  }

  @Delete("wishlist/:slug")
  @Auth()
  async unsave(@CurrentViewer() v: Viewer, @Param("slug") slug: string) {
    const l = await this.prisma.listing.findUnique({ where: { slug } });
    if (l) await this.prisma.wishlistItem.deleteMany({ where: { userId: v.userId, itemId: l.itemId } });
    return { ok: true };
  }

  @Get("account/addresses")
  @Auth()
  async addresses(@CurrentViewer() v: Viewer) { return { addresses: await this.prisma.address.findMany({ where: { userId: v.userId }, orderBy: [{ isDefault: "desc" }, { id: "asc" }] }) }; }

  @Post("account/addresses")
  @Auth()
  async addAddress(@CurrentViewer() v: Viewer, @Body() body: unknown) {
    const a = parse(AddressInput.extend({ label: z.string().max(30).optional(), isDefault: z.boolean().optional() }), body);
    const phone = normalizePkPhone(a.phone);
    if (!phone) throw badRequest("Enter a valid mobile number.", "INVALID_PHONE");
    if (a.isDefault) await this.prisma.address.updateMany({ where: { userId: v.userId }, data: { isDefault: false } });
    return this.prisma.address.create({ data: { userId: v.userId, label: a.label, recipient: a.recipient, phone, line1: a.line1, line2: a.line2 ?? null, city: a.city, province: a.province ?? null, postalCode: a.postalCode ?? null, isDefault: !!a.isDefault } });
  }

  @Delete("account/addresses/:id")
  @Auth()
  async delAddress(@CurrentViewer() v: Viewer, @Param("id") id: string) {
    await this.prisma.address.deleteMany({ where: { id, userId: v.userId } });
    return { ok: true };
  }
}
