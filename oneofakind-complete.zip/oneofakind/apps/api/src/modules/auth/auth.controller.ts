import { Body, Controller, Get, HttpCode, Patch, Post, Req, Res } from "@nestjs/common";
import { Throttle } from "@nestjs/throttler";
import type { Request, Response } from "express";
import { z } from "zod";
import { Auth, CurrentViewer, hashToken, newSessionToken, type Viewer } from "../../common/auth";
import { AuditService } from "../../common/audit.service";
import { PrismaService } from "../../common/prisma.service";
import { conflict, parse } from "../../common/problem";
import { config } from "../../config";
import { OtpService } from "./otp.service";

export const TERMS_VERSION = "2026-10";

const RequestBody = z.object({ phone: z.string().min(7).max(20) });
const VerifyBody = z.object({
  phone: z.string().min(7).max(20),
  code: z.string().length(6),
  name: z.string().trim().min(2).max(80).optional(),
  acceptTerms: z.boolean().optional(),
});
const UpdateMe = z.object({ name: z.string().trim().min(2).max(80).optional(), email: z.string().email().max(120).nullable().optional() });

export function setSessionCookie(res: Response, token: string) {
  const c = config();
  res.cookie(c.SESSION_COOKIE_NAME, token, {
    httpOnly: true, sameSite: "lax", secure: c.COOKIE_SECURE, path: "/", maxAge: c.SESSION_TTL_DAYS * 86_400_000,
  });
}

@Controller("auth")
export class AuthController {
  constructor(private readonly prisma: PrismaService, private readonly otp: OtpService, private readonly audit: AuditService) {}

  /** Step 1 of the single phone-OTP login (buyers, sellers, verified resellers and staff). */
  @Post("otp/request")
  @HttpCode(200)
  @Throttle({ default: { limit: 10, ttl: 60_000 } })
  async requestOtp(@Body() body: unknown, @Req() req: Request) {
    const { phone: raw } = parse(RequestBody, body);
    const phone = this.otp.normalise(raw);
    const user = await this.prisma.user.findUnique({ where: { phone }, select: { id: true, activatedAt: true, disabledAt: true } });
    const r = await this.otp.request(phone, "LOGIN", req.ip ?? null);
    // Tell the client whether to show the name + terms step (new or not-yet-activated staff-registered account).
    return { phone, ...r, isNewAccount: !user, needsActivation: !!user && !user.activatedAt };
  }

  /** Step 2: verify the code; creates the account on first login (terms must be accepted) and sets the session cookie. */
  @Post("otp/verify")
  @HttpCode(200)
  @Throttle({ default: { limit: 20, ttl: 60_000 } })
  async verifyOtp(@Body() body: unknown, @Req() req: Request, @Res({ passthrough: true }) res: Response) {
    const input = parse(VerifyBody, body);
    const phone = this.otp.normalise(input.phone);
    let user = await this.prisma.user.findUnique({ where: { phone } });
    const needsTerms = !user || !user.activatedAt;
    await this.otp.check(phone, "LOGIN", input.code, false);
    if (needsTerms && !input.acceptTerms) throw conflict("Please accept the Terms and Privacy Policy to continue.", "TERMS_REQUIRED");
    if (!user && !input.name) throw conflict("Please tell us your name.", "NAME_REQUIRED");
    await this.otp.check(phone, "LOGIN", input.code, true);
    const now = new Date();
    if (!user) {
      user = await this.prisma.user.create({ data: { phone, name: input.name!, phoneVerified: now, activatedAt: now, roles: ["CUSTOMER"] } });
      await this.audit.log({ actorId: user.id, action: "USER_REGISTERED", entity: "User", entityId: user.id, ip: req.ip });
    } else if (!user.activatedAt) {
      // Staff-registered account: the person confirms their own phone and accepts the terms. Staff never know or set their login.
      user = await this.prisma.user.update({ where: { id: user.id }, data: { activatedAt: now, phoneVerified: now, ...(input.name ? { name: input.name } : {}) } });
      await this.audit.log({ actorId: user.id, action: "ACCOUNT_ACTIVATED", entity: "User", entityId: user.id, ip: req.ip });
    } else if (!user.phoneVerified) {
      user = await this.prisma.user.update({ where: { id: user.id }, data: { phoneVerified: now } });
    }
    if (user.disabledAt) throw conflict("This account is disabled. Please contact support.", "ACCOUNT_DISABLED");
    if (needsTerms) {
      await this.prisma.consentRecord.createMany({
        data: [
          { userId: user.id, type: "TERMS", version: TERMS_VERSION, granted: true },
          { userId: user.id, type: "PRIVACY", version: TERMS_VERSION, granted: true },
        ],
      });
    }
    const token = newSessionToken();
    await this.prisma.session.create({
      data: {
        userId: user.id, refreshHash: hashToken(token), userAgent: req.headers["user-agent"]?.slice(0, 200) ?? null, ip: req.ip ?? null,
        expiresAt: new Date(now.getTime() + config().SESSION_TTL_DAYS * 86_400_000),
      },
    });
    setSessionCookie(res, token);
    // The token is also returned so the future mobile app can use it as a Bearer token. The web app relies on the httpOnly cookie.
    return { token, me: await this.meFor(user.id) };
  }

  @Post("logout")
  @HttpCode(200)
  async logout(@CurrentViewer() v: Viewer | null, @Res({ passthrough: true }) res: Response) {
    if (v) await this.prisma.session.update({ where: { id: v.sessionId }, data: { revokedAt: new Date() } });
    res.clearCookie(config().SESSION_COOKIE_NAME, { path: "/" });
    return { ok: true };
  }

  @Get("me")
  async me(@CurrentViewer() v: Viewer | null) {
    return v ? this.meFor(v.userId) : { user: null };
  }

  @Patch("me")
  @Auth()
  async updateMe(@CurrentViewer() v: Viewer, @Body() body: unknown) {
    const input = parse(UpdateMe, body);
    await this.prisma.user.update({ where: { id: v.userId }, data: input });
    return this.meFor(v.userId);
  }

  /** Request a confirmation code for a sensitive action (payout change, accept offer, approve price, close account). */
  @Post("confirm/request")
  @HttpCode(200)
  @Auth()
  @Throttle({ default: { limit: 5, ttl: 60_000 } })
  async requestConfirm(@CurrentViewer() v: Viewer, @Req() req: Request) {
    return this.otp.request(v.phone!, "CONFIRM_ACTION", req.ip ?? null);
  }

  /** Account deletion request (processed by support within the legal retention rules; orders/ledger are retained). */
  @Post("me/delete-request")
  @HttpCode(200)
  @Auth()
  async deleteRequest(@CurrentViewer() v: Viewer, @Body() body: unknown) {
    const { code } = parse(z.object({ code: z.string().length(6) }), body);
    await this.otp.confirmOwnAction(v.phone, code);
    await this.prisma.user.update({ where: { id: v.userId }, data: { deletionRequestedAt: new Date() } });
    await this.audit.log({ actorId: v.userId, action: "ACCOUNT_DELETION_REQUESTED", entity: "User", entityId: v.userId });
    return { ok: true };
  }

  async meFor(userId: string) {
    const u = await this.prisma.user.findUniqueOrThrow({
      where: { id: userId },
      include: {
        sellerProfile: { select: { id: true, slug: true, displayName: true, status: true, payoutVerifiedAt: true } },
        resellerVerification: { select: { status: true, businessName: true } },
        applications: { select: { reference: true, kind: true, status: true }, orderBy: { createdAt: "desc" } },
        consents: { select: { type: true, granted: true, version: true, createdAt: true }, orderBy: { createdAt: "desc" } },
      },
    });
    return {
      user: {
        id: u.id, name: u.name, phone: u.phone, email: u.email, roles: u.roles, activated: !!u.activatedAt,
        deletionRequestedAt: u.deletionRequestedAt,
        seller: u.sellerProfile, reseller: u.resellerVerification, applications: u.applications,
        consents: u.consents,
      },
    };
  }
}
