import { Injectable } from "@nestjs/common";
import { normalizePkPhone } from "@ooak/shared";
import { createHash, randomInt, timingSafeEqual } from "node:crypto";
import { config, isProd } from "../../config";
import { NotifierService } from "../../common/notifier.service";
import { PrismaService } from "../../common/prisma.service";
import { badRequest, tooMany } from "../../common/problem";

export type OtpPurpose = "LOGIN" | "CONFIRM_ACTION";
const OTP_TTL_MS = 5 * 60_000;
const MAX_ATTEMPTS = 5;
const MAX_PER_PHONE_15M = 5;
const MAX_PER_IP_HOUR = 30;

const hashCode = (phone: string, purpose: string, code: string) => createHash("sha256").update(`${phone}|${purpose}|${code}`).digest("hex");

@Injectable()
export class OtpService {
  constructor(private readonly prisma: PrismaService, private readonly notifier: NotifierService) {}

  normalise(raw: string): string {
    const phone = normalizePkPhone(raw);
    if (!phone) throw badRequest("Please enter a Pakistani mobile number, e.g. 0300 1234567.", "INVALID_PHONE");
    return phone;
  }

  async request(phone: string, purpose: OtpPurpose, ip: string | null): Promise<{ expiresInSec: number; devCode?: string }> {
    const now = Date.now();
    const recentPhone = await this.prisma.otpChallenge.count({ where: { phone, createdAt: { gte: new Date(now - 15 * 60_000) } } });
    if (recentPhone >= MAX_PER_PHONE_15M) throw tooMany("Too many codes requested for this number. Please wait 15 minutes.");
    if (ip) {
      const recentIp = await this.prisma.otpChallenge.count({ where: { ip, createdAt: { gte: new Date(now - 3_600_000) } } });
      if (recentIp >= MAX_PER_IP_HOUR) throw tooMany("Too many codes requested. Please try again later.");
    }
    const code = String(randomInt(0, 1_000_000)).padStart(6, "0");
    await this.prisma.otpChallenge.create({ data: { phone, purpose, codeHash: hashCode(phone, purpose, code), expiresAt: new Date(now + OTP_TTL_MS), ip } });
    await this.notifier.sendSms(phone, `OTP_${purpose}`, `${code} is your ONEOFAKIND code. It expires in 5 minutes. Never share it. Our team will never ask for it.`);
    const echo = config().OTP_DEV_ECHO && !isProd();
    return { expiresInSec: OTP_TTL_MS / 1000, ...(echo ? { devCode: code } : {}) };
  }

  /** Checks the code. Increments attempts on failure. Consumes on success only when consume=true. */
  async check(phone: string, purpose: OtpPurpose, code: string, consume: boolean): Promise<void> {
    const ch = await this.prisma.otpChallenge.findFirst({
      where: { phone, purpose, consumedAt: null, expiresAt: { gt: new Date() } }, orderBy: { createdAt: "desc" },
    });
    if (!ch) throw badRequest("This code has expired. Please request a new one.", "OTP_EXPIRED");
    if (ch.attempts >= MAX_ATTEMPTS) throw tooMany("Too many wrong attempts. Please request a new code.");
    const ok = /^\d{6}$/.test(code) && timingSafeEqual(Buffer.from(ch.codeHash), Buffer.from(hashCode(phone, purpose, code)));
    if (!ok) {
      await this.prisma.otpChallenge.update({ where: { id: ch.id }, data: { attempts: { increment: 1 } } });
      throw badRequest(`That code is not right. ${Math.max(0, MAX_ATTEMPTS - ch.attempts - 1)} attempts left.`, "OTP_INVALID");
    }
    if (consume) {
      // Conditional update: a code can be consumed exactly once even under concurrent requests
      const r = await this.prisma.otpChallenge.updateMany({ where: { id: ch.id, consumedAt: null }, data: { consumedAt: new Date() } });
      if (r.count !== 1) throw badRequest("This code was already used. Please request a new one.", "OTP_USED");
    }
  }

  /** The seller's/user's own confirmation for money, ownership and security actions (never available to staff on their behalf). */
  async confirmOwnAction(userPhone: string | null, code: string | undefined) {
    if (!userPhone) throw badRequest("Your account has no phone number.", "NO_PHONE");
    if (!code) throw badRequest("Please confirm with the code we sent to your phone.", "CONFIRMATION_REQUIRED");
    await this.check(userPhone, "CONFIRM_ACTION", code, true);
  }
}
