import { Injectable, Logger } from "@nestjs/common";
import type { AiJob, AiJobKind, Prisma } from "@prisma/client";
import { GRADE_LETTER, type ConditionGrade } from "@ooak/shared";
import { randomUUID } from "node:crypto";
import { AuditService } from "../../common/audit.service";
import { PrismaService } from "../../common/prisma.service";
import { badRequest, conflict, notFound, tooMany } from "../../common/problem";
import { StorageService } from "../../common/storage.service";
import { config } from "../../config";
import { AiUserError, imageAdapter, textAdapter, type TextFacts } from "./adapters";

export const MAX_ATTEMPTS = 3;
const GRADE_WORDS: Record<string, string> = { NEW_WITH_TAGS: "new with tags", EXCELLENT: "excellent", VERY_GOOD: "very good", GOOD: "good", FAIR: "fair" };

/**
 * AI jobs: queued in the DB, claimed with FOR UPDATE SKIP LOCKED (safe across instances), run with a timeout, retried
 * up to 3 times on provider/transient errors (never on user errors), with latency and cost recorded per job.
 * Outputs are NEW MediaAssets (aiLabel=true, sourceAssetId → original, useInListing=false) - originals are never touched.
 */
@Injectable()
export class AiService {
  private readonly log = new Logger("AI");
  constructor(private readonly prisma: PrismaService, private readonly storage: StorageService, private readonly audit: AuditService) {}

  private async checkQuota(userId: string, isStaff: boolean) {
    if (isStaff) return;
    const since = new Date(Date.now() - 86_400_000);
    const n = await this.prisma.aiJob.count({ where: { userId, createdAt: { gte: since } } });
    if (n >= config().AI_DAILY_QUOTA) throw tooMany(`Daily AI limit reached (${config().AI_DAILY_QUOTA} a day). Try again tomorrow.`, "AI_QUOTA");
  }

  private async ownedItem(itemId: string, sellerId: string) {
    const item = await this.prisma.item.findUnique({ where: { id: itemId } });
    if (!item || item.sellerId !== sellerId) throw notFound("Item");
    if (item.arrangement !== "SELF_MANAGED") throw conflict("Photos and text of managed pieces are handled by our studio.", "MANAGED_FIELDS");
    return item;
  }

  async enqueue(kind: AiJobKind, userId: string, input: Prisma.InputJsonValue, isStaff = false) {
    await this.checkQuota(userId, isStaff);
    const provider = kind === "LISTING_TEXT" ? textAdapter().name : imageAdapter().name;
    const job = await this.prisma.aiJob.create({ data: { kind, userId, provider, input } });
    if (config().JOBS_ENABLED) setImmediate(() => { void this.processDue(1); });
    return job;
  }

  async requestBackgroundRemoval(userId: string, sellerId: string, itemId: string, assetId: string) {
    await this.ownedItem(itemId, sellerId);
    const src = await this.prisma.mediaAsset.findUnique({ where: { id: assetId } });
    if (!src || src.itemId !== itemId || src.deletedAt) throw notFound("Photo");
    if (src.kind !== "ORIGINAL") throw badRequest("Pick one of your original photos.", "NOT_ORIGINAL");
    const open = await this.prisma.aiJob.count({ where: { userId, kind: "BACKGROUND_REMOVAL", state: { in: ["QUEUED", "RUNNING"] }, input: { path: ["assetId"], equals: assetId } } });
    if (open) throw conflict("That photo is already being processed.", "AI_JOB_PENDING");
    return this.enqueue("BACKGROUND_REMOVAL", userId, { itemId, assetId });
  }

  async requestListingText(userId: string, sellerId: string, itemId: string) {
    await this.ownedItem(itemId, sellerId);
    return this.enqueue("LISTING_TEXT", userId, { itemId });
  }

  /** Claims up to `limit` queued jobs and runs them. Also recovers jobs whose worker died (RUNNING past timeoutAt). */
  async processDue(limit = 5): Promise<number> {
    await this.prisma.$executeRawUnsafe(
      `UPDATE "AiJob" SET state = CASE WHEN attempts >= ${MAX_ATTEMPTS} THEN 'TIMED_OUT'::"AiJobState" ELSE 'QUEUED'::"AiJobState" END,
         error = 'Worker timed out', "finishedAt" = CASE WHEN attempts >= ${MAX_ATTEMPTS} THEN now() ELSE NULL END
       WHERE state = 'RUNNING' AND "timeoutAt" < now()`,
    );
    const claimed = await this.prisma.$queryRawUnsafe<{ id: string }[]>(
      `UPDATE "AiJob" SET state = 'RUNNING', attempts = attempts + 1, "timeoutAt" = now() + interval '${Math.ceil(config().AI_JOB_TIMEOUT_MS / 1000) + 30} seconds'
       WHERE id IN (SELECT id FROM "AiJob" WHERE state = 'QUEUED' ORDER BY "createdAt" LIMIT ${Math.max(1, Math.floor(limit))} FOR UPDATE SKIP LOCKED)
       RETURNING id`,
    );
    for (const { id } of claimed) await this.run(id);
    return claimed.length;
  }

  private async run(id: string) {
    const job = await this.prisma.aiJob.findUniqueOrThrow({ where: { id } });
    const started = Date.now();
    let timer: NodeJS.Timeout | undefined;
    try {
      const timeout = new Promise<never>((_, rej) => { timer = setTimeout(() => rej(new TimeoutError()), config().AI_JOB_TIMEOUT_MS); });
      const { output, costMicros } = await Promise.race([this.execute(job), timeout]);
      await this.prisma.aiJob.update({ where: { id }, data: { state: "SUCCEEDED", output: output as Prisma.InputJsonValue, costMicros, latencyMs: Date.now() - started, finishedAt: new Date(), error: null } });
    } catch (e) {
      const user = e instanceof AiUserError;
      const timedOut = e instanceof TimeoutError;
      const final = user || job.attempts >= MAX_ATTEMPTS;
      const msg = user ? (e as Error).message : timedOut ? "The AI provider took too long." : "The AI provider failed.";
      if (!user) this.log.warn(`job ${id} attempt ${job.attempts} failed: ${(e as Error).message}`);
      await this.prisma.aiJob.update({ where: { id }, data: { state: final ? (timedOut ? "TIMED_OUT" : "FAILED") : "QUEUED", error: msg, latencyMs: Date.now() - started, finishedAt: final ? new Date() : null } });
    } finally { clearTimeout(timer); }
  }

  private async execute(job: AiJob): Promise<{ output: Record<string, unknown>; costMicros: number }> {
    const input = job.input as { itemId: string; assetId?: string };
    if (job.kind === "BACKGROUND_REMOVAL") {
      const src = await this.prisma.mediaAsset.findUniqueOrThrow({ where: { id: input.assetId! } });
      const body = await this.storage.get(src.storageKey);
      if (!body) throw new AiUserError("The original photo is missing.");
      const r = await imageAdapter().removeBackground(body);
      const key = `public/items/${input.itemId}/ai-${randomUUID()}.webp`;
      await this.storage.put(key, r.image, r.mime);
      const meta = await import("sharp").then((s) => s.default(r.image).metadata());
      const asset = await this.prisma.mediaAsset.create({
        data: { itemId: input.itemId, ownerUserId: job.userId, kind: "BACKGROUND_REMOVED", visibility: "PRIVATE", storageKey: key, mime: r.mime, bytes: r.image.length, width: meta.width, height: meta.height,
          sourceAssetId: src.id, aiJobId: job.id, aiLabel: true, useInListing: false, approvedForPublish: false, position: src.position },
      });
      return { output: { assetId: asset.id, ...r.meta }, costMicros: r.costMicros };
    }
    if (job.kind === "LISTING_TEXT") {
      const item = await this.prisma.item.findUniqueOrThrow({ where: { id: input.itemId }, include: { brand: true, category: true, style: true, conditionReports: { orderBy: { createdAt: "desc" }, take: 1 } } });
      const schema = (item.category.attributeSchema ?? {}) as { measurements?: string[] };
      const facts: TextFacts = {
        brand: item.brand?.name ?? null, category: item.category.name, style: item.style?.name ?? null, size: item.size, color: item.color, material: item.material,
        measurements: (item.measurements ?? {}) as Record<string, number>, requiredMeasurements: schema.measurements ?? [],
        grade: item.conditionGrade ? `${GRADE_WORDS[item.conditionGrade]} (grade ${GRADE_LETTER[item.conditionGrade as ConditionGrade]})` : null,
        defects: (item.conditionReports[0]?.defects ?? []) as TextFacts["defects"],
      };
      const r = await textAdapter().listingText(facts);
      return { output: { title: r.title, description: r.description, missing: r.missing }, costMicros: r.costMicros };
    }
    throw new AiUserError(`${job.kind} isn't available yet.`);
  }

  /** Seller chooses to use (or stop using) an AI image in the listing. It goes public only after moderation approval, with the AI label. */
  async setUse(userId: string, sellerId: string, assetId: string, use: boolean) {
    const a = await this.prisma.mediaAsset.findUnique({ where: { id: assetId }, include: { item: true } });
    if (!a || a.deletedAt || !a.aiLabel || a.item?.sellerId !== sellerId) throw notFound("Image");
    await this.prisma.mediaAsset.update({ where: { id: assetId }, data: use ? { useInListing: true } : { useInListing: false, approvedForPublish: false, visibility: "PRIVATE" } });
    await this.audit.log({ actorId: userId, action: use ? "AI_IMAGE_SELECTED" : "AI_IMAGE_UNSELECTED", entity: "MediaAsset", entityId: assetId });
  }

  async discard(sellerId: string, assetId: string) {
    const a = await this.prisma.mediaAsset.findUnique({ where: { id: assetId }, include: { item: true } });
    if (!a || a.deletedAt || !a.aiLabel || a.item?.sellerId !== sellerId) throw notFound("Image");
    await this.prisma.mediaAsset.update({ where: { id: assetId }, data: { deletedAt: new Date(), approvedForPublish: false } });
  }

  async retry(jobId: string, actorId: string) {
    const n = await this.prisma.aiJob.updateMany({ where: { id: jobId, state: { in: ["FAILED", "TIMED_OUT"] } }, data: { state: "QUEUED", attempts: 0, error: null, finishedAt: null } });
    if (!n.count) throw conflict("Only failed jobs can be retried.", "INVALID_STATE");
    await this.audit.log({ actorId, action: "AI_JOB_RETRIED", entity: "AiJob", entityId: jobId });
    if (config().JOBS_ENABLED) setImmediate(() => { void this.processDue(1); });
  }
}

class TimeoutError extends Error {}
