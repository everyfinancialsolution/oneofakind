import sharp from "sharp";
import { config } from "../../config";

/** An error the seller can act on (bad input). Never retried. */
export class AiUserError extends Error {}

export interface ImageResult { image: Buffer; mime: string; costMicros: number; provider: string; meta?: Record<string, unknown> }
export interface TextFacts {
  brand: string | null; category: string; style: string | null; size: string | null; color: string | null; material: string | null;
  measurements: Record<string, number>; requiredMeasurements: string[]; grade: string | null; defects: Array<{ type?: string; location?: string; severity?: string }>;
}
export interface TextResult { title: string; description: string; missing: string[]; costMicros: number; provider: string }

/** Server-side adapter interfaces. Real providers plug in here; credentials never reach the browser. */
export interface ImageAdapter { readonly name: string; removeBackground(input: Buffer): Promise<ImageResult> }
export interface TextAdapter { readonly name: string; listingText(facts: TextFacts): Promise<TextResult> }

/** "Dresses" → "Dress", "Fleece jackets" → "Fleece jacket", "Jeans" stays. */
export function singular(s: string) {
  if (/(jeans|trousers|shorts|chinos|leggings|joggers)$/i.test(s)) return s;
  if (/(ss|sh|ch|x)es$/i.test(s)) return s.slice(0, -2);
  if (/[^s]s$/i.test(s)) return s.slice(0, -1);
  return s;
}

const BACKDROP = { r: 246, g: 243, b: 238 }; // ivory studio backdrop (design token)

/**
 * Local background removal (no external provider, zero cost). Estimates the backdrop colour from the image border and
 * flood-fills similar pixels inward from the edges; the garment is composited onto a clean ivory backdrop.
 * Works for the photos we ask sellers to take (plain background, daylight). It refuses - rather than guesses - when it
 * can't separate the garment. The original photo is never modified.
 */
export class LocalImageAdapter implements ImageAdapter {
  readonly name = "local-heuristic";
  async removeBackground(input: Buffer): Promise<ImageResult> {
    const img = sharp(input, { failOn: "error" }).rotate().resize({ width: 1600, height: 1600, fit: "inside", withoutEnlargement: true });
    const { data, info } = await img.ensureAlpha().raw().toBuffer({ resolveWithObject: true });
    const { width: w, height: h } = info;
    const px = (i: number) => [data[i * 4]!, data[i * 4 + 1]!, data[i * 4 + 2]!] as const;
    // Backdrop estimate: median of border pixels per channel.
    const border: number[][] = [[], [], []];
    for (let x = 0; x < w; x += 2) for (const y of [0, h - 1]) { const p = px(y * w + x); p.forEach((v, c) => border[c]!.push(v)); }
    for (let y = 0; y < h; y += 2) for (const x of [0, w - 1]) { const p = px(y * w + x); p.forEach((v, c) => border[c]!.push(v)); }
    const med = border.map((a) => a.sort((x, y) => x - y)[a.length >> 1]!);
    // Border must be fairly uniform, otherwise the background isn't plain.
    const spread = border.map((a) => a[Math.floor(a.length * 0.9)]! - a[Math.floor(a.length * 0.1)]!);
    if (Math.max(...spread) > 70) throw new AiUserError("The background isn't plain enough to remove cleanly. Retake the photo on a plain wall or sheet.");
    const T = 42 * 42;
    const near = (i: number) => { const [r, g, b] = px(i); return (r - med[0]!) ** 2 + (g - med[1]!) ** 2 + (b - med[2]!) ** 2 < T; };
    const bg = new Uint8Array(w * h);
    const queue = new Int32Array(w * h);
    let head = 0, tail = 0;
    const seed = (i: number) => { if (!bg[i] && near(i)) { bg[i] = 1; queue[tail++] = i; } };
    for (let x = 0; x < w; x++) { seed(x); seed((h - 1) * w + x); }
    for (let y = 0; y < h; y++) { seed(y * w); seed(y * w + w - 1); }
    while (head < tail) {
      const i = queue[head++]!; const x = i % w;
      if (x > 0) seed(i - 1); if (x < w - 1) seed(i + 1); if (i >= w) seed(i - w); if (i < w * (h - 1)) seed(i + w);
    }
    const fg = 1 - tail / (w * h);
    if (fg < 0.04 || fg > 0.97) throw new AiUserError("We couldn't find the garment against the background. Make sure the whole piece is in frame on a plain background.");
    const alpha = Buffer.alloc(w * h);
    for (let i = 0; i < w * h; i++) alpha[i] = bg[i] ? 0 : 255;
    const mask = await sharp(alpha, { raw: { width: w, height: h, channels: 1 } }).blur(1.2).extractChannel(0).raw().toBuffer();
    if (mask.length !== w * h) throw new Error("mask size mismatch");
    const rgba = Buffer.from(data);
    for (let i = 0; i < w * h; i++) rgba[i * 4 + 3] = mask[i]!;
    const cutout = await sharp(rgba, { raw: { width: w, height: h, channels: 4 } }).png().toBuffer();
    const out = await sharp({ create: { width: w, height: h, channels: 3, background: BACKDROP } }).composite([{ input: cutout }]).webp({ quality: 85 }).toBuffer();
    return { image: out, mime: "image/webp", costMicros: 0, provider: this.name, meta: { foregroundShare: Math.round(fg * 100) / 100, backdrop: med } };
  }
}

/**
 * Template text adapter: writes a title and description ONLY from facts already on the listing. It never invents
 * measurements, material, authenticity, colour or condition; anything missing is reported back as `missing`.
 */
export class TemplateTextAdapter implements TextAdapter {
  readonly name = "template";
  async listingText(f: TextFacts): Promise<TextResult> {
    const missing: string[] = [];
    const kind = f.category.replace(/s?\s*&.*$/, "").replace(/s$/, "").trim();
    const noun = f.style ? singular(f.style) : kind; // "Fleece jackets" → "Fleece jacket"
    const title = [f.brand, f.color, noun].filter(Boolean).join(" ").replace(/\s+/g, " ").trim() + (f.size ? `, size ${f.size}` : "");
    const lines: string[] = [];
    lines.push([f.brand, f.color?.toLowerCase(), noun.toLowerCase()].filter(Boolean).join(" ").replace(/^./, (c) => c.toUpperCase()) + ".");
    const m = Object.entries(f.measurements).filter(([, v]) => typeof v === "number");
    if (m.length) lines.push(`Measured flat: ${m.map(([k, v]) => `${k.replace(/_cm$/, "").replace(/_/g, " ")} ${v}${k.endsWith("_cm") ? " cm" : ""}`).join(", ")}.`);
    for (const r of f.requiredMeasurements) if (f.measurements[r] === undefined) missing.push(`measurement: ${r.replace(/_cm$/, "").replace(/_/g, " ")}`);
    if (f.size) lines.push(`Tagged size ${f.size}. Please go by the measurements.`); else missing.push("size");
    if (f.material) lines.push(`Material: ${f.material}.`); else missing.push("material (check the care label)");
    if (!f.color) missing.push("colour");
    if (f.grade) lines.push(`Condition: ${f.grade}.`); else missing.push("condition grade");
    if (f.defects.length) lines.push(`Flaws disclosed: ${f.defects.map((d) => [d.type, d.location && `(${d.location})`].filter(Boolean).join(" ")).join("; ")}. See photos.`);
    else if (f.grade) lines.push("No flaws disclosed.");
    return { title: title.slice(0, 120), description: lines.join(" "), missing, costMicros: 0, provider: this.name };
  }
}

export function imageAdapter(): ImageAdapter {
  const p = config().AI_IMAGE_PROVIDER || "fake";
  if (p === "fake" || p === "local") return new LocalImageAdapter();
  throw new Error(`AI image provider "${p}" has no adapter yet. Implement ImageAdapter in src/modules/ai/adapters.ts.`);
}
export function textAdapter(): TextAdapter {
  const p = config().AI_TEXT_PROVIDER || "fake";
  if (p === "fake" || p === "template") return new TemplateTextAdapter();
  throw new Error(`AI text provider "${p}" has no adapter yet. Implement TextAdapter in src/modules/ai/adapters.ts.`);
}
