import { Body, Controller, Delete, Get, HttpCode, Param, Post, Query, UploadedFile, UseInterceptors } from "@nestjs/common";
import { randomUUID } from "node:crypto";
import { z } from "zod";
import { AuditService } from "../../common/audit.service";
import { Auth, CurrentViewer, requireSeller, type Viewer } from "../../common/auth";
import { PrismaService } from "../../common/prisma.service";
import { badRequest, conflict, notFound, parse } from "../../common/problem";
import { StorageService } from "../../common/storage.service";
import { SingleUpload, type UploadedFileT } from "../../common/upload";
import { config } from "../../config";
import { mediaUrl } from "../catalog/presenters";
import { AiService } from "./ai.service";

/** A binary glTF 2.0 file: magic "glTF", version 2, declared length equals the file length. */
export function isGlb(buf: Buffer) {
  return buf.length >= 20 && buf.toString("ascii", 0, 4) === "glTF" && buf.readUInt32LE(4) === 2 && buf.readUInt32LE(8) === buf.length;
}

const jobView = (j: { id: string; kind: string; state: string; error: string | null; output: unknown; input: unknown; createdAt: Date; finishedAt: Date | null; latencyMs: number | null }) => ({
  id: j.id, kind: j.kind, state: j.state, error: j.error, createdAt: j.createdAt, finishedAt: j.finishedAt, latencyMs: j.latencyMs,
  input: j.input, output: j.output,
});

/** Seller photo studio: background removal + listing text suggestions (self-managed pieces), and optional 3D models. */
@Controller("seller/studio")
@Auth("SELLER")
export class StudioController {
  constructor(private readonly prisma: PrismaService, private readonly ai: AiService, private readonly storage: StorageService, private readonly audit: AuditService) {}

  @Get("items")
  async items(@CurrentViewer() v: Viewer, @Query() q: unknown) {
    const { itemId } = parse(z.object({ itemId: z.string().optional() }), q);
    const items = await this.prisma.item.findMany({
      where: { sellerId: requireSeller(v), arrangement: "SELF_MANAGED", stockState: { in: ["EXPECTED", "READY_TO_LIST", "AVAILABLE", "RESERVED"] }, ...(itemId ? { id: itemId } : {}) },
      orderBy: { updatedAt: "desc" }, take: 60,
      include: { media: { where: { deletedAt: null }, orderBy: [{ position: "asc" }, { createdAt: "asc" }] }, listings: { take: 1, orderBy: { createdAt: "desc" } } },
    });
    return {
      items: items.map((i) => ({
        id: i.id, sku: i.sku, title: i.title, description: i.description, listingState: i.listings[0]?.state ?? null,
        photos: i.media.filter((m) => m.kind !== "ASSET_3D").map((m) => ({ id: m.id, url: mediaUrl(m.id), kind: m.kind, aiLabel: m.aiLabel, sourceAssetId: m.sourceAssetId, useInListing: m.useInListing, live: m.approvedForPublish })),
        model3d: i.media.find((m) => m.kind === "ASSET_3D") ? { id: i.media.find((m) => m.kind === "ASSET_3D")!.id, url: mediaUrl(i.media.find((m) => m.kind === "ASSET_3D")!.id), live: i.media.find((m) => m.kind === "ASSET_3D")!.approvedForPublish } : null,
      })),
    };
  }

  @Get("jobs")
  async jobs(@CurrentViewer() v: Viewer, @Query() q: unknown) {
    const { itemId } = parse(z.object({ itemId: z.string().optional() }), q);
    const rows = await this.prisma.aiJob.findMany({ where: { userId: v.userId, ...(itemId ? { input: { path: ["itemId"], equals: itemId } } : {}) }, orderBy: { createdAt: "desc" }, take: 50 });
    const since = new Date(Date.now() - 86_400_000);
    const used = await this.prisma.aiJob.count({ where: { userId: v.userId, createdAt: { gte: since } } });
    return { jobs: rows.map(jobView), quota: { used, limit: config().AI_DAILY_QUOTA } };
  }

  @Post("items/:itemId/background")
  async background(@CurrentViewer() v: Viewer, @Param("itemId") itemId: string, @Body() body: unknown) {
    const { assetId } = parse(z.object({ assetId: z.string() }), body);
    return jobView(await this.ai.requestBackgroundRemoval(v.userId, requireSeller(v), itemId, assetId));
  }

  @Post("items/:itemId/text")
  async text(@CurrentViewer() v: Viewer, @Param("itemId") itemId: string) {
    return jobView(await this.ai.requestListingText(v.userId, requireSeller(v), itemId));
  }

  @Post("assets/:id/use") @HttpCode(200)
  async use(@CurrentViewer() v: Viewer, @Param("id") id: string, @Body() body: unknown) {
    await this.ai.setUse(v.userId, requireSeller(v), id, parse(z.object({ use: z.boolean() }), body).use);
    return { ok: true };
  }

  @Delete("assets/:id")
  async discard(@CurrentViewer() v: Viewer, @Param("id") id: string) { await this.ai.discard(requireSeller(v), id); return { ok: true }; }

  /** Optional 3D model (.glb). Private until the listing's next moderation approval. Replaces any previous model (soft delete). */
  @Post("items/:itemId/model3d")
  @UseInterceptors(SingleUpload())
  async model3d(@CurrentViewer() v: Viewer, @Param("itemId") itemId: string, @UploadedFile() file: UploadedFileT) {
    const sellerId = requireSeller(v);
    const item = await this.prisma.item.findUnique({ where: { id: itemId } });
    if (!item || item.sellerId !== sellerId) throw notFound("Item");
    if (!file?.buffer?.length) throw badRequest("Please choose a .glb file.", "FILE_REQUIRED");
    if (!isGlb(file.buffer)) throw badRequest("That isn't a valid .glb (binary glTF 2.0) file.", "UNSUPPORTED_FILE");
    const key = `public/items/${itemId}/model-${randomUUID()}.glb`;
    await this.storage.put(key, file.buffer, "model/gltf-binary");
    const asset = await this.prisma.$transaction(async (tx) => {
      await tx.mediaAsset.updateMany({ where: { itemId, kind: "ASSET_3D", deletedAt: null }, data: { deletedAt: new Date(), approvedForPublish: false } });
      return tx.mediaAsset.create({ data: { itemId, ownerUserId: v.userId, kind: "ASSET_3D", visibility: "PRIVATE", storageKey: key, mime: "model/gltf-binary", bytes: file.buffer.length, approvedForPublish: false } });
    });
    await this.audit.log({ actorId: v.userId, action: "MODEL3D_UPLOADED", entity: "Item", entityId: itemId, after: { bytes: file.buffer.length } });
    return { id: asset.id, url: mediaUrl(asset.id), live: false };
  }

  @Delete("items/:itemId/model3d")
  async removeModel(@CurrentViewer() v: Viewer, @Param("itemId") itemId: string) {
    const item = await this.prisma.item.findUnique({ where: { id: itemId } });
    if (!item || item.sellerId !== requireSeller(v)) throw notFound("Item");
    const n = await this.prisma.mediaAsset.updateMany({ where: { itemId, kind: "ASSET_3D", deletedAt: null }, data: { deletedAt: new Date(), approvedForPublish: false } });
    if (!n.count) throw conflict("No 3D model on this piece.", "NOT_FOUND");
    return { ok: true };
  }
}

/** Admin: usage, failures and cost of AI jobs. */
@Controller("admin/ai")
@Auth("ADMIN")
export class AdminAiController {
  constructor(private readonly prisma: PrismaService, private readonly ai: AiService) {}

  @Get()
  async overview(@Query() q: unknown) {
    const { days } = parse(z.object({ days: z.coerce.number().int().min(1).max(90).default(30) }), q);
    const since = new Date(Date.now() - days * 86_400_000);
    const [byKind, failures, users] = await Promise.all([
      this.prisma.aiJob.groupBy({ by: ["kind", "state", "provider"], where: { createdAt: { gte: since } }, _count: true, _sum: { costMicros: true }, _avg: { latencyMs: true } }),
      this.prisma.aiJob.findMany({ where: { state: { in: ["FAILED", "TIMED_OUT"] }, createdAt: { gte: since } }, orderBy: { createdAt: "desc" }, take: 50, include: { user: { select: { name: true } } } }),
      this.prisma.aiJob.groupBy({ by: ["userId"], where: { createdAt: { gte: since } }, _count: true, orderBy: { _count: { userId: "desc" } }, take: 10 }),
    ]);
    const names = await this.prisma.user.findMany({ where: { id: { in: users.map((u) => u.userId) } }, select: { id: true, name: true } });
    return {
      days, quotaPerDay: config().AI_DAILY_QUOTA, providers: { image: config().AI_IMAGE_PROVIDER || "fake", text: config().AI_TEXT_PROVIDER || "fake" },
      breakdown: byKind.map((r) => ({ kind: r.kind, state: r.state, provider: r.provider, count: r._count, costMicros: r._sum.costMicros ?? 0, avgLatencyMs: Math.round(r._avg.latencyMs ?? 0) })),
      failures: failures.map((f) => ({ id: f.id, kind: f.kind, state: f.state, error: f.error, attempts: f.attempts, user: f.user.name, createdAt: f.createdAt })),
      topUsers: users.map((u) => ({ name: names.find((n) => n.id === u.userId)?.name ?? u.userId, count: u._count })),
    };
  }

  @Post("jobs/:id/retry") @HttpCode(200)
  async retry(@CurrentViewer() v: Viewer, @Param("id") id: string) { await this.ai.retry(id, v.userId); return { ok: true }; }
}
