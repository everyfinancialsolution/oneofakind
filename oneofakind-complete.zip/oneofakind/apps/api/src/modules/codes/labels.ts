import bwipjs from "bwip-js";
import { PDFDocument, StandardFonts, rgb, type PDFFont, type PDFPage } from "pdf-lib";
import { A4_ITEM_SHEET, FORBIDDEN_LABEL_FIELDS, LABEL_SPECS, qrPayload, type LabelKind } from "@ooak/shared";

/**
 * Label PDFs at EXACT physical size (thermal printers: set the driver paper size once). No prices or personal contact
 * data on any label; the codes are opaque and resolved server-side.
 */
const mm = (v: number) => (v * 72) / 25.4;

export interface ItemLabelData { code: string; sku: string; brand: string | null; size: string | null; title: string }
export interface LotLabelData { code: string; lotSku: string; brand: string; style: string; pieceCount: number }
export interface PackLabelData { code: string; orderRef: string; expectedPieces: string[]; shipToName: string; shipToCity: string }
export interface DispatchLabelData { code: string; orderRef: string; courier: string; trackingNo: string | null; shipToName: string; shipToCity: string; pieceCount: number; parcelIndexOfCount: string }

/** Throws if label data contains any forbidden field (price, phone, address, ID numbers, email). */
export function assertLabelSafe(data: object, kind: LabelKind) {
  const keys = Object.keys(data);
  const bad = keys.filter((k) => (FORBIDDEN_LABEL_FIELDS as readonly string[]).includes(k));
  if (bad.length) throw new Error(`label data contains forbidden fields: ${bad.join(", ")}`);
  const allowed = new Set([...LABEL_SPECS[kind].fields, "code"]);
  const extra = keys.filter((k) => !allowed.has(k));
  if (extra.length) throw new Error(`label data has fields not in LABEL_SPECS.${kind}: ${extra.join(", ")}`);
}

type Png = (opts: Record<string, unknown>) => Promise<Buffer>;
const toPng = bwipjs.toBuffer as unknown as Png;
async function barcodePng(code: string) {
  return toPng({ bcid: "code128", text: code, scale: 3, height: 9, includetext: true, textxalign: "center", textsize: 9 });
}
async function qrPng(code: string) {
  return toPng({ bcid: "qrcode", text: qrPayload(code), scale: 4, eclevel: "M" });
}
const fit = (font: PDFFont, text: string, size: number, maxW: number) => {
  let t = text;
  while (t.length > 1 && font.widthOfTextAtSize(t, size) > maxW) t = t.slice(0, -2) + "…";
  return t;
};

async function drawItemLabel(doc: PDFDocument, page: PDFPage, font: PDFFont, bold: PDFFont, d: ItemLabelData, x: number, y: number, w: number, h: number) {
  const pad = mm(1.5);
  const qr = await doc.embedPng(await qrPng(d.code));
  const bc = await doc.embedPng(await barcodePng(d.code));
  const qrSize = h - pad * 2 - mm(9);
  page.drawImage(qr, { x: x + pad, y: y + h - pad - qrSize, width: qrSize, height: qrSize });
  const tx = x + pad * 2 + qrSize;
  const tw = w - (tx - x) - pad;
  page.drawText(fit(bold, d.sku, 7, tw), { x: tx, y: y + h - pad - mm(3), size: 7, font: bold });
  page.drawText(fit(font, [d.brand, d.size].filter(Boolean).join(" · "), 6, tw), { x: tx, y: y + h - pad - mm(6), size: 6, font });
  page.drawText(fit(font, d.title, 5.5, tw), { x: tx, y: y + h - pad - mm(9), size: 5.5, font, color: rgb(0.25, 0.25, 0.25) });
  const bcH = mm(8.5);
  page.drawImage(bc, { x: x + pad, y: y + pad, width: w - pad * 2, height: bcH });
}

export async function itemLabelsPdf(items: ItemLabelData[], format: "thermal" | "a4"): Promise<Uint8Array> {
  items.forEach((d) => assertLabelSafe(d, "ITEM"));
  const doc = await PDFDocument.create();
  doc.setTitle("ONEOFAKIND item labels");
  const font = await doc.embedFont(StandardFonts.Helvetica);
  const bold = await doc.embedFont(StandardFonts.HelveticaBold);
  const spec = LABEL_SPECS.ITEM;
  if (format === "thermal") {
    for (const d of items) {
      const page = doc.addPage([mm(spec.widthMm), mm(spec.heightMm)]);
      await drawItemLabel(doc, page, font, bold, d, 0, 0, mm(spec.widthMm), mm(spec.heightMm));
    }
  } else {
    // A4 sheet fallback for sellers without a thermal printer: 3 × 8 grid of 63.5 × 33.9 mm (standard 24-up sheets)
    const { columns, rows } = A4_ITEM_SHEET;
    const lw = mm(63.5), lh = mm(33.9), mx = mm(7.2), my = mm(12.9);
    for (let i = 0; i < items.length; i += columns * rows) {
      const page = doc.addPage([mm(210), mm(297)]);
      for (let j = 0; j < columns * rows && i + j < items.length; j++) {
        const c = j % columns, r = Math.floor(j / columns);
        await drawItemLabel(doc, page, font, bold, items[i + j]!, mx + c * lw, mm(297) - my - (r + 1) * lh, lw, lh);
      }
    }
  }
  return doc.save();
}

async function bigLabel(kind: "LOT" | "ORDER_PACK" | "DISPATCH", code: string, lines: Array<[string, number, boolean?]>, list?: string[]) {
  const spec = LABEL_SPECS[kind];
  const doc = await PDFDocument.create();
  doc.setTitle(`ONEOFAKIND ${kind.toLowerCase()} label`);
  const font = await doc.embedFont(StandardFonts.Helvetica);
  const bold = await doc.embedFont(StandardFonts.HelveticaBold);
  const W = mm(spec.widthMm), H = mm(spec.heightMm), pad = mm(4);
  const page = doc.addPage([W, H]);
  const qr = await doc.embedPng(await qrPng(code));
  const bc = await doc.embedPng(await barcodePng(code));
  const qrSize = kind === "LOT" ? H - pad * 2 - mm(14) : mm(38);
  page.drawImage(qr, { x: W - pad - qrSize, y: H - pad - qrSize, width: qrSize, height: qrSize });
  let y = H - pad - mm(4);
  for (const [text, size, isBold] of lines) {
    page.drawText(fit(isBold ? bold : font, text, size, W - qrSize - pad * 3), { x: pad, y, size, font: isBold ? bold : font });
    y -= size + mm(2);
  }
  if (list?.length) {
    y = Math.min(y, H - pad - qrSize - mm(4));
    page.drawText("Expected pack codes:", { x: pad, y, size: 8, font: bold });
    y -= mm(4);
    for (const c of list.slice(0, 30)) { page.drawText(c, { x: pad, y, size: 8, font }); y -= mm(3.6); if (y < mm(30)) break; }
  }
  page.drawImage(bc, { x: pad, y: pad, width: W - pad * 2, height: kind === "LOT" ? mm(12) : mm(22) });
  return doc.save();
}

export function lotLabelPdf(d: LotLabelData) {
  assertLabelSafe(d, "LOT");
  return bigLabel("LOT", d.code, [[d.lotSku, 12, true], [`${d.brand} · ${d.style}`, 10], [`${d.pieceCount} pieces · sealed lot`, 10]]);
}
export function orderPackLabelPdf(d: PackLabelData) {
  assertLabelSafe(d, "ORDER_PACK");
  return bigLabel("ORDER_PACK", d.code, [["PACK SLIP", 9, true], [d.orderRef, 14, true], [`Ship to: ${d.shipToName}`, 10], [d.shipToCity, 10], [`${d.expectedPieces.length} code(s) to scan`, 9]], d.expectedPieces);
}
export function dispatchLabelPdf(d: DispatchLabelData) {
  assertLabelSafe(d, "DISPATCH");
  return bigLabel("DISPATCH", d.code, [["DISPATCH", 9, true], [d.orderRef, 14, true], [`${d.courier}${d.trackingNo ? ` · ${d.trackingNo}` : ""}`, 10], [`To: ${d.shipToName}, ${d.shipToCity}`, 10], [`${d.pieceCount} piece(s) · parcel ${d.parcelIndexOfCount}`, 10]]);
}
