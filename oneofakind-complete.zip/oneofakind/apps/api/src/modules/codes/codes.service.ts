import { Injectable } from "@nestjs/common";
import { Prisma, type ScanAction, type ScanCode, type ScanCodeKind } from "@prisma/client";
import { makeCode, parseScan } from "@ooak/shared";
import { hasRole, type Viewer } from "../../common/auth";
import { PrismaService, type SequenceName, type Tx } from "../../common/prisma.service";
import { badRequest, conflict, forbidden, notFound } from "../../common/problem";

const SEQ: Record<ScanCodeKind, SequenceName> = { ITEM_PACK: "seq_scan_item_pack", BUNDLE_PACK: "seq_scan_bundle_pack", ORDER_PACK: "seq_scan_order_pack", DISPATCH: "seq_scan_dispatch" };
type Ref = { itemId: string } | { bundleId: string } | { groupId: string } | { shipmentId: string; groupId: string; parentId: string };

/** Barcode/QR codes: Postgres sequence per kind, idempotent issue (one active code per entity), void + reissue, append-only scan log. */
@Injectable()
export class CodesService {
  constructor(private readonly prisma: PrismaService) {}

  private where(kind: ScanCodeKind, ref: Ref): Prisma.ScanCodeWhereInput {
    if ("shipmentId" in ref) return { kind, shipmentId: ref.shipmentId, voidedAt: null };
    if ("itemId" in ref) return { kind, itemId: ref.itemId, voidedAt: null };
    if ("bundleId" in ref) return { kind, bundleId: ref.bundleId, voidedAt: null };
    return { kind, groupId: ref.groupId, voidedAt: null };
  }

  /** Returns the active code for the entity, creating one if needed. Safe under concurrent calls (partial unique index + retry). */
  async issue(kind: ScanCodeKind, ref: Ref, actorId: string | null, tx: Tx = this.prisma): Promise<ScanCode> {
    for (let attempt = 0; attempt < 3; attempt++) {
      const existing = await tx.scanCode.findFirst({ where: this.where(kind, ref) });
      if (existing) return existing;
      const code = makeCode(kind, await this.prisma.nextval(SEQ[kind], tx));
      try {
        const created = await tx.scanCode.create({ data: { code, kind, ...ref, createdById: actorId } });
        await tx.scanEvent.create({ data: { codeId: created.id, action: "GENERATED", actorId } });
        return created;
      } catch (e) {
        if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === "P2002" && tx === this.prisma) continue; // lost a race: re-read
        throw e;
      }
    }
    throw conflict("Could not issue a code, please retry.", "CODE_RACE");
  }

  async log(codeId: string, action: ScanAction, actorId: string | null, extra: { ok?: boolean; note?: string; shipmentId?: string; locationId?: string } = {}, tx: Tx = this.prisma) {
    await tx.scanEvent.create({ data: { codeId, action, actorId, ok: extra.ok ?? true, note: extra.note, shipmentId: extra.shipmentId, locationId: extra.locationId } });
  }

  async markPrinted(codes: ScanCode[], actorId: string) {
    for (const c of codes) {
      await this.prisma.scanCode.update({ where: { id: c.id }, data: { printCount: { increment: 1 } } });
      await this.log(c.id, c.printCount > 0 ? "REPRINTED" : "PRINTED", actorId);
    }
  }

  /** Lost/damaged label: void (reason logged) and issue a replacement. */
  async voidAndReissue(code: string, reason: string, actorId: string) {
    const c = await this.prisma.scanCode.findUnique({ where: { code } });
    if (!c || c.voidedAt) throw notFound("Code");
    if (c.kind === "DISPATCH" || c.kind === "ORDER_PACK") throw badRequest("Order and dispatch codes are reissued through the packing flow.", "NOT_REISSUABLE");
    await this.prisma.scanCode.update({ where: { id: c.id }, data: { voidedAt: new Date(), voidReason: reason } });
    await this.log(c.id, "VOIDED", actorId, { note: reason });
    const ref: Ref = c.itemId ? { itemId: c.itemId } : { bundleId: c.bundleId! };
    return this.issue(c.kind, ref, actorId);
  }

  /** Role-scoped resolve of a scanned code. Labels carry no data; this decides what the scanner may see. Customers can't scan. */
  async resolve(raw: string, v: Viewer) {
    const p = parseScan(raw);
    if (!p.ok) throw badRequest(`Not a valid ONEOFAKIND code (${p.reason}).`, "INVALID_CODE");
    const c = await this.prisma.scanCode.findUnique({
      where: { code: p.code },
      include: {
        item: { select: { id: true, sku: true, title: true, sellerId: true, stockState: true, size: true, location: { select: { code: true } } } },
        bundle: { select: { id: true, sku: true, title: true, sellerId: true, state: true, size: true } },
        group: { select: { id: true, sellerId: true, order: { select: { reference: true } } } },
        shipment: { select: { id: true, trackingNo: true, courier: true, state: true } },
      },
    });
    if (!c) throw notFound("Code");
    const staff = hasRole(v, "WAREHOUSE", "ADMIN", "SUPPORT");
    const ownerSellerId = c.item?.sellerId ?? c.bundle?.sellerId ?? c.group?.sellerId ?? null;
    if (!staff && !(v.sellerId && ownerSellerId === v.sellerId)) throw forbidden("You can't scan this code.", "SCAN_FORBIDDEN");
    return { code: c.code, kind: c.kind, voided: !!c.voidedAt, voidReason: c.voidReason, item: c.item, bundle: c.bundle, group: c.group ? { id: c.group.id, orderRef: c.group.order.reference } : null, shipment: c.shipment };
  }
}
