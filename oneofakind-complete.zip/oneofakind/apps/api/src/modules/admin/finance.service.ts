import { Injectable } from "@nestjs/common";
import { applyBps, compareNames, MIN_PAYOUT_MINOR, money, PAYOUT_HOLD_DAYS } from "@ooak/shared";
import { AuditService } from "../../common/audit.service";
import { NotifierService } from "../../common/notifier.service";
import { PrismaService } from "../../common/prisma.service";
import { badRequest, conflict, notFound } from "../../common/problem";
import { LedgerService, PLATFORM_REF } from "../commerce/ledger.service";

const OPEN_CLAIM = ["REQUESTED", "APPROVED", "IN_TRANSIT", "RECEIVED"];
const OPEN_DISPUTE = ["OPEN", "EVIDENCE_REQUESTED", "UNDER_REVIEW"];

/**
 * Settlement: a seller's order line is payable once its group was delivered ≥ 7 days ago, it has no open claim or dispute,
 * and it isn't on a statement yet (StatementLine.orderItemId is unique ⇒ never settled twice). Platform-owned sales never
 * appear (principal sales). Statements are DRAFT → FINALIZED → PAID; PAID requires a verified own-name payout account.
 */
@Injectable()
export class FinanceService {
  constructor(private readonly prisma: PrismaService, private readonly ledger: LedgerService, private readonly audit: AuditService, private readonly notifier: NotifierService) {}

  async eligibleLines(sellerId: string, periodEnd: Date) {
    const cutoff = new Date(periodEnd.getTime() - PAYOUT_HOLD_DAYS * 86_400_000);
    const lines = await this.prisma.orderItem.findMany({
      where: {
        voidedAt: null, ownerType: "SELLER", group: { sellerId, deliveredAt: { lte: cutoff } },
        NOT: { id: { in: (await this.prisma.statementLine.findMany({ select: { orderItemId: true } })).map((x) => x.orderItemId) } },
      },
      include: { item: { select: { sku: true, title: true } }, group: { include: { order: { select: { reference: true, returns: true } } } } },
    });
    const disputes = new Set((await this.prisma.dispute.findMany({ where: { state: { in: OPEN_DISPUTE as never }, orderItemId: { in: lines.map((l) => l.id) } } })).map((d) => d.orderItemId));
    const refunds = await this.prisma.refund.groupBy({ by: ["orderItemId"], where: { orderItemId: { in: lines.map((l) => l.id) }, state: "SUCCEEDED" }, _sum: { amountMinor: true } });
    return lines
      .filter((l) => !disputes.has(l.id) && !l.group.order.returns.some((r) => r.orderItemId === l.id && OPEN_CLAIM.includes(r.state)))
      .map((l) => {
        const commission = applyBps(money(l.priceMinor), l.commissionBps ?? 0).amountMinor;
        const refunded = refunds.find((r) => r.orderItemId === l.id)?._sum.amountMinor ?? 0;
        // Self-managed sellers bear damage refunds (deducted); managed-resale damage is borne by the platform.
        const sellerShareRefunded = l.arrangement === "SELF_MANAGED" && refunded ? Math.round((refunded * (l.priceMinor - commission)) / l.priceMinor) : 0;
        return { orderItemId: l.id, sku: l.item.sku, title: l.item.title, orderRef: l.group.order.reference, grossMinor: l.priceMinor, commissionMinor: commission, refundMinor: sellerShareRefunded, netMinor: l.priceMinor - commission - sellerShareRefunded };
      });
  }

  async generate(periodStart: Date, periodEnd: Date, actorId: string) {
    const sellers = await this.prisma.sellerProfile.findMany({ select: { id: true } });
    const created: string[] = [];
    for (const s of sellers) {
      const lines = await this.eligibleLines(s.id, periodEnd);
      if (!lines.length) continue;
      const totals = lines.reduce((a, l) => ({ gross: a.gross + l.grossMinor, commission: a.commission + l.commissionMinor, refunds: a.refunds + l.refundMinor, net: a.net + l.netMinor }), { gross: 0, commission: 0, refunds: 0, net: 0 });
      const existing = await this.prisma.sellerStatement.findUnique({ where: { sellerId_periodStart_periodEnd: { sellerId: s.id, periodStart, periodEnd } } });
      if (existing) continue;
      const st = await this.prisma.sellerStatement.create({
        data: { sellerId: s.id, periodStart, periodEnd, grossMinor: totals.gross, commissionMinor: totals.commission, feesMinor: 0, refundsMinor: totals.refunds, netMinor: totals.net,
          lines: { create: lines.map((l) => ({ orderItemId: l.orderItemId, grossMinor: l.grossMinor, commissionMinor: l.commissionMinor })) } },
      });
      created.push(st.id);
    }
    await this.audit.log({ actorId, action: "STATEMENTS_GENERATED", entity: "SellerStatement", entityId: periodEnd.toISOString(), after: { count: created.length } });
    return { created: created.length, ids: created };
  }

  async finalize(id: string, actorId: string) {
    const st = await this.prisma.sellerStatement.findUnique({ where: { id } });
    if (!st) throw notFound("Statement");
    if (st.state !== "DRAFT") throw conflict("Only drafts can be finalised.", "INVALID_STATE");
    await this.prisma.sellerStatement.update({ where: { id }, data: { state: "FINALIZED" } });
    await this.audit.log({ actorId, action: "STATEMENT_FINALIZED", entity: "SellerStatement", entityId: id });
  }

  /** PAID only with a verified own-name payout account, a payout reference, and at least the minimum payout. Posts Dr SELLER_PAYABLE / Cr CASH. */
  async markPaid(id: string, actorId: string, payoutRef: string) {
    const st = await this.prisma.sellerStatement.findUnique({ where: { id }, include: { seller: true } });
    if (!st) throw notFound("Statement");
    if (st.state !== "FINALIZED") throw conflict("Finalise the statement before paying.", "INVALID_STATE");
    if (!st.seller.payoutVerifiedAt) throw conflict("The seller's payout account isn't verified as their own name. No payout until it is.", "PAYOUT_NOT_VERIFIED");
    if (st.netMinor < MIN_PAYOUT_MINOR) throw conflict(`Below the minimum payout (PKR ${MIN_PAYOUT_MINOR / 100}); it carries over.`, "BELOW_MINIMUM");
    if (!payoutRef.trim()) throw badRequest("Payout reference required.", "PAYOUT_REF_REQUIRED");
    await this.prisma.$transaction(async (tx) => {
      const n = await tx.sellerStatement.updateMany({ where: { id, state: "FINALIZED" }, data: { state: "PAID", paidAt: new Date(), payoutRef } });
      if (n.count !== 1) throw conflict("Statement changed meanwhile.", "INVALID_STATE");
      await this.ledger.postPayout(tx, st.sellerId, st.netMinor, st.id);
      await this.audit.log({ actorId, action: "STATEMENT_PAID", entity: "SellerStatement", entityId: id, after: { payoutRef, netMinor: st.netMinor } }, tx);
    });
    await this.notifier.inApp(st.seller.userId, "PAYOUT_SENT", `Payout of PKR ${(st.netMinor / 100).toLocaleString("en-PK")} sent (ref ${payoutRef}).`);
  }

  async payoutVerificationQueue() {
    const sellers = await this.prisma.sellerProfile.findMany({ where: { payoutAccountTitle: { not: null }, payoutVerifiedAt: null }, include: { user: { select: { name: true } } } });
    const apps = await this.prisma.onboardingApplication.findMany({ where: { id: { in: sellers.map((s) => s.applicationId).filter((x): x is string => !!x) } }, select: { id: true, fullName: true } });
    return sellers.map((s) => {
      const idName = apps.find((a) => a.id === s.applicationId)?.fullName ?? s.user.name;
      return { sellerId: s.id, displayName: s.displayName, idName, accountTitle: s.payoutAccountTitle, payoutMethod: s.payoutMethod, match: compareNames(idName, s.payoutAccountTitle!) };
    });
  }

  async verifyPayout(sellerId: string, actorId: string, approve: boolean, note?: string) {
    const s = await this.prisma.sellerProfile.findUnique({ where: { id: sellerId } });
    if (!s || !s.payoutAccountTitle) throw notFound("Payout account");
    await this.prisma.sellerProfile.update({ where: { id: sellerId }, data: approve ? { payoutVerifiedAt: new Date(), payoutVerifiedById: actorId } : { payoutVerifiedAt: null, payoutMethod: undefined } });
    await this.audit.log({ actorId, action: approve ? "PAYOUT_ACCOUNT_VERIFIED" : "PAYOUT_ACCOUNT_REJECTED", entity: "SellerProfile", entityId: sellerId, after: { note } });
    await this.notifier.inApp(s.userId, approve ? "PAYOUT_VERIFIED" : "PAYOUT_REJECTED", approve ? "Your payout account is verified. Payouts will go there." : `We couldn't verify your payout account: ${note ?? "it must be in your own name"}. Please add an account in your own name.`);
  }

  /** Gateway vs ledger: captured payments − succeeded refunds must equal the CASH_PROVIDER balance from sales/refunds (excluding transfers/payouts). */
  async reconciliation() {
    const [captured, refunded] = await Promise.all([
      this.prisma.payment.aggregate({ where: { state: { in: ["CAPTURED", "PARTIALLY_REFUNDED", "REFUNDED"] } }, _sum: { amountMinor: true } }),
      this.prisma.refund.aggregate({ where: { state: "SUCCEEDED" }, _sum: { amountMinor: true } }),
    ]);
    const cash = await this.prisma.ledgerAccount.findFirst({ where: { type: "CASH_PROVIDER", ownerRef: PLATFORM_REF } });
    const flows = cash ? await this.prisma.ledgerEntry.groupBy({ by: ["refType"], where: { accountId: cash.id }, _sum: { debitMinor: true, creditMinor: true } }) : [];
    const sum = (types: string[]) => flows.filter((f) => types.includes(f.refType)).reduce((a, f) => a + (f._sum.debitMinor ?? 0) - (f._sum.creditMinor ?? 0), 0);
    const gatewayNet = (captured._sum.amountMinor ?? 0) - (refunded._sum.amountMinor ?? 0);
    const ledgerNet = sum(["ORDER_ITEM", "ORDER", "REFUND", "PAYMENT"]);
    const balances = await this.prisma.ledgerAccount.findMany({ include: { entries: { select: { debitMinor: true, creditMinor: true } } } });
    return {
      gatewayNetMinor: gatewayNet, ledgerNetMinor: ledgerNet, differenceMinor: gatewayNet - ledgerNet,
      transfersOutMinor: -sum(["OWNERSHIP_TRANSFER"]), payoutsMinor: -sum(["SETTLEMENT"]),
      accounts: balances.map((a) => ({ type: a.type, ownerRef: a.ownerRef, balanceMinor: a.entries.reduce((x, e) => x + e.debitMinor - e.creditMinor, 0) })).filter((a) => a.balanceMinor !== 0),
    };
  }
}
