import { Body, Controller, Delete, Get, HttpCode, Param, Patch, Post, Put, Query, Res } from "@nestjs/common";
import type { Prisma, Role } from "@prisma/client";
import type { Response } from "express";
import { BUNDLE_SIZES, normalizePkPhone } from "@ooak/shared";
import { z } from "zod";
import { AuditService } from "../../common/audit.service";
import { Auth, CurrentViewer, hasRole, type Viewer } from "../../common/auth";
import { NotifierService } from "../../common/notifier.service";
import { PrismaService } from "../../common/prisma.service";
import { badRequest, conflict, forbidden, notFound, parse } from "../../common/problem";
import { StorageService } from "../../common/storage.service";
import { BundleService } from "../bundles/bundle.service";
import { mediaUrl } from "../catalog/presenters";
import { CheckoutService } from "../commerce/checkout.service";
import { ReturnsService } from "../commerce/returns.service";
import { ListingService } from "../seller/listing.service";
import { FinanceService } from "./finance.service";

const ROLES = ["CUSTOMER", "SELLER", "WAREHOUSE", "SUPPORT", "FINANCE", "MODERATOR", "ADMIN", "SELLER_AGENT", "VERIFIED_RESELLER"] as const;
const page = z.object({ q: z.string().max(80).optional(), cursor: z.string().optional(), limit: z.coerce.number().int().min(1).max(200).default(50) });

@Controller("admin")
@Auth("ADMIN", "SUPPORT", "FINANCE", "MODERATOR", "SELLER_AGENT")
export class AdminController {
  constructor(private readonly prisma: PrismaService, private readonly audit: AuditService, private readonly finance: FinanceService) {}

  @Get("dashboard")
  async dashboard() {
    const since = new Date(Date.now() - 30 * 86_400_000);
    const [gmv, ordersByState, pendingListings, pendingBundles, onboarding, claims, tickets, dps, payoutsToVerify, openReports, aiFailures, statementsToPay] = await Promise.all([
      this.prisma.order.aggregate({ where: { paidAt: { gte: since } }, _sum: { totalMinor: true }, _count: true }),
      this.prisma.order.groupBy({ by: ["state"], _count: true }),
      this.prisma.listing.count({ where: { state: "PENDING_REVIEW" } }),
      this.prisma.bundle.count({ where: { state: "PENDING_REVIEW" } }),
      this.prisma.onboardingApplication.count({ where: { status: { in: ["SUBMITTED", "UNDER_REVIEW"] } } }),
      this.prisma.returnRequest.count({ where: { state: "REQUESTED" } }),
      this.prisma.supportTicket.count({ where: { state: { in: ["OPEN", "PENDING_INTERNAL"] } } }),
      this.prisma.directPurchase.count({ where: { state: { in: ["SUBMITTED", "UNDER_REVIEW", "AWAITING_PAYMENT"] } } }),
      this.prisma.sellerProfile.count({ where: { payoutAccountTitle: { not: null }, payoutVerifiedAt: null } }),
      this.prisma.moderationReport.count({ where: { state: { in: ["OPEN", "APPEALED"] } } }),
      this.prisma.aiJob.count({ where: { state: { in: ["FAILED", "TIMED_OUT"] }, createdAt: { gte: since } } }),
      this.prisma.sellerStatement.count({ where: { state: "FINALIZED" } }),
    ]);
    return { gmv30dMinor: gmv._sum.totalMinor ?? 0, orders30d: gmv._count, ordersByState: ordersByState.map((o) => ({ state: o.state, count: o._count })), queues: { pendingListings, pendingBundles, onboarding, claims, tickets, dps, payoutsToVerify, openReports, aiFailures, statementsToPay } };
  }

  // ── Users & roles ──
  @Get("users")
  async users(@Query() query: unknown) {
    const q = parse(page.extend({ role: z.enum(ROLES).optional() }), query);
    const phone = q.q ? normalizePkPhone(q.q) : null;
    const rows = await this.prisma.user.findMany({
      where: { ...(q.role ? { roles: { has: q.role } } : {}), ...(q.q ? { OR: [{ name: { contains: q.q, mode: "insensitive" } }, { email: { contains: q.q, mode: "insensitive" } }, ...(phone ? [{ phone }] : [])] } : {}) },
      orderBy: { createdAt: "desc" }, take: q.limit + 1, ...(q.cursor ? { cursor: { id: q.cursor }, skip: 1 } : {}), include: { sellerProfile: { select: { slug: true, status: true } } },
    });
    const p = rows.slice(0, q.limit);
    return { users: p.map((u) => ({ id: u.id, name: u.name, phone: u.phone, email: u.email, roles: u.roles, activated: !!u.activatedAt, disabled: !!u.disabledAt, deletionRequested: !!u.deletionRequestedAt, seller: u.sellerProfile, createdAt: u.createdAt })), nextCursor: rows.length > q.limit ? p[p.length - 1]!.id : null };
  }

  @Get("users/:id")
  async user(@Param("id") id: string) {
    const u = await this.prisma.user.findUnique({ where: { id }, include: { sellerProfile: true, resellerVerification: true, applications: true, orders: { take: 20, orderBy: { createdAt: "desc" } }, consents: true } });
    if (!u) throw notFound("User");
    const activity = await this.prisma.auditLog.findMany({ where: { OR: [{ actorId: id }, { onBehalfOfId: id }, { entityId: id }] }, orderBy: { createdAt: "desc" }, take: 50 });
    return { user: { ...u, passwordHash: undefined }, activity };
  }

  /** Role grants are ADMIN-only and audited. SELLER_AGENT is granted to individual people (decided). */
  @Post("users/:id/roles") @HttpCode(200)
  @Auth("ADMIN")
  async roles(@CurrentViewer() v: Viewer, @Param("id") id: string, @Body() body: unknown) {
    const { add = [], remove = [] } = parse(z.object({ add: z.array(z.enum(ROLES)).optional(), remove: z.array(z.enum(ROLES)).optional() }), body);
    if (id === v.userId && remove.includes("ADMIN")) throw badRequest("You can't remove your own admin role.", "SELF_DEMOTION");
    const u = await this.prisma.user.findUnique({ where: { id } });
    if (!u) throw notFound("User");
    const roles = [...new Set([...u.roles.filter((r) => !remove.includes(r as never)), ...add])] as Role[];
    await this.prisma.user.update({ where: { id }, data: { roles } });
    if (remove.includes("VERIFIED_RESELLER")) await this.prisma.resellerVerification.updateMany({ where: { userId: id }, data: { status: "REVOKED", reviewedById: v.userId, reviewedAt: new Date() } });
    await this.audit.log({ actorId: v.userId, action: "ROLES_CHANGED", entity: "User", entityId: id, before: { roles: u.roles }, after: { roles } });
    return { roles };
  }

  @Post("users/:id/disable") @HttpCode(200)
  @Auth("ADMIN")
  async disable(@CurrentViewer() v: Viewer, @Param("id") id: string, @Body() body: unknown) {
    const { disabled, reason } = parse(z.object({ disabled: z.boolean(), reason: z.string().min(3).max(300) }), body);
    if (id === v.userId) throw badRequest("You can't disable yourself.");
    await this.prisma.user.update({ where: { id }, data: { disabledAt: disabled ? new Date() : null } });
    if (disabled) await this.prisma.session.updateMany({ where: { userId: id, revokedAt: null }, data: { revokedAt: new Date() } });
    await this.audit.log({ actorId: v.userId, action: disabled ? "USER_DISABLED" : "USER_ENABLED", entity: "User", entityId: id, after: { reason } });
    return { ok: true };
  }

  // ── Sellers ──
  @Get("sellers")
  async sellers(@Query() query: unknown) {
    const q = parse(page.extend({ status: z.enum(["PENDING", "VERIFIED", "SUSPENDED"]).optional() }), query);
    const rows = await this.prisma.sellerProfile.findMany({
      where: { ...(q.status ? { status: q.status } : {}), ...(q.q ? { OR: [{ displayName: { contains: q.q, mode: "insensitive" } }, { slug: { contains: q.q } }] } : {}) },
      orderBy: { createdAt: "desc" }, take: 200, include: { _count: { select: { items: true, listings: { where: { state: "PUBLISHED" } } } }, user: { select: { phone: true, name: true } } },
    });
    return { sellers: rows.map((s) => ({ id: s.id, slug: s.slug, displayName: s.displayName, type: s.type, status: s.status, city: s.city, owner: s.user.name, phone: s.user.phone, items: s._count.items, live: s._count.listings, payoutVerified: !!s.payoutVerifiedAt, allowStaffListing: s.allowStaffListing, createdAt: s.createdAt })) };
  }

  @Post("sellers/:id/status") @HttpCode(200)
  @Auth("ADMIN", "MODERATOR")
  async sellerStatus(@CurrentViewer() v: Viewer, @Param("id") id: string, @Body() body: unknown) {
    const { status, reason } = parse(z.object({ status: z.enum(["VERIFIED", "SUSPENDED"]), reason: z.string().min(3).max(300) }), body);
    const s = await this.prisma.sellerProfile.update({ where: { id }, data: { status } });
    if (status === "SUSPENDED") await this.prisma.listing.updateMany({ where: { sellerId: id, state: "PUBLISHED", item: { stockState: "AVAILABLE" } }, data: { state: "PAUSED" } });
    await this.audit.log({ actorId: v.userId, action: `SELLER_${status}`, entity: "SellerProfile", entityId: id, after: { reason } });
    return { status: s.status };
  }

  // ── Audit viewer ──
  @Get("audit")
  @Auth("ADMIN", "FINANCE")
  async auditLog(@Query() query: unknown) {
    const q = parse(page.extend({ entity: z.string().max(40).optional(), action: z.string().max(60).optional(), actorId: z.string().optional(), entityId: z.string().optional() }), query);
    const rows = await this.prisma.auditLog.findMany({
      where: { ...(q.entity ? { entity: q.entity } : {}), ...(q.action ? { action: { contains: q.action.toUpperCase() } } : {}), ...(q.actorId ? { actorId: q.actorId } : {}), ...(q.entityId ? { entityId: q.entityId } : {}) },
      orderBy: { createdAt: "desc" }, take: q.limit + 1, ...(q.cursor ? { cursor: { id: q.cursor }, skip: 1 } : {}), include: { actor: { select: { name: true } } },
    });
    const p = rows.slice(0, q.limit);
    return { events: p.map((e) => ({ id: e.id, at: e.createdAt, actor: e.actor?.name ?? "System", actorId: e.actorId, onBehalfOfId: e.onBehalfOfId, action: e.action, entity: e.entity, entityId: e.entityId, before: e.before, after: e.after })), nextCursor: rows.length > q.limit ? p[p.length - 1]!.id : null };
  }

  // ── Settings (runtime config) ──
  @Get("settings")
  @Auth("ADMIN", "FINANCE")
  async settings() {
    const [settings, rules, tiers] = await Promise.all([this.prisma.setting.findMany(), this.prisma.commissionRule.findMany({ orderBy: { effectiveFrom: "desc" } }), this.prisma.bundleTier.findMany({ orderBy: { size: "asc" } })]);
    return { settings, commissionRules: rules, bundleTiers: tiers };
  }

  @Put("settings/:key")
  @Auth("ADMIN", "FINANCE")
  async setSetting(@CurrentViewer() v: Viewer, @Param("key") key: string, @Body() body: unknown) {
    if (!["shipping.flatRates", "shipping.bundleRatePerKgMinor", "features"].includes(key)) throw badRequest("Unknown setting.", "UNKNOWN_SETTING");
    const { value } = parse(z.object({ value: z.unknown() }), body);
    const before = await this.prisma.setting.findUnique({ where: { key } });
    const s = await this.prisma.setting.upsert({ where: { key }, update: { value: value as Prisma.InputJsonValue, updatedById: v.userId }, create: { key, value: value as Prisma.InputJsonValue, updatedById: v.userId } });
    await this.audit.log({ actorId: v.userId, action: "SETTING_CHANGED", entity: "Setting", entityId: key, before: before?.value, after: value });
    return s;
  }

  @Put("bundle-tiers/:size")
  @Auth("ADMIN")
  async tier(@CurrentViewer() v: Viewer, @Param("size") size: string, @Body() body: unknown) {
    const input = parse(z.object({ active: z.boolean().default(true), minPriceMinor: z.number().int().min(0) }), body);
    const n = Number(size);
    if (!(BUNDLE_SIZES as readonly number[]).includes(n)) throw badRequest("Bundles are 5, 10 or 15 pieces only.", "INVALID_BUNDLE_SIZE");
    const t = await this.prisma.bundleTier.upsert({ where: { size: n }, update: input, create: { size: n, ...input } });
    await this.audit.log({ actorId: v.userId, action: "BUNDLE_TIER_CHANGED", entity: "BundleTier", entityId: String(n), after: input });
    return t;
  }
}

/** Moderation: listings, bundles, reports (prohibited/IP/counterfeit), appeals. */
@Controller("admin/moderation")
@Auth("MODERATOR", "ADMIN")
export class ModerationController {
  constructor(private readonly prisma: PrismaService, private readonly listings: ListingService, private readonly bundles: BundleService, private readonly audit: AuditService, private readonly notifier: NotifierService) {}

  @Get("listings")
  async queue(@Query() q: unknown) {
    const { state } = parse(z.object({ state: z.enum(["PENDING_REVIEW", "CHANGES_REQUESTED", "PUBLISHED"]).default("PENDING_REVIEW") }), q);
    const rows = await this.prisma.listing.findMany({
      where: { state }, orderBy: { updatedAt: "asc" }, take: 100,
      include: { seller: true, item: { include: { brand: true, category: true, media: { where: { deletedAt: null }, orderBy: { position: "asc" } }, conditionReports: { orderBy: { createdAt: "desc" }, take: 1 } } } },
    });
    return {
      listings: rows.map((l) => ({
        id: l.id, slug: l.slug, state: l.state, seller: l.seller.displayName, sellerId: l.sellerId, sellerStatus: l.seller.status, title: l.item.title, sku: l.item.sku, brand: l.item.brand?.name ?? null, brandVerified: l.item.brand?.verifiedBrand ?? false,
        category: l.item.category.name, size: l.item.size, color: l.item.color, material: l.item.material, priceMinor: l.item.priceMinor, grade: l.item.conditionGrade, measurements: l.item.measurements, description: l.item.description,
        arrangement: l.item.arrangement, defects: l.item.conditionReports[0]?.defects ?? [], photos: l.item.media.map((m) => ({ id: m.id, url: mediaUrl(m.id), approved: m.approvedForPublish, aiLabel: m.aiLabel, kind: m.kind })), updatedAt: l.updatedAt,
      })),
    };
  }

  @Post("listings/:id/approve") @HttpCode(200)
  async approve(@CurrentViewer() v: Viewer, @Param("id") id: string) { await this.listings.approve(id, v.userId); return { ok: true }; }
  @Post("listings/:id/changes") @HttpCode(200)
  async changes(@CurrentViewer() v: Viewer, @Param("id") id: string, @Body() body: unknown) { await this.listings.requestChanges(id, v.userId, parse(z.object({ note: z.string().trim().min(5).max(500) }), body).note); return { ok: true }; }
  @Post("listings/:id/remove") @HttpCode(200)
  async remove(@CurrentViewer() v: Viewer, @Param("id") id: string, @Body() body: unknown) { await this.listings.moderatorRemove(id, v.userId, parse(z.object({ note: z.string().trim().min(5).max(500) }), body).note); return { ok: true }; }

  @Get("bundles")
  async bundlesQueue() {
    const rows = await this.prisma.bundle.findMany({ where: { state: "PENDING_REVIEW" }, include: { brand: true, style: true, seller: true, items: { where: { releasedAt: null }, include: { item: { include: { media: { where: { deletedAt: null }, take: 1, orderBy: { position: "asc" } } } } } } } });
    return { bundles: rows.map((b) => ({ id: b.id, title: b.title, sku: b.sku, seller: b.seller?.displayName ?? "ONEOFAKIND", brand: b.brand.name, style: b.style.name, size: b.size, priceMinor: b.priceMinor, retailValueMinor: b.retailValueMinor,
      pieces: b.items.map((bi) => ({ sku: bi.item.sku, title: bi.item.title, size: bi.item.size, grade: bi.item.conditionGrade, photo: bi.item.media[0] ? mediaUrl(bi.item.media[0].id) : null, brandId: bi.item.brandId === b.brandId, styleId: bi.item.styleId === b.styleId })) })) };
  }
  @Post("bundles/:id/approve") @HttpCode(200)
  async approveBundle(@CurrentViewer() v: Viewer, @Param("id") id: string) { await this.bundles.transition(id, "PUBLISHED", v.userId); return { ok: true }; }
  @Post("bundles/:id/changes") @HttpCode(200)
  async bundleChanges(@CurrentViewer() v: Viewer, @Param("id") id: string, @Body() body: unknown) { await this.bundles.transition(id, "CHANGES_REQUESTED", v.userId, { note: parse(z.object({ note: z.string().min(5).max(500) }), body).note }); return { ok: true }; }
  @Post("bundles/:id/remove") @HttpCode(200)
  async bundleRemove(@CurrentViewer() v: Viewer, @Param("id") id: string, @Body() body: unknown) { await this.bundles.transition(id, "REMOVED", v.userId, { note: parse(z.object({ note: z.string().min(5).max(500) }), body).note }); return { ok: true }; }

  @Get("reports")
  async reports(@Query() q: unknown) {
    const { state } = parse(z.object({ state: z.string().default("OPEN,APPEALED") }), q);
    const rows = await this.prisma.moderationReport.findMany({ where: { state: { in: state.split(",") } }, orderBy: { createdAt: "asc" } });
    const listings = await this.prisma.listing.findMany({ where: { id: { in: rows.map((r) => r.listingId).filter((x): x is string => !!x) } }, include: { item: true, seller: true } });
    return { reports: rows.map((r) => { const l = listings.find((x) => x.id === r.listingId); return { ...r, listing: l ? { slug: l.slug, title: l.item.title, state: l.state, seller: l.seller.displayName } : null }; }) };
  }

  @Post("reports/:id/resolve") @HttpCode(200)
  async resolve(@CurrentViewer() v: Viewer, @Param("id") id: string, @Body() body: unknown) {
    const { action, note } = parse(z.object({ action: z.enum(["REMOVE_LISTING", "DISMISS"]), note: z.string().min(3).max(500) }), body);
    const r = await this.prisma.moderationReport.findUnique({ where: { id } });
    if (!r) throw notFound("Report");
    if (action === "REMOVE_LISTING" && r.listingId) await this.listings.moderatorRemove(r.listingId, v.userId, `Report upheld: ${note}`);
    if (action === "DISMISS" && r.state === "APPEALED" && r.listingId) {
      // Appeal upheld: the listing comes back for review.
      const l = await this.prisma.listing.findUnique({ where: { id: r.listingId } });
      if (l?.state === "REMOVED") await this.audit.log({ actorId: v.userId, action: "APPEAL_UPHELD_RELIST_MANUALLY", entity: "Listing", entityId: l.id });
    }
    await this.prisma.moderationReport.update({ where: { id }, data: { state: action === "REMOVE_LISTING" ? "UPHELD" : "DISMISSED", details: `${r.details ?? ""}\n[${new Date().toISOString()}] ${action}: ${note}`.trim() } });
    await this.audit.log({ actorId: v.userId, action: `REPORT_${action}`, entity: "ModerationReport", entityId: id, after: { note } });
    return { ok: true };
  }

  @Post("brands/:id/verify") @HttpCode(200)
  async verifyBrand(@CurrentViewer() v: Viewer, @Param("id") id: string, @Body() body: unknown) {
    const { verified } = parse(z.object({ verified: z.boolean() }), body);
    await this.prisma.brand.update({ where: { id }, data: { verifiedBrand: verified } });
    await this.audit.log({ actorId: v.userId, action: verified ? "BRAND_VERIFIED" : "BRAND_UNVERIFIED", entity: "Brand", entityId: id });
    return { ok: true };
  }
}

/** Public reporting and seller appeals. */
@Controller()
export class ReportsController {
  constructor(private readonly prisma: PrismaService, private readonly audit: AuditService) {}

  @Post("reports")
  @Auth()
  async report(@CurrentViewer() v: Viewer, @Body() body: unknown) {
    const { listingSlug, reason, details } = parse(z.object({ listingSlug: z.string(), reason: z.enum(["PROHIBITED_GOODS", "INTELLECTUAL_PROPERTY", "COUNTERFEIT", "MISLEADING_INFO", "OTHER"]), details: z.string().trim().max(1000).optional() }), body);
    const l = await this.prisma.listing.findUnique({ where: { slug: listingSlug } });
    if (!l) throw notFound("Listing");
    const r = await this.prisma.moderationReport.create({ data: { listingId: l.id, reporterId: v.userId, reason, details } });
    return { id: r.id };
  }

  @Get("seller/reports")
  @Auth("SELLER")
  async mine(@CurrentViewer() v: Viewer) {
    const listings = await this.prisma.listing.findMany({ where: { sellerId: v.sellerId! }, select: { id: true, slug: true, item: { select: { title: true } } } });
    const rows = await this.prisma.moderationReport.findMany({ where: { listingId: { in: listings.map((l) => l.id) }, state: { in: ["UPHELD", "APPEALED", "DISMISSED"] } }, orderBy: { createdAt: "desc" } });
    return { reports: rows.map((r) => ({ id: r.id, reason: r.reason, state: r.state, appealNote: r.appealNote, title: listings.find((l) => l.id === r.listingId)?.item.title })) };
  }

  @Post("seller/reports/:id/appeal") @HttpCode(200)
  @Auth("SELLER")
  async appeal(@CurrentViewer() v: Viewer, @Param("id") id: string, @Body() body: unknown) {
    const { note } = parse(z.object({ note: z.string().trim().min(10).max(1000) }), body);
    const r = await this.prisma.moderationReport.findUnique({ where: { id } });
    const l = r?.listingId ? await this.prisma.listing.findUnique({ where: { id: r.listingId } }) : null;
    if (!r || !l || l.sellerId !== v.sellerId) throw notFound("Report");
    if (r.state !== "UPHELD") throw conflict("Only upheld reports can be appealed.", "NOT_APPEALABLE");
    await this.prisma.moderationReport.update({ where: { id }, data: { state: "APPEALED", appealNote: note } });
    await this.audit.log({ actorId: v.userId, action: "REPORT_APPEALED", entity: "ModerationReport", entityId: id });
    return { ok: true };
  }
}

/** Catalogue + CMS administration. */
@Controller("admin/catalog")
@Auth("ADMIN", "MODERATOR")
export class CatalogAdminController {
  constructor(private readonly prisma: PrismaService, private readonly audit: AuditService, private readonly storage: StorageService) {}

  @Get("categories")
  async categories() { return { categories: await this.prisma.category.findMany({ orderBy: [{ sortOrder: "asc" }, { name: "asc" }], include: { _count: { select: { items: true } } } }) }; }

  @Get("styles")
  async styles() { return { styles: await this.prisma.styleTag.findMany({ orderBy: { name: "asc" }, include: { _count: { select: { items: true } } } }) }; }

  @Post("categories")
  async addCategory(@CurrentViewer() v: Viewer, @Body() body: unknown) {
    const input = parse(z.object({ slug: z.string().regex(/^[a-z0-9-]{2,40}$/), name: z.string().min(2).max(60), parentId: z.string().nullable().optional(), measurements: z.array(z.string().regex(/^[a-z_]{2,30}$/)).max(10).default([]) }), body);
    const c = await this.prisma.category.create({ data: { slug: input.slug, name: input.name, parentId: input.parentId ?? null, attributeSchema: { measurements: input.measurements } } });
    await this.audit.log({ actorId: v.userId, action: "CATEGORY_CREATED", entity: "Category", entityId: c.id, after: input });
    return c;
  }

  @Patch("categories/:id")
  async editCategory(@CurrentViewer() v: Viewer, @Param("id") id: string, @Body() body: unknown) {
    const input = parse(z.object({ name: z.string().min(2).max(60).optional(), enabled: z.boolean().optional(), sortOrder: z.number().int().optional(), measurements: z.array(z.string().regex(/^[a-z_]{2,30}$/)).max(10).optional() }), body);
    const { measurements, ...rest } = input;
    const c = await this.prisma.category.update({ where: { id }, data: { ...rest, ...(measurements ? { attributeSchema: { measurements } } : {}) } });
    await this.audit.log({ actorId: v.userId, action: "CATEGORY_EDITED", entity: "Category", entityId: id, after: input });
    return c;
  }

  @Get("brands")
  async brands() { return { brands: await this.prisma.brand.findMany({ orderBy: { name: "asc" }, include: { _count: { select: { items: true } } } }) }; }

  @Post("styles")
  async addStyle(@CurrentViewer() v: Viewer, @Body() body: unknown) {
    const input = parse(z.object({ slug: z.string().regex(/^[a-z0-9-]{2,40}$/), name: z.string().min(2).max(60), categoryId: z.string().nullable().optional() }), body);
    const s = await this.prisma.styleTag.create({ data: { slug: input.slug, name: input.name, categoryId: input.categoryId ?? null } });
    await this.audit.log({ actorId: v.userId, action: "STYLE_CREATED", entity: "StyleTag", entityId: s.id });
    return s;
  }

  @Patch("styles/:id")
  async editStyle(@Param("id") id: string, @Body() body: unknown) { return this.prisma.styleTag.update({ where: { id }, data: parse(z.object({ name: z.string().min(2).max(60).optional(), enabled: z.boolean().optional() }), body) }); }

  // CMS: home/campaign blocks (promotions are campaigns, not discount codes, in v1)
  @Get("cms")
  async cms() { return { blocks: await this.prisma.contentBlock.findMany({ orderBy: [{ position: "asc" }, { key: "asc" }] }) }; }

  @Put("cms/:key")
  async upsertBlock(@CurrentViewer() v: Viewer, @Param("key") key: string, @Body() body: unknown) {
    const input = parse(z.object({ title: z.string().min(1).max(120), body: z.string().max(600).nullable().optional(), linkHref: z.string().max(200).nullable().optional(), linkLabel: z.string().max(60).nullable().optional(), position: z.number().int().default(0), published: z.boolean().default(false) }), body);
    if (input.linkHref && !input.linkHref.startsWith("/")) throw badRequest("Links must be internal paths (start with /).", "EXTERNAL_LINK");
    const b = await this.prisma.contentBlock.upsert({ where: { key }, update: input, create: { key, ...input } });
    await this.audit.log({ actorId: v.userId, action: "CMS_BLOCK_SAVED", entity: "ContentBlock", entityId: key, after: input });
    return b;
  }

  @Delete("cms/:key")
  async deleteBlock(@CurrentViewer() v: Viewer, @Param("key") key: string) { await this.prisma.contentBlock.deleteMany({ where: { key } }); await this.audit.log({ actorId: v.userId, action: "CMS_BLOCK_DELETED", entity: "ContentBlock", entityId: key }); return { ok: true }; }

  // Collections (curated edits / drops)
  @Get("collections")
  async collections() { return { collections: await this.prisma.collection.findMany({ orderBy: { title: "asc" }, include: { _count: { select: { items: true } } } }) }; }

  @Post("collections")
  async addCollection(@CurrentViewer() v: Viewer, @Body() body: unknown) {
    const input = parse(z.object({ slug: z.string().regex(/^[a-z0-9-]{2,60}$/), title: z.string().min(2).max(80), description: z.string().max(400).optional(), startsAt: z.coerce.date().optional(), endsAt: z.coerce.date().optional() }), body);
    const c = await this.prisma.collection.create({ data: { ...input, isEditorial: true, approved: true, curatorId: v.userId } });
    await this.audit.log({ actorId: v.userId, action: "COLLECTION_CREATED", entity: "Collection", entityId: c.id });
    return c;
  }

  @Put("collections/:id/items")
  async setItems(@CurrentViewer() v: Viewer, @Param("id") id: string, @Body() body: unknown) {
    const { skus } = parse(z.object({ skus: z.array(z.string()).max(60) }), body);
    const items = await this.prisma.item.findMany({ where: { sku: { in: skus } }, select: { id: true, sku: true } });
    await this.prisma.$transaction([
      this.prisma.collectionItem.deleteMany({ where: { collectionId: id } }),
      this.prisma.collectionItem.createMany({ data: skus.map((s, i) => ({ collectionId: id, itemId: items.find((x) => x.sku === s)?.id ?? "", position: i })).filter((x) => x.itemId) }),
    ]);
    await this.audit.log({ actorId: v.userId, action: "COLLECTION_ITEMS_SET", entity: "Collection", entityId: id, after: { count: items.length } });
    return { count: items.length, unknown: skus.filter((s) => !items.some((x) => x.sku === s)) };
  }

  @Patch("collections/:id")
  async editCollection(@Param("id") id: string, @Body() body: unknown) { return this.prisma.collection.update({ where: { id }, data: parse(z.object({ title: z.string().min(2).max(80).optional(), description: z.string().max(400).optional(), approved: z.boolean().optional() }), body) }); }
}

/** Support desk: tickets, disputes, orders, damage claims; staff cancellation of a paid group before dispatch. */
@Controller()
export class SupportController {
  constructor(private readonly prisma: PrismaService, private readonly audit: AuditService, private readonly returns: ReturnsService, private readonly checkout: CheckoutService, private readonly storage: StorageService, private readonly notifier: NotifierService) {}

  @Post("support/tickets")
  @Auth()
  async open(@CurrentViewer() v: Viewer, @Body() body: unknown) {
    const { subject, message, orderRef } = parse(z.object({ subject: z.string().trim().min(3).max(120), message: z.string().trim().min(5).max(2000), orderRef: z.string().max(30).optional() }), body);
    const order = orderRef ? await this.prisma.order.findUnique({ where: { reference: orderRef } }) : null;
    if (order && order.userId !== v.userId && !v.sellerId) throw forbidden();
    const t = await this.prisma.supportTicket.create({ data: { userId: v.userId, orderId: order?.id ?? null, subject, messages: [{ from: "USER", by: v.name, at: new Date().toISOString(), text: message }] } });
    return { id: t.id };
  }

  @Get("support/tickets")
  @Auth()
  async mine(@CurrentViewer() v: Viewer) { return { tickets: await this.prisma.supportTicket.findMany({ where: { userId: v.userId }, orderBy: { createdAt: "desc" } }) }; }

  @Post("support/tickets/:id/messages") @HttpCode(200)
  @Auth()
  async message(@CurrentViewer() v: Viewer, @Param("id") id: string, @Body() body: unknown) {
    const { text, state } = parse(z.object({ text: z.string().trim().min(1).max(2000), state: z.enum(["OPEN", "PENDING_CUSTOMER", "PENDING_INTERNAL", "RESOLVED", "CLOSED"]).optional() }), body);
    const t = await this.prisma.supportTicket.findUnique({ where: { id } });
    const staff = hasRole(v, "SUPPORT", "ADMIN");
    if (!t || (t.userId !== v.userId && !staff)) throw notFound("Ticket");
    const msgs = [...((t.messages as unknown[]) ?? []), { from: staff && t.userId !== v.userId ? "STAFF" : "USER", by: v.name, at: new Date().toISOString(), text }];
    await this.prisma.supportTicket.update({ where: { id }, data: { messages: msgs as Prisma.InputJsonValue, state: staff && state ? state : staff ? "PENDING_CUSTOMER" : "PENDING_INTERNAL" } });
    if (staff && t.userId !== v.userId) await this.notifier.inApp(t.userId, "SUPPORT_REPLY", `Support replied: ${t.subject}`);
    return { ok: true };
  }

  @Get("admin/support")
  @Auth("SUPPORT", "ADMIN")
  async queue(@Query() q: unknown) {
    const { state } = parse(z.object({ state: z.string().default("OPEN,PENDING_INTERNAL,PENDING_CUSTOMER") }), q);
    const rows = await this.prisma.supportTicket.findMany({ where: { state: { in: state.split(",") as never } }, orderBy: { createdAt: "asc" }, include: { user: { select: { name: true, phone: true } }, disputes: true } });
    const orderIds = rows.map((t) => t.orderId).filter((x): x is string => !!x);
    const [orders, lines] = await Promise.all([
      this.prisma.order.findMany({ where: { id: { in: orderIds } }, select: { id: true, reference: true, state: true } }),
      this.prisma.orderItem.findMany({ where: { group: { orderId: { in: orderIds } } }, select: { id: true, priceMinor: true, voidedAt: true, group: { select: { orderId: true } }, item: { select: { sku: true, title: true } } } }),
    ]);
    return { tickets: rows.map((t) => ({ ...t, order: orders.find((o) => o.id === t.orderId) ?? null, lines: lines.filter((l) => l.group.orderId === t.orderId).map((l) => ({ id: l.id, sku: l.item.sku, title: l.item.title, priceMinor: l.priceMinor, voided: !!l.voidedAt })) })) };
  }

  @Post("admin/support/:id/disputes")
  @Auth("SUPPORT", "ADMIN")
  async dispute(@CurrentViewer() v: Viewer, @Param("id") id: string, @Body() body: unknown) {
    const { orderItemId } = parse(z.object({ orderItemId: z.string() }), body);
    const d = await this.prisma.dispute.create({ data: { ticketId: id, orderItemId } });
    await this.audit.log({ actorId: v.userId, action: "DISPUTE_OPENED", entity: "Dispute", entityId: d.id, after: { orderItemId } });
    return d;
  }

  @Post("admin/disputes/:id/resolve") @HttpCode(200)
  @Auth("SUPPORT", "ADMIN")
  async resolveDispute(@CurrentViewer() v: Viewer, @Param("id") id: string, @Body() body: unknown) {
    const { outcome, resolution } = parse(z.object({ outcome: z.enum(["RESOLVED_BUYER", "RESOLVED_SELLER"]), resolution: z.string().min(5).max(1000) }), body);
    await this.prisma.dispute.update({ where: { id }, data: { state: outcome, resolution } });
    await this.audit.log({ actorId: v.userId, action: `DISPUTE_${outcome}`, entity: "Dispute", entityId: id, after: { resolution } });
    return { ok: true };
  }

  @Get("admin/orders")
  @Auth("SUPPORT", "ADMIN", "FINANCE")
  async orders(@Query() query: unknown) {
    const q = parse(page.extend({ state: z.string().optional() }), query);
    const rows = await this.prisma.order.findMany({
      where: { ...(q.state ? { state: { in: q.state.split(",") as never } } : {}), ...(q.q ? { OR: [{ reference: { contains: q.q.toUpperCase() } }, { user: { name: { contains: q.q, mode: "insensitive" } } }] } : {}) },
      orderBy: { createdAt: "desc" }, take: q.limit + 1, ...(q.cursor ? { cursor: { id: q.cursor }, skip: 1 } : {}), include: { user: { select: { name: true, phone: true } }, payments: { select: { state: true, method: true } }, groups: { select: { id: true, state: true, mode: true, sellerId: true, shippingMinor: true, subtotalMinor: true } } },
    });
    const p = rows.slice(0, q.limit);
    return { orders: p.map((o) => ({ reference: o.reference, state: o.state, totalMinor: o.totalMinor, createdAt: o.createdAt, paidAt: o.paidAt, buyer: o.user.name, phone: o.user.phone, payment: o.payments[0] ?? null, groups: o.groups })), nextCursor: rows.length > q.limit ? p[p.length - 1]!.id : null };
  }

  /** Staff cancel of a paid seller group before dispatch: refund every line (mode CANCEL) + its shipping, pieces back on sale. */
  @Post("admin/groups/:id/cancel") @HttpCode(200)
  @Auth("SUPPORT", "ADMIN")
  async cancelGroup(@CurrentViewer() v: Viewer, @Param("id") id: string, @Body() body: unknown) {
    const { reason } = parse(z.object({ reason: z.string().trim().min(5).max(300) }), body);
    const g = await this.prisma.fulfilmentGroup.findUnique({ where: { id }, include: { items: { where: { voidedAt: null }, include: { item: true } }, order: { include: { payments: true, groups: true } }, shipments: true } });
    if (!g) throw notFound("Group");
    if (!["PAID", "PROCESSING"].includes(g.state) || g.shipments.some((s) => s.state !== "LABEL_PENDING" && s.state !== "READY")) throw conflict("Only paid, not-yet-dispatched groups can be cancelled here.", "NOT_CANCELLABLE");
    if (g.items.some((i) => i.bundleLineId)) throw conflict("Lots are cancelled via the bundling desk (swap or full refund).", "USE_BUNDLE_FLOW");
    const pay = g.order.payments.find((p) => p.state === "CAPTURED" || p.state === "PARTIALLY_REFUNDED");
    if (!pay) throw conflict("No captured payment.", "NO_PAYMENT");
    const refunds: string[] = [];
    await this.prisma.$transaction(async (tx) => {
      for (const oi of g.items) {
        const back = oi.item.stockState === "PACKED" ? ["PACKED", "SOLD", "AVAILABLE"] : ["SOLD", "AVAILABLE"];
        await tx.item.update({ where: { id: oi.itemId }, data: { stockState: back[back.length - 1] as never, version: { increment: 1 } } });
        await tx.orderItem.update({ where: { id: oi.id }, data: { voidedAt: new Date() } });
        await tx.listing.updateMany({ where: { itemId: oi.itemId, state: "SOLD_OUT" }, data: { state: "PUBLISHED" } });
        refunds.push((await tx.refund.create({ data: { paymentId: pay.id, orderItemId: oi.id, amountMinor: oi.priceMinor, reason: `Cancelled by ONEOFAKIND: ${reason}`, mode: "CANCEL" } })).id);
      }
      if (g.shippingMinor > 0) refunds.push((await tx.refund.create({ data: { paymentId: pay.id, amountMinor: g.shippingMinor, reason: "Shipping refund (cancellation)", mode: "SHIPPING" } })).id);
      await tx.fulfilmentGroup.update({ where: { id }, data: { state: "CANCELLED" } });
      const others = g.order.groups.filter((x) => x.id !== id && x.state !== "CANCELLED");
      if (!others.length) await tx.order.update({ where: { id: g.orderId }, data: { state: "REFUND_PENDING" } });
      await this.audit.log({ actorId: v.userId, action: "GROUP_CANCELLED_BY_STAFF", entity: "FulfilmentGroup", entityId: id, after: { reason } }, tx);
    });
    for (const r of refunds) await this.checkout.sendRefund(r);
    return { refunds: refunds.length };
  }

  @Get("admin/claims")
  @Auth("SUPPORT", "ADMIN")
  async claims(@Query() q: unknown) {
    const { state } = parse(z.object({ state: z.string().default("REQUESTED") }), q);
    const rows = await this.prisma.returnRequest.findMany({ where: { state: { in: state.split(",") as never } }, orderBy: { createdAt: "asc" }, include: { order: { include: { user: { select: { name: true } } } } } });
    const items = await this.prisma.orderItem.findMany({ where: { id: { in: rows.map((r) => r.orderItemId) } }, include: { item: { include: { conditionReports: { orderBy: { createdAt: "desc" }, take: 1 }, media: { where: { deletedAt: null }, take: 2, orderBy: { position: "asc" } } } }, group: true } });
    return { claims: rows.map((r) => { const oi = items.find((i) => i.id === r.orderItemId); return { id: r.id, state: r.state, reason: r.reason, createdAt: r.createdAt, orderRef: r.order.reference, buyer: r.order.user.name, evidence: r.evidenceKeys.map((_, i) => `/v1/admin/claims/${r.id}/evidence/${i}`), item: oi ? { title: oi.item.title, sku: oi.item.sku, priceMinor: oi.priceMinor, arrangement: oi.arrangement, disclosedDefects: oi.item.conditionReports[0]?.defects ?? [], photos: oi.item.media.map((m) => mediaUrl(m.id)), deliveredAt: oi.group.deliveredAt } : null }; }) };
  }

  @Get("admin/claims/:id/evidence/:n")
  @Auth("SUPPORT", "ADMIN")
  async evidence(@CurrentViewer() v: Viewer, @Param("id") id: string, @Param("n") n: string, @Res() res: Response) {
    const r = await this.prisma.returnRequest.findUnique({ where: { id } });
    const key = r?.evidenceKeys[Number(n)];
    if (!key) throw notFound("Evidence");
    const body = await this.storage.get(key);
    if (!body) throw notFound("Evidence");
    await this.audit.log({ actorId: v.userId, action: "CLAIM_EVIDENCE_VIEWED", entity: "ReturnRequest", entityId: id });
    res.type("image/webp").setHeader("Cache-Control", "private, no-store"); res.send(body);
  }

  @Post("admin/claims/:id/decide") @HttpCode(200)
  @Auth("SUPPORT", "ADMIN")
  async decide(@CurrentViewer() v: Viewer, @Param("id") id: string, @Body() body: unknown) {
    const input = parse(z.object({ approve: z.boolean(), note: z.string().trim().min(5).max(500), refundWithoutReturn: z.boolean().optional() }), body);
    await this.returns.decide(v.userId, id, input);
    return { ok: true };
  }
}

@Controller("admin/finance")
@Auth("FINANCE", "ADMIN")
export class FinanceController {
  constructor(private readonly prisma: PrismaService, private readonly finance: FinanceService) {}

  @Get("reconciliation")
  reconciliation() { return this.finance.reconciliation(); }

  @Get("payout-verifications")
  async queue() { return { sellers: await this.finance.payoutVerificationQueue() }; }

  @Post("payout-verifications/:sellerId") @HttpCode(200)
  async verify(@CurrentViewer() v: Viewer, @Param("sellerId") sellerId: string, @Body() body: unknown) {
    const { approve, note } = parse(z.object({ approve: z.boolean(), note: z.string().max(300).optional() }), body);
    await this.finance.verifyPayout(sellerId, v.userId, approve, note);
    return { ok: true };
  }

  @Get("statements")
  async statements(@Query() q: unknown) {
    const { state } = parse(z.object({ state: z.string().optional() }), q);
    const rows = await this.prisma.sellerStatement.findMany({ where: state ? { state: { in: state.split(",") as never } } : {}, orderBy: [{ periodEnd: "desc" }], take: 200, include: { seller: { select: { displayName: true, payoutVerifiedAt: true, payoutMethod: true } }, _count: { select: { lines: true } } } });
    return { statements: rows.map((s) => ({ id: s.id, seller: s.seller.displayName, payoutVerified: !!s.seller.payoutVerifiedAt, payoutMethod: s.seller.payoutMethod, periodStart: s.periodStart, periodEnd: s.periodEnd, state: s.state, grossMinor: s.grossMinor, commissionMinor: s.commissionMinor, refundsMinor: s.refundsMinor, netMinor: s.netMinor, lines: s._count.lines, payoutRef: s.payoutRef, paidAt: s.paidAt })) };
  }

  @Get("statements/:id")
  async statement(@Param("id") id: string, @Query() q: unknown, @Res({ passthrough: true }) res: Response) {
    const { format } = parse(z.object({ format: z.enum(["json", "csv"]).default("json") }), q);
    const s = await this.prisma.sellerStatement.findUnique({ where: { id }, include: { seller: true, lines: true } });
    if (!s) throw notFound("Statement");
    const items = await this.prisma.orderItem.findMany({ where: { id: { in: s.lines.map((l) => l.orderItemId) } }, include: { item: { select: { sku: true, title: true } }, group: { include: { order: { select: { reference: true } } } } } });
    const lines = s.lines.map((l) => { const oi = items.find((i) => i.id === l.orderItemId)!; return { orderRef: oi.group.order.reference, sku: oi.item.sku, title: oi.item.title, grossMinor: l.grossMinor, commissionMinor: l.commissionMinor, netMinor: l.grossMinor - l.commissionMinor }; });
    if (format === "csv") {
      res.setHeader("Content-Type", "text/csv; charset=utf-8");
      res.setHeader("Content-Disposition", `attachment; filename="statement-${s.seller.slug}-${s.periodEnd.toISOString().slice(0, 10)}.csv"`);
      return ["order,sku,title,gross_pkr,commission_pkr,net_pkr", ...lines.map((l) => [l.orderRef, l.sku, `"${l.title.replace(/"/g, '""')}"`, l.grossMinor / 100, l.commissionMinor / 100, l.netMinor / 100].join(","))].join("\n");
    }
    return { statement: { ...s, seller: { displayName: s.seller.displayName, payoutVerifiedAt: s.seller.payoutVerifiedAt, payoutAccountTitle: s.seller.payoutAccountTitle }, lines } };
  }

  @Post("statements/generate") @HttpCode(200)
  generate(@CurrentViewer() v: Viewer, @Body() body: unknown) {
    const { periodStart, periodEnd } = parse(z.object({ periodStart: z.coerce.date(), periodEnd: z.coerce.date() }), body);
    if (periodEnd <= periodStart) throw badRequest("Period end must be after the start.");
    return this.finance.generate(periodStart, periodEnd, v.userId);
  }

  @Post("statements/:id/finalize") @HttpCode(200)
  async finalize(@CurrentViewer() v: Viewer, @Param("id") id: string) { await this.finance.finalize(id, v.userId); return { ok: true }; }

  @Post("statements/:id/paid") @HttpCode(200)
  async paid(@CurrentViewer() v: Viewer, @Param("id") id: string, @Body() body: unknown) { await this.finance.markPaid(id, v.userId, parse(z.object({ payoutRef: z.string().trim().min(3).max(80) }), body).payoutRef); return { ok: true }; }

  @Get("ledger")
  async ledger(@Query() query: unknown) {
    const q = parse(page.extend({ type: z.string().optional(), ownerRef: z.string().optional(), refType: z.string().optional() }), query);
    const rows = await this.prisma.ledgerEntry.findMany({
      where: { ...(q.type || q.ownerRef ? { account: { ...(q.type ? { type: q.type as never } : {}), ...(q.ownerRef ? { ownerRef: q.ownerRef } : {}) } } : {}), ...(q.refType ? { refType: q.refType } : {}) },
      orderBy: { createdAt: "desc" }, take: q.limit + 1, ...(q.cursor ? { cursor: { id: q.cursor }, skip: 1 } : {}), include: { account: true },
    });
    const p = rows.slice(0, q.limit);
    return { entries: p.map((e) => ({ id: e.id, txnId: e.txnId, at: e.createdAt, account: e.account.type, ownerRef: e.account.ownerRef, debitMinor: e.debitMinor, creditMinor: e.creditMinor, refType: e.refType, refId: e.refId, memo: e.memo })), nextCursor: rows.length > q.limit ? p[p.length - 1]!.id : null };
  }

  @Get("payments")
  async payments(@Query() query: unknown) {
    const q = parse(page, query);
    const rows = await this.prisma.payment.findMany({ orderBy: { createdAt: "desc" }, take: q.limit, include: { order: { select: { reference: true } }, refunds: true, events: { select: { type: true, receivedAt: true, signatureVerified: true } } } });
    return { payments: rows.map((p) => ({ id: p.id, orderRef: p.order.reference, provider: p.provider, method: p.method, state: p.state, amountMinor: p.amountMinor, providerRef: p.providerRef, createdAt: p.createdAt, refunds: p.refunds.map((r) => ({ amountMinor: r.amountMinor, state: r.state, mode: r.mode })), events: p.events })) };
  }
}
