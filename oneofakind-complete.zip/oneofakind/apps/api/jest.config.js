/** API integration tests run against a real PostgreSQL database (DATABASE_URL_TEST, default ooak_test). */
module.exports = {
  testEnvironment: "node",
  roots: ["<rootDir>/test"],
  testRegex: ".*\\.test\\.ts$",
  transform: { "^.+\\.(t|j)s$": ["@swc/jest", { jsc: { parser: { syntax: "typescript", decorators: true }, transform: { legacyDecorator: true, decoratorMetadata: true }, target: "es2022" } }] },
  moduleNameMapper: { "^@ooak/shared$": "<rootDir>/../../packages/shared/src/index.ts" },
  globalSetup: "<rootDir>/test/global-setup.ts",
  setupFiles: ["<rootDir>/test/env.ts"],
  testTimeout: 30000,
};
