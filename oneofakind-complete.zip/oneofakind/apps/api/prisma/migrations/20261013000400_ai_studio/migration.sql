-- M8: AI studio. Generated assets are only published if the seller chose to use them in the listing.
ALTER TABLE "MediaAsset" ADD COLUMN "useInListing" BOOLEAN NOT NULL DEFAULT true;
-- Every AI-generated asset must carry the AI label.
ALTER TABLE "MediaAsset" ADD CONSTRAINT "media_ai_label_generated" CHECK (("aiJobId" IS NULL) OR "aiLabel" = true);
CREATE INDEX "AiJob_state_createdAt_idx" ON "AiJob"("state", "createdAt");
