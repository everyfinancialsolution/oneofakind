-- AlterTable
ALTER TABLE "Item" ADD COLUMN     "priceApprovedAt" TIMESTAMP(3),
ADD COLUMN     "proposedPriceMinor" INTEGER;

-- AlterTable
ALTER TABLE "IntakeManifest" ADD COLUMN     "courier" TEXT,
ADD COLUMN     "receivedAt" TIMESTAMP(3),
ADD COLUMN     "reconciledAt" TIMESTAMP(3),
ADD COLUMN     "trackingNo" TEXT;

