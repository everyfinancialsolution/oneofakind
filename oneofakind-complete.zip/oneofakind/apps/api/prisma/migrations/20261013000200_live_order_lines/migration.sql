-- DropIndex
DROP INDEX "OrderBundleLine_bundleId_key";

-- DropIndex
DROP INDEX "OrderItem_itemId_key";

-- AlterTable
ALTER TABLE "OrderBundleLine" ADD COLUMN     "voidedAt" TIMESTAMP(3);

-- AlterTable
ALTER TABLE "OrderItem" ADD COLUMN     "voidedAt" TIMESTAMP(3);

-- AlterTable
ALTER TABLE "Refund" ADD COLUMN     "mode" TEXT NOT NULL DEFAULT 'DAMAGE',
ADD COLUMN     "orderItemId" TEXT;

-- CreateIndex
CREATE INDEX "OrderBundleLine_bundleId_idx" ON "OrderBundleLine"("bundleId");

-- CreateIndex
CREATE INDEX "OrderItem_itemId_idx" ON "OrderItem"("itemId");


-- One LIVE order line per one-of-a-kind item / per bundle (history is kept; cancelled or returned lines are voided)
CREATE UNIQUE INDEX order_item_one_live ON "OrderItem" ("itemId") WHERE "voidedAt" IS NULL;
CREATE UNIQUE INDEX order_bundle_line_one_live ON "OrderBundleLine" ("bundleId") WHERE "voidedAt" IS NULL;
-- A line can be settled once (already unique on StatementLine.orderItemId) and refunds never exceed the line price (checked in service)
