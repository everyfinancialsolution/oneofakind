-- ONEOFAKIND integrity rules that Prisma cannot express (docs/DATABASE_SCHEMA.md).
-- IMPORTANT: when creating future migrations with `prisma migrate dev --create-only`, delete any generated
-- DROP statements for the objects below (Prisma does not model partial/expression indexes, triggers or sequences).

-- pg_trgm is created in the init migration (trigram indexes are modelled in schema.prisma)

-- 1. Money columns are never negative
ALTER TABLE "Item"            ADD CONSTRAINT item_price_nonneg      CHECK ("priceMinor" >= 0);
ALTER TABLE "Item"            ADD CONSTRAINT item_cost_nonneg       CHECK ("costMinor" IS NULL OR "costMinor" >= 0);
ALTER TABLE "Bundle"          ADD CONSTRAINT bundle_price_pos       CHECK ("priceMinor" > 0 AND "retailValueMinor" >= 0);
ALTER TABLE "OrderItem"       ADD CONSTRAINT order_item_price_nonneg CHECK ("priceMinor" >= 0);
ALTER TABLE "OrderBundleLine" ADD CONSTRAINT order_bundle_price_pos CHECK ("priceMinor" > 0);
ALTER TABLE "Order"           ADD CONSTRAINT order_totals_nonneg    CHECK ("subtotalMinor" >= 0 AND "shippingMinor" >= 0 AND "discountMinor" >= 0 AND "totalMinor" >= 0);
ALTER TABLE "Payment"         ADD CONSTRAINT payment_amount_pos     CHECK ("amountMinor" > 0);
ALTER TABLE "Refund"          ADD CONSTRAINT refund_amount_pos      CHECK ("amountMinor" > 0);
ALTER TABLE "LedgerEntry"     ADD CONSTRAINT ledger_one_side
  CHECK ("debitMinor" >= 0 AND "creditMinor" >= 0 AND ("debitMinor" = 0 OR "creditMinor" = 0) AND ("debitMinor" + "creditMinor") > 0);

-- 2. Every ledger transaction balances (checked at COMMIT) and entries are append-only
CREATE OR REPLACE FUNCTION ooak_ledger_txn_balanced() RETURNS trigger AS $$
DECLARE d bigint; c bigint;
BEGIN
  SELECT COALESCE(SUM("debitMinor"),0), COALESCE(SUM("creditMinor"),0) INTO d, c FROM "LedgerEntry" WHERE "txnId" = NEW."txnId";
  IF d <> c THEN RAISE EXCEPTION 'ledger txn % unbalanced: debit % credit %', NEW."txnId", d, c; END IF;
  RETURN NULL;
END $$ LANGUAGE plpgsql;
CREATE CONSTRAINT TRIGGER ledger_txn_balanced AFTER INSERT ON "LedgerEntry"
  DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION ooak_ledger_txn_balanced();

CREATE OR REPLACE FUNCTION ooak_append_only() RETURNS trigger AS $$
BEGIN RAISE EXCEPTION '% is append-only', TG_TABLE_NAME; END $$ LANGUAGE plpgsql;
CREATE TRIGGER ledger_append_only    BEFORE UPDATE OR DELETE ON "LedgerEntry" FOR EACH ROW EXECUTE FUNCTION ooak_append_only();
CREATE TRIGGER audit_append_only     BEFORE UPDATE OR DELETE ON "AuditLog"    FOR EACH ROW EXECUTE FUNCTION ooak_append_only();
CREATE TRIGGER scanevent_append_only BEFORE UPDATE OR DELETE ON "ScanEvent"   FOR EACH ROW EXECUTE FUNCTION ooak_append_only();

-- 3. One active reservation per item; one active bundle per item
CREATE UNIQUE INDEX stock_reservation_one_active ON "StockReservation" ("itemId") WHERE "releasedAt" IS NULL;
CREATE UNIQUE INDEX bundle_item_one_active       ON "BundleItem" ("itemId")       WHERE "releasedAt" IS NULL;

-- 4. A cart line is either a single item or a bundle
ALTER TABLE "CartItem" ADD CONSTRAINT cart_item_xor CHECK (("itemId" IS NOT NULL) <> ("bundleId" IS NOT NULL));

-- 5. Scan codes: right reference per kind, one active code per entity, code immutable
ALTER TABLE "ScanCode" ADD CONSTRAINT scan_code_ref_matches_kind CHECK (
  ("kind" = 'ITEM_PACK'   AND "itemId"   IS NOT NULL AND "bundleId" IS NULL AND "groupId" IS NULL AND "shipmentId" IS NULL) OR
  ("kind" = 'BUNDLE_PACK' AND "bundleId" IS NOT NULL AND "itemId"   IS NULL AND "groupId" IS NULL AND "shipmentId" IS NULL) OR
  ("kind" = 'ORDER_PACK'  AND "groupId"  IS NOT NULL AND "itemId"   IS NULL AND "bundleId" IS NULL AND "shipmentId" IS NULL) OR
  ("kind" = 'DISPATCH'    AND "shipmentId" IS NOT NULL AND "parentId" IS NOT NULL AND "itemId" IS NULL AND "bundleId" IS NULL)
);
CREATE UNIQUE INDEX scan_code_item_active     ON "ScanCode" ("itemId")     WHERE "kind" = 'ITEM_PACK'   AND "voidedAt" IS NULL;
CREATE UNIQUE INDEX scan_code_bundle_active   ON "ScanCode" ("bundleId")   WHERE "kind" = 'BUNDLE_PACK' AND "voidedAt" IS NULL;
CREATE UNIQUE INDEX scan_code_group_active    ON "ScanCode" ("groupId")    WHERE "kind" = 'ORDER_PACK'  AND "voidedAt" IS NULL;
CREATE UNIQUE INDEX scan_code_shipment_active ON "ScanCode" ("shipmentId") WHERE "kind" = 'DISPATCH'    AND "voidedAt" IS NULL;
CREATE OR REPLACE FUNCTION ooak_scan_code_immutable() RETURNS trigger AS $$
BEGIN
  IF NEW."code" <> OLD."code" OR NEW."kind" <> OLD."kind" THEN RAISE EXCEPTION 'scan code/kind are immutable'; END IF;
  RETURN NEW;
END $$ LANGUAGE plpgsql;
CREATE TRIGGER scan_code_immutable BEFORE UPDATE ON "ScanCode" FOR EACH ROW EXECUTE FUNCTION ooak_scan_code_immutable();

-- 6. Sequences feeding human/scan identifiers
CREATE SEQUENCE IF NOT EXISTS seq_scan_item_pack;
CREATE SEQUENCE IF NOT EXISTS seq_scan_bundle_pack;
CREATE SEQUENCE IF NOT EXISTS seq_scan_order_pack;
CREATE SEQUENCE IF NOT EXISTS seq_scan_dispatch;
CREATE SEQUENCE IF NOT EXISTS seq_order_ref;
CREATE SEQUENCE IF NOT EXISTS seq_application_seller;
CREATE SEQUENCE IF NOT EXISTS seq_application_reseller;
CREATE SEQUENCE IF NOT EXISTS seq_item_sku;
CREATE SEQUENCE IF NOT EXISTS seq_bundle_sku;

-- 7. Bundles: defence in depth when a bundle is PUBLISHED (the app validator in @ooak/shared is the primary gate)
CREATE OR REPLACE FUNCTION ooak_bundle_publish_check() RETURNS trigger AS $$
DECLARE n int; bad int;
BEGIN
  IF NEW."state" = 'PUBLISHED' AND (OLD."state" IS DISTINCT FROM 'PUBLISHED') THEN
    SELECT COUNT(*) INTO n FROM "BundleItem" WHERE "bundleId" = NEW."id" AND "releasedAt" IS NULL;
    IF n <> NEW."size" THEN RAISE EXCEPTION 'bundle % has % active pieces, size %', NEW."id", n, NEW."size"; END IF;
    IF NOT EXISTS (SELECT 1 FROM "BundleTier" WHERE "size" = NEW."size" AND "active") THEN
      RAISE EXCEPTION 'bundle size % is not an active tier', NEW."size"; END IF;
    SELECT COUNT(*) INTO bad FROM "BundleItem" bi JOIN "Item" i ON i."id" = bi."itemId"
      WHERE bi."bundleId" = NEW."id" AND bi."releasedAt" IS NULL
        AND (i."brandId" IS DISTINCT FROM NEW."brandId" OR i."styleId" IS DISTINCT FROM NEW."styleId"
             OR i."arrangement" <> NEW."arrangement" OR i."ownerType" <> NEW."ownerType" OR i."channel" <> 'BUNDLE');
    IF bad > 0 THEN RAISE EXCEPTION 'bundle % has % non-conforming pieces', NEW."id", bad; END IF;
  END IF;
  RETURN NEW;
END $$ LANGUAGE plpgsql;
CREATE TRIGGER bundle_publish_check BEFORE UPDATE ON "Bundle" FOR EACH ROW EXECUTE FUNCTION ooak_bundle_publish_check();

-- 8. Channel consistency: a piece in an active bundle can't have a PUBLISHED retail listing, and vice versa
CREATE OR REPLACE FUNCTION ooak_listing_channel_check() RETURNS trigger AS $$
BEGIN
  IF NEW."state" = 'PUBLISHED' AND EXISTS (SELECT 1 FROM "BundleItem" WHERE "itemId" = NEW."itemId" AND "releasedAt" IS NULL) THEN
    RAISE EXCEPTION 'item % is in an active bundle and cannot be published retail', NEW."itemId"; END IF;
  RETURN NEW;
END $$ LANGUAGE plpgsql;
CREATE TRIGGER listing_channel_check BEFORE INSERT OR UPDATE ON "Listing" FOR EACH ROW EXECUTE FUNCTION ooak_listing_channel_check();
CREATE OR REPLACE FUNCTION ooak_bundle_item_channel_check() RETURNS trigger AS $$
BEGIN
  IF NEW."releasedAt" IS NULL AND EXISTS (SELECT 1 FROM "Listing" WHERE "itemId" = NEW."itemId" AND "state" = 'PUBLISHED') THEN
    RAISE EXCEPTION 'item % has a published retail listing', NEW."itemId"; END IF;
  RETURN NEW;
END $$ LANGUAGE plpgsql;
CREATE TRIGGER bundle_item_channel_check BEFORE INSERT ON "BundleItem" FOR EACH ROW EXECUTE FUNCTION ooak_bundle_item_channel_check();

-- 9. Full-text search (Postgres FTS first; pg_trgm for typo tolerance)
CREATE INDEX item_fts ON "Item" USING GIN (to_tsvector('simple', coalesce("title",'') || ' ' || coalesce("description",'') || ' ' || coalesce("color",'') || ' ' || coalesce("size",'')));
