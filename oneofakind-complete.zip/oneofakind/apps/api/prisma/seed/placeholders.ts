/**
 * Dev/staging placeholder product photography: quiet editorial SVG plates (garment silhouette on ivory),
 * so the storefront has realistic imagery before real seller photos exist. Never used in production listings.
 */
export type Silhouette = "tee" | "jacket" | "hoodie" | "shirt" | "jeans" | "dress" | "sneaker" | "bag" | "cap" | "sweatshirt";

const SHAPES: Record<Silhouette, { body: string; details: string }> = {
  tee: {
    body: "M262 230 L345 196 Q400 236 455 196 L538 230 L640 330 L582 392 L540 360 L540 808 L260 808 L260 360 L218 392 L160 330 Z",
    details: "M345 196 Q400 250 455 196 M260 790 L540 790 M218 392 L260 360 M582 392 L540 360",
  },
  sweatshirt: {
    body: "M252 222 L345 192 Q400 228 455 192 L548 222 L628 320 L668 700 Q668 722 646 722 L604 722 Q590 722 588 706 L556 420 L556 808 L244 808 L244 420 L212 706 Q210 722 196 722 L154 722 Q132 722 132 700 L172 320 Z",
    details: "M345 192 Q400 244 455 192 M244 776 L556 776 M152 690 L190 690 M610 690 L648 690",
  },
  jacket: {
    body: "M248 214 L342 182 Q400 214 458 182 L552 214 L630 310 L670 708 L594 718 L558 410 L558 812 L242 812 L242 410 L206 718 L130 708 L170 310 Z",
    details: "M400 214 L400 812 M342 182 L372 286 L400 214 L428 286 L458 182 M300 560 L360 560 M440 560 L500 560 M242 780 L558 780",
  },
  hoodie: {
    body: "M252 230 L330 200 Q300 100 400 92 Q500 100 470 200 L548 230 L628 320 L666 700 L598 712 L556 420 L556 808 L244 808 L244 420 L202 712 L134 700 L172 320 Z",
    details: "M330 200 Q400 270 470 200 M384 250 L378 360 M416 250 L422 360 M300 600 L500 600 L520 700 L280 700 Z M244 776 L556 776",
  },
  shirt: {
    body: "M256 214 L350 186 L400 222 L450 186 L544 214 L626 312 L664 690 L594 700 L556 420 L556 812 L244 812 L244 420 L206 700 L136 690 L174 312 Z",
    details: "M350 186 L380 262 L400 222 L420 262 L450 186 M400 230 L400 812 M410 300 a5 5 0 1 0 0.1 0 M410 400 a5 5 0 1 0 0.1 0 M410 500 a5 5 0 1 0 0.1 0 M410 600 a5 5 0 1 0 0.1 0 M300 330 L360 330 L360 380 L300 380 Z",
  },
  jeans: {
    body: "M282 196 L518 196 L540 262 L566 830 L446 830 L404 392 L396 392 L354 830 L234 830 L260 262 Z",
    details: "M282 236 L518 236 M400 236 L400 392 M300 250 Q330 300 370 252 M500 250 Q470 300 430 252 M246 800 L350 800 M450 800 L554 800",
  },
  dress: {
    body: "M336 170 L362 170 Q400 226 438 170 L464 170 L482 268 L468 392 L604 830 L196 830 L332 392 L318 268 Z",
    details: "M332 392 L468 392 M362 170 Q400 240 438 170 M260 700 Q400 730 540 700",
  },
  sneaker: {
    body: "M150 640 Q156 540 256 516 L372 482 Q412 470 436 500 Q470 540 560 552 Q668 570 676 648 L676 700 L150 700 Z",
    details: "M150 676 L676 676 M300 520 L330 600 M340 508 L372 590 M384 496 L414 580 M460 560 Q520 600 600 590",
  },
  bag: {
    body: "M226 420 L574 420 Q594 420 596 440 L612 780 Q612 800 592 800 L208 800 Q188 800 188 780 L204 440 Q206 420 226 420 Z",
    details: "M300 420 Q300 280 400 280 Q500 280 500 420 M320 420 Q320 300 400 300 Q480 300 480 420 M204 520 L596 520 M384 520 L384 560 L416 560 L416 520",
  },
  cap: {
    body: "M246 580 Q252 392 400 380 Q548 392 554 580 Z M520 580 Q640 576 690 618 L540 622 Z",
    details: "M400 380 L400 580 M320 400 Q300 480 300 580 M480 400 Q500 480 500 580 M392 372 a8 8 0 1 0 16 0 a8 8 0 1 0 -16 0",
  },
};

function shade(hex: string, amt: number) {
  const n = parseInt(hex.slice(1), 16);
  const c = (v: number) => Math.max(0, Math.min(255, Math.round(v + amt)));
  const r = c(n >> 16), g = c((n >> 8) & 255), b = c(n & 255);
  return `#${((r << 16) | (g << 8) | b).toString(16).padStart(6, "0")}`;
}

/** variant 0 = front, 1 = detail crop, 2 = back/alternate light. 800x1000 (4:5). */
export function garmentSvg(shape: Silhouette, color: string, variant = 0, bg = "#EFE9DD"): string {
  const s = SHAPES[shape];
  const dark = shade(color, -38), light = shade(color, 26);
  const transform = variant === 1 ? "translate(-340 -260) scale(1.85)" : variant === 2 ? "translate(800 0) scale(-1 1)" : "";
  const bgTop = variant === 2 ? shade(bg, 6) : bg;
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 1000" width="800" height="1000">
<defs>
<linearGradient id="bg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${bgTop}"/><stop offset="1" stop-color="${shade(bg, -14)}"/></linearGradient>
<linearGradient id="fab" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${light}"/><stop offset=".55" stop-color="${color}"/><stop offset="1" stop-color="${dark}"/></linearGradient>
<pattern id="weave" width="6" height="6" patternUnits="userSpaceOnUse"><path d="M0 6 L6 0" stroke="#000" stroke-opacity=".05" stroke-width="1"/></pattern>
<filter id="soft" x="-20%" y="-20%" width="140%" height="140%"><feGaussianBlur stdDeviation="18"/></filter>
</defs>
<rect width="800" height="1000" fill="url(#bg)"/>
<ellipse cx="400" cy="880" rx="250" ry="26" fill="#000" opacity=".10" filter="url(#soft)"/>
<g transform="${transform}">
<path d="${s.body}" fill="url(#fab)" stroke="${dark}" stroke-width="3" stroke-linejoin="round"/>
<path d="${s.body}" fill="url(#weave)"/>
<path d="${s.details}" fill="none" stroke="${dark}" stroke-width="3" stroke-linecap="round" stroke-dasharray="${variant === 1 ? "7 6" : "0"}" opacity=".75"/>
</g>
</svg>`;
}

export const SILHOUETTE_FOR_CATEGORY: Record<string, Silhouette> = {
  jackets: "jacket", "hoodies-sweatshirts": "sweatshirt", "t-shirts": "tee", shirts: "shirt",
  "jeans-trousers": "jeans", dresses: "dress", shoes: "sneaker", bags: "bag", accessories: "cap",
};
