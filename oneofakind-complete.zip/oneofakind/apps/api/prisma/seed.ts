/**
 * Dev/staging seed. Refuses to run with NODE_ENV=production. Wipes and recreates demo data:
 * 6 sellers, ~100 items across categories/grades/arrangements (incl. grade C/D to prove bundle rules),
 * style tags, bundle tiers 5/10/15, 4 valid bundles, verified resellers + pending applications,
 * collections, staff users (phone-OTP login; dev OTP is shown in the API response), scan codes,
 * a managed-resale agreement + manifest in transit, direct-purchase offers, buying budget, CMS blocks.
 */
import { PrismaClient, type Prisma, type ConditionGrade, type SellingArrangement } from "@prisma/client";
import { mkdirSync, writeFileSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import {
  makeCode, applicationReference, idDocDeleteAfter, validateBundleComposition, allocate, money, COMMISSION_BPS, MANAGED_RETAIL_TIERS,
} from "@ooak/shared";
import { garmentSvg, SILHOUETTE_FOR_CATEGORY } from "./seed/placeholders";

if (process.env.NODE_ENV === "production") throw new Error("Refusing to seed a production database");
const prisma = new PrismaClient();
const STORAGE_DIR = resolve(process.env.STORAGE_DIR ?? join(__dirname, "..", "storage"));

// Deterministic PRNG so the seed is reproducible
let rngState = 20261013;
const rnd = () => ((rngState = (rngState * 1664525 + 1013904223) % 4294967296) / 4294967296);
const pick = <T>(xs: readonly T[]): T => xs[Math.floor(rnd() * xs.length)]!;
const between = (a: number, b: number) => Math.round(a + rnd() * (b - a));
const slugify = (s: string) => s.toLowerCase().replace(/['’]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
const pkr = (rupees: number) => rupees * 100;

function writeFile(key: string, body: string) {
  const p = join(STORAGE_DIR, key);
  mkdirSync(dirname(p), { recursive: true });
  writeFileSync(p, body);
}

async function nextval(seq: string): Promise<number> {
  const rows = await prisma.$queryRawUnsafe<{ v: bigint }[]>(`SELECT nextval('${seq}') AS v`);
  return Number(rows[0]!.v);
}

const CATEGORIES = [
  { slug: "clothing", name: "Clothing", parent: null, schema: null },
  { slug: "jackets", name: "Jackets & coats", parent: "clothing", schema: ["chest_cm", "length_cm", "sleeve_cm", "shoulder_cm"] },
  { slug: "hoodies-sweatshirts", name: "Hoodies & sweatshirts", parent: "clothing", schema: ["chest_cm", "length_cm", "sleeve_cm"] },
  { slug: "t-shirts", name: "T-shirts", parent: "clothing", schema: ["chest_cm", "length_cm"] },
  { slug: "shirts", name: "Shirts", parent: "clothing", schema: ["chest_cm", "length_cm", "sleeve_cm", "shoulder_cm"] },
  { slug: "jeans-trousers", name: "Jeans & trousers", parent: "clothing", schema: ["waist_cm", "inseam_cm", "rise_cm", "hip_cm"] },
  { slug: "dresses", name: "Dresses", parent: "clothing", schema: ["bust_cm", "waist_cm", "length_cm"] },
  { slug: "shoes", name: "Shoes", parent: null, schema: ["insole_cm", "eu_size"] },
  { slug: "bags", name: "Bags", parent: null, schema: ["width_cm", "height_cm", "depth_cm"] },
  { slug: "accessories", name: "Accessories", parent: null, schema: ["circumference_cm"] },
] as const;

const BRANDS = ["Nike", "Adidas", "Levi's", "Carhartt", "Ralph Lauren", "Tommy Hilfiger", "Champion", "The North Face", "Wrangler", "Dr. Martens", "Coach", "Zara", "Patagonia", "Lacoste"];
const STYLES = [
  { slug: "track-jackets", name: "Track jackets", cat: "jackets" },
  { slug: "90s-denim-jackets", name: "90s denim jackets", cat: "jackets" },
  { slug: "workwear-jackets", name: "Workwear jackets", cat: "jackets" },
  { slug: "fleece-jackets", name: "Fleece jackets", cat: "jackets" },
  { slug: "vintage-sweatshirts", name: "Vintage sweatshirts", cat: "hoodies-sweatshirts" },
  { slug: "band-tees", name: "Band & graphic tees", cat: "t-shirts" },
  { slug: "polo-shirts", name: "Polo shirts", cat: "shirts" },
  { slug: "straight-leg-jeans", name: "Straight-leg jeans", cat: "jeans-trousers" },
];

const MEASURE_RANGES: Record<string, [number, number]> = {
  chest_cm: [48, 66], length_cm: [64, 80], sleeve_cm: [58, 68], shoulder_cm: [42, 54], waist_cm: [34, 48], inseam_cm: [70, 84],
  rise_cm: [24, 32], hip_cm: [46, 60], bust_cm: [42, 52], insole_cm: [24, 30], eu_size: [38, 46], width_cm: [24, 40],
  height_cm: [18, 32], depth_cm: [8, 16], circumference_cm: [54, 60],
};
const CLOTHING_SIZES = ["XS", "S", "M", "L", "XL", "XXL"];
const COLORS: Record<string, string> = {
  Black: "#1E1D1B", Navy: "#1F2A44", "Washed blue": "#5B7895", Indigo: "#2E3F66", Olive: "#5C5F3A", Cream: "#E8DFC9", Grey: "#8D8B86",
  Burgundy: "#6B2A31", "Forest green": "#2F4A3A", Tan: "#B08A5B", White: "#F4F1EA", Red: "#A3302B", Brown: "#5E4330", Mustard: "#C29A3A",
};
const COLOR_NAMES = Object.keys(COLORS);

interface ItemSpec {
  cat: string; brand: string; style?: string; title: string; grade: ConditionGrade; price: number; weight: number; color?: string; size?: string;
}

const RETAIL_TEMPLATES: Array<Omit<ItemSpec, "grade" | "price" | "color" | "size"> & { price: [number, number] }> = [
  { cat: "jackets", brand: "The North Face", style: "fleece-jackets", title: "Denali fleece jacket", price: [6500, 14000], weight: 650 },
  { cat: "jackets", brand: "Carhartt", style: "workwear-jackets", title: "Detroit canvas work jacket", price: [9000, 22000], weight: 1300 },
  { cat: "jackets", brand: "Levi's", style: "90s-denim-jackets", title: "Type III trucker denim jacket", price: [5500, 12000], weight: 900 },
  { cat: "jackets", brand: "Adidas", style: "track-jackets", title: "Firebird track jacket", price: [3800, 8500], weight: 450 },
  { cat: "jackets", brand: "Patagonia", style: "fleece-jackets", title: "Retro-X pile fleece", price: [9500, 19000], weight: 700 },
  { cat: "jackets", brand: "Ralph Lauren", title: "Wool blend harrington jacket", price: [7000, 16000], weight: 800 },
  { cat: "hoodies-sweatshirts", brand: "Champion", style: "vintage-sweatshirts", title: "Reverse weave crewneck sweatshirt", price: [3500, 7500], weight: 600 },
  { cat: "hoodies-sweatshirts", brand: "Nike", title: "Embroidered swoosh hoodie", price: [3800, 8000], weight: 650 },
  { cat: "hoodies-sweatshirts", brand: "Tommy Hilfiger", title: "Colour-block flag sweatshirt", price: [3200, 6500], weight: 550 },
  { cat: "t-shirts", brand: "Nike", style: "band-tees", title: "Single-stitch graphic tee", price: [1800, 4500], weight: 200 },
  { cat: "t-shirts", brand: "Champion", style: "band-tees", title: "Varsity logo tee", price: [1500, 3500], weight: 200 },
  { cat: "t-shirts", brand: "Carhartt", title: "Pocket heavyweight tee", price: [2200, 4200], weight: 260 },
  { cat: "shirts", brand: "Ralph Lauren", style: "polo-shirts", title: "Custom fit pique polo", price: [2800, 6000], weight: 280 },
  { cat: "shirts", brand: "Lacoste", style: "polo-shirts", title: "Classic L.12.12 polo", price: [3200, 7000], weight: 280 },
  { cat: "shirts", brand: "Tommy Hilfiger", title: "Oxford button-down shirt", price: [2500, 5500], weight: 300 },
  { cat: "jeans-trousers", brand: "Levi's", style: "straight-leg-jeans", title: "501 original straight jeans", price: [3500, 9000], weight: 700 },
  { cat: "jeans-trousers", brand: "Wrangler", style: "straight-leg-jeans", title: "Cowboy cut rigid jeans", price: [3000, 7000], weight: 750 },
  { cat: "jeans-trousers", brand: "Carhartt", title: "Double-knee carpenter trousers", price: [5500, 12000], weight: 900 },
  { cat: "dresses", brand: "Zara", title: "Satin slip midi dress", price: [2200, 5000], weight: 250 },
  { cat: "dresses", brand: "Ralph Lauren", title: "Floral tea dress", price: [3800, 8500], weight: 320 },
  { cat: "shoes", brand: "Dr. Martens", title: "1460 leather boots", price: [9000, 18000], weight: 1600 },
  { cat: "shoes", brand: "Nike", title: "Air Force 1 low trainers", price: [6000, 14000], weight: 1100 },
  { cat: "shoes", brand: "Adidas", title: "Samba leather trainers", price: [6500, 13000], weight: 950 },
  { cat: "bags", brand: "Coach", title: "Leather shoulder bag", price: [8000, 25000], weight: 700 },
  { cat: "bags", brand: "The North Face", title: "Base camp duffel", price: [4500, 9000], weight: 1200 },
  { cat: "accessories", brand: "Carhartt", title: "Acrylic watch beanie", price: [1200, 2500], weight: 90 },
  { cat: "accessories", brand: "Ralph Lauren", title: "Embroidered pony cap", price: [1800, 3800], weight: 110 },
];

const DEFECTS_BY_LETTER: Record<string, Array<{ type: string; location: string; severity: string }>> = {
  A: [], B: [{ type: "light fade", location: "cuffs", severity: "minor" }],
  C: [{ type: "small stain", location: "lower front", severity: "moderate" }, { type: "loose seam", location: "left underarm", severity: "minor" }],
  D: [{ type: "hole", location: "back hem", severity: "major" }, { type: "heavy fade", location: "overall", severity: "moderate" }],
};

async function wipe() {
  const tables = await prisma.$queryRawUnsafe<{ tablename: string }[]>(
    `SELECT tablename FROM pg_tables WHERE schemaname='public' AND tablename <> '_prisma_migrations'`,
  );
  await prisma.$executeRawUnsafe(`TRUNCATE ${tables.map((t) => `"${t.tablename}"`).join(", ")} RESTART IDENTITY CASCADE`);
  for (const s of ["seq_scan_item_pack", "seq_scan_bundle_pack", "seq_scan_order_pack", "seq_scan_dispatch", "seq_order_ref",
    "seq_application_seller", "seq_application_reseller", "seq_item_sku", "seq_bundle_sku"]) {
    await prisma.$executeRawUnsafe(`ALTER SEQUENCE ${s} RESTART WITH 1`);
  }
}

async function main() {
  await wipe();
  const now = new Date();

  // ── Staff (phone-OTP login, no passwords) ──
  const staffDefs = [
    { name: "Moon (Admin)", phone: "+923000000001", roles: ["ADMIN", "CUSTOMER"] },
    { name: "Warehouse Lead", phone: "+923000000002", roles: ["WAREHOUSE"] },
    { name: "Support Desk", phone: "+923000000003", roles: ["SUPPORT"] },
    { name: "Finance Team", phone: "+923000000004", roles: ["FINANCE"] },
    { name: "Moderator", phone: "+923000000005", roles: ["MODERATOR"] },
    { name: "Seller Agent", phone: "+923000000006", roles: ["SELLER_AGENT", "SUPPORT"] },
  ] as const;
  const staff: Record<string, string> = {};
  for (const s of staffDefs) {
    const u = await prisma.user.create({ data: { name: s.name, phone: s.phone, phoneVerified: now, activatedAt: now, roles: [...s.roles] } });
    staff[s.roles[0]] = u.id;
  }

  // ── Catalogue ──
  const catId: Record<string, string> = {};
  let sort = 0;
  for (const c of CATEGORIES) {
    const row = await prisma.category.create({
      data: {
        slug: c.slug, name: c.name, sortOrder: sort++, parentId: c.parent ? catId[c.parent] : null,
        attributeSchema: c.schema ? { measurements: c.schema } : undefined,
      },
    });
    catId[c.slug] = row.id;
  }
  const brandId: Record<string, string> = {};
  for (const b of BRANDS) brandId[b] = (await prisma.brand.create({ data: { name: b, slug: slugify(b), verifiedBrand: true } })).id;
  const styleId: Record<string, string> = {};
  for (const s of STYLES) styleId[s.slug] = (await prisma.styleTag.create({ data: { slug: s.slug, name: s.name, categoryId: catId[s.cat] } })).id;
  for (const size of [5, 10, 15]) await prisma.bundleTier.create({ data: { size, active: true, minPriceMinor: pkr(1000) * size } });

  const locations: string[] = [];
  for (const code of ["LHR-A-01-1", "LHR-A-01-2", "LHR-A-02-1", "LHR-B-01-1", "LHR-B-02-3", "LHR-BULK-01"])
    locations.push((await prisma.storageLocation.create({ data: { code, label: `Lahore warehouse ${code}` } })).id);

  // Commission rules (seed from adopted defaults; finance edits them in /admin/settings)
  const eff = new Date("2026-10-01T00:00:00Z");
  await prisma.commissionRule.createMany({
    data: [
      { arrangement: "SELF_MANAGED", channel: "RETAIL", bps: COMMISSION_BPS.RETAIL_SELF_MANAGED, effectiveFrom: eff },
      { arrangement: "MANAGED_RESALE", channel: "RETAIL", bps: MANAGED_RETAIL_TIERS[0].bps, effectiveFrom: eff },
      { arrangement: "SELF_MANAGED", channel: "BUNDLE", bps: COMMISSION_BPS.BUNDLE_SELF_MANAGED, effectiveFrom: eff },
      { arrangement: "MANAGED_RESALE", channel: "BUNDLE", bps: COMMISSION_BPS.BUNDLE_MANAGED, effectiveFrom: eff },
    ],
  });
  await prisma.setting.createMany({
    data: [
      { key: "shipping.flatRates", value: { LOCAL: pkr(250), NATIONAL: pkr(350), localCities: ["Lahore"] } },
      { key: "shipping.bundleRatePerKgMinor", value: pkr(120) },
      { key: "features", value: { aiListingText: true, aiBackgroundRemoval: true, aiModelImagery: false, tryOn: false, viewer3d: true } },
    ],
  });

  // ── Sellers ──
  const sellerDefs = [
    { slug: "lahore-vintage-co", name: "Lahore Vintage Co.", type: "RESELLER", city: "Lahore", owner: "Bilal Ahmed", phone: "+923010000001", bio: "Hand-picked 90s outerwear and workwear, sourced from Landa Bazaar and graded piece by piece." },
    { slug: "karachi-thrift-house", name: "Karachi Thrift House", type: "BUSINESS", city: "Karachi", owner: "Sana Qureshi", phone: "+923010000002", bio: "Sweatshirts, denim and everyday classics. Every piece measured flat in centimetres." },
    { slug: "ayeshas-closet", name: "Ayesha's Closet", type: "INDIVIDUAL", city: "Islamabad", owner: "Ayesha Malik", phone: "+923010000003", bio: "Dresses and occasion pieces from my own wardrobe, worn with love." },
    { slug: "peshawar-denim-depot", name: "Peshawar Denim Depot", type: "RESELLER", city: "Peshawar", owner: "Imran Khan Afridi", phone: "+923010000004", bio: "Denim specialists. Trucker jackets, straight-leg jeans and rigid cuts." },
    { slug: "retro-rawalpindi", name: "Retro Rawalpindi", type: "RESELLER", city: "Rawalpindi", owner: "Hamza Raja", phone: "+923010000005", bio: "Sportswear from the 90s and 2000s: track jackets, tees and trainers." },
    { slug: "multan-market-finds", name: "Multan Market Finds", type: "INDIVIDUAL", city: "Multan", owner: "Zainab Shah", phone: "+923010000006", bio: "Small batches of bags, accessories and shoes." },
  ] as const;
  const sellers: Record<string, { id: string; userId: string }> = {};
  for (const s of sellerDefs) {
    const seq = await nextval("seq_application_seller");
    const app = await prisma.onboardingApplication.create({
      data: {
        reference: applicationReference("SELLER", seq), kind: "SELLER", status: "APPROVED", channel: seq % 2 ? "SELF_SERVE" : "ASSISTED_WHATSAPP",
        fullName: s.owner, phone: s.phone, city: s.city, businessName: s.name, intendedSellerType: s.type, decidedById: staff.ADMIN, decidedAt: now,
        consentMethod: seq % 2 ? null : "WHATSAPP_MESSAGE", consentAt: seq % 2 ? null : now, registeredById: seq % 2 ? null : staff.SELLER_AGENT,
      },
    });
    const user = await prisma.user.create({
      data: { name: s.owner, phone: s.phone, phoneVerified: now, activatedAt: now, roles: ["CUSTOMER", "SELLER"], createdByStaffId: app.registeredById },
    });
    await prisma.onboardingApplication.update({ where: { id: app.id }, data: { applicantUserId: user.id } });
    const sp = await prisma.sellerProfile.create({
      data: {
        userId: user.id, slug: s.slug, displayName: s.name, type: s.type, status: "VERIFIED", city: s.city, bio: s.bio, cnicLast4: String(between(1000, 9999)),
        applicationId: app.id, payoutAccountTitle: s.owner, payoutVerifiedAt: now, payoutVerifiedById: staff.FINANCE,
        payoutMethod: { kind: "BANK", bank: "Meezan Bank", accountMasked: `****${between(1000, 9999)}` }, allowStaffListing: true,
        ratingAvg: Number((4.3 + rnd() * 0.7).toFixed(1)), ratingCount: between(8, 140),
      },
    });
    for (const t of ["TERMS", "PRIVACY"] as const) await prisma.consentRecord.create({ data: { userId: user.id, type: t, version: "2026-10", granted: true } });
    sellers[s.slug] = { id: sp.id, userId: user.id };
  }

  // ── Items ──
  const allItems: Array<{ id: string; sku: string; slug?: string }> = [];
  async function createItem(spec: ItemSpec, opts: {
    sellerSlug: string; arrangement: SellingArrangement; ownerType?: "SELLER" | "PLATFORM"; stockState?: Prisma.ItemCreateInput["stockState"];
    listingState?: "PUBLISHED" | "PENDING_REVIEW" | "DRAFT" | null; channel?: "RETAIL" | "BUNDLE"; locationId?: string | null; costMinor?: number; directPurchaseId?: string;
    publishedDaysAgo?: number;
  }) {
    const seq = await nextval("seq_item_sku");
    const sku = `OOAK-${String(seq).padStart(6, "0")}`;
    const color = spec.color ?? pick(COLOR_NAMES);
    const schema = CATEGORIES.find((c) => c.slug === spec.cat)!.schema ?? [];
    const measurements = Object.fromEntries(schema.map((k) => [k, between(...MEASURE_RANGES[k]!)]));
    const size = spec.size ?? (spec.cat === "shoes" ? `EU ${measurements.eu_size}` : spec.cat === "bags" || spec.cat === "accessories" ? "One size"
      : spec.cat === "jeans-trousers" ? `W${Math.round((measurements.waist_cm as number) * 2 / 2.54)} L${Math.round((measurements.inseam_cm as number) / 2.54)}` : pick(CLOTHING_SIZES));
    const letter = spec.grade === "NEW_WITH_TAGS" || spec.grade === "EXCELLENT" ? "A" : spec.grade === "VERY_GOOD" ? "B" : spec.grade === "GOOD" ? "C" : "D";
    const title = `${spec.brand} ${spec.title}`;
    const managed = opts.arrangement !== "SELF_MANAGED";
    const item = await prisma.item.create({
      data: {
        sku, sellerId: sellers[opts.sellerSlug]!.id, categoryId: catId[spec.cat]!, brandId: brandId[spec.brand], styleId: spec.style ? styleId[spec.style] : null,
        arrangement: opts.arrangement, ownerType: opts.ownerType ?? "SELLER", stockState: opts.stockState ?? "AVAILABLE", conditionGrade: spec.grade,
        title, size, color, measurements, weightGrams: spec.weight, priceMinor: pkr(spec.price), channel: opts.channel ?? "RETAIL",
        locationId: managed ? (opts.locationId ?? pick(locations)) : null, costMinor: opts.costMinor, directPurchaseId: opts.directPurchaseId,
        material: spec.cat === "jeans-trousers" || spec.style === "90s-denim-jackets" ? "100% cotton denim (per care label)" : null,
        description: `${title} in ${color.toLowerCase()}. Measured flat: ${Object.entries(measurements).map(([k, v]) => `${k.replace("_cm", "").replace("_", " ")} ${v}${k.endsWith("_cm") ? " cm" : ""}`).join(", ")}. ${letter === "A" ? "Excellent condition, no flaws found." : letter === "B" ? "Light wear only; any marks are photographed." : "Has disclosed flaws, see the condition report and photos."}`,
      },
    });
    const shape = SILHOUETTE_FOR_CATEGORY[spec.cat]!;
    for (let v = 0; v < 3; v++) {
      const key = `public/seed/${sku}-${v + 1}.svg`;
      writeFile(key, garmentSvg(shape, COLORS[color]!, v));
      await prisma.mediaAsset.create({
        data: { itemId: item.id, kind: "ORIGINAL", visibility: "PUBLIC", storageKey: key, mime: "image/svg+xml", bytes: 4000, width: 800, height: 1000, approvedForPublish: true, position: v },
      });
    }
    await prisma.conditionReport.create({
      data: { itemId: item.id, grade: spec.grade, defects: DEFECTS_BY_LETTER[letter], source: managed ? "WAREHOUSE" : "SELLER", inspectedById: managed ? staff.WAREHOUSE : null, notes: managed ? "Inspected at Lahore warehouse." : null },
    });
    if (managed) {
      await prisma.custodyEvent.createMany({
        data: [
          { itemId: item.id, fromParty: "SELLER", toParty: "COURIER:intake", note: "Sent to warehouse", createdAt: new Date(now.getTime() - 20 * 86_400_000) },
          { itemId: item.id, fromParty: "COURIER:intake", toParty: "WAREHOUSE:LHR", locationId: item.locationId, actorId: staff.WAREHOUSE, note: "Received and shelved", createdAt: new Date(now.getTime() - 18 * 86_400_000) },
        ],
      });
    }
    let slug: string | undefined;
    if (opts.listingState) {
      slug = `${slugify(title)}-${sku.slice(5)}`;
      const publishedAt = opts.listingState === "PUBLISHED" ? new Date(now.getTime() - (opts.publishedDaysAgo ?? between(0, 30)) * 86_400_000) : null;
      await prisma.listing.create({ data: { itemId: item.id, sellerId: item.sellerId, slug, state: opts.listingState, publishedAt, moderatedById: publishedAt ? staff.MODERATOR : null } });
    }
    allItems.push({ id: item.id, sku, slug });
    return item;
  }

  const gradesRetail: ConditionGrade[] = ["NEW_WITH_TAGS", "EXCELLENT", "EXCELLENT", "VERY_GOOD", "VERY_GOOD", "VERY_GOOD", "GOOD", "FAIR"];
  const sellerSlugs = Object.keys(sellers);
  for (let i = 0; i < 62; i++) {
    const t = RETAIL_TEMPLATES[i % RETAIL_TEMPLATES.length]!;
    const grade = pick(gradesRetail);
    const discount = grade === "GOOD" ? 0.75 : grade === "FAIR" ? 0.55 : 1;
    const price = Math.round((between(t.price[0], t.price[1]) * discount) / 50) * 50;
    const sellerSlug = t.cat === "dresses" ? "ayeshas-closet" : t.cat === "bags" || t.cat === "accessories" ? "multan-market-finds" : sellerSlugs[i % sellerSlugs.length]!;
    const arrangement: SellingArrangement = i % 5 === 0 && price >= 2000 ? "MANAGED_RESALE" : "SELF_MANAGED";
    const listingState = i % 17 === 3 ? "PENDING_REVIEW" : i % 23 === 5 ? "DRAFT" : "PUBLISHED";
    await createItem({ ...t, grade, price, size: undefined, color: undefined }, {
      sellerSlug, arrangement, listingState, stockState: listingState === "PUBLISHED" ? "AVAILABLE" : "READY_TO_LIST",
    });
  }

  // ── Direct purchase: one TRANSFERRED collection (platform-owned retail + a platform bundle), one open offer ──
  const dpDone = await prisma.directPurchase.create({
    data: {
      sellerId: sellers["karachi-thrift-house"]!.id, state: "TRANSFERRED", title: "Champion sweatshirt lot (15) + 2 jackets",
      description: "Bulk lot of Champion reverse-weave sweatshirts and two outerwear pieces.", expectedRetailMinor: 0, offerMinor: 0,
      approvedById: staff.ADMIN, budgetCode: "BUY-2026-10", paymentRef: "BANK-TRF-778812", offerExpiresAt: new Date(now.getTime() - 5 * 86_400_000),
    },
  });
  const platformItems: Array<{ id: string; priceMinor: number }> = [];
  const champColors = ["Grey", "Navy", "Burgundy", "Forest green", "Black", "Cream"];
  for (let i = 0; i < 15; i++) {
    const it = await createItem(
      { cat: "hoodies-sweatshirts", brand: "Champion", style: "vintage-sweatshirts", title: "Reverse weave crewneck sweatshirt", grade: i % 3 ? "EXCELLENT" : "VERY_GOOD", price: between(3800, 5500), weight: 600, color: champColors[i % champColors.length], size: CLOTHING_SIZES[1 + (i % 4)] },
      { sellerSlug: "karachi-thrift-house", arrangement: "DIRECT_PURCHASE", ownerType: "PLATFORM", channel: "BUNDLE", listingState: null, directPurchaseId: dpDone.id, locationId: locations[5] },
    );
    platformItems.push({ id: it.id, priceMinor: it.priceMinor });
  }
  for (const t of [RETAIL_TEMPLATES[0]!, RETAIL_TEMPLATES[1]!]) {
    const it = await createItem({ ...t, grade: "EXCELLENT", price: t.price[1] }, { sellerSlug: "karachi-thrift-house", arrangement: "DIRECT_PURCHASE", ownerType: "PLATFORM", listingState: "PUBLISHED", directPurchaseId: dpDone.id });
    platformItems.push({ id: it.id, priceMinor: it.priceMinor });
  }
  const dpRetail = platformItems.reduce((a, b) => a + b.priceMinor, 0);
  const dpOffer = Math.round((dpRetail * 0.4) / 10000) * 10000;
  await prisma.directPurchase.update({ where: { id: dpDone.id }, data: { expectedRetailMinor: dpRetail, offerMinor: dpOffer } });
  const costs = allocate(money(dpOffer), platformItems.map((p) => p.priceMinor));
  const invAcct = await prisma.ledgerAccount.create({ data: { type: "INVENTORY_ASSET", ownerRef: "PLATFORM" } });
  const cashAcct = await prisma.ledgerAccount.create({ data: { type: "CASH_PROVIDER", ownerRef: "PLATFORM" } });
  for (const [idx, p] of platformItems.entries()) {
    const cost = costs[idx]!.amountMinor;
    await prisma.item.update({ where: { id: p.id }, data: { costMinor: cost } });
    const tr = await prisma.ownershipTransfer.create({ data: { directPurchaseId: dpDone.id, itemId: p.id, priceMinor: cost, paymentRef: "BANK-TRF-778812", handoverVerifiedById: staff.WAREHOUSE } });
    const txnId = `seed-transfer-${tr.id}`;
    await prisma.ledgerEntry.createMany({
      data: [
        { txnId, accountId: invAcct.id, debitMinor: cost, refType: "OWNERSHIP_TRANSFER", refId: tr.id, memo: "Direct purchase: inventory acquired" },
        { txnId, accountId: cashAcct.id, creditMinor: cost, refType: "OWNERSHIP_TRANSFER", refId: tr.id, memo: "Direct purchase: paid seller" },
      ],
    });
  }
  // Open offer the seller must respond to (demonstrates "offer made - not purchased" copy)
  const dpOpen = await prisma.directPurchase.create({
    data: {
      sellerId: sellers["lahore-vintage-co"]!.id, state: "OFFER_MADE", title: "Three Carhartt work jackets", description: "Detroit and Active jackets, light wear.",
      expectedRetailMinor: pkr(48000), sellerAskMinor: pkr(22000), offerMinor: pkr(19000), offerExpiresAt: new Date(now.getTime() + 60 * 3_600_000),
      approvedById: staff.ADMIN, budgetCode: "BUY-2026-10",
    },
  });
  for (let i = 0; i < 3; i++)
    await createItem({ ...RETAIL_TEMPLATES[1]!, grade: "VERY_GOOD", price: 16000 }, { sellerSlug: "lahore-vintage-co", arrangement: "DIRECT_PURCHASE", stockState: "EXPECTED", listingState: null, directPurchaseId: dpOpen.id });
  await prisma.directPurchase.create({
    data: { sellerId: sellers["retro-rawalpindi"]!.id, state: "SUBMITTED", title: "Nike Air Max 95 (pair)", description: "Worn twice, original box.", sellerAskMinor: pkr(15000) },
  });
  await prisma.buyingBudget.create({
    data: { code: "BUY-2026-10", label: "October 2026 buying budget", limitMinor: pkr(600000), periodStart: new Date("2026-10-01T00:00:00Z"), periodEnd: new Date("2026-11-01T00:00:00Z") },
  });

  // ── Bundles (4 valid: 5 / 10 / 15 / 5) ──
  async function makeBundle(opts: { sellerSlug: string | null; brand: string; style: string; cat: string; size: number; pieceTitle: string; weight: number; arrangement: SellingArrangement; pieces?: Array<{ id: string; priceMinor: number }>; priceRatio: number }) {
    const pieces = opts.pieces ?? [];
    if (!opts.pieces) {
      for (let i = 0; i < opts.size; i++) {
        const it = await createItem(
          { cat: opts.cat, brand: opts.brand, style: opts.style, title: opts.pieceTitle, grade: i % 4 === 0 ? "VERY_GOOD" : "EXCELLENT", price: between(3500, 6500), weight: opts.weight, color: pick(COLOR_NAMES), size: CLOTHING_SIZES[i % CLOTHING_SIZES.length] },
          { sellerSlug: opts.sellerSlug!, arrangement: opts.arrangement, channel: "BUNDLE", listingState: null },
        );
        pieces.push({ id: it.id, priceMinor: it.priceMinor });
      }
    }
    const items = await prisma.item.findMany({ where: { id: { in: pieces.map((p) => p.id) } } });
    const retailValue = items.reduce((a, b) => a + b.priceMinor, 0);
    const priceMinor = Math.max(pkr(1000) * opts.size, Math.round((retailValue * opts.priceRatio) / 10000) * 10000);
    const ownerType = opts.sellerSlug ? "SELLER" : "PLATFORM";
    const draft = { size: opts.size, brandId: brandId[opts.brand]!, styleId: styleId[opts.style]!, sellerId: opts.sellerSlug ? sellers[opts.sellerSlug]!.id : null, ownerType, arrangement: opts.arrangement, priceMinor, currency: "PKR" } as const;
    const issues = validateBundleComposition(draft, items.map((i) => ({ ...i, refRetailMinor: i.priceMinor, activeBundleId: null, hasPublishedRetailListing: false })));
    if (issues.length) throw new Error(`seed bundle invalid: ${JSON.stringify(issues)}`);
    const seq = await nextval("seq_bundle_sku");
    const sku = `OOAK-L-${String(seq).padStart(6, "0")}`;
    const title = `${opts.size} × ${opts.brand} ${STYLES.find((s) => s.slug === opts.style)!.name.toLowerCase()}`;
    const b = await prisma.bundle.create({
      data: {
        sku, slug: `${slugify(title)}-${sku.slice(7)}`, title, description: `A lot of ${opts.size} ${opts.brand} ${STYLES.find((s) => s.slug === opts.style)!.name.toLowerCase()}, mixed sizes and colours, every piece graded A or B and photographed.`,
        sellerId: draft.sellerId, ownerType, arrangement: opts.arrangement, brandId: draft.brandId, styleId: draft.styleId, categoryId: catId[opts.cat]!, size: opts.size,
        priceMinor, retailValueMinor: retailValue, state: "DRAFT", minConditionGrade: "VERY_GOOD",
        items: { create: items.map((it, idx) => ({ itemId: it.id, position: idx, refRetailMinor: it.priceMinor })) },
      },
    });
    await prisma.bundle.update({ where: { id: b.id }, data: { state: "PENDING_REVIEW" } });
    await prisma.bundle.update({ where: { id: b.id }, data: { state: "PUBLISHED", publishedAt: new Date(now.getTime() - between(1, 10) * 86_400_000), moderatedById: staff.MODERATOR } });
    await prisma.item.updateMany({ where: { id: { in: items.map((i) => i.id) } }, data: { stockState: "AVAILABLE" } });
    return b;
  }
  await makeBundle({ sellerSlug: "retro-rawalpindi", brand: "Nike", style: "track-jackets", cat: "jackets", size: 5, pieceTitle: "Woven track jacket", weight: 450, arrangement: "SELF_MANAGED", priceRatio: 0.6 });
  await makeBundle({ sellerSlug: "peshawar-denim-depot", brand: "Levi's", style: "90s-denim-jackets", cat: "jackets", size: 10, pieceTitle: "Type III trucker denim jacket", weight: 900, arrangement: "SELF_MANAGED", priceRatio: 0.58 });
  await makeBundle({ sellerSlug: null, brand: "Champion", style: "vintage-sweatshirts", cat: "hoodies-sweatshirts", size: 15, pieceTitle: "", weight: 600, arrangement: "DIRECT_PURCHASE", pieces: platformItems.slice(0, 15), priceRatio: 0.6 });

  // Managed-resale agreement + managed bundle + manifest in transit
  const agreement = await prisma.managedResaleAgreement.create({
    data: {
      sellerId: sellers["lahore-vintage-co"]!.id, status: "ACTIVE", commissionBps: 3000, requiresPriceApproval: true, storageDays: 90, unsoldPolicy: "RETURN",
      effectiveFrom: new Date("2026-09-15T00:00:00Z"), approvedById: staff.ADMIN, approvedAt: new Date("2026-09-15T00:00:00Z"), requestNote: "Moving my winter stock to managed resale.",
    },
  });
  await makeBundle({ sellerSlug: "lahore-vintage-co", brand: "Carhartt", style: "workwear-jackets", cat: "jackets", size: 5, pieceTitle: "Active duck hooded jacket", weight: 1200, arrangement: "MANAGED_RESALE", priceRatio: 0.62 });
  const manifest = await prisma.intakeManifest.create({
    data: { sellerId: sellers["lahore-vintage-co"]!.id, agreementId: agreement.id, state: "IN_TRANSIT", expectedCount: 4, notes: "Sent with Leopards, 1 carton." },
  });
  const manifestLines = [
    { d: "The North Face Nuptse puffer, black, size M", cat: "jackets", brand: "The North Face", p: 18000 },
    { d: "Levi's 550 relaxed jeans, W32", cat: "jeans-trousers", brand: "Levi's", p: 4500 },
    { d: "Ralph Lauren cable knit jumper, cream", cat: "hoodies-sweatshirts", brand: "Ralph Lauren", p: 6500 },
    { d: "Adidas Gazelle trainers, EU 42", cat: "shoes", brand: "Adidas", p: 7000 },
  ];
  for (const l of manifestLines) {
    const seq = await nextval("seq_item_sku");
    const sku = `OOAK-${String(seq).padStart(6, "0")}`;
    const item = await prisma.item.create({
      data: { sku, sellerId: sellers["lahore-vintage-co"]!.id, categoryId: catId[l.cat]!, brandId: brandId[l.brand], arrangement: "MANAGED_RESALE", stockState: "EXPECTED", title: l.d.split(",")[0]!, priceMinor: pkr(l.p) },
    });
    await prisma.intakeManifestLine.create({ data: { manifestId: manifest.id, itemId: item.id, description: l.d, categoryId: catId[l.cat], brandName: l.brand, expectedPriceMinor: pkr(l.p) } });
  }
  await prisma.managedResaleAgreement.create({
    data: { sellerId: sellers["karachi-thrift-house"]!.id, status: "REQUESTED", commissionBps: 3000, unsoldPolicy: "RETURN", effectiveFrom: now, requestNote: "About 40 sweatshirts and jackets to consign." },
  });

  // ── Scan codes for a few items ──
  for (const it of allItems.slice(0, 8)) {
    const code = makeCode("ITEM_PACK", await nextval("seq_scan_item_pack"));
    const sc = await prisma.scanCode.create({ data: { code, kind: "ITEM_PACK", itemId: it.id, createdById: staff.WAREHOUSE } });
    await prisma.scanEvent.create({ data: { codeId: sc.id, action: "GENERATED", actorId: staff.WAREHOUSE } });
  }

  // ── Resellers: 2 verified + 1 pending; plus a pending seller application ──
  const resellerDefs = [
    { name: "Usman Tariq", phone: "+923020000001", biz: "Tariq Thrift Store", city: "Lahore", status: "APPROVED" },
    { name: "Mehwish Iqbal", phone: "+923020000002", biz: "Pre-Loved by Mehwish", city: "Karachi", status: "APPROVED" },
    { name: "Ahsan Javed", phone: "+923020000003", biz: "Javed Vintage", city: "Faisalabad", status: "SUBMITTED" },
  ] as const;
  for (const r of resellerDefs) {
    const approved = r.status === "APPROVED";
    const u = await prisma.user.create({ data: { name: r.name, phone: r.phone, phoneVerified: now, activatedAt: now, roles: approved ? ["CUSTOMER", "VERIFIED_RESELLER"] : ["CUSTOMER"] } });
    const app = await prisma.onboardingApplication.create({
      data: {
        reference: applicationReference("RESELLER", await nextval("seq_application_reseller")), kind: "RESELLER", status: r.status, channel: "SELF_SERVE",
        applicantUserId: u.id, fullName: r.name, phone: r.phone, city: r.city, businessName: r.biz, shopLink: `https://instagram.com/${slugify(r.biz)}`,
        decidedAt: approved ? now : null, decidedById: approved ? staff.ADMIN : null,
      },
    });
    for (const kind of ["ID_FRONT", "ID_BACK", "SHOP_PROOF"] as const) {
      const key = `restricted/onboarding/${app.reference}/${kind}.svg`;
      writeFile(key, `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 250"><rect width="400" height="250" fill="#ddd"/><text x="20" y="130" font-size="20">SAMPLE ${kind} (dev seed)</text></svg>`);
      await prisma.onboardingDocument.create({
        data: { applicationId: app.id, kind, storageKey: key, receivedVia: "UPLOAD", verifiedAt: approved ? now : null, verifiedById: approved ? staff.ADMIN : null, deleteAfter: approved ? idDocDeleteAfter(now) : null },
      });
    }
    await prisma.resellerVerification.create({
      data: {
        userId: u.id, status: approved ? "VERIFIED" : "PENDING", businessName: r.biz, shopType: "BOTH", shopLink: `https://instagram.com/${slugify(r.biz)}`,
        cnicLast4: String(between(1000, 9999)), applicationId: app.id, reviewedById: approved ? staff.ADMIN : null, reviewedAt: approved ? now : null,
      },
    });
  }
  const pendingSeller = await prisma.onboardingApplication.create({
    data: {
      reference: applicationReference("SELLER", await nextval("seq_application_seller")), kind: "SELLER", status: "SUBMITTED", channel: "ASSISTED_WHATSAPP",
      fullName: "Rukhsana Bibi", phone: "+923040000001", city: "Gujranwala", businessName: "Rukhsana's Preloved", intendedSellerType: "INDIVIDUAL",
      registeredById: staff.SELLER_AGENT, consentMethod: "WHATSAPP_MESSAGE", consentAt: now, consentEvidenceKey: "restricted/onboarding/consent-sample.svg",
    },
  });
  writeFile("restricted/onboarding/consent-sample.svg", `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 120"><rect width="400" height="120" fill="#e7ffdb"/><text x="16" y="66" font-size="16">"I agree, please register me" (dev seed)</text></svg>`);
  for (const kind of ["ID_FRONT", "ID_BACK"] as const) {
    const key = `restricted/onboarding/${pendingSeller.reference}/${kind}.svg`;
    writeFile(key, `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 250"><rect width="400" height="250" fill="#ddd"/><text x="20" y="130" font-size="20">SAMPLE ${kind} (dev seed)</text></svg>`);
    await prisma.onboardingDocument.create({ data: { applicationId: pendingSeller.id, kind, storageKey: key, receivedVia: "WHATSAPP", uploadedById: staff.SELLER_AGENT } });
  }

  // ── Buyer ──
  const buyer = await prisma.user.create({ data: { name: "Fatima Noor", phone: "+923030000001", phoneVerified: now, activatedAt: now, email: "fatima@example.com", roles: ["CUSTOMER"] } });
  await prisma.address.create({ data: { userId: buyer.id, label: "Home", recipient: "Fatima Noor", phone: "+923030000001", line1: "House 12, Street 4, DHA Phase 5", city: "Lahore", province: "Punjab", postalCode: "54000", isDefault: true } });

  // ── Collections + CMS ──
  const published = await prisma.item.findMany({
    where: { listings: { some: { state: "PUBLISHED" } } }, include: { category: true }, orderBy: { createdAt: "asc" },
  });
  const coll = async (slug: string, title: string, description: string, filter: (i: (typeof published)[number]) => boolean) => {
    const c = await prisma.collection.create({ data: { slug, title, description, isEditorial: true, approved: true, curatorId: staff.ADMIN } });
    const picks = published.filter(filter).slice(0, 12);
    await prisma.collectionItem.createMany({ data: picks.map((p, i) => ({ collectionId: c.id, itemId: p.id, position: i })) });
  };
  await coll("the-denim-edit", "The denim edit", "Trucker jackets and straight-leg jeans, measured flat and graded.", (i) => /denim|jeans/i.test(i.title) || i.category.slug === "jeans-trousers");
  await coll("winter-layers", "Winter layers", "Fleece, workwear and sweatshirts for the cold months.", (i) => ["jackets", "hoodies-sweatshirts"].includes(i.category.slug));
  await coll("under-3000", "Under PKR 3,000", "Good pieces at small prices.", (i) => i.priceMinor <= pkr(3000));
  await prisma.contentBlock.createMany({
    data: [
      { key: "home.hero", title: "One of one.", body: "Secondhand pieces from Pakistan's best thrift sellers. Every item inspected, graded and measured in centimetres.", linkHref: "/shop", linkLabel: "Shop new arrivals", published: true, position: 0 },
      { key: "home.drop.1", title: "The denim edit", body: "Trucker jackets and straight-leg jeans.", linkHref: "/collections/the-denim-edit", linkLabel: "View the edit", published: true, position: 1 },
      { key: "home.drop.2", title: "Winter layers", body: "Fleece, workwear and sweatshirts.", linkHref: "/collections/winter-layers", linkLabel: "View the edit", published: true, position: 2 },
    ],
  });

  const counts = {
    users: await prisma.user.count(), sellers: await prisma.sellerProfile.count(), items: await prisma.item.count(),
    publishedListings: await prisma.listing.count({ where: { state: "PUBLISHED" } }), bundles: await prisma.bundle.count({ where: { state: "PUBLISHED" } }),
    collections: await prisma.collection.count(), applications: await prisma.onboardingApplication.count(),
  };
  console.log("Seed complete:", counts);
  console.log("Login (dev OTP shown on screen): admin +923000000001 · warehouse …02 · support …03 · finance …04 · moderator …05 · agent …06 · seller +923010000001 · verified reseller +923020000001 · buyer +923030000001");
}

main().then(() => prisma.$disconnect()).catch(async (e) => { console.error(e); await prisma.$disconnect(); process.exit(1); });
