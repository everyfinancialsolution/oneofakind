# apps/web — Next.js storefront + portals (to be created in Milestone 1)
Create with: `pnpm create next-app@latest . --ts --tailwind --app --eslint --src-dir --import-alias "@/*"` then wire `@ooak/design-tokens` (preset + `tokens.css`) and `@ooak/shared`.
Shells: `(public)`, `seller`, `ops`, `admin` route groups. Use logical CSS properties for RTL readiness.
