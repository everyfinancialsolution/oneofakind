"use client";
import { useCallback, useEffect, useState } from "react";
import { call, ClientApiError } from "./client";

/** Minimal data hook for portal pages (authenticated, never cached). */
export function useApi<T>(path: string | null) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<ClientApiError | null>(null);
  const [loading, setLoading] = useState(!!path);
  const reload = useCallback(async () => {
    if (!path) return;
    setLoading(true);
    try { setData(await call<T>(path)); setError(null); }
    catch (e) { setError(e as ClientApiError); }
    finally { setLoading(false); }
  }, [path]);
  useEffect(() => { void reload(); }, [reload]);
  return { data, error, loading, reload, setData };
}

/** Wrap an async action with busy state + toast-friendly error message. */
export function useAction() {
  const [busy, setBusy] = useState(false);
  const run = useCallback(async <T,>(fn: () => Promise<T>, onError?: (msg: string) => void): Promise<T | undefined> => {
    setBusy(true);
    try { return await fn(); }
    catch (e) { onError?.((e as Error).message); return undefined; }
    finally { setBusy(false); }
  }, []);
  return { busy, run };
}

/** Open a PDF (labels, statements) returned by a POST endpoint in a new tab. */
export async function openPdf(path: string, body: unknown) {
  const win = window.open("", "_blank");
  const res = await fetch(path, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body), credentials: "same-origin" });
  if (!res.ok) { win?.close(); let msg = "Could not create the PDF"; try { msg = (await res.json()).detail ?? msg; } catch { /* */ } throw new Error(msg); }
  const url = URL.createObjectURL(await res.blob());
  if (win) win.location.href = url; else window.open(url, "_blank");
}
