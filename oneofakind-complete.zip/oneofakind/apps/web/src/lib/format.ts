/** PKR shown without decimals ("PKR 4,500"). Amounts arrive in minor units (paisa). */
export function pkr(minor: number | null | undefined): string {
  if (minor === null || minor === undefined) return "-";
  const rupees = Math.round(minor / 100);
  return `PKR ${rupees.toLocaleString("en-PK")}`;
}

export const percent = (bps: number) => `${Math.round(bps / 100)}%`;

const MEASURE_LABELS: Record<string, string> = {
  chest_cm: "Chest (pit to pit)", length_cm: "Length", sleeve_cm: "Sleeve", shoulder_cm: "Shoulder", waist_cm: "Waist (flat)",
  inseam_cm: "Inseam", rise_cm: "Rise", hip_cm: "Hip (flat)", bust_cm: "Bust (flat)", insole_cm: "Insole", eu_size: "EU size",
  width_cm: "Width", height_cm: "Height", depth_cm: "Depth", circumference_cm: "Circumference",
};
export const measureLabel = (k: string) => MEASURE_LABELS[k] ?? k.replace(/_cm$/, "").replace(/_/g, " ");
export const measureValue = (k: string, v: number) => (k.endsWith("_cm") ? `${v} cm` : String(v));

export function dateShort(iso: string | Date | null | undefined) {
  if (!iso) return "-";
  return new Date(iso).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" });
}
export function dateTime(iso: string | Date | null | undefined) {
  if (!iso) return "-";
  return new Date(iso).toLocaleString("en-GB", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });
}

/** Human labels for internal states - plain words, no jargon (seller UX requirement). */
export const STATE_LABELS: Record<string, string> = {
  DRAFT: "Draft", PENDING_REVIEW: "In review", CHANGES_REQUESTED: "Changes needed", PUBLISHED: "Live", PAUSED: "Paused", SOLD_OUT: "Sold", REMOVED: "Removed",
  EXPECTED: "On its way to us", RECEIVED: "Received", IN_INSPECTION: "Being inspected", REJECTED: "Not accepted", READY_TO_LIST: "Ready to list",
  AVAILABLE: "Available", RESERVED: "Reserved", SOLD: "Sold", PACKED: "Packed", DISPATCHED: "Sent to buyer", DELIVERED: "Delivered",
  RETURN_PENDING: "Return requested", RETURNED_TO_STOCK: "Back in stock", RETURNED_TO_SELLER: "Returned to you", WITHDRAWN: "Withdrawn", LOST_OR_DAMAGED: "Lost or damaged",
  PENDING_PAYMENT: "Awaiting payment", PAID: "Paid", PROCESSING: "Being prepared", PARTIALLY_FULFILLED: "Partly sent", FULFILLED: "Sent",
  COMPLETED: "Completed", CANCELLED: "Cancelled", REFUND_PENDING: "Refund in progress", REFUNDED: "Refunded",
  SUBMITTED: "Submitted", UNDER_REVIEW: "Under review", OFFER_MADE: "Offer made", ACCEPTED: "Offer accepted, awaiting handover",
  REJECTED_BY_SELLER: "You declined", REJECTED_BY_BUYER_TEAM: "Not offered", AWAITING_HANDOVER: "Offer accepted, awaiting handover",
  AWAITING_PAYMENT: "Received, payment to you in progress", TRANSFERRED: "Purchased by ONEOFAKIND",
  DOCS_REQUESTED: "Documents needed", APPROVED: "Approved", WITHDRAWN_APP: "Withdrawn",
  REQUESTED: "Requested", APPROVED_RETURN: "Approved", IN_TRANSIT: "In transit", RECEIVING: "Being received", RECONCILED: "Reconciled",
  LABEL_PENDING: "Label pending", READY: "Ready for pickup", PICKED_UP: "Picked up", OUT_FOR_DELIVERY: "Out for delivery", FAILED_DELIVERY: "Delivery failed", RETURNING: "Returning", RETURNED: "Returned",
  FINALIZED: "Finalised", DISPUTED: "Disputed", OPEN: "Open", RESOLVED: "Resolved", CLOSED: "Closed", ACTIVE: "Active", DECLINED: "Declined",
  QUEUED: "Queued", RUNNING: "Running", SUCCEEDED: "Done", FAILED: "Failed", TIMED_OUT: "Timed out",
};
export const stateLabel = (s: string | null | undefined) => (s ? STATE_LABELS[s] ?? s.replace(/_/g, " ").toLowerCase() : "-");

/** Handling label. A direct-purchase piece only reads "Sold to us" once ownership has transferred (ownerType PLATFORM). */
export function handlingLabel(arrangement: string, ownerType?: string) {
  if (arrangement === "SELF_MANAGED") return "You ship";
  if (arrangement === "MANAGED_RESALE") return "Managed by us";
  return ownerType === "PLATFORM" ? "Sold to us" : "Offered to us (not sold yet)";
}
