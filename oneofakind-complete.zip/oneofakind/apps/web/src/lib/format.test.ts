import { describe, expect, it } from "vitest";
import { handlingLabel, measureLabel, measureValue, percent, pkr, stateLabel } from "./format";

describe("format", () => {
  it("shows PKR without decimals from minor units", () => {
    expect(pkr(450_000)).toBe("PKR 4,500");
    expect(pkr(99)).toBe("PKR 1");
    expect(pkr(0)).toBe("PKR 0");
    expect(pkr(null)).toBe("-");
  });
  it("bps → percent", () => { expect(percent(1200)).toBe("12%"); expect(percent(3000)).toBe("30%"); });
  it("plain-English state labels with a readable fallback", () => {
    expect(stateLabel("PENDING_REVIEW")).toBe("In review");
    expect(stateLabel("SOME_NEW_STATE")).toBe("some new state");
    expect(stateLabel(null)).toBe("-");
  });
  it("never says a direct-purchase piece is sold to us before ownership transferred", () => {
    expect(handlingLabel("DIRECT_PURCHASE", "SELLER")).toBe("Offered to us (not sold yet)");
    expect(handlingLabel("DIRECT_PURCHASE")).not.toMatch(/^Sold/);
    expect(handlingLabel("DIRECT_PURCHASE", "PLATFORM")).toBe("Sold to us");
  });
  it("measurement labels and units", () => {
    expect(measureLabel("chest_cm")).toBe("Chest (pit to pit)");
    expect(measureLabel("thigh_cm")).toBe("thigh");
    expect(measureValue("chest_cm", 55)).toBe("55 cm");
    expect(measureValue("eu_size", 43)).toBe("43");
  });
});
