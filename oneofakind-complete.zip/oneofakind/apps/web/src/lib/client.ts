"use client";
import type { Problem } from "./types";

export class ClientApiError extends Error {
  constructor(public readonly status: number, public readonly problem: Problem | null) {
    super(problem?.detail ?? problem?.title ?? "Something went wrong. Please try again.");
  }
  get code() { return this.problem?.code; }
  fieldError(name: string) { return this.problem?.errors?.fieldErrors?.[name]?.[0]; }
}

/** Browser-side API call. Same origin (/v1 is proxied by Next), so the httpOnly session cookie is sent automatically. */
export async function call<T>(path: string, init: { method?: string; body?: unknown; form?: FormData; idempotencyKey?: string } = {}): Promise<T> {
  const headers: Record<string, string> = { accept: "application/json" };
  let body: BodyInit | undefined;
  if (init.form) body = init.form;
  else if (init.body !== undefined) { headers["content-type"] = "application/json"; body = JSON.stringify(init.body); }
  if (init.idempotencyKey) headers["idempotency-key"] = init.idempotencyKey;
  const res = await fetch(path, { method: init.method ?? (body ? "POST" : "GET"), headers, body, credentials: "same-origin", cache: "no-store" });
  if (!res.ok) {
    let p: Problem | null = null;
    try { p = (await res.json()) as Problem; } catch { /* ignore */ }
    throw new ClientApiError(res.status, p);
  }
  if (res.status === 204) return undefined as T;
  const type = res.headers.get("content-type") ?? "";
  return (type.includes("json") ? await res.json() : await res.blob()) as T;
}

export const newIdempotencyKey = () => (typeof crypto !== "undefined" && "randomUUID" in crypto ? crypto.randomUUID() : `${Date.now()}-${Math.random()}`);
