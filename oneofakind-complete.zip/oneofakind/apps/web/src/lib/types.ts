/** Response shapes from the ONEOFAKIND API (apps/api). Kept hand-written and minimal. */
export interface Img { id: string; url: string; width: number | null; height: number | null; kind?: string; aiLabel: boolean; alt: string }
export interface Grade { code: string; letter: "A" | "B" | "C" | "D"; label: string; rule: string; bundleEligible: boolean }
export interface SellerRef { slug: string | null; displayName: string; city: string | null; ratingAvg: number | null; ratingCount: number; type: string }
export interface ItemCard {
  slug: string; sku: string; title: string; brand: { name: string; slug: string } | null; category: { name: string; slug: string };
  size: string | null; color: string | null; grade: Grade | null; priceMinor: number; currency: string; image: Img | null; hoverImage: Img | null;
  seller: SellerRef; availability: "AVAILABLE" | "RESERVED" | "SOLD"; managed: boolean; publishedAt: string | null;
}
export interface Defect { type: string; location: string; severity: string }
export interface ItemDetail extends ItemCard {
  description: string | null; material: string | null; measurements: Record<string, number> | null; style: { name: string; slug: string } | null;
  images: Img[]; model3d: { url: string } | null;
  condition: { grade: Grade | null; defects: Defect[]; notes: string | null; inspectedBy: string } | null;
  fulfilment: { shipsFrom: string; handledBy: string; deliveryEstimate: string; returns: string; payment: string };
  listingState: string; arrangement: string;
}
export interface SearchResult { items: ItemCard[]; nextCursor: string | null; total: number }
export interface Facets {
  brands: Array<{ slug: string; name: string; count: number }>; sizes: Array<{ value: string; count: number }>;
  grades: Array<{ value: string; count: number }>; colors: Array<{ value: string; count: number }>; price: { minMinor: number; maxMinor: number } | null;
}
export interface Category { id: string; slug: string; name: string; parentId: string | null; liveCount: number; attributeSchema: { measurements?: string[] } | null }
export interface BundleBreakdown { sizes: Record<string, number>; colors: Record<string, number>; grades: Record<string, number> }
/** Price fields are absent unless the viewer may see them (server-side redaction). */
export interface BundleCard {
  slug: string; sku: string; title: string; size: number; brand: { name: string; slug: string }; style: { name: string; slug: string };
  category: { name: string; slug: string }; seller: { slug: string | null; displayName: string; city: string | null; type: string };
  availability: "AVAILABLE" | "RESERVED" | "SOLD"; cover: Img | null; thumbnails: Array<Img | null>; breakdown: BundleBreakdown; weightGrams: number;
  publishedAt: string | null; currency: string;
  priceMinor?: number; retailValueMinor?: number; pricePerPieceMinor?: number; savingsBps?: number;
}
export interface BundlePiece { position: number; sku: string; title: string; size: string | null; color: string | null; grade: Grade | null; measurements: Record<string, number> | null; images: Img[]; defects: Defect[]; refRetailMinor?: number }
export interface BundleDetail extends BundleCard {
  description: string | null; managed: boolean; pieces: BundlePiece[];
  fulfilment: { shipsFrom: string; shipping: string; returns: string; buyers: string };
}
export interface Me {
  user: null | {
    id: string; name: string; phone: string | null; email: string | null; roles: string[]; activated: boolean; deletionRequestedAt: string | null;
    seller: { id: string; slug: string; displayName: string; status: string; payoutVerifiedAt: string | null } | null;
    reseller: { status: string; businessName: string } | null;
    applications: Array<{ reference: string; kind: string; status: string }>;
    consents: Array<{ type: string; granted: boolean; version: string; createdAt: string }>;
  };
}
export interface HomeData {
  blocks: Array<{ key: string; title: string; body: string | null; linkHref: string | null; linkLabel: string | null; image: string | null }>;
  newArrivals: ItemCard[]; inspected: ItemCard[];
  collections: Array<{ slug: string; title: string; description: string | null; covers: Array<Img | null> }>;
  sellers: Array<{ slug: string; displayName: string; city: string | null; type: string; ratingAvg: number; ratingCount: number; liveListings: number; bio: string | null }>;
  bundles: BundleCard[];
  categories: Array<{ slug: string; name: string; children: Array<{ slug: string; name: string }> }>;
}
export interface Problem { type: string; title: string; status: number; detail?: string; code?: string; errors?: { fieldErrors?: Record<string, string[]>; formErrors?: string[] } }
