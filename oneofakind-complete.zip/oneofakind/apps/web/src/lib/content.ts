import { GRADE_CRITERIA, COMMISSION_BPS, MANAGED_RETAIL_TIERS, DAMAGE_CLAIM_WINDOW_HOURS, PAYOUT_HOLD_DAYS, MANAGED_STORAGE_DAYS, MANAGED_MIN_ITEM_PRICE_MINOR } from "@ooak/shared";

export interface Article { slug: string; title: string; summary: string; sections: Array<{ heading?: string; body: string[] }> }

const pct = (bps: number) => `${bps / 100}%`;
const LEGAL_NOTE = "Draft: this text needs review by a Pakistani lawyer before launch.";

export const HELP: Article[] = [
  {
    slug: "grades", title: "Condition grades explained", summary: "What A, B, C and D mean, and who decides.",
    sections: [
      { body: ["Every piece gets one letter grade. The same rules are used by our warehouse inspectors and by verified sellers, and the grade is shown with photos of any marks."] },
      ...(["A", "B", "C", "D"] as const).map((l) => ({ heading: `Grade ${l} · ${GRADE_CRITERIA[l].label}`, body: [GRADE_CRITERIA[l].rule, GRADE_CRITERIA[l].bundleEligible ? "Allowed in reseller bundles." : "Sold as single pieces only."] })),
      { heading: "Who decides", body: ["For managed and ONEOFAKIND-owned pieces, our inspectors grade every item in our Lahore warehouse and their grade is final. Self-managed sellers grade their own pieces against the same rules; we audit samples and remove sellers who repeatedly mis-grade."] },
    ],
  },
  {
    slug: "measurements", title: "How we measure", summary: "Why centimetres, and how to compare with your own clothes.",
    sections: [
      { body: ["Labels lie: a vintage M can be a modern S. Every piece is measured flat, in centimetres.", "Chest is measured armpit to armpit across the front. Length is from the highest point of the shoulder to the hem. Sleeve is from the shoulder seam to the cuff. Waist is measured flat across the top of the waistband.", "To compare, lay a piece you own flat and measure it the same way. Returns are only possible for damage, so please check measurements before you buy."] },
    ],
  },
  {
    slug: "delivery", title: "Delivery", summary: "Prepaid, tracked delivery across Pakistan.",
    sections: [
      { body: ["We deliver across Pakistan with a local courier. Delivery is charged at a flat rate per parcel, shown before you pay. Bundles use a weight-based rate.", "Pieces from our warehouse usually arrive in 2-4 working days; pieces shipped by sellers in 3-6 working days.", "Payment is prepaid only: card, mobile wallet or bank transfer. There is no cash on delivery.", "You'll get a tracking link as soon as your parcel is handed to the courier."] },
    ],
  },
  {
    slug: "damage-claims", title: "Damage claims", summary: `Claim within ${DAMAGE_CLAIM_WINDOW_HOURS} hours if a piece arrives damaged.`,
    sections: [
      { body: [`Because every piece is one of one and fully described, returns are accepted only when an item arrives damaged or with a flaw that wasn't disclosed in its condition report.`, `Open a claim from your order page within ${DAMAGE_CLAIM_WINDOW_HOURS} hours of delivery, with clear photos (and your unboxing video if you have one).`, "If the claim is approved we arrange the return at our cost and refund the item price to your original payment method. For bundles, claims are per piece and the refund is that piece's share of the lot price.", "Change of mind, size or fit, and anything shown in the condition report are not eligible."] },
    ],
  },
  {
    slug: "selling", title: "Selling on ONEOFAKIND", summary: "Three ways to sell, and what each costs.",
    sections: [
      { heading: "List it yourself", body: [`You keep your pieces, photograph and list them, and pack them when they sell. We take ${pct(COMMISSION_BPS.RETAIL_SELF_MANAGED)} of the item price. Listing is free.`] },
      { heading: "Managed resale", body: [`Hand your pieces to us. We inspect, grade, measure, photograph, list, store (up to ${MANAGED_STORAGE_DAYS} days), pack and ship. We take ${pct(MANAGED_RETAIL_TIERS[0].bps)} up to PKR 5,000, ${pct(MANAGED_RETAIL_TIERS[1].bps)} up to PKR 20,000 and ${pct(MANAGED_RETAIL_TIERS[2].bps)} above. Minimum item price PKR ${(MANAGED_MIN_ITEM_PRICE_MINOR / 100).toLocaleString("en-PK")}.`] },
      { heading: "Sell to us outright", body: ["Send photos of a piece or a collection and our buying team may make you an offer. It becomes ours only after we've received and checked the pieces and paid you. Until then it is still yours."] },
      { heading: "Getting paid", body: [`Your earnings become payable ${PAYOUT_HOLD_DAYS} days after the buyer receives the order, and are paid weekly to a bank or wallet account in your own name.`] },
    ],
  },
];

export const POLICIES: Article[] = [
  {
    slug: "terms", title: "Terms of use", summary: LEGAL_NOTE,
    sections: [
      { body: [LEGAL_NOTE] },
      { heading: "Who we are", body: ["ONEOFAKIND operates a marketplace where verified sellers list secondhand pieces, and where ONEOFAKIND also sells pieces it has bought outright."] },
      { heading: "Buying", body: ["Prices are in Pakistani rupees and include no hidden fees; delivery is shown before payment. Payment is prepaid. An order is confirmed only when your payment is confirmed by our payment provider.", "Every item is unique. If two people check out at the same time, the first confirmed payment wins and the other is never charged."] },
      { heading: "Your account", body: ["You log in with your phone number and a one-time code. Keep your phone secure and never share codes."] },
    ],
  },
  {
    slug: "privacy", title: "Privacy policy", summary: LEGAL_NOTE,
    sections: [
      { body: [LEGAL_NOTE] },
      { heading: "What we collect", body: ["Your name, phone number, delivery addresses, orders, and, for sellers and resellers, identity and payout documents needed to verify you."] },
      { heading: "Identity documents", body: ["ID and bank documents are stored in restricted storage that only our onboarding, support and admin staff can open; every access is logged. Images are deleted 90 days after your application is decided. We keep only the last 4 digits of your ID number and the outcome."] },
      { heading: "Photos and AI", body: ["Product photos you upload may be processed (for example background removal) by service providers acting for us. Any generated image is labelled. Photos you upload for virtual try-on are private to you and deleted under our retention rules."] },
      { heading: "Your rights", body: ["You can see your consents, and request deletion of your account from your account page. We keep order and payment records for as long as the law requires."] },
    ],
  },
  {
    slug: "returns", title: "Damage claims (returns)", summary: "Returns are accepted only for damaged items or undisclosed flaws.",
    sections: HELP.find((h) => h.slug === "damage-claims")!.sections,
  },
  {
    slug: "seller-terms", title: "Seller terms", summary: LEGAL_NOTE,
    sections: [
      { body: [LEGAL_NOTE] },
      { heading: "Accurate listings", body: ["You must describe and grade pieces honestly, disclose every flaw with a photo, and enter real measurements. You may not list counterfeit, stolen or prohibited goods."] },
      { heading: "Managed resale (consignment)", body: ["Pieces you hand to us for managed resale remain yours until they sell. We hold them in custody, record every handover, and pay you the sale price minus our commission. Unsold pieces are handled as set out in your agreement."] },
      { heading: "Direct purchase", body: ["When we make an offer and you accept it, ownership passes to ONEOFAKIND only once we have received and verified the pieces and paid you. Until then the pieces remain yours."] },
      { heading: "Payouts", body: [`Payouts go only to a bank or wallet account in your own name, verified by our team. Earnings become payable ${PAYOUT_HOLD_DAYS} days after delivery. Changing payout details requires your own confirmation code and re-verification.`] },
      { heading: "Help from our team", body: ["If you ask us to, authorised members of our team can prepare draft listings for you from photos you send. They can never change your payout details or phone number, accept offers or approve prices for you."] },
    ],
  },
];
