import "server-only";
import { redirect } from "next/navigation";
import { api } from "./api";
import type { Me } from "./types";

/** Server-side gate for portal layouts. The API enforces the same roles on every endpoint; this is UX, not security. */
export async function requireUser(next: string, roles?: string[]) {
  const me = await api<Me>("/v1/auth/me", { auth: true }).catch(() => ({ user: null }) as Me);
  if (!me.user) redirect(`/login?next=${encodeURIComponent(next)}`);
  const allowed = !roles || me.user.roles.some((r) => roles.includes(r));
  return { user: me.user, allowed };
}
