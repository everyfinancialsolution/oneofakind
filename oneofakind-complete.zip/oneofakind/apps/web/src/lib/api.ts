import "server-only";
import { cookies } from "next/headers";
import type { Problem } from "./types";

const API = process.env.API_INTERNAL_URL ?? "http://localhost:4000";

export class ApiError extends Error {
  constructor(public readonly status: number, public readonly problem: Problem | null) {
    super(problem?.detail ?? problem?.title ?? `API error ${status}`);
  }
}

interface Opts {
  /** Forward the visitor's session cookie (makes the page dynamic). Public ISR pages must NOT do this. */
  auth?: boolean;
  /** ISR revalidation seconds for anonymous fetches. */
  revalidate?: number;
  method?: string;
  body?: unknown;
}

/** Server-side API call from React Server Components / route handlers. */
export async function api<T>(path: string, opts: Opts = {}): Promise<T> {
  const headers: Record<string, string> = { accept: "application/json" };
  if (opts.auth) {
    const jar = await cookies();
    const c = jar.get("ooak_session");
    if (c) headers.cookie = `ooak_session=${c.value}`;
  }
  if (opts.body !== undefined) headers["content-type"] = "application/json";
  const res = await fetch(`${API}${path}`, {
    method: opts.method ?? "GET", headers, body: opts.body !== undefined ? JSON.stringify(opts.body) : undefined,
    ...(opts.auth || opts.method ? { cache: "no-store" as const } : { next: { revalidate: opts.revalidate ?? 60 } }),
  });
  if (!res.ok) {
    let problem: Problem | null = null;
    try { problem = (await res.json()) as Problem; } catch { /* not json */ }
    throw new ApiError(res.status, problem);
  }
  return (await res.json()) as T;
}

/** Same as api() but returns null on 404 (for notFound() handling). */
export async function apiOrNull<T>(path: string, opts: Opts = {}): Promise<T | null> {
  try { return await api<T>(path, opts); } catch (e) { if (e instanceof ApiError && e.status === 404) return null; throw e; }
}
