"use client";
import { useEffect, useState } from "react";
import { call } from "@/lib/client";
import { useApi } from "@/lib/useApi";
import { dateShort, percent, stateLabel } from "@/lib/format";
import { PageHeader } from "@/components/chrome/PortalShell";
import { DataTable, Panel } from "@/components/admin/kit";
import { Button } from "@/components/ui/Button";
import { TextField } from "@/components/ui/Field";
import { Notice } from "@/components/ui/misc";
import { useToast } from "@/components/ui/Toast";

interface Data { settings: Array<{ key: string; value: unknown }>; commissionRules: Array<{ id: string; arrangement: string; bps: number; effectiveFrom: string; categoryId: string | null }>; bundleTiers: Array<{ size: number; minPriceMinor: number; active: boolean }> }
interface Rates { LOCAL: number; NATIONAL: number; localCities: string[] }

export default function Settings() {
  const { data, reload } = useApi<Data>("/v1/admin/settings");
  const [rates, setRates] = useState({ local: "", national: "", cities: "", perKg: "" });
  const [tiers, setTiers] = useState<Record<number, string>>({});
  const toast = useToast();
  useEffect(() => {
    if (!data) return;
    const r = data.settings.find((s) => s.key === "shipping.flatRates")?.value as Rates | undefined;
    const kg = data.settings.find((s) => s.key === "shipping.bundleRatePerKgMinor")?.value as number | undefined;
    setRates({ local: r ? String(r.LOCAL / 100) : "", national: r ? String(r.NATIONAL / 100) : "", cities: r?.localCities.join(", ") ?? "", perKg: kg != null ? String(kg / 100) : "" });
    setTiers(Object.fromEntries(data.bundleTiers.map((t) => [t.size, String(t.minPriceMinor / 100)])));
  }, [data]);
  const save = async (fn: () => Promise<unknown>) => { try { await fn(); toast("Saved (audited)", "good"); await reload(); } catch (e) { toast((e as Error).message, "bad"); } };
  const rupees = (s: string) => Math.round(Number(s.replace(/[^\d.]/g, "")) * 100);
  return (
    <div className="max-w-4xl space-y-5">
      <PageHeader title="Settings" sub="Every change is written to the audit log with before/after values." />
      <Panel title="Shipping (prepaid, charged at checkout)">
        <div className="grid gap-3 sm:grid-cols-2">
          <TextField label="Same-city rate (PKR)" inputMode="numeric" value={rates.local} onChange={(e) => setRates((r) => ({ ...r, local: e.target.value }))} />
          <TextField label="Nationwide rate (PKR)" inputMode="numeric" value={rates.national} onChange={(e) => setRates((r) => ({ ...r, national: e.target.value }))} />
          <TextField label="Cities counted as local to the warehouse" value={rates.cities} onChange={(e) => setRates((r) => ({ ...r, cities: e.target.value }))} />
          <TextField label="Lot shipping per kg (PKR)" inputMode="numeric" value={rates.perKg} onChange={(e) => setRates((r) => ({ ...r, perKg: e.target.value }))} />
        </div>
        <div className="mt-3 flex gap-2">
          <Button onClick={() => save(() => call("/v1/admin/settings/shipping.flatRates", { method: "PUT", body: { value: { LOCAL: rupees(rates.local), NATIONAL: rupees(rates.national), localCities: rates.cities.split(",").map((c) => c.trim()).filter(Boolean) } } }))}>Save rates</Button>
          <Button variant="secondary" onClick={() => save(() => call("/v1/admin/settings/shipping.bundleRatePerKgMinor", { method: "PUT", body: { value: rupees(rates.perKg) } }))}>Save lot rate</Button>
        </div>
      </Panel>
      <Panel title="Bundle tiers (admin only): 5, 10 or 15 pieces">
        <Notice className="mb-3">Bundle sizes are fixed at 5, 10 and 15 pieces. Only the minimum lot price per tier can change.</Notice>
        <div className="grid gap-3 sm:grid-cols-3">{[5, 10, 15].map((n) => (
          <div key={n} className="space-y-2"><TextField label={`${n} pieces: minimum (PKR)`} inputMode="numeric" value={tiers[n] ?? ""} onChange={(e) => setTiers((t) => ({ ...t, [n]: e.target.value }))} /><Button size="sm" variant="secondary" onClick={() => save(() => call(`/v1/admin/bundle-tiers/${n}`, { method: "PUT", body: { minPriceMinor: rupees(tiers[n] ?? "0"), active: true } }))}>Save</Button></div>
        ))}</div>
      </Panel>
      <Panel title="Commission rules">
        <DataTable rows={data?.commissionRules} rowKey={(r) => r.id} empty="Defaults apply: 12% self-managed, 30% managed resale." cols={[
          { h: "Arrangement", c: (r) => stateLabel(r.arrangement) }, { h: "Rate", c: (r) => percent(r.bps) }, { h: "From", c: (r) => dateShort(r.effectiveFrom) }, { h: "Category", c: (r) => r.categoryId ?? "All" },
        ]} />
        <p className="mt-2 text-xs text-muted">Commission changes apply to new sales only (the rate is snapshotted on each order line).</p>
      </Panel>
    </div>
  );
}
