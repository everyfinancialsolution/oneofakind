"use client";
import { useState } from "react";
import { call } from "@/lib/client";
import { useApi } from "@/lib/useApi";
import { PageHeader } from "@/components/chrome/PortalShell";
import { DataTable, Panel, Tabs } from "@/components/admin/kit";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { TextField } from "@/components/ui/Field";
import { useToast } from "@/components/ui/Toast";

interface Cat { id: string; slug: string; name: string; enabled: boolean; sortOrder: number; attributeSchema: { measurements?: string[] } | null; _count: { items: number } }
interface Sty { id: string; slug: string; name: string; enabled: boolean; _count: { items: number } }
interface Br { id: string; name: string; slug: string; verifiedBrand: boolean; _count: { items: number } }
const slugify = (s: string) => s.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");

/** Categories define which measurements are required for a listing. Styles group bundle lots (same brand AND style). */
export default function CatalogAdmin() {
  const [tab, setTab] = useState<"categories" | "styles" | "brands">("categories");
  const cats = useApi<{ categories: Cat[] }>("/v1/admin/catalog/categories");
  const styles = useApi<{ styles: Sty[] }>("/v1/admin/catalog/styles");
  const brands = useApi<{ brands: Br[] }>(tab === "brands" ? "/v1/admin/catalog/brands" : null);
  const [nc, setNc] = useState({ name: "", measurements: "chest_cm, length_cm" });
  const [ns, setNs] = useState("");
  const toast = useToast();
  const act = async (fn: () => Promise<unknown>, reload: () => Promise<void>) => { try { await fn(); toast("Saved", "good"); await reload(); } catch (e) { toast((e as Error).message, "bad"); } };
  return (
    <div className="space-y-4">
      <PageHeader title="Categories, styles & brands" />
      <Tabs value={tab} onChange={setTab} tabs={[{ k: "categories", label: "Categories" }, { k: "styles", label: "Styles" }, { k: "brands", label: "Brands" }]} />
      {tab === "categories" && <>
        <DataTable rows={cats.data?.categories} rowKey={(c) => c.id} cols={[
          { h: "Name", c: (c) => <div>{c.name}<div className="font-mono text-xs text-muted">{c.slug}</div></div> },
          { h: "Required measurements", c: (c) => (c.attributeSchema?.measurements ?? []).join(", ") || "-" },
          { h: "Items", c: (c) => <span className="num">{c._count.items}</span> },
          { h: "Shown", c: (c) => (c.enabled ? "Yes" : <Badge tone="warn">Hidden</Badge>) },
          { h: "", c: (c) => <Button size="sm" variant="ghost" onClick={() => act(() => call(`/v1/admin/catalog/categories/${c.id}`, { method: "PATCH", body: { enabled: !c.enabled } }), cats.reload)}>{c.enabled ? "Hide" : "Show"}</Button> },
        ]} />
        <Panel title="Add a category">
          <div className="grid gap-3 sm:grid-cols-2"><TextField label="Name" value={nc.name} onChange={(e) => setNc((x) => ({ ...x, name: e.target.value }))} /><TextField label="Required measurements" help="Comma separated, e.g. chest_cm, length_cm, waist_cm" value={nc.measurements} onChange={(e) => setNc((x) => ({ ...x, measurements: e.target.value }))} /></div>
          <Button className="mt-3" disabled={nc.name.length < 2} onClick={() => act(() => call("/v1/admin/catalog/categories", { body: { name: nc.name, slug: slugify(nc.name), measurements: nc.measurements.split(",").map((m) => m.trim()).filter(Boolean) } }), cats.reload)}>Add category</Button>
        </Panel>
      </>}
      {tab === "styles" && <>
        <DataTable rows={styles.data?.styles} rowKey={(s) => s.id} cols={[
          { h: "Style", c: (s) => <div>{s.name}<div className="font-mono text-xs text-muted">{s.slug}</div></div> }, { h: "Items", c: (s) => <span className="num">{s._count.items}</span> },
          { h: "Shown", c: (s) => (s.enabled ? "Yes" : <Badge tone="warn">Hidden</Badge>) },
          { h: "", c: (s) => <Button size="sm" variant="ghost" onClick={() => act(() => call(`/v1/admin/catalog/styles/${s.id}`, { method: "PATCH", body: { enabled: !s.enabled } }), styles.reload)}>{s.enabled ? "Hide" : "Show"}</Button> },
        ]} />
        <Panel title="Add a style"><div className="flex flex-wrap items-end gap-3"><TextField label="Name" placeholder="Workwear" value={ns} onChange={(e) => setNs(e.target.value)} /><Button disabled={ns.length < 2} onClick={() => act(() => call("/v1/admin/catalog/styles", { body: { name: ns, slug: slugify(ns) } }), styles.reload)}>Add style</Button></div></Panel>
      </>}
      {tab === "brands" && <DataTable rows={brands.data?.brands} rowKey={(b) => b.id} cols={[
        { h: "Brand", c: (b) => b.name }, { h: "Items", c: (b) => <span className="num">{b._count.items}</span> },
        { h: "Verified brand", c: (b) => (b.verifiedBrand ? <Badge tone="good">Verified</Badge> : "-") },
        { h: "", c: (b) => <Button size="sm" variant="ghost" onClick={() => act(() => call(`/v1/admin/moderation/brands/${b.id}/verify`, { body: { verified: !b.verifiedBrand } }), brands.reload)}>{b.verifiedBrand ? "Unverify" : "Verify"}</Button> },
      ]} />}
    </div>
  );
}
