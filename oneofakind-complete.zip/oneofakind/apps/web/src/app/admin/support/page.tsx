"use client";
import { useState } from "react";
import { call } from "@/lib/client";
import { useApi } from "@/lib/useApi";
import { dateTime, pkr, stateLabel } from "@/lib/format";
import { PageHeader } from "@/components/chrome/PortalShell";
import { ActionButton, Panel, Tabs } from "@/components/admin/kit";
import { StatusPill } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { EmptyState } from "@/components/ui/misc";
import { useToast } from "@/components/ui/Toast";

interface Msg { from: string; by: string; at: string; text: string }
interface T { id: string; subject: string; state: string; createdAt: string; messages: Msg[]; user: { name: string; phone: string | null }; order: { reference: string; state: string } | null; lines: Array<{ id: string; sku: string; title: string; priceMinor: number; voided: boolean }>; disputes: Array<{ id: string; orderItemId: string | null; state: string; resolution: string | null }> }
const VIEWS = { open: "OPEN,PENDING_INTERNAL", waiting: "PENDING_CUSTOMER", closed: "RESOLVED,CLOSED" } as const;

export default function Support() {
  const [view, setView] = useState<keyof typeof VIEWS>("open");
  const { data, reload } = useApi<{ tickets: T[] }>(`/v1/admin/support?state=${VIEWS[view]}`);
  const [reply, setReply] = useState<Record<string, string>>({});
  const toast = useToast();
  const send = async (t: T, state?: string) => {
    try { await call(`/v1/support/tickets/${t.id}/messages`, { body: { text: reply[t.id] ?? "", ...(state ? { state } : {}) } }); setReply((r) => ({ ...r, [t.id]: "" })); toast("Sent", "good"); await reload(); }
    catch (e) { toast((e as Error).message, "bad"); }
  };
  return (
    <div className="space-y-4">
      <PageHeader title="Tickets & disputes" />
      <Tabs value={view} onChange={setView} tabs={[{ k: "open", label: "Needs us" }, { k: "waiting", label: "Waiting for customer" }, { k: "closed", label: "Closed" }]} />
      {data?.tickets.length === 0 && <EmptyState title="No tickets" />}
      {data?.tickets.map((t) => (
        <Panel key={t.id} title={t.subject} actions={<StatusPill state={t.state} />}>
          <div className="text-xs text-muted">{t.user.name} · <span className="num">{t.user.phone}</span> · {dateTime(t.createdAt)} {t.order && <>· order <span className="num">{t.order.reference}</span> ({stateLabel(t.order.state)})</>}</div>
          <ol className="mt-3 space-y-2 text-sm">{t.messages.map((m, i) => <li key={i} className={m.from === "STAFF" ? "ml-8 rounded-md bg-ivory-deep p-2" : "mr-8 rounded-md border hairline p-2"}><div className="text-xs text-muted">{m.by} · {dateTime(m.at)}</div><p className="whitespace-pre-line">{m.text}</p></li>)}</ol>
          <textarea className="mt-3 w-full rounded-md border hairline bg-surface p-2 text-sm" rows={2} placeholder="Reply to the customer" value={reply[t.id] ?? ""} onChange={(e) => setReply((r) => ({ ...r, [t.id]: e.target.value }))} aria-label="Reply" />
          <div className="mt-2 flex flex-wrap gap-2"><Button size="sm" disabled={!reply[t.id]?.trim()} onClick={() => send(t)}>Send reply</Button><Button size="sm" variant="secondary" disabled={!reply[t.id]?.trim()} onClick={() => send(t, "RESOLVED")}>Reply & resolve</Button></div>
          {t.lines.length > 0 && (
            <div className="mt-4 border-t hairline pt-3 text-sm">
              <div className="mb-2 text-xs font-semibold uppercase text-muted">Disputes (holds the seller's payout for that line)</div>
              <ul className="space-y-2">{t.lines.map((l) => { const d = t.disputes.find((x) => x.orderItemId === l.id); return (
                <li key={l.id} className="flex flex-wrap items-center gap-2"><span>{l.title} <span className="num text-muted">{l.sku} · {pkr(l.priceMinor)}</span></span>
                  {d ? <><StatusPill state={d.state} />{["OPEN", "EVIDENCE_REQUESTED", "UNDER_REVIEW"].includes(d.state) && <><ActionButton path={`/v1/admin/disputes/${d.id}/resolve`} body={{ outcome: "RESOLVED_BUYER" }} note="resolution" label="Resolve for buyer" onDone={reload} /><ActionButton path={`/v1/admin/disputes/${d.id}/resolve`} body={{ outcome: "RESOLVED_SELLER" }} note="resolution" label="Resolve for seller" onDone={reload} /></>}{d.resolution && <span className="text-xs text-muted">{d.resolution}</span>}</>
                    : !l.voided && <ActionButton path={`/v1/admin/support/${t.id}/disputes`} body={{ orderItemId: l.id }} label="Open dispute" confirm="Opening a dispute holds the seller's payout for this piece until resolved." onDone={reload} />}
                </li>); })}</ul>
            </div>
          )}
        </Panel>
      ))}
    </div>
  );
}
