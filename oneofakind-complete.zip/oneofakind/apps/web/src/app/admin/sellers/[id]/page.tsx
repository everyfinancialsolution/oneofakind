"use client";
import { use, useState } from "react";
import { call, ClientApiError } from "@/lib/client";
import { openPdf, useApi } from "@/lib/useApi";
import { stateLabel } from "@/lib/format";
import { PageHeader } from "@/components/chrome/PortalShell";
import { DataTable, Panel } from "@/components/admin/kit";
import { ListingForm, emptyListing, toPayload, type ListingValues } from "@/components/seller/ListingForm";
import { PhotoPicker, type LocalPhoto } from "@/components/seller/PhotoPicker";
import { StatusPill } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { Notice } from "@/components/ui/misc";
import { useToast } from "@/components/ui/Toast";

interface I { id: string; sku: string; title: string; stockState: string; listingState: string | null }

/**
 * Listing on a seller's behalf (SELLER_AGENT/ADMIN, seller opted in). Every write carries AuditLog.onBehalfOfId.
 * Price approval, offers, payout and phone changes are refused by the API - they need the seller's own OTP.
 */
export default function OnBehalf({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const base = `/v1/admin/sellers/${id}/on-behalf`;
  const { data, error, reload } = useApi<{ items: I[] }>(`${base}/listings`);
  const [adding, setAdding] = useState(false);
  const [photos, setPhotos] = useState<LocalPhoto[]>([]);
  const [v, setV] = useState<ListingValues>(emptyListing);
  const [busy, setBusy] = useState(false);
  const [sel, setSel] = useState<string[]>([]);
  const toast = useToast();
  const save = async (submit: boolean) => {
    setBusy(true);
    try {
      const created = await call<{ itemId: string }>(`${base}/listings`, { body: toPayload(v) });
      for (const p of photos) { const fd = new FormData(); fd.set("file", p.file); await call(`${base}/listings/${created.itemId}/photos`, { form: fd }); }
      if (submit) await call(`${base}/listings/${created.itemId}/submit`, { method: "POST" });
      toast(submit ? "Sent for review on the seller's behalf" : "Draft saved", "good");
      setAdding(false); setPhotos([]); setV(emptyListing); await reload();
    } catch (e) { toast((e as ClientApiError).message, "bad"); } finally { setBusy(false); }
  };
  return (
    <div className="max-w-5xl space-y-5">
      <PageHeader title="List on the seller's behalf" sub="Everything you do here is recorded as done by you, on behalf of the seller." actions={!adding && <Button onClick={() => setAdding(true)}>Add an item</Button>} />
      <Notice>You can create drafts, upload photos, submit for review and print labels. You cannot approve prices, accept offers, change payout details or the phone number. Those need the seller themselves.</Notice>
      {error && <Notice tone="bad">{error.message}</Notice>}
      {adding && (
        <Panel title="New item">
          <div className="space-y-5"><PhotoPicker photos={photos} onChange={setPhotos} /><ListingForm value={v} onChange={setV} />
            <div className="flex flex-wrap gap-2"><Button variant="ghost" onClick={() => setAdding(false)}>Cancel</Button><Button variant="secondary" loading={busy} onClick={() => save(false)} disabled={!v.title || !v.categoryId}>Save draft</Button><Button loading={busy} onClick={() => save(true)} disabled={photos.length < 2 || !v.title || !v.categoryId || !v.priceRupees || !v.conditionGrade}>Submit for review</Button></div>
          </div>
        </Panel>
      )}
      <Panel title="Seller's items" actions={<Button size="sm" variant="secondary" disabled={!sel.length} onClick={() => openPdf(`${base}/labels`, { itemIds: sel, format: "thermal" }).catch((e) => toast((e as Error).message, "bad"))}>Print {sel.length || ""} labels</Button>}>
        <DataTable rows={data?.items} rowKey={(i) => i.id} cols={[
          { h: "", c: (i) => <input type="checkbox" aria-label={`Select ${i.sku}`} checked={sel.includes(i.id)} onChange={(e) => setSel((x) => (e.target.checked ? [...x, i.id] : x.filter((y) => y !== i.id)))} /> },
          { h: "SKU", c: (i) => <span className="num">{i.sku}</span> }, { h: "Title", c: (i) => i.title },
          { h: "Stock", c: (i) => stateLabel(i.stockState) }, { h: "Listing", c: (i) => (i.listingState ? <StatusPill state={i.listingState} /> : "-") },
        ]} />
      </Panel>
    </div>
  );
}
