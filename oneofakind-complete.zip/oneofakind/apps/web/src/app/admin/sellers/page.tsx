"use client";
import Link from "next/link";
import { useState } from "react";
import { useApi } from "@/lib/useApi";
import { dateShort } from "@/lib/format";
import { PageHeader } from "@/components/chrome/PortalShell";
import { ActionButton, DataTable } from "@/components/admin/kit";
import { Badge, StatusPill } from "@/components/ui/Badge";

interface S { id: string; slug: string; displayName: string; type: string; status: string; city: string | null; owner: string; phone: string | null; items: number; live: number; payoutVerified: boolean; allowStaffListing: boolean; createdAt: string }

export default function Sellers() {
  const [q, setQ] = useState("");
  const [status, setStatus] = useState("");
  const { data, reload } = useApi<{ sellers: S[] }>(`/v1/admin/sellers?${q ? `q=${encodeURIComponent(q)}&` : ""}${status ? `status=${status}` : ""}`);
  return (
    <div className="space-y-4">
      <PageHeader title="Sellers" />
      <div className="flex flex-wrap gap-2">
        <input className="h-10 w-full max-w-xs rounded-md border hairline bg-surface px-3 text-sm" placeholder="Shop name or slug" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search sellers" />
        <select className="h-10 rounded-md border hairline bg-surface px-2 text-sm" value={status} onChange={(e) => setStatus(e.target.value)} aria-label="Status"><option value="">All</option><option value="VERIFIED">Verified</option><option value="PENDING">Pending</option><option value="SUSPENDED">Suspended</option></select>
      </div>
      <DataTable rows={data?.sellers} rowKey={(s) => s.id} cols={[
        { h: "Shop", c: (s) => <div><Link className="underline" href={`/sellers/${s.slug}`} target="_blank">{s.displayName}</Link><div className="text-xs text-muted">{s.owner} · <span className="num">{s.phone}</span> · {s.city}</div></div> },
        { h: "Status", c: (s) => <StatusPill state={s.status} /> },
        { h: "Items / live", c: (s) => <span className="num">{s.items} / {s.live}</span> },
        { h: "Payout", c: (s) => (s.payoutVerified ? <Badge tone="good">Own-name verified</Badge> : <Badge tone="warn">Not verified</Badge>) },
        { h: "Staff listing", c: (s) => (s.allowStaffListing ? <Link className="underline" href={`/admin/sellers/${s.id}`}>List on behalf</Link> : <span className="text-muted">Not allowed</span>) },
        { h: "Since", c: (s) => dateShort(s.createdAt) },
        { h: "", c: (s) => s.status === "SUSPENDED"
          ? <ActionButton path={`/v1/admin/sellers/${s.id}/status`} body={{ status: "VERIFIED" }} note="reason" label="Reinstate" onDone={reload} />
          : <ActionButton path={`/v1/admin/sellers/${s.id}/status`} body={{ status: "SUSPENDED" }} note="reason" label="Suspend" variant="danger" confirm="Suspending pauses all their live listings." onDone={reload} /> },
      ]} />
    </div>
  );
}
