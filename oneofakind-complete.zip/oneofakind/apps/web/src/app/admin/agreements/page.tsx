"use client";
import { useApi } from "@/lib/useApi";
import { dateShort, percent, stateLabel } from "@/lib/format";
import { PageHeader } from "@/components/chrome/PortalShell";
import { ActionButton, DataTable } from "@/components/admin/kit";
import { StatusPill } from "@/components/ui/Badge";

interface A { id: string; status: string; seller: string; commissionBps: number | null; requiresPriceApproval: boolean; storageDays: number | null; unsoldPolicy: string | null; requestNote: string | null; manifests: number; createdAt: string }

export default function Agreements() {
  const { data, reload } = useApi<{ agreements: A[] }>("/v1/admin/agreements");
  return (
    <div className="space-y-4">
      <PageHeader title="Managed resale agreements" sub="Sellers who want us to store, photograph and sell for them. Standard terms: 30% commission, seller approves prices, 90 days, unsold returned." />
      <DataTable rows={data?.agreements} rowKey={(a) => a.id} cols={[
        { h: "Seller", c: (a) => <div>{a.seller}{a.requestNote && <div className="max-w-xs text-xs text-muted">“{a.requestNote}”</div>}</div> },
        { h: "Status", c: (a) => <StatusPill state={a.status} /> },
        { h: "Terms", c: (a) => (a.commissionBps != null ? `${percent(a.commissionBps)} · ${a.storageDays ?? 90} days · unsold ${stateLabel(a.unsoldPolicy ?? "RETURN")}${a.requiresPriceApproval ? " · seller approves price" : ""}` : "-") },
        { h: "Manifests", c: (a) => <span className="num">{a.manifests}</span> }, { h: "Requested", c: (a) => dateShort(a.createdAt) },
        { h: "", c: (a) => a.status === "REQUESTED" && <div className="flex gap-1">
          <ActionButton path={`/v1/admin/agreements/${a.id}/approve`} body={{ commissionBps: 3000, requiresPriceApproval: true, storageDays: 90, unsoldPolicy: "RETURN" }} label="Approve (standard terms)" variant="primary" confirm="Approve with 30% commission, seller price approval, 90 days storage, unsold returned?" onDone={reload} />
          <ActionButton path={`/v1/admin/agreements/${a.id}/decline`} label="Decline" variant="danger" confirm="Decline this request?" onDone={reload} />
        </div> },
      ]} />
    </div>
  );
}
