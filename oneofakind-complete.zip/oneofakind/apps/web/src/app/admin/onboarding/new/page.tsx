"use client";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { call, ClientApiError } from "@/lib/client";
import { PageHeader } from "@/components/chrome/PortalShell";
import { Button } from "@/components/ui/Button";
import { SelectField, TextField } from "@/components/ui/Field";
import { Notice } from "@/components/ui/misc";

/** Staff-assisted registration from WhatsApp/phone/in person (docs/ONBOARDING.md). The applicant still activates with their own OTP. */
export default function AssistedRegistration() {
  const [v, setV] = useState({ kind: "SELLER", channel: "ASSISTED_WHATSAPP", reference: "", fullName: "", phone: "", city: "", businessName: "", shopLink: "", intendedSellerType: "INDIVIDUAL", consentMethod: "WHATSAPP_MESSAGE" });
  const [err, setErr] = useState<ClientApiError | null>(null);
  const [busy, setBusy] = useState(false);
  const router = useRouter();
  const set = (k: keyof typeof v) => (e: { target: { value: string } }) => setV((x) => ({ ...x, [k]: e.target.value }));
  const save = async () => {
    setBusy(true); setErr(null);
    try {
      const body = { ...v, reference: v.reference || undefined, city: v.city || undefined, businessName: v.businessName || undefined, shopLink: v.shopLink || undefined };
      const r = await call<{ reference: string }>("/v1/admin/onboarding", { body });
      router.push(`/admin/onboarding/${r.reference}`);
    } catch (e) { setErr(e as ClientApiError); } finally { setBusy(false); }
  };
  return (
    <div className="max-w-2xl space-y-5">
      <PageHeader title="Register from WhatsApp" sub="Type in what the applicant sent. Next you'll attach their documents and the consent screenshot." />
      <Notice>Never register someone without their clear agreement. Record how they agreed. The application can't be submitted without consent evidence. They activate the account themselves with an OTP on their own phone.</Notice>
      {err && <Notice tone="bad">{err.message}</Notice>}
      <div className="grid gap-4 sm:grid-cols-2">
        <SelectField label="Applying as" value={v.kind} onChange={set("kind")}><option value="SELLER">Seller</option><option value="RESELLER">Verified reseller (buys lots)</option></SelectField>
        <SelectField label="Came in via" value={v.channel} onChange={set("channel")}><option value="ASSISTED_WHATSAPP">WhatsApp</option><option value="ASSISTED_PHONE">Phone call</option><option value="ASSISTED_IN_PERSON">In person</option></SelectField>
        <TextField label="WhatsApp reference" optional help="If they tapped the WhatsApp button on the site, their message starts with a reference like SA-…" value={v.reference} onChange={set("reference")} />
        <TextField label="Full name (as on CNIC)" value={v.fullName} onChange={set("fullName")} error={err?.fieldError("fullName")} />
        <TextField label="Mobile number" inputMode="tel" placeholder="03xx xxxxxxx" value={v.phone} onChange={set("phone")} error={err?.code === "INVALID_PHONE" ? err.message : err?.fieldError("phone")} />
        <TextField label="City" optional value={v.city} onChange={set("city")} />
        <TextField label="Shop / business name" optional value={v.businessName} onChange={set("businessName")} />
        <TextField label="Shop link (Instagram, website)" optional value={v.shopLink} onChange={set("shopLink")} error={err?.fieldError("shopLink")} />
        {v.kind === "SELLER" && <SelectField label="Seller type" value={v.intendedSellerType} onChange={set("intendedSellerType")}><option value="INDIVIDUAL">Individual</option><option value="RESELLER">Reseller</option><option value="BUSINESS">Business</option></SelectField>}
        <SelectField label="How they agreed" value={v.consentMethod} onChange={set("consentMethod")}><option value="WHATSAPP_MESSAGE">WhatsApp message</option><option value="PHONE_CALL">Phone call</option><option value="IN_PERSON">In person</option></SelectField>
      </div>
      <Button onClick={save} loading={busy} disabled={!v.fullName || !v.phone}>Create application</Button>
    </div>
  );
}
