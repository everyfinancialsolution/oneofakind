"use client";
import Link from "next/link";
import { useState } from "react";
import { useApi } from "@/lib/useApi";
import { dateShort, stateLabel } from "@/lib/format";
import { PageHeader } from "@/components/chrome/PortalShell";
import { DataTable, Tabs } from "@/components/admin/kit";
import { StatusPill, Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";

interface App { reference: string; kind: string; status: string; channel: string; fullName: string; phone: string; city: string | null; businessName: string | null; createdAt: string; ageHours: number; docs: number; hasConsent: boolean }
const VIEWS = { review: "SUBMITTED,UNDER_REVIEW", docs: "DOCS_REQUESTED", drafts: "DRAFT", done: "APPROVED,REJECTED,WITHDRAWN" } as const;

export default function OnboardingQueue() {
  const [view, setView] = useState<keyof typeof VIEWS>("review");
  const [search, setSearch] = useState("");
  const { data } = useApi<{ applications: App[] }>(`/v1/admin/onboarding?status=${VIEWS[view]}${search ? `&search=${encodeURIComponent(search)}` : ""}`);
  return (
    <div className="space-y-4">
      <PageHeader title="Onboarding" sub="Seller and reseller applications, online and via WhatsApp. Oldest first." actions={<Button href="/admin/onboarding/new">Register from WhatsApp</Button>} />
      <Tabs value={view} onChange={setView} tabs={[{ k: "review", label: "To review" }, { k: "docs", label: "Waiting for documents" }, { k: "drafts", label: "Drafts / WhatsApp refs" }, { k: "done", label: "Decided" }]} />
      <input className="h-10 w-full max-w-sm rounded-md border hairline bg-surface px-3 text-sm" placeholder="Search name, phone or reference" value={search} onChange={(e) => setSearch(e.target.value)} aria-label="Search applications" />
      <DataTable rows={data?.applications} rowKey={(a) => a.reference} empty="No applications in this view." cols={[
        { h: "Ref", c: (a) => <Link className="num underline" href={`/admin/onboarding/${a.reference}`}>{a.reference}</Link> },
        { h: "Applicant", c: (a) => <div><div className="font-medium">{a.fullName}</div><div className="text-xs text-muted">{a.businessName ?? ""} {a.city ? `· ${a.city}` : ""}</div></div> },
        { h: "Type", c: (a) => stateLabel(a.kind) },
        { h: "Channel", c: (a) => a.channel.startsWith("ASSISTED") ? <Badge tone="champagne">{stateLabel(a.channel.replace("ASSISTED_", ""))}</Badge> : "Online" },
        { h: "Phone", c: (a) => <span className="num">{a.phone}</span> },
        { h: "Docs", c: (a) => <span className="num">{a.docs}</span> },
        { h: "Consent", c: (a) => (a.hasConsent ? "Yes" : <span className="text-[#8A2E25]">Missing</span>) },
        { h: "Status", c: (a) => <StatusPill state={a.status} /> },
        { h: "Waiting", c: (a) => <span className={a.ageHours > 24 ? "text-[#8A2E25]" : ""}>{a.ageHours < 48 ? `${a.ageHours} h` : dateShort(a.createdAt)}</span> },
      ]} />
    </div>
  );
}
