"use client";
import { use, useState } from "react";
import { call } from "@/lib/client";
import { useApi } from "@/lib/useApi";
import { dateShort, dateTime, stateLabel } from "@/lib/format";
import { PageHeader } from "@/components/chrome/PortalShell";
import { ActionButton, KV, Panel } from "@/components/admin/kit";
import { StatusPill } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { Checkbox, SelectField, TextField } from "@/components/ui/Field";
import { Notice } from "@/components/ui/misc";
import { useToast } from "@/components/ui/Toast";

interface Detail {
  application: { reference: string; kind: string; status: string; channel: string; fullName: string; phone: string; email: string | null; city: string | null; businessName: string | null; shopLink: string | null; intendedSellerType: string | null; decisionNote: string | null; createdAt: string; missing: string[]; consentMethod: string | null; consentAt: string | null; hasConsentEvidence: boolean; registeredBy: string | null; decidedBy: string | null; decidedAt: string | null; assignedTo: string | null };
  documents: Array<{ id: string; kind: string; receivedVia: string; receivedAt: string; verifiedAt: string | null; rejectedReason: string | null; deleteAfter: string | null }>;
  duplicates: { otherApplications: Array<{ reference: string; status: string; kind: string }>; existingUsers: Array<{ id: string; name: string; roles: string[]; disabledAt: string | null }> };
}
const DOC_KINDS = ["ID_FRONT", "ID_BACK", "PAYOUT_ACCOUNT_PROOF", "SHOP_PROOF", "BUSINESS_REG", "OTHER"];

export default function ApplicationDetail({ params }: { params: Promise<{ ref: string }> }) {
  const { ref } = use(params);
  const { data, reload, error } = useApi<Detail>(`/v1/admin/onboarding/${ref}`);
  const [docKind, setDocKind] = useState("ID_FRONT");
  const [consentMethod, setConsentMethod] = useState("WHATSAPP_MESSAGE");
  const [cnic, setCnic] = useState("");
  const [allowStaff, setAllowStaff] = useState(false);
  const [rejectDocs, setRejectDocs] = useState<string[]>([]);
  const toast = useToast();
  if (error) return <Notice tone="bad">{error.message}</Notice>;
  if (!data) return <p className="text-sm text-muted">Loading…</p>;
  const a = data.application;
  const decidable = ["SUBMITTED", "UNDER_REVIEW"].includes(a.status);
  const upload = async (path: string, field: Record<string, string>, file: File | undefined) => {
    if (!file) return;
    const fd = new FormData(); fd.set("file", file); for (const [k, v] of Object.entries(field)) fd.set(k, v);
    try { await call(path, { form: fd }); toast("Uploaded", "good"); await reload(); } catch (e) { toast((e as Error).message, "bad"); }
  };
  return (
    <div className="max-w-5xl space-y-5">
      <PageHeader title={a.fullName || "(details pending)"} sub={<span className="num">{a.reference} · {stateLabel(a.kind)} · {a.channel.startsWith("ASSISTED") ? `Assisted (${stateLabel(a.channel.replace("ASSISTED_", ""))})` : "Online"}</span>} actions={<StatusPill state={a.status} />} />
      {(data.duplicates.otherApplications.length > 0 || data.duplicates.existingUsers.length > 0) && <Notice tone="warn">Same phone already used: {[...data.duplicates.otherApplications.map((d) => `${d.reference} (${stateLabel(d.status)})`), ...data.duplicates.existingUsers.map((u) => `account "${u.name}"${u.disabledAt ? " (disabled)" : ""}`)].join(", ")}. Check before approving.</Notice>}
      <Panel title="Applicant">
        <KV items={[["Phone", <span key="p" className="num">{a.phone}</span>], ["Email", a.email], ["City", a.city], ["Business", a.businessName], ["Shop link", a.shopLink ? <a key="l" className="underline" href={a.shopLink} target="_blank" rel="noreferrer noopener">{a.shopLink}</a> : null], ["Seller type", a.intendedSellerType ? stateLabel(a.intendedSellerType) : null], ["Registered by", a.registeredBy ?? "Self (online)"], ["Assigned to", a.assignedTo], ["Created", dateTime(a.createdAt)], ["Decided", a.decidedAt ? `${dateTime(a.decidedAt)} by ${a.decidedBy}` : null], ["Decision note", a.decisionNote]]} />
        <div className="mt-3"><ActionButton path={`/v1/admin/onboarding/${ref}`} method="PATCH" body={{ assignToMe: true }} label="Assign to me" onDone={reload} /></div>
      </Panel>
      <Panel title="Consent">
        {a.consentMethod ? <p className="text-sm">Agreed by <strong>{stateLabel(a.consentMethod)}</strong> on {dateTime(a.consentAt)}. Evidence: {a.hasConsentEvidence ? "attached" : <span className="text-[#8A2E25]">missing</span>}</p> : <p className="text-sm text-[#8A2E25]">No consent recorded yet.</p>}
        <div className="mt-3 flex flex-wrap items-end gap-3">
          <SelectField label="Method" value={consentMethod} onChange={(e) => setConsentMethod(e.target.value)} className="w-48"><option value="WHATSAPP_MESSAGE">WhatsApp message</option><option value="PHONE_CALL">Phone call</option><option value="IN_PERSON">In person</option></SelectField>
          <label className="text-sm"><span className="mb-1 block font-medium">Screenshot / note photo</span><input type="file" accept="image/*" onChange={(e) => upload(`/v1/admin/onboarding/${ref}/consent-evidence`, { method: consentMethod }, e.target.files?.[0])} /></label>
        </div>
      </Panel>
      <Panel title="Documents (restricted, every view is logged)">
        {a.missing.length > 0 && <Notice tone="warn" className="mb-3">Missing: {a.missing.map(stateLabel).join(", ")}</Notice>}
        <ul className="divide-y divide-[color:var(--hairline,#e5e0d8)] text-sm">
          {data.documents.map((d) => (
            <li key={d.id} className="flex flex-wrap items-center justify-between gap-2 py-2">
              <span><strong>{stateLabel(d.kind)}</strong> · via {stateLabel(d.receivedVia)} · {dateShort(d.receivedAt)} {d.rejectedReason && <span className="text-[#8A2E25]">· rejected: {d.rejectedReason}</span>} {d.deleteAfter && <span className="text-muted">· deleted after {dateShort(d.deleteAfter)}</span>}</span>
              <span className="flex items-center gap-3">
                <a className="underline" href={`/v1/admin/onboarding/documents/${d.id}`} target="_blank" rel="noreferrer">View</a>
                {decidable && <label className="flex items-center gap-1 text-xs"><input type="checkbox" checked={rejectDocs.includes(d.id)} onChange={(e) => setRejectDocs((x) => (e.target.checked ? [...x, d.id] : x.filter((y) => y !== d.id)))} />reject</label>}
              </span>
            </li>
          ))}
          {!data.documents.length && <li className="py-2 text-muted">No documents yet.</li>}
        </ul>
        {!["APPROVED", "REJECTED", "WITHDRAWN"].includes(a.status) && (
          <div className="mt-3 flex flex-wrap items-end gap-3">
            <SelectField label="Document" value={docKind} onChange={(e) => setDocKind(e.target.value)} className="w-56">{DOC_KINDS.map((k) => <option key={k} value={k}>{stateLabel(k)}</option>)}</SelectField>
            <label className="text-sm"><span className="mb-1 block font-medium">Image received on WhatsApp</span><input type="file" accept="image/*,application/pdf" onChange={(e) => upload(`/v1/admin/onboarding/${ref}/documents`, { kind: docKind, via: "WHATSAPP" }, e.target.files?.[0])} /></label>
          </div>
        )}
      </Panel>
      <Panel title="Decision">
        {a.status === "DRAFT" || a.status === "DOCS_REQUESTED" ? (
          <ActionButton path={`/v1/admin/onboarding/${ref}/submit`} label="Submit for review" variant="primary" size="md" onDone={reload} />
        ) : decidable ? (
          <div className="space-y-4">
            <div className="flex flex-wrap items-end gap-4">
              <TextField label="CNIC last 4 digits" optional inputMode="numeric" maxLength={4} value={cnic} onChange={(e) => setCnic(e.target.value.replace(/\D/g, ""))} className="w-44" />
              {a.kind === "SELLER" && <Checkbox label="Seller allows authorised staff to list for them" checked={allowStaff} onChange={(e) => setAllowStaff(e.target.checked)} />}
            </div>
            <div className="flex flex-wrap gap-2">
              <ActionButton path={`/v1/admin/onboarding/${ref}/approve`} body={{ cnicLast4: cnic || undefined, ...(a.kind === "SELLER" ? { allowStaffListing: allowStaff } : {}) }} label="Approve" variant="primary" size="md" confirm="Approve this application? The applicant gets an activation link by SMS and must confirm with their own OTP." onDone={reload} />
              <ActionButton path={`/v1/admin/onboarding/${ref}/request-documents`} body={{ rejectDocumentIds: rejectDocs }} note="note" noteLabel="What do they need to send? (sent to the applicant)" label="Request documents" size="md" onDone={reload} />
              <ActionButton path={`/v1/admin/onboarding/${ref}/reject`} note="reason" noteLabel="Reason (sent to the applicant)" label="Reject" variant="danger" size="md" onDone={reload} />
            </div>
          </div>
        ) : a.status === "APPROVED" ? (
          <Button variant="secondary" onClick={async () => { try { const r = await call<{ link: string }>(`/v1/admin/onboarding/${ref}/resend-activation`, { method: "POST" }); toast(`Sent: ${r.link}`, "good"); } catch (e) { toast((e as Error).message, "bad"); } }}>Resend activation SMS</Button>
        ) : <p className="text-sm text-muted">{stateLabel(a.status)}.</p>}
      </Panel>
    </div>
  );
}
