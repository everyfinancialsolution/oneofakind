"use client";
import { useState } from "react";
import { call } from "@/lib/client";
import { useApi } from "@/lib/useApi";
import { PageHeader } from "@/components/chrome/PortalShell";
import { Panel } from "@/components/admin/kit";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { Checkbox, TextArea, TextField } from "@/components/ui/Field";
import { Notice } from "@/components/ui/misc";
import { useToast } from "@/components/ui/Toast";

interface Block { key: string; title: string; body: string | null; linkHref: string | null; linkLabel: string | null; position: number; published: boolean }
const blank: Block = { key: "", title: "", body: "", linkHref: "", linkLabel: "", position: 0, published: false };

/** Home page and campaign blocks. Promotions are editorial campaigns - no discount codes in v1. */
export default function Cms() {
  const { data, reload } = useApi<{ blocks: Block[] }>("/v1/admin/catalog/cms");
  const [edit, setEdit] = useState<Block | null>(null);
  const toast = useToast();
  const save = async () => {
    if (!edit) return;
    try { await call(`/v1/admin/catalog/cms/${encodeURIComponent(edit.key)}`, { method: "PUT", body: { title: edit.title, body: edit.body || null, linkHref: edit.linkHref || null, linkLabel: edit.linkLabel || null, position: Number(edit.position) || 0, published: edit.published } }); toast("Saved", "good"); setEdit(null); await reload(); }
    catch (e) { toast((e as Error).message, "bad"); }
  };
  return (
    <div className="max-w-4xl space-y-4">
      <PageHeader title="Home & campaigns" sub="Keys: home.hero, home.drop.1, home.drop.2, home.notice … Published blocks appear on the home page." actions={<Button onClick={() => setEdit({ ...blank })}>New block</Button>} />
      <Notice>Never put bundle prices in campaign blocks. They are public.</Notice>
      {data?.blocks.map((b) => (
        <Panel key={b.key} title={b.title} actions={<div className="flex items-center gap-2"><span className="font-mono text-xs text-muted">{b.key}</span>{b.published ? <Badge tone="good">Live</Badge> : <Badge>Draft</Badge>}<Button size="sm" variant="ghost" onClick={() => setEdit({ ...b })}>Edit</Button><Button size="sm" variant="ghost" onClick={async () => { if (!window.confirm(`Delete ${b.key}?`)) return; await call(`/v1/admin/catalog/cms/${encodeURIComponent(b.key)}`, { method: "DELETE" }); await reload(); }}>Delete</Button></div>}>
          <p className="text-sm">{b.body}</p>{b.linkHref && <p className="mt-1 text-xs text-muted">{b.linkLabel} → {b.linkHref}</p>}
        </Panel>
      ))}
      {edit && (
        <Panel title={edit.key ? `Edit ${edit.key}` : "New block"}>
          <div className="grid gap-3 sm:grid-cols-2">
            <TextField label="Key" value={edit.key} onChange={(e) => setEdit({ ...edit, key: e.target.value.replace(/[^a-z0-9.\-_]/gi, "") })} />
            <TextField label="Position" inputMode="numeric" value={String(edit.position)} onChange={(e) => setEdit({ ...edit, position: Number(e.target.value.replace(/\D/g, "")) })} />
            <TextField label="Title" value={edit.title} onChange={(e) => setEdit({ ...edit, title: e.target.value })} className="sm:col-span-2" />
            <TextArea label="Text" value={edit.body ?? ""} onChange={(e) => setEdit({ ...edit, body: e.target.value })} className="sm:col-span-2" rows={3} />
            <TextField label="Link (internal path)" placeholder="/discover" value={edit.linkHref ?? ""} onChange={(e) => setEdit({ ...edit, linkHref: e.target.value })} />
            <TextField label="Link label" value={edit.linkLabel ?? ""} onChange={(e) => setEdit({ ...edit, linkLabel: e.target.value })} />
            <Checkbox label="Published" checked={edit.published} onChange={(e) => setEdit({ ...edit, published: e.target.checked })} />
          </div>
          <div className="mt-3 flex gap-2"><Button onClick={save} disabled={!edit.key || !edit.title}>Save</Button><Button variant="ghost" onClick={() => setEdit(null)}>Cancel</Button></div>
        </Panel>
      )}
    </div>
  );
}
