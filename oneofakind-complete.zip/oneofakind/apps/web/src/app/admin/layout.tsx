import type { ReactNode } from "react";
import { requireUser } from "@/lib/guard";
import { PortalShell, type NavGroup } from "@/components/chrome/PortalShell";

export const dynamic = "force-dynamic";
const STAFF_ROLES = ["ADMIN", "SUPPORT", "FINANCE", "MODERATOR", "SELLER_AGENT"];

/** Nav is filtered by role for clarity; every endpoint enforces the same roles server-side. */
const NAV: Array<NavGroup & { roles?: string[] }> = [
  { items: [{ href: "/admin", label: "Dashboard", exact: true }] },
  { title: "People", items: [{ href: "/admin/onboarding", label: "Onboarding" }, { href: "/admin/sellers", label: "Sellers" }, { href: "/admin/users", label: "Users & roles" }] },
  { title: "Trust", roles: ["ADMIN", "MODERATOR"], items: [{ href: "/admin/moderation", label: "Listings & lots" }, { href: "/admin/moderation/reports", label: "Reports & appeals" }] },
  { title: "Support", roles: ["ADMIN", "SUPPORT", "FINANCE"], items: [{ href: "/admin/orders", label: "Orders" }, { href: "/admin/claims", label: "Damage claims" }, { href: "/admin/support", label: "Tickets & disputes" }] },
  { title: "Buying", roles: ["ADMIN", "FINANCE"], items: [{ href: "/admin/buying", label: "Direct purchases" }, { href: "/admin/buying/budgets", label: "Budgets" }, { href: "/admin/agreements", label: "Managed resale agreements" }] },
  { title: "Finance", roles: ["ADMIN", "FINANCE"], items: [{ href: "/admin/finance", label: "Reconciliation" }, { href: "/admin/finance/payouts", label: "Payout accounts" }, { href: "/admin/finance/statements", label: "Statements" }, { href: "/admin/finance/ledger", label: "Ledger" }, { href: "/admin/finance/payments", label: "Payments" }] },
  { title: "Site", roles: ["ADMIN", "MODERATOR"], items: [{ href: "/admin/catalog", label: "Categories & styles" }, { href: "/admin/cms", label: "Home & campaigns" }, { href: "/admin/collections", label: "Collections" }] },
  { title: "AI", roles: ["ADMIN"], items: [{ href: "/admin/ai", label: "AI jobs" }] },
  { title: "System", roles: ["ADMIN", "FINANCE"], items: [{ href: "/admin/settings", label: "Settings" }, { href: "/admin/audit", label: "Audit log" }] },
];

export default async function AdminLayout({ children }: { children: ReactNode }) {
  const { user, allowed } = await requireUser("/admin", STAFF_ROLES);
  if (!allowed) return <main className="page py-24"><h1 className="font-display text-3xl">Staff only</h1><p className="mt-2 text-muted">This area is for the ONEOFAKIND team.</p></main>;
  const nav = NAV.filter((g) => !g.roles || g.roles.some((r) => user.roles.includes(r))).map(({ title, items }) => ({ title, items }));
  return <PortalShell title="Admin" nav={nav}>{children}</PortalShell>;
}
