"use client";
import { useState } from "react";
import { call } from "@/lib/client";
import { useApi } from "@/lib/useApi";
import { dateTime } from "@/lib/format";
import { PageHeader } from "@/components/chrome/PortalShell";
import { DataTable } from "@/components/admin/kit";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";

interface E { id: string; at: string; actor: string; actorId: string | null; onBehalfOfId: string | null; action: string; entity: string; entityId: string; before: unknown; after: unknown }

/** Append-only audit log (DB trigger blocks UPDATE/DELETE). */
export default function Audit() {
  const [f, setF] = useState({ action: "", entity: "", entityId: "" });
  const qs = `limit=100${f.action ? `&action=${encodeURIComponent(f.action)}` : ""}${f.entity ? `&entity=${encodeURIComponent(f.entity)}` : ""}${f.entityId ? `&entityId=${encodeURIComponent(f.entityId)}` : ""}`;
  const { data, setData } = useApi<{ events: E[]; nextCursor: string | null }>(`/v1/admin/audit?${qs}`);
  const more = async () => { if (!data?.nextCursor) return; const n = await call<{ events: E[]; nextCursor: string | null }>(`/v1/admin/audit?${qs}&cursor=${data.nextCursor}`); setData({ events: [...data.events, ...n.events], nextCursor: n.nextCursor }); };
  return (
    <div className="space-y-4">
      <PageHeader title="Audit log" />
      <div className="flex flex-wrap gap-2">
        {(["action", "entity", "entityId"] as const).map((k) => <input key={k} className="h-10 w-48 rounded-md border hairline bg-surface px-3 text-sm" placeholder={k === "entityId" ? "Entity id" : k === "entity" ? "Entity (e.g. Listing)" : "Action contains…"} value={f[k]} onChange={(e) => setF((x) => ({ ...x, [k]: e.target.value }))} aria-label={k} />)}
      </div>
      <DataTable rows={data?.events} rowKey={(e) => e.id} cols={[
        { h: "When", c: (e) => <span className="whitespace-nowrap">{dateTime(e.at)}</span> },
        { h: "Who", c: (e) => <div>{e.actor}{e.onBehalfOfId && <div><Badge tone="champagne">on behalf of {e.onBehalfOfId.slice(0, 8)}</Badge></div>}</div> },
        { h: "Action", c: (e) => <span className="font-mono text-xs">{e.action}</span> },
        { h: "Entity", c: (e) => <span className="text-xs">{e.entity} <span className="font-mono">{e.entityId.slice(0, 12)}</span></span> },
        { h: "Change", c: (e) => <details className="max-w-md text-xs"><summary className="cursor-pointer text-muted">details</summary><pre className="mt-1 overflow-x-auto whitespace-pre-wrap">{JSON.stringify({ before: e.before, after: e.after }, null, 1)}</pre></details> },
      ]} />
      {data?.nextCursor && <Button variant="secondary" onClick={more}>Load more</Button>}
    </div>
  );
}
