"use client";
import { useState } from "react";
import { useApi } from "@/lib/useApi";
import { dateTime, pkr, stateLabel } from "@/lib/format";
import { PageHeader } from "@/components/chrome/PortalShell";
import { ActionButton, DataTable } from "@/components/admin/kit";
import { StatusPill } from "@/components/ui/Badge";

interface O { reference: string; state: string; totalMinor: number; createdAt: string; paidAt: string | null; buyer: string; phone: string | null; payment: { state: string; method: string } | null; groups: Array<{ id: string; state: string; mode: string; sellerId: string; shippingMinor: number; subtotalMinor: number }> }

export default function Orders() {
  const [q, setQ] = useState("");
  const [state, setState] = useState("");
  const { data, reload } = useApi<{ orders: O[] }>(`/v1/admin/orders?limit=100${q ? `&q=${encodeURIComponent(q)}` : ""}${state ? `&state=${state}` : ""}`);
  return (
    <div className="space-y-4">
      <PageHeader title="Orders" sub="Prepaid only. Cancel a paid seller shipment before dispatch to refund the buyer in full (items go back on sale)." />
      <div className="flex flex-wrap gap-2">
        <input className="h-10 w-full max-w-xs rounded-md border hairline bg-surface px-3 text-sm" placeholder="Order ref or buyer name" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search orders" />
        <select className="h-10 rounded-md border hairline bg-surface px-2 text-sm" value={state} onChange={(e) => setState(e.target.value)} aria-label="State">
          {["", "PENDING_PAYMENT", "PAID", "PROCESSING", "PARTIALLY_FULFILLED", "FULFILLED", "COMPLETED", "REFUND_PENDING", "REFUNDED", "CANCELLED"].map((s) => <option key={s} value={s}>{s ? stateLabel(s) : "All states"}</option>)}
        </select>
      </div>
      <DataTable rows={data?.orders} rowKey={(o) => o.reference} cols={[
        { h: "Ref", c: (o) => <span className="num font-medium">{o.reference}</span> },
        { h: "Buyer", c: (o) => <div>{o.buyer}<div className="num text-xs text-muted">{o.phone}</div></div> },
        { h: "Total", c: (o) => <span className="num">{pkr(o.totalMinor)}</span> },
        { h: "Payment", c: (o) => (o.payment ? `${stateLabel(o.payment.state)} · ${stateLabel(o.payment.method)}` : "-") },
        { h: "State", c: (o) => <StatusPill state={o.state} /> },
        { h: "Shipments", c: (o) => <ul className="space-y-1">{o.groups.map((g) => <li key={g.id} className="flex flex-wrap items-center gap-2 text-xs"><span>{g.sellerId === "PLATFORM" ? "Warehouse" : stateLabel(g.mode)} · {pkr(g.subtotalMinor + g.shippingMinor)}</span><StatusPill state={g.state} />{["PAID", "PROCESSING"].includes(g.state) && <ActionButton path={`/v1/admin/groups/${g.id}/cancel`} note="reason" noteLabel="Why is it cancelled? (buyer is refunded in full)" label="Cancel & refund" variant="danger" onDone={reload} />}</li>)}</ul> },
        { h: "Placed", c: (o) => dateTime(o.createdAt) },
      ]} />
    </div>
  );
}
