"use client";
import { useApi } from "@/lib/useApi";
import { pkr, stateLabel } from "@/lib/format";
import { PageHeader } from "@/components/chrome/PortalShell";
import { Panel, QueueCard } from "@/components/admin/kit";
import { Stat } from "@/components/ui/misc";

interface Dash { gmv30dMinor: number; orders30d: number; ordersByState: Array<{ state: string; count: number }>; queues: Record<string, number> }

export default function AdminHome() {
  const { data, error } = useApi<Dash>("/v1/admin/dashboard");
  const q = data?.queues;
  return (
    <div className="space-y-6">
      <PageHeader title="Dashboard" sub="Queues that need a person, and the last 30 days." />
      {error && <p className="text-sm text-[#8A2E25]">{error.message}</p>}
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Stat label="Paid orders value (30 days)" value={data ? pkr(data.gmv30dMinor) : "-"} />
        <Stat label="Paid orders (30 days)" value={data?.orders30d ?? "-"} />
      </div>
      <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-5">
        <QueueCard href="/admin/onboarding" label="Onboarding to review" count={q?.onboarding} />
        <QueueCard href="/admin/moderation" label="Listings to review" count={q?.pendingListings} />
        <QueueCard href="/admin/moderation?tab=bundles" label="Lots to review" count={q?.pendingBundles} />
        <QueueCard href="/admin/moderation/reports" label="Reports & appeals" count={q?.openReports} tone="bad" />
        <QueueCard href="/admin/claims" label="Damage claims" count={q?.claims} tone="bad" />
        <QueueCard href="/admin/support" label="Open tickets" count={q?.tickets} />
        <QueueCard href="/admin/buying" label="Direct purchases open" count={q?.dps} />
        <QueueCard href="/admin/finance/payouts" label="Payout accounts to verify" count={q?.payoutsToVerify} tone="bad" />
        <QueueCard href="/admin/finance/statements" label="Statements to pay" count={q?.statementsToPay} />
        <QueueCard href="/admin/ai" label="AI failures (30 days)" count={q?.aiFailures} />
      </div>
      <Panel title="Orders by state (all time)">
        <ul className="grid gap-2 text-sm sm:grid-cols-3 lg:grid-cols-5">{data?.ordersByState.map((o) => <li key={o.state} className="flex justify-between gap-2 border-b hairline py-1"><span>{stateLabel(o.state)}</span><span className="num">{o.count}</span></li>)}</ul>
      </Panel>
    </div>
  );
}
