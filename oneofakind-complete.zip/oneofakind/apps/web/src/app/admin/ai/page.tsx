"use client";
import { useApi } from "@/lib/useApi";
import { dateTime, stateLabel } from "@/lib/format";
import { PageHeader } from "@/components/chrome/PortalShell";
import { ActionButton, DataTable, Panel } from "@/components/admin/kit";
import { StatusPill } from "@/components/ui/Badge";
import { Notice, Stat } from "@/components/ui/misc";

interface O { days: number; quotaPerDay: number; providers: { image: string; text: string }; breakdown: Array<{ kind: string; state: string; provider: string; count: number; costMicros: number; avgLatencyMs: number }>; failures: Array<{ id: string; kind: string; state: string; error: string | null; attempts: number; user: string; createdAt: string }>; topUsers: Array<{ name: string; count: number }> }
const usd = (micros: number) => `$${(micros / 1_000_000).toFixed(2)}`;

export default function AdminAi() {
  const { data, reload, error } = useApi<O>("/v1/admin/ai");
  const total = data?.breakdown.reduce((a, r) => a + r.count, 0) ?? 0;
  const failed = data?.breakdown.filter((r) => r.state === "FAILED" || r.state === "TIMED_OUT").reduce((a, r) => a + r.count, 0) ?? 0;
  const cost = data?.breakdown.reduce((a, r) => a + r.costMicros, 0) ?? 0;
  return (
    <div className="space-y-5">
      <PageHeader title="AI jobs" sub="Server-side only. Generated media is always a separate, labelled asset; originals are never overwritten." />
      {error && <Notice tone="bad">{error.message}</Notice>}
      {data && (data.providers.image === "fake" || data.providers.text === "fake") && <Notice>Running local adapters (background removal heuristic, fact-only text template). No external AI provider is configured, so cost is zero. Set AI_IMAGE_PROVIDER / AI_TEXT_PROVIDER once a provider is chosen and its adapter written.</Notice>}
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Stat label={`Jobs (${data?.days ?? 30} days)`} value={total} /><Stat label="Failed / timed out" value={failed} /><Stat label="Provider cost" value={usd(cost)} /><Stat label="Quota per seller per day" value={data?.quotaPerDay ?? "-"} />
      </div>
      <Panel title="Breakdown">
        <DataTable rows={data?.breakdown} rowKey={(r) => `${r.kind}${r.state}${r.provider}`} empty="No AI jobs yet." cols={[
          { h: "Kind", c: (r) => stateLabel(r.kind) }, { h: "Provider", c: (r) => r.provider }, { h: "State", c: (r) => <StatusPill state={r.state} /> },
          { h: "Jobs", c: (r) => <span className="num">{r.count}</span> }, { h: "Avg latency", c: (r) => `${r.avgLatencyMs} ms` }, { h: "Cost", c: (r) => usd(r.costMicros) },
        ]} />
      </Panel>
      <Panel title="Recent failures">
        <DataTable rows={data?.failures} rowKey={(f) => f.id} empty="No failures." cols={[
          { h: "When", c: (f) => dateTime(f.createdAt) }, { h: "Kind", c: (f) => stateLabel(f.kind) }, { h: "User", c: (f) => f.user },
          { h: "Error", c: (f) => <span className="text-xs">{f.error}</span> }, { h: "Attempts", c: (f) => <span className="num">{f.attempts}</span> },
          { h: "", c: (f) => <ActionButton path={`/v1/admin/ai/jobs/${f.id}/retry`} label="Retry" onDone={reload} /> },
        ]} />
      </Panel>
      <Panel title="Top users"><ul className="text-sm">{data?.topUsers.map((u) => <li key={u.name} className="flex justify-between border-b hairline py-1"><span>{u.name}</span><span className="num">{u.count}</span></li>)}</ul></Panel>
    </div>
  );
}
