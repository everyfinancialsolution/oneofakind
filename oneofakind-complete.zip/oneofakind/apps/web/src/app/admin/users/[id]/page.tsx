"use client";
import { use } from "react";
import { useApi } from "@/lib/useApi";
import { dateTime, stateLabel } from "@/lib/format";
import { PageHeader } from "@/components/chrome/PortalShell";
import { ActionButton, DataTable, KV, Panel } from "@/components/admin/kit";
import { Badge } from "@/components/ui/Badge";
import { Notice } from "@/components/ui/misc";

interface D { user: { id: string; name: string; phone: string | null; email: string | null; roles: string[]; disabledAt: string | null; activatedAt: string | null; createdAt: string; sellerProfile: { displayName: string; status: string } | null; resellerVerification: { status: string; businessName: string } | null }; activity: Array<{ id: string; action: string; entity: string; entityId: string; createdAt: string; onBehalfOfId: string | null }> }
const GRANTABLE = ["SELLER_AGENT", "WAREHOUSE", "SUPPORT", "FINANCE", "MODERATOR", "ADMIN", "VERIFIED_RESELLER"];

export default function UserDetail({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const { data, reload, error } = useApi<D>(`/v1/admin/users/${id}`);
  if (error) return <Notice tone="bad">{error.message}</Notice>;
  if (!data) return <p className="text-sm text-muted">Loading…</p>;
  const u = data.user;
  return (
    <div className="max-w-5xl space-y-5">
      <PageHeader title={u.name} sub={<span className="num">{u.phone}</span>} actions={u.disabledAt ? <Badge tone="bad">Disabled</Badge> : undefined} />
      <Panel title="Account">
        <KV items={[["Email", u.email], ["Activated", u.activatedAt ? dateTime(u.activatedAt) : "No"], ["Joined", dateTime(u.createdAt)], ["Seller", u.sellerProfile ? `${u.sellerProfile.displayName} (${stateLabel(u.sellerProfile.status)})` : null], ["Reseller verification", u.resellerVerification ? `${u.resellerVerification.businessName} (${stateLabel(u.resellerVerification.status)})` : null]]} />
      </Panel>
      <Panel title="Roles (admin only)">
        <div className="flex flex-wrap gap-2">{u.roles.map((r) => <Badge key={r}>{stateLabel(r)}</Badge>)}</div>
        <p className="mt-2 text-xs text-muted">VERIFIED_RESELLER is normally granted by approving a reseller application. Removing it revokes the verification.</p>
        <div className="mt-3 flex flex-wrap gap-2">
          {GRANTABLE.map((r) => u.roles.includes(r)
            ? <ActionButton key={r} path={`/v1/admin/users/${id}/roles`} body={{ remove: [r] }} label={`Remove ${stateLabel(r)}`} confirm={`Remove ${stateLabel(r)} from ${u.name}?`} onDone={reload} />
            : <ActionButton key={r} path={`/v1/admin/users/${id}/roles`} body={{ add: [r] }} label={`Grant ${stateLabel(r)}`} variant="ghost" confirm={`Grant ${stateLabel(r)} to ${u.name}?`} onDone={reload} />)}
        </div>
        <div className="mt-4">
          {u.disabledAt
            ? <ActionButton path={`/v1/admin/users/${id}/disable`} body={{ disabled: false }} note="reason" label="Re-enable account" onDone={reload} />
            : <ActionButton path={`/v1/admin/users/${id}/disable`} body={{ disabled: true }} note="reason" label="Disable account" variant="danger" confirm="Disabling signs them out everywhere." onDone={reload} />}
        </div>
      </Panel>
      <Panel title="Recent activity">
        <DataTable rows={data.activity} rowKey={(a) => a.id} empty="No activity." cols={[
          { h: "When", c: (a) => dateTime(a.createdAt) }, { h: "Action", c: (a) => <span className="font-mono text-xs">{a.action}</span> },
          { h: "Entity", c: (a) => `${a.entity} ${a.entityId.slice(0, 10)}` }, { h: "", c: (a) => (a.onBehalfOfId ? <Badge tone="champagne">on behalf</Badge> : null) },
        ]} />
      </Panel>
    </div>
  );
}
