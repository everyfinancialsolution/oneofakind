"use client";
import Link from "next/link";
import { useState } from "react";
import { useApi } from "@/lib/useApi";
import { dateShort, stateLabel } from "@/lib/format";
import { PageHeader } from "@/components/chrome/PortalShell";
import { DataTable } from "@/components/admin/kit";
import { Badge } from "@/components/ui/Badge";

interface U { id: string; name: string; phone: string | null; email: string | null; roles: string[]; activated: boolean; disabled: boolean; deletionRequested: boolean; seller: { slug: string; status: string } | null; createdAt: string }
const ROLES = ["", "CUSTOMER", "SELLER", "VERIFIED_RESELLER", "SELLER_AGENT", "WAREHOUSE", "SUPPORT", "FINANCE", "MODERATOR", "ADMIN"];

export default function Users() {
  const [q, setQ] = useState("");
  const [role, setRole] = useState("");
  const { data } = useApi<{ users: U[] }>(`/v1/admin/users?limit=100${q ? `&q=${encodeURIComponent(q)}` : ""}${role ? `&role=${role}` : ""}`);
  return (
    <div className="space-y-4">
      <PageHeader title="Users & roles" sub="Role changes are admin-only and written to the audit log." />
      <div className="flex flex-wrap gap-2">
        <input className="h-10 w-full max-w-xs rounded-md border hairline bg-surface px-3 text-sm" placeholder="Name, email or phone" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search users" />
        <select className="h-10 rounded-md border hairline bg-surface px-2 text-sm" value={role} onChange={(e) => setRole(e.target.value)} aria-label="Filter by role">{ROLES.map((r) => <option key={r} value={r}>{r ? stateLabel(r) : "All roles"}</option>)}</select>
      </div>
      <DataTable rows={data?.users} rowKey={(u) => u.id} cols={[
        { h: "Name", c: (u) => <Link className="underline" href={`/admin/users/${u.id}`}>{u.name}</Link> },
        { h: "Phone", c: (u) => <span className="num">{u.phone ?? "-"}</span> },
        { h: "Roles", c: (u) => <div className="flex flex-wrap gap-1">{u.roles.map((r) => <Badge key={r} tone={["ADMIN", "FINANCE"].includes(r) ? "ink" : r === "SELLER_AGENT" ? "champagne" : "neutral"}>{stateLabel(r)}</Badge>)}</div> },
        { h: "Status", c: (u) => (u.disabled ? <Badge tone="bad">Disabled</Badge> : !u.activated ? <Badge tone="warn">Not activated</Badge> : u.deletionRequested ? <Badge tone="warn">Deletion requested</Badge> : "Active") },
        { h: "Joined", c: (u) => dateShort(u.createdAt) },
      ]} />
    </div>
  );
}
