"use client";
import { useState } from "react";
import { call } from "@/lib/client";
import { useApi } from "@/lib/useApi";
import { dateShort, pkr } from "@/lib/format";
import { PageHeader } from "@/components/chrome/PortalShell";
import { ActionButton, DataTable, Panel, Tabs } from "@/components/admin/kit";
import { Badge, StatusPill } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { TextField } from "@/components/ui/Field";
import { useToast } from "@/components/ui/Toast";

interface S { id: string; seller: string; payoutVerified: boolean; payoutMethod: string | null; periodStart: string; periodEnd: string; state: string; grossMinor: number; commissionMinor: number; refundsMinor: number; netMinor: number; lines: number; payoutRef: string | null; paidAt: string | null }
const VIEWS = { draft: "DRAFT", final: "FINALIZED", paid: "PAID" } as const;
const iso = (d: Date) => d.toISOString().slice(0, 10);

/** Settlement: lines delivered ≥ 7 days ago with no open claim/dispute. DRAFT → FINALIZED → PAID (own-name verified account only). */
export default function Statements() {
  const [view, setView] = useState<keyof typeof VIEWS>("draft");
  const { data, reload } = useApi<{ statements: S[] }>(`/v1/admin/finance/statements?state=${VIEWS[view]}`);
  const today = new Date();
  const [period, setPeriod] = useState({ periodStart: iso(new Date(today.getFullYear(), today.getMonth(), 1)), periodEnd: iso(today) });
  const toast = useToast();
  const generate = async () => {
    try { const r = await call<{ created: number }>("/v1/admin/finance/statements/generate", { body: { periodStart: period.periodStart, periodEnd: `${period.periodEnd}T23:59:59.999Z` } }); toast(`${r.created} statement(s) created`, "good"); setView("draft"); await reload(); }
    catch (e) { toast((e as Error).message, "bad"); }
  };
  return (
    <div className="space-y-4">
      <PageHeader title="Seller statements" />
      <Panel title="Generate statements">
        <div className="flex flex-wrap items-end gap-3">
          <TextField label="From" type="date" value={period.periodStart} onChange={(e) => setPeriod((p) => ({ ...p, periodStart: e.target.value }))} />
          <TextField label="To" type="date" value={period.periodEnd} onChange={(e) => setPeriod((p) => ({ ...p, periodEnd: e.target.value }))} />
          <Button onClick={generate}>Generate</Button>
        </div>
        <p className="mt-2 text-xs text-muted">Includes every unsettled seller line delivered at least 7 days before the end date, without an open damage claim or dispute. A line is never settled twice. Pieces ONEOFAKIND owns never appear.</p>
      </Panel>
      <Tabs value={view} onChange={setView} tabs={[{ k: "draft", label: "Drafts" }, { k: "final", label: "Finalised, ready to pay" }, { k: "paid", label: "Paid" }]} />
      <DataTable rows={data?.statements} rowKey={(s) => s.id} empty="No statements." cols={[
        { h: "Seller", c: (s) => <div>{s.seller}<div className="text-xs">{s.payoutVerified ? <Badge tone="good">Own-name verified</Badge> : <Badge tone="bad">Payout not verified</Badge>}</div></div> },
        { h: "Period", c: (s) => `${dateShort(s.periodStart)} - ${dateShort(s.periodEnd)}` }, { h: "Lines", c: (s) => <span className="num">{s.lines}</span> },
        { h: "Gross", c: (s) => <span className="num">{pkr(s.grossMinor)}</span> }, { h: "Commission", c: (s) => <span className="num">{pkr(s.commissionMinor)}</span> },
        { h: "Damage deductions", c: (s) => <span className="num">{pkr(s.refundsMinor)}</span> }, { h: "Net payout", c: (s) => <span className="num font-semibold">{pkr(s.netMinor)}</span> },
        { h: "State", c: (s) => <div><StatusPill state={s.state} />{s.payoutRef && <div className="num text-xs text-muted">{s.payoutRef}</div>}</div> },
        { h: "", c: (s) => <div className="flex flex-wrap gap-1">
          <a className="text-sm underline" href={`/v1/admin/finance/statements/${s.id}?format=csv`}>CSV</a>
          {s.state === "DRAFT" && <ActionButton path={`/v1/admin/finance/statements/${s.id}/finalize`} label="Finalise" confirm="Finalise this statement? The seller will be able to see it." onDone={reload} />}
          {s.state === "FINALIZED" && <ActionButton path={`/v1/admin/finance/statements/${s.id}/paid`} extra={[{ name: "payoutRef", label: "Bank / wallet transfer reference", placeholder: "IBFT-…" }]} confirm={`Record that ${pkr(s.netMinor)} was sent to ${s.seller}'s verified own-name account.`} label="Mark paid" variant="primary" onDone={reload} />}
        </div> },
      ]} />
    </div>
  );
}
