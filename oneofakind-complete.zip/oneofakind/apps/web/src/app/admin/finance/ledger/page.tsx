"use client";
import { useState } from "react";
import { call } from "@/lib/client";
import { useApi } from "@/lib/useApi";
import { dateTime, pkr, stateLabel } from "@/lib/format";
import { PageHeader } from "@/components/chrome/PortalShell";
import { DataTable } from "@/components/admin/kit";
import { Button } from "@/components/ui/Button";

interface E { id: string; txnId: string; at: string; account: string; ownerRef: string; debitMinor: number; creditMinor: number; refType: string; refId: string; memo: string | null }
const TYPES = ["", "CASH_PROVIDER", "SELLER_PAYABLE", "COMMISSION_REVENUE", "PLATFORM_REVENUE", "INVENTORY_ASSET", "COGS", "FEES_EXPENSE", "REFUNDS_PAYABLE", "CUSTOMER_RECEIVABLE"];

/** Append-only double-entry ledger (DB trigger enforces balanced transactions). Read-only here. */
export default function Ledger() {
  const [type, setType] = useState("");
  const [ownerRef, setOwnerRef] = useState("");
  const qs = `limit=100${type ? `&type=${type}` : ""}${ownerRef ? `&ownerRef=${encodeURIComponent(ownerRef)}` : ""}`;
  const { data, setData } = useApi<{ entries: E[]; nextCursor: string | null }>(`/v1/admin/finance/ledger?${qs}`);
  const more = async () => { if (!data?.nextCursor) return; const n = await call<{ entries: E[]; nextCursor: string | null }>(`/v1/admin/finance/ledger?${qs}&cursor=${data.nextCursor}`); setData({ entries: [...data.entries, ...n.entries], nextCursor: n.nextCursor }); };
  return (
    <div className="space-y-4">
      <PageHeader title="Ledger" sub="Every money movement, append-only. Corrections are new reversing entries." />
      <div className="flex flex-wrap gap-2">
        <select className="h-10 rounded-md border hairline bg-surface px-2 text-sm" value={type} onChange={(e) => setType(e.target.value)} aria-label="Account type">{TYPES.map((t) => <option key={t} value={t}>{t ? stateLabel(t) : "All accounts"}</option>)}</select>
        <input className="h-10 w-full max-w-xs rounded-md border hairline bg-surface px-3 text-sm" placeholder="Owner (seller id or PLATFORM)" value={ownerRef} onChange={(e) => setOwnerRef(e.target.value)} aria-label="Owner" />
      </div>
      <DataTable rows={data?.entries} rowKey={(e) => e.id} cols={[
        { h: "When", c: (e) => <span className="whitespace-nowrap">{dateTime(e.at)}</span> }, { h: "Txn", c: (e) => <span className="font-mono text-xs">{e.txnId.slice(0, 8)}</span> },
        { h: "Account", c: (e) => <div>{stateLabel(e.account)}<div className="font-mono text-[11px] text-muted">{e.ownerRef}</div></div> },
        { h: "Debit", c: (e) => (e.debitMinor ? <span className="num">{pkr(e.debitMinor)}</span> : ""), className: "text-right" },
        { h: "Credit", c: (e) => (e.creditMinor ? <span className="num">{pkr(e.creditMinor)}</span> : ""), className: "text-right" },
        { h: "Ref", c: (e) => <span className="text-xs">{e.refType} <span className="font-mono">{e.refId.slice(0, 10)}</span></span> }, { h: "Memo", c: (e) => <span className="text-xs">{e.memo}</span> },
      ]} />
      {data?.nextCursor && <Button variant="secondary" onClick={more}>Load more</Button>}
    </div>
  );
}
