"use client";
import { useApi } from "@/lib/useApi";
import { stateLabel } from "@/lib/format";
import { PageHeader } from "@/components/chrome/PortalShell";
import { ActionButton, DataTable } from "@/components/admin/kit";
import { Badge } from "@/components/ui/Badge";
import { Notice } from "@/components/ui/misc";

interface P { sellerId: string; displayName: string; idName: string; accountTitle: string; payoutMethod: string | null; match: "EXACT" | "PARTIAL" | "MISMATCH" }

/** Payouts go ONLY to an account in the seller's own name. Compare the CNIC name with the account title (and the proof document in onboarding). */
export default function PayoutVerifications() {
  const { data, reload } = useApi<{ sellers: P[] }>("/v1/admin/finance/payout-verifications");
  return (
    <div className="space-y-4">
      <PageHeader title="Payout accounts to verify" />
      <Notice>Approve only when the account title is the seller&apos;s own name as on their CNIC. Third-party, family or business accounts in another name are rejected. No statement can be marked paid until this is verified.</Notice>
      <DataTable rows={data?.sellers} rowKey={(p) => p.sellerId} empty="Nothing to verify." cols={[
        { h: "Seller", c: (p) => p.displayName }, { h: "Name on ID", c: (p) => p.idName }, { h: "Account title", c: (p) => p.accountTitle },
        { h: "Method", c: (p) => (p.payoutMethod ? stateLabel(p.payoutMethod) : "-") },
        { h: "Match", c: (p) => <Badge tone={p.match === "EXACT" ? "good" : p.match === "PARTIAL" ? "warn" : "bad"}>{stateLabel(p.match)}</Badge> },
        { h: "", c: (p) => <div className="flex gap-1">
          <ActionButton path={`/v1/admin/finance/payout-verifications/${p.sellerId}`} body={{ approve: true }} label="Verify own name" variant="primary" confirm={p.match === "EXACT" ? `Verify "${p.accountTitle}" as ${p.idName}'s own account?` : `Names don't match exactly ("${p.idName}" vs "${p.accountTitle}"). Only verify if the proof document shows it's their own account.`} onDone={reload} />
          <ActionButton path={`/v1/admin/finance/payout-verifications/${p.sellerId}`} body={{ approve: false }} note="note" noteLabel="Why? (seller sees this)" label="Reject" variant="danger" onDone={reload} />
        </div> },
      ]} />
    </div>
  );
}
