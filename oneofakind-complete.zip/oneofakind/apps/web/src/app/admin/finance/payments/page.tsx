"use client";
import { useApi } from "@/lib/useApi";
import { dateTime, pkr, stateLabel } from "@/lib/format";
import { PageHeader } from "@/components/chrome/PortalShell";
import { DataTable } from "@/components/admin/kit";
import { Badge, StatusPill } from "@/components/ui/Badge";

interface P { id: string; orderRef: string; provider: string; method: string; state: string; amountMinor: number; providerRef: string | null; createdAt: string; refunds: Array<{ amountMinor: number; state: string; mode: string }>; events: Array<{ type: string; receivedAt: string; signatureVerified: boolean }> }

/** Payments and the raw webhook trail. Status comes only from signature-verified provider events. */
export default function Payments() {
  const { data } = useApi<{ payments: P[] }>("/v1/admin/finance/payments?limit=100");
  return (
    <div className="space-y-4">
      <PageHeader title="Payments" sub="Prepaid only: card, wallet or bank transfer via the gateway (sandbox)." />
      <DataTable rows={data?.payments} rowKey={(p) => p.id} cols={[
        { h: "Order", c: (p) => <span className="num">{p.orderRef}</span> }, { h: "Provider", c: (p) => `${p.provider} · ${stateLabel(p.method)}` },
        { h: "Amount", c: (p) => <span className="num">{pkr(p.amountMinor)}</span> }, { h: "State", c: (p) => <StatusPill state={p.state} /> },
        { h: "Refunds", c: (p) => p.refunds.map((r, i) => <div key={i} className="text-xs">{pkr(r.amountMinor)} · {stateLabel(r.mode)} · {stateLabel(r.state)}</div>) },
        { h: "Webhooks", c: (p) => <div className="flex flex-wrap gap-1">{p.events.map((e, i) => <Badge key={i} tone={e.signatureVerified ? "good" : "bad"}>{e.type}</Badge>)}</div> },
        { h: "Created", c: (p) => dateTime(p.createdAt) },
      ]} />
    </div>
  );
}
