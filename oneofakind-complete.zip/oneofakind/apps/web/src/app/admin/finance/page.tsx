"use client";
import { useApi } from "@/lib/useApi";
import { pkr, stateLabel } from "@/lib/format";
import { PageHeader } from "@/components/chrome/PortalShell";
import { DataTable, Panel } from "@/components/admin/kit";
import { Notice, Stat } from "@/components/ui/misc";

interface R { gatewayNetMinor: number; ledgerNetMinor: number; differenceMinor: number; transfersOutMinor: number; payoutsMinor: number; accounts: Array<{ type: string; ownerRef: string; balanceMinor: number }> }

/** Gateway (captured − refunded) vs the ledger's cash account. Any difference must be explained before payouts. */
export default function Reconciliation() {
  const { data, error } = useApi<R>("/v1/admin/finance/reconciliation");
  return (
    <div className="space-y-5">
      <PageHeader title="Reconciliation" sub="Sandbox gateway only until production credentials are approved." />
      {error && <Notice tone="bad">{error.message}</Notice>}
      {data && (data.differenceMinor === 0 ? <Notice tone="good">Gateway and ledger agree.</Notice> : <Notice tone="bad">Difference of {pkr(data.differenceMinor)} between the gateway and the ledger. Investigate before paying sellers.</Notice>)}
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
        <Stat label="Gateway net (captured − refunds)" value={data ? pkr(data.gatewayNetMinor) : "-"} />
        <Stat label="Ledger cash from sales/refunds" value={data ? pkr(data.ledgerNetMinor) : "-"} />
        <Stat label="Difference" value={data ? pkr(data.differenceMinor) : "-"} />
        <Stat label="Paid to sellers (payouts)" value={data ? pkr(data.payoutsMinor) : "-"} />
        <Stat label="Paid for direct purchases" value={data ? pkr(data.transfersOutMinor) : "-"} />
      </div>
      <Panel title="Non-zero ledger balances (debit − credit)">
        <DataTable rows={data?.accounts} rowKey={(a) => `${a.type}:${a.ownerRef}`} cols={[
          { h: "Account", c: (a) => stateLabel(a.type) }, { h: "Owner", c: (a) => <span className="font-mono text-xs">{a.ownerRef}</span> },
          { h: "Balance", c: (a) => <span className="num">{pkr(a.balanceMinor)}</span>, className: "text-right" },
        ]} />
      </Panel>
    </div>
  );
}
