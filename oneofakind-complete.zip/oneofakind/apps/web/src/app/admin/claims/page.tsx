"use client";
import { useState } from "react";
import { useApi } from "@/lib/useApi";
import { dateTime, pkr, stateLabel } from "@/lib/format";
import { PageHeader } from "@/components/chrome/PortalShell";
import { ActionButton, Tabs } from "@/components/admin/kit";
import { StatusPill } from "@/components/ui/Badge";
import { EmptyState, Notice } from "@/components/ui/misc";

interface C { id: string; state: string; reason: string; createdAt: string; orderRef: string; buyer: string; evidence: string[]; item: { title: string; sku: string; priceMinor: number; arrangement: string; disclosedDefects: Array<{ type?: string; location?: string; severity?: string }>; photos: string[]; deliveredAt: string | null } | null }
const VIEWS = { new: "REQUESTED", progress: "APPROVED,IN_TRANSIT,RECEIVED", done: "REFUNDED,REJECTED,CLOSED" } as const;

/** Damaged-item claims only (the only returns we accept). Compare buyer photos with the disclosed defects and listing photos. */
export default function Claims() {
  const [view, setView] = useState<keyof typeof VIEWS>("new");
  const { data, reload } = useApi<{ claims: C[] }>(`/v1/admin/claims?state=${VIEWS[view]}`);
  return (
    <div className="space-y-4">
      <PageHeader title="Damage claims" sub="Returns are accepted only for damage not disclosed in the listing, reported within 48 hours with photos." />
      <Tabs value={view} onChange={setView} tabs={[{ k: "new", label: "To decide" }, { k: "progress", label: "In progress" }, { k: "done", label: "Closed" }]} />
      {data?.claims.length === 0 && <EmptyState title="No claims here" />}
      {data?.claims.map((c) => (
        <article key={c.id} className="space-y-3 rounded-md border hairline bg-surface p-4 text-sm">
          <div className="flex flex-wrap justify-between gap-2"><div><div className="font-medium">{c.item?.title} <span className="num text-muted">{c.item?.sku}</span></div><div className="text-muted">Order <span className="num">{c.orderRef}</span> · {c.buyer} · {stateLabel(c.reason)} · filed {dateTime(c.createdAt)} (delivered {dateTime(c.item?.deliveredAt)})</div></div><div className="text-right"><StatusPill state={c.state} /><div className="num mt-1">{pkr(c.item?.priceMinor)}</div></div></div>
          <div className="grid gap-4 md:grid-cols-2">
            <div><div className="mb-1 text-xs font-semibold uppercase text-muted">Buyer photos (private)</div><div className="grid grid-cols-3 gap-1">{c.evidence.map((u) => <a key={u} href={u} target="_blank" rel="noreferrer"><img src={u} alt="Buyer evidence" className="aspect-square w-full rounded-sm object-cover" /></a>)}</div></div>
            <div><div className="mb-1 text-xs font-semibold uppercase text-muted">Listing photos & disclosed defects</div><div className="grid grid-cols-3 gap-1">{c.item?.photos.map((u) => <img key={u} src={u} alt="" className="aspect-square w-full rounded-sm object-cover" />)}</div><p className="mt-1">{c.item?.disclosedDefects.length ? `Disclosed: ${c.item.disclosedDefects.map((d) => [d.type, d.location && `(${d.location})`, d.severity].filter(Boolean).join(" ")).join("; ")}` : "No defects disclosed."}</p></div>
          </div>
          {c.item?.arrangement === "SELF_MANAGED" ? <Notice>Self-managed: the seller bears an approved damage refund (deducted from their payout).</Notice> : <Notice>Platform-handled piece: ONEOFAKIND bears an approved damage refund.</Notice>}
          {c.state === "REQUESTED" && <div className="flex flex-wrap gap-2">
            <ActionButton path={`/v1/admin/claims/${c.id}/decide`} body={{ approve: true }} note="note" noteLabel="Decision note (buyer sees this)" label="Approve (buyer returns the piece)" variant="primary" onDone={reload} />
            <ActionButton path={`/v1/admin/claims/${c.id}/decide`} body={{ approve: true, refundWithoutReturn: true }} note="note" label="Approve (refund without return)" onDone={reload} />
            <ActionButton path={`/v1/admin/claims/${c.id}/decide`} body={{ approve: false }} note="note" noteLabel="Why is it rejected? (buyer sees this)" label="Reject" variant="danger" onDone={reload} />
          </div>}
          {c.state !== "REQUESTED" && <p className="text-xs text-muted">Return receiving and refunds are handled by the warehouse (Returns) and run automatically once received.</p>}
        </article>
      ))}
    </div>
  );
}
