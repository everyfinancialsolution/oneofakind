"use client";
import { useState } from "react";
import { call } from "@/lib/client";
import { useApi } from "@/lib/useApi";
import { PageHeader } from "@/components/chrome/PortalShell";
import { DataTable, Panel } from "@/components/admin/kit";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { TextArea, TextField } from "@/components/ui/Field";
import { useToast } from "@/components/ui/Toast";

interface C { id: string; slug: string; title: string; description: string | null; approved: boolean; _count: { items: number } }

export default function Collections() {
  const { data, reload } = useApi<{ collections: C[] }>("/v1/admin/catalog/collections");
  const [n, setN] = useState({ title: "", description: "" });
  const [skus, setSkus] = useState<Record<string, string>>({});
  const toast = useToast();
  const act = async (fn: () => Promise<unknown>, msg = "Saved") => { try { const r = await fn(); toast(msg, "good"); await reload(); return r; } catch (e) { toast((e as Error).message, "bad"); } };
  return (
    <div className="max-w-5xl space-y-4">
      <PageHeader title="Collections" sub="Curated edits and drops shown under /collections." />
      <DataTable rows={data?.collections} rowKey={(c) => c.id} cols={[
        { h: "Collection", c: (c) => <div><a className="underline" href={`/collections/${c.slug}`} target="_blank" rel="noreferrer">{c.title}</a><div className="text-xs text-muted">{c.description}</div></div> },
        { h: "Pieces", c: (c) => <span className="num">{c._count.items}</span> },
        { h: "Live", c: (c) => (c.approved ? <Badge tone="good">Live</Badge> : <Badge>Hidden</Badge>) },
        { h: "Set pieces (SKUs, in order)", c: (c) => <div className="flex min-w-[18rem] gap-2"><input className="h-9 flex-1 rounded-md border hairline bg-surface px-2 text-xs" placeholder="LV-000123, LV-000456" value={skus[c.id] ?? ""} onChange={(e) => setSkus((s) => ({ ...s, [c.id]: e.target.value }))} aria-label={`SKUs for ${c.title}`} /><Button size="sm" variant="secondary" disabled={!skus[c.id]} onClick={async () => { const r = (await act(() => call<{ count: number; unknown: string[] }>(`/v1/admin/catalog/collections/${c.id}/items`, { method: "PUT", body: { skus: (skus[c.id] ?? "").split(/[\s,]+/).filter(Boolean) } }))) as { unknown: string[] } | undefined; if (r?.unknown.length) toast(`Unknown SKUs: ${r.unknown.join(", ")}`, "bad"); }}>Save</Button></div> },
        { h: "", c: (c) => <Button size="sm" variant="ghost" onClick={() => act(() => call(`/v1/admin/catalog/collections/${c.id}`, { method: "PATCH", body: { approved: !c.approved } }))}>{c.approved ? "Hide" : "Make live"}</Button> },
      ]} />
      <Panel title="New collection">
        <div className="grid gap-3"><TextField label="Title" value={n.title} onChange={(e) => setN((x) => ({ ...x, title: e.target.value }))} /><TextArea label="Description" optional rows={2} value={n.description} onChange={(e) => setN((x) => ({ ...x, description: e.target.value }))} /></div>
        <Button className="mt-3" disabled={n.title.length < 2} onClick={() => act(() => call("/v1/admin/catalog/collections", { body: { title: n.title, description: n.description || undefined, slug: n.title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") } }), "Collection created").then(() => setN({ title: "", description: "" }))}>Create</Button>
      </Panel>
    </div>
  );
}
