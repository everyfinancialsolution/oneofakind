"use client";
import { useEffect, useState } from "react";
import { useApi } from "@/lib/useApi";
import { measureLabel, measureValue, stateLabel } from "@/lib/format";
import { PageHeader } from "@/components/chrome/PortalShell";
import { ActionButton, Tabs } from "@/components/admin/kit";
import { Badge, GradeBadge } from "@/components/ui/Badge";
import { EmptyState, Price } from "@/components/ui/misc";

interface L { id: string; slug: string; state: string; seller: string; sellerStatus: string; title: string; sku: string; brand: string | null; brandVerified: boolean; category: string; size: string | null; color: string | null; material: string | null; priceMinor: number; grade: string; measurements: Record<string, number> | null; description: string | null; arrangement: string; defects: Array<{ type?: string; location?: string; severity?: string } | string>; photos: Array<{ id: string; url: string; aiLabel: boolean; kind: string }> }
interface B { id: string; title: string; sku: string; seller: string; brand: string; style: string; size: number; priceMinor: number; retailValueMinor: number; pieces: Array<{ sku: string; title: string; size: string | null; grade: string; photo: string | null; brandId: boolean; styleId: boolean }> }

export default function Moderation() {
  const [tab, setTab] = useState<"listings" | "bundles">("listings");
  useEffect(() => { if (new URLSearchParams(window.location.search).get("tab") === "bundles") setTab("bundles"); }, []);
  const listings = useApi<{ listings: L[] }>(tab === "listings" ? "/v1/admin/moderation/listings" : null);
  const bundles = useApi<{ bundles: B[] }>(tab === "bundles" ? "/v1/admin/moderation/bundles" : null);
  return (
    <div className="space-y-4">
      <PageHeader title="Review queue" sub="Check photos match the description, measurements are present, condition is honest, nothing prohibited or counterfeit." />
      <Tabs value={tab} onChange={setTab} tabs={[{ k: "listings", label: "Listings" }, { k: "bundles", label: "Lots" }]} />
      {tab === "listings" && (listings.data?.listings.length === 0 ? <EmptyState title="Queue is clear" /> : listings.data?.listings.map((l) => (
        <article key={l.id} className="grid gap-4 rounded-md border hairline bg-surface p-4 lg:grid-cols-[minmax(0,2fr)_minmax(0,3fr)]">
          <div className="grid grid-cols-3 gap-1.5">{l.photos.map((p) => <a key={p.id} href={p.url} target="_blank" rel="noreferrer" className="relative"><img src={p.url} alt="" className="aspect-[4/5] w-full rounded-sm object-cover" />{p.aiLabel && <span className="absolute left-1 top-1 rounded bg-ink px-1 text-[10px] text-ivory">AI-edited</span>}</a>)}</div>
          <div className="space-y-2 text-sm">
            <div className="flex flex-wrap items-start justify-between gap-2"><div><h2 className="text-lg font-medium">{l.title}</h2><div className="text-muted"><span className="num">{l.sku}</span> · {l.seller} {l.sellerStatus !== "VERIFIED" && <Badge tone="bad">{stateLabel(l.sellerStatus)}</Badge>}</div></div><Price minor={l.priceMinor} /></div>
            <div className="flex flex-wrap gap-2"><GradeBadge grade={l.grade as never} /><Badge>{l.category}</Badge>{l.brand && <Badge tone={l.brandVerified ? "good" : "neutral"}>{l.brand}{l.brandVerified ? " ✓" : ""}</Badge>}<Badge>{stateLabel(l.arrangement)}</Badge></div>
            <p>Size {l.size ?? "-"} · {l.color ?? "-"} · {l.material ?? "material not stated"}</p>
            <p>{l.measurements && Object.keys(l.measurements).length ? Object.entries(l.measurements).map(([k, v]) => `${measureLabel(k)} ${measureValue(k, v)}`).join(" · ") : <span className="text-[#8A2E25]">No measurements</span>}</p>
            {l.defects.length > 0 && <p>Disclosed: {l.defects.map((d) => (typeof d === "string" ? d : [d.type, d.location && `(${d.location})`, d.severity].filter(Boolean).join(" "))).join("; ")}</p>}
            {l.description && <p className="whitespace-pre-line text-muted">{l.description}</p>}
            <div className="flex flex-wrap gap-2 pt-2">
              <ActionButton path={`/v1/admin/moderation/listings/${l.id}/approve`} label="Approve & publish" variant="primary" onDone={listings.reload} />
              <ActionButton path={`/v1/admin/moderation/listings/${l.id}/changes`} note="note" noteLabel="What should the seller change? (they see this)" label="Request changes" onDone={listings.reload} />
              <ActionButton path={`/v1/admin/moderation/listings/${l.id}/remove`} note="note" noteLabel="Why is it removed? (seller sees this; they can appeal)" label="Remove" variant="danger" onDone={listings.reload} />
            </div>
          </div>
        </article>
      )))}
      {tab === "bundles" && (bundles.data?.bundles.length === 0 ? <EmptyState title="No lots waiting" /> : bundles.data?.bundles.map((b) => (
        <article key={b.id} className="space-y-3 rounded-md border hairline bg-surface p-4 text-sm">
          <div className="flex flex-wrap justify-between gap-2"><div><h2 className="text-lg font-medium">{b.title}</h2><div className="text-muted"><span className="num">{b.sku}</span> · {b.seller} · {b.brand} · {b.style} · {b.size} pieces</div></div><div className="text-right"><Price minor={b.priceMinor} /><div className="text-xs text-muted">retail value <Price minor={b.retailValueMinor} size="sm" /></div></div></div>
          <div className="grid grid-cols-3 gap-2 sm:grid-cols-5">{b.pieces.map((p) => (
            <div key={p.sku} className="text-xs">{p.photo ? <img src={p.photo} alt="" className="aspect-[4/5] w-full rounded-sm object-cover" /> : <div className="aspect-[4/5] bg-ivory-deep" />}<div className="mt-1 truncate">{p.title}</div><div className="text-muted">{p.size} · grade {p.grade}</div>{(!p.brandId || !p.styleId) && <div className="text-[#8A2E25]">Brand/style mismatch</div>}</div>
          ))}</div>
          <div className="flex flex-wrap gap-2">
            <ActionButton path={`/v1/admin/moderation/bundles/${b.id}/approve`} label="Approve lot" variant="primary" onDone={bundles.reload} />
            <ActionButton path={`/v1/admin/moderation/bundles/${b.id}/changes`} note="note" label="Request changes" onDone={bundles.reload} />
            <ActionButton path={`/v1/admin/moderation/bundles/${b.id}/remove`} note="note" label="Remove" variant="danger" onDone={bundles.reload} />
          </div>
        </article>
      )))}
      {(listings.error || bundles.error) && <p className="text-sm text-[#8A2E25]">{(listings.error ?? bundles.error)!.message}</p>}
    </div>
  );
}
