"use client";
import Link from "next/link";
import { useApi } from "@/lib/useApi";
import { dateShort, stateLabel } from "@/lib/format";
import { PageHeader } from "@/components/chrome/PortalShell";
import { ActionButton, DataTable } from "@/components/admin/kit";
import { StatusPill } from "@/components/ui/Badge";

interface R { id: string; reason: string; state: string; details: string | null; appealNote: string | null; createdAt: string; listing: { slug: string; title: string; state: string; seller: string } | null }

export default function Reports() {
  const { data, reload } = useApi<{ reports: R[] }>("/v1/admin/moderation/reports");
  return (
    <div className="space-y-4">
      <PageHeader title="Reports & appeals" sub="Prohibited goods, IP, counterfeit and misleading listings reported by users; appeals from sellers after removal." />
      <DataTable rows={data?.reports} rowKey={(r) => r.id} empty="No open reports." cols={[
        { h: "Reported", c: (r) => dateShort(r.createdAt) },
        { h: "Listing", c: (r) => r.listing ? <div><Link className="underline" href={`/product/${r.listing.slug}`} target="_blank">{r.listing.title}</Link><div className="text-xs text-muted">{r.listing.seller} · {stateLabel(r.listing.state)}</div></div> : "-" },
        { h: "Reason", c: (r) => stateLabel(r.reason) },
        { h: "Details", c: (r) => <div className="max-w-sm whitespace-pre-line text-xs">{r.details}{r.appealNote && <div className="mt-1 font-medium">Appeal: {r.appealNote}</div>}</div> },
        { h: "State", c: (r) => <StatusPill state={r.state} /> },
        { h: "", c: (r) => <div className="flex flex-wrap gap-1">
          {r.state === "OPEN" && <ActionButton path={`/v1/admin/moderation/reports/${r.id}/resolve`} body={{ action: "REMOVE_LISTING" }} note="note" label="Uphold & remove" variant="danger" onDone={reload} />}
          <ActionButton path={`/v1/admin/moderation/reports/${r.id}/resolve`} body={{ action: "DISMISS" }} note="note" label={r.state === "APPEALED" ? "Accept appeal" : "Dismiss"} onDone={reload} />
          {r.state === "APPEALED" && <ActionButton path={`/v1/admin/moderation/reports/${r.id}/resolve`} body={{ action: "REMOVE_LISTING" }} note="note" label="Reject appeal" variant="danger" onDone={reload} />}
        </div> },
      ]} />
    </div>
  );
}
