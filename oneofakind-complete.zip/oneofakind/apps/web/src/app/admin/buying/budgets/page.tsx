"use client";
import { useState } from "react";
import { call } from "@/lib/client";
import { useApi } from "@/lib/useApi";
import { dateShort, pkr } from "@/lib/format";
import { PageHeader } from "@/components/chrome/PortalShell";
import { DataTable, Panel } from "@/components/admin/kit";
import { Button } from "@/components/ui/Button";
import { TextField } from "@/components/ui/Field";
import { useToast } from "@/components/ui/Toast";

interface B { id: string; code: string; label: string; limitMinor: number; remainingMinor: number; periodStart: string; periodEnd: string; active: boolean }

export default function Budgets() {
  const { data, reload } = useApi<{ budgets: B[] }>("/v1/admin/budgets");
  const [v, setV] = useState({ code: "", label: "", rupees: "", periodStart: "", periodEnd: "" });
  const toast = useToast();
  const add = async () => {
    try { await call("/v1/admin/budgets", { body: { code: v.code.toUpperCase(), label: v.label, limitMinor: Math.round(Number(v.rupees) * 100), periodStart: v.periodStart, periodEnd: v.periodEnd } }); toast("Budget added", "good"); setV({ code: "", label: "", rupees: "", periodStart: "", periodEnd: "" }); await reload(); }
    catch (e) { toast((e as Error).message, "bad"); }
  };
  return (
    <div className="space-y-4">
      <PageHeader title="Buying budgets" sub="Offers are checked against what's left (accepted + paid purchases count against the budget)." />
      <DataTable rows={data?.budgets} rowKey={(b) => b.id} cols={[
        { h: "Code", c: (b) => <span className="num font-medium">{b.code}</span> }, { h: "Label", c: (b) => b.label },
        { h: "Limit", c: (b) => <span className="num">{pkr(b.limitMinor)}</span> }, { h: "Remaining", c: (b) => <span className={`num ${b.remainingMinor <= 0 ? "text-[#8A2E25]" : ""}`}>{pkr(b.remainingMinor)}</span> },
        { h: "Period", c: (b) => `${dateShort(b.periodStart)} - ${dateShort(b.periodEnd)}` },
      ]} />
      <Panel title="Add a budget">
        <div className="grid gap-3 sm:grid-cols-3">
          <TextField label="Code" placeholder="BUY-2026-11" value={v.code} onChange={(e) => setV((x) => ({ ...x, code: e.target.value }))} />
          <TextField label="Label" value={v.label} onChange={(e) => setV((x) => ({ ...x, label: e.target.value }))} />
          <TextField label="Limit (PKR)" inputMode="numeric" value={v.rupees} onChange={(e) => setV((x) => ({ ...x, rupees: e.target.value.replace(/\D/g, "") }))} />
          <TextField label="From" type="date" value={v.periodStart} onChange={(e) => setV((x) => ({ ...x, periodStart: e.target.value }))} />
          <TextField label="To" type="date" value={v.periodEnd} onChange={(e) => setV((x) => ({ ...x, periodEnd: e.target.value }))} />
        </div>
        <Button className="mt-3" onClick={add} disabled={!v.code || !v.rupees || !v.periodStart || !v.periodEnd}>Add budget</Button>
      </Panel>
    </div>
  );
}
