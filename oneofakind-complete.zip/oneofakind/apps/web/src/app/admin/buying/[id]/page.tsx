"use client";
import { use, useState } from "react";
import { call } from "@/lib/client";
import { useApi } from "@/lib/useApi";
import { dateTime, pkr, stateLabel } from "@/lib/format";
import { PageHeader } from "@/components/chrome/PortalShell";
import { ActionButton, DataTable, KV, Panel } from "@/components/admin/kit";
import { StatusPill } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { SelectField, TextField } from "@/components/ui/Field";
import { Notice } from "@/components/ui/misc";
import { useToast } from "@/components/ui/Toast";

interface S { id: string; title: string; description: string; state: string; sellerAskMinor: number | null; expectedRetailMinor: number | null; offerMinor: number | null; offerExpiresAt: string | null; budgetCode: string | null; paymentRef: string | null; decisionNote: string | null; createdAt: string; seller: { displayName: string; city: string | null }; items: Array<{ id: string; sku: string; title: string; category: string; size: string | null; priceMinor: number; stockState: string; ownerType: string; costMinor: number | null; photos: string[] }>; transfers: Array<{ id: string; createdAt: string; amountMinor?: number }> }
interface Budget { code: string; label: string; remainingMinor: number; active: boolean }

export default function DirectPurchase({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const { data, reload, error } = useApi<{ submission: S }>(`/v1/admin/direct-purchases/${id}`);
  const budgets = useApi<{ budgets: Budget[] }>("/v1/admin/budgets");
  const [offer, setOffer] = useState({ rupees: "", budgetCode: "", expiresHours: "72", note: "", retailRupees: "" });
  const toast = useToast();
  if (error) return <Notice tone="bad">{error.message}</Notice>;
  if (!data) return <p className="text-sm text-muted">Loading…</p>;
  const d = data.submission;
  const base = `/v1/admin/direct-purchases/${id}`;
  const sendOffer = async () => {
    try {
      await call(`${base}/offer`, { body: { offerMinor: Math.round(Number(offer.rupees) * 100), budgetCode: offer.budgetCode, expiresHours: Number(offer.expiresHours), note: offer.note || undefined, expectedRetailMinor: offer.retailRupees ? Math.round(Number(offer.retailRupees) * 100) : undefined } });
      toast("Offer sent to the seller", "good"); await reload();
    } catch (e) { toast((e as Error).message, "bad"); }
  };
  return (
    <div className="max-w-5xl space-y-5">
      <PageHeader title={d.title || "Submission"} sub={`${d.seller.displayName} · ${d.seller.city ?? ""} · ${dateTime(d.createdAt)}`} actions={<StatusPill state={d.state} />} />
      <Panel title="Details"><p className="mb-3 whitespace-pre-line text-sm">{d.description}</p><KV items={[["Seller asks", pkr(d.sellerAskMinor)], ["Our offer", pkr(d.offerMinor)], ["Offer expires", d.offerExpiresAt ? dateTime(d.offerExpiresAt) : null], ["Expected retail", pkr(d.expectedRetailMinor)], ["Budget", d.budgetCode], ["Payment ref", d.paymentRef], ["Note", d.decisionNote]]} /></Panel>
      <Panel title="Pieces">
        <DataTable rows={d.items} rowKey={(i) => i.id} cols={[
          { h: "", c: (i) => (i.photos[0] ? <img src={i.photos[0]} alt="" className="h-14 w-11 rounded-sm object-cover" /> : null) },
          { h: "Piece", c: (i) => <div>{i.title}<div className="num text-xs text-muted">{i.sku} · {i.category} · {i.size}</div></div> },
          { h: "Stock", c: (i) => stateLabel(i.stockState) }, { h: "Owner", c: (i) => (i.ownerType === "PLATFORM" ? "ONEOFAKIND" : "Seller (not bought yet)") }, { h: "Cost", c: (i) => pkr(i.costMinor) },
        ]} />
      </Panel>
      {d.state === "SUBMITTED" && <ActionButton path={`${base}/review`} label="Start review" variant="primary" size="md" onDone={reload} />}
      {d.state === "UNDER_REVIEW" && (
        <Panel title="Make an offer">
          <div className="grid gap-3 sm:grid-cols-2">
            <TextField label="Offer for all pieces (PKR)" inputMode="numeric" value={offer.rupees} onChange={(e) => setOffer((o) => ({ ...o, rupees: e.target.value.replace(/\D/g, "") }))} />
            <SelectField label="Budget" value={offer.budgetCode} onChange={(e) => setOffer((o) => ({ ...o, budgetCode: e.target.value }))}><option value="">Choose…</option>{budgets.data?.budgets.filter((b) => b.active).map((b) => <option key={b.code} value={b.code}>{b.code}, {pkr(b.remainingMinor)} left</option>)}</SelectField>
            <TextField label="Offer valid for (hours)" inputMode="numeric" value={offer.expiresHours} onChange={(e) => setOffer((o) => ({ ...o, expiresHours: e.target.value.replace(/\D/g, "") }))} />
            <TextField label="Expected retail (PKR)" optional inputMode="numeric" value={offer.retailRupees} onChange={(e) => setOffer((o) => ({ ...o, retailRupees: e.target.value.replace(/\D/g, "") }))} />
            <TextField label="Note to seller" optional value={offer.note} onChange={(e) => setOffer((o) => ({ ...o, note: e.target.value }))} className="sm:col-span-2" />
          </div>
          <div className="mt-3 flex flex-wrap gap-2"><Button onClick={sendOffer} disabled={!offer.rupees || !offer.budgetCode}>Send offer</Button><ActionButton path={`${base}/decline`} note="note" noteLabel="Why are we not buying? (seller sees this)" label="Decline" variant="danger" size="md" onDone={reload} /></div>
        </Panel>
      )}
      {d.state === "AWAITING_PAYMENT" && (
        <Panel title="Pay the seller and transfer ownership">
          <Notice className="mb-3">Pay the seller&apos;s verified own-name account, then record the bank reference. Only then do the pieces become ONEOFAKIND stock.</Notice>
          <ActionButton path={`${base}/transfer`} extra={[{ name: "paymentRef", label: "Bank / wallet reference", placeholder: "IBFT-…" }]} label="Record payment & transfer" variant="primary" size="md" onDone={reload} />
        </Panel>
      )}
      {["SUBMITTED", "ACCEPTED", "AWAITING_HANDOVER", "AWAITING_PAYMENT"].includes(d.state) && <ActionButton path={`${base}/cancel`} note="note" label="Cancel purchase" variant="danger" onDone={reload} />}
    </div>
  );
}
