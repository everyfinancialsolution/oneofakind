"use client";
import Link from "next/link";
import { useState } from "react";
import { useApi } from "@/lib/useApi";
import { dateShort, pkr } from "@/lib/format";
import { PageHeader } from "@/components/chrome/PortalShell";
import { DataTable, Tabs } from "@/components/admin/kit";
import { StatusPill } from "@/components/ui/Badge";

interface D { id: string; title: string; seller: string; state: string; pieces: number; sellerAskMinor: number | null; expectedRetailMinor: number | null; offerMinor: number | null; budgetCode: string | null; createdAt: string; offerExpiresAt: string | null }
const VIEWS = { review: "SUBMITTED,UNDER_REVIEW", offered: "OFFER_MADE,ACCEPTED,AWAITING_HANDOVER", pay: "AWAITING_PAYMENT", done: "TRANSFERRED,REJECTED_BY_BUYER_TEAM,REJECTED_BY_SELLER,EXPIRED,CANCELLED" } as const;

/** Direct purchase: ONEOFAKIND buys pieces outright. Ownership moves ONLY at TRANSFERRED (after finance pays the seller's own-name account). */
export default function Buying() {
  const [view, setView] = useState<keyof typeof VIEWS>("review");
  const { data } = useApi<{ submissions: D[] }>(`/v1/admin/direct-purchases?state=${VIEWS[view]}`);
  return (
    <div className="space-y-4">
      <PageHeader title="Direct purchases" sub="Sellers offering pieces for us to buy. Nothing is ours until finance pays and it shows Transferred." />
      <Tabs value={view} onChange={setView} tabs={[{ k: "review", label: "To review" }, { k: "offered", label: "Offer out / handover" }, { k: "pay", label: "Ready to pay" }, { k: "done", label: "Closed" }]} />
      <DataTable rows={data?.submissions} rowKey={(d) => d.id} empty="Nothing in this view." cols={[
        { h: "Submission", c: (d) => <Link className="underline" href={`/admin/buying/${d.id}`}>{d.title || "Untitled"}</Link> },
        { h: "Seller", c: (d) => d.seller }, { h: "Pieces", c: (d) => <span className="num">{d.pieces}</span> },
        { h: "Ask", c: (d) => <span className="num">{pkr(d.sellerAskMinor)}</span> }, { h: "Our offer", c: (d) => <span className="num">{pkr(d.offerMinor)}</span> },
        { h: "Budget", c: (d) => d.budgetCode ?? "-" }, { h: "State", c: (d) => <StatusPill state={d.state} /> }, { h: "Submitted", c: (d) => dateShort(d.createdAt) },
      ]} />
    </div>
  );
}
