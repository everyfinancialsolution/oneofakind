"use client";
import { use, useState } from "react";
import { call } from "@/lib/client";
import { useApi } from "@/lib/useApi";
import { PageHeader } from "@/components/chrome/PortalShell";
import { ScanInput } from "@/components/ScanInput";
import { StatusPill } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { Notice } from "@/components/ui/misc";
import { useToast } from "@/components/ui/Toast";

interface G { id: string; orderRef: string; state: string; packVerifiedAt: string | null; shipTo: Record<string, string>; expectedCodes: string[]; items: Array<{ id: string; sku: string; title: string; location: string | null; code: string | null; photo: string | null }>; bundles: Array<{ id: string; sealedCode: string | null }>; shipments: Array<{ id: string; courier: string; trackingNo: string | null; state: string; code: string | null }> }
const openGet = async (u: string) => { const w = window.open("", "_blank"); const b = await (await fetch(u, { credentials: "same-origin" })).blob(); if (w) w.location.href = URL.createObjectURL(b); };

export default function Pack({ params }: { params: Promise<{ groupId: string }> }) {
  const { groupId } = use(params);
  const { data, reload } = useApi<{ group: G }>(`/v1/ops/groups/${groupId}`);
  const [scans, setScans] = useState<string[]>([]);
  const [msg, setMsg] = useState<{ tone: "warn" | "bad" | "good"; text: string } | null>(null);
  const [parcels, setParcels] = useState(1);
  const toast = useToast();
  if (!data) return <p className="text-muted">Loading…</p>;
  const g = data.group;
  const scanned = new Set(scans.map((s) => s.replace(/^OOAK1:/, "")));
  const scan = async (code: string) => {
    const next = [...scans, code];
    setScans(next);
    const r = await call<{ status: string; missing: string[]; unexpected: string[] }>(`/v1/ops/groups/${groupId}/pack`, { body: { scans: next } });
    if (r.status === "COMPLETE") { setMsg({ tone: "good", text: "All pieces verified." }); await reload(); }
    else if (r.status === "MISMATCH") { setMsg({ tone: "bad", text: `Wrong piece: ${r.unexpected.join(", ")} is not in this order. Take it out.` }); setScans(scans); }
    else setMsg({ tone: "warn", text: `${r.missing.length} still to scan.` });
  };
  return (
    <div className="max-w-4xl space-y-6">
      <PageHeader title={`Pack ${g.orderRef}`} sub={<><StatusPill state={g.state} /> to {g.shipTo.recipient}, {g.shipTo.city}</>} actions={<Button variant="secondary" onClick={() => openGet(`/v1/ops/groups/${groupId}/pack-slip`)}>Print pack slip</Button>} />
      <ul className="grid gap-3 sm:grid-cols-2">
        {g.items.map((i) => (
          <li key={i.id} className={`flex gap-3 rounded-md border-2 p-3 ${i.code && scanned.has(i.code) ? "border-[#2F5D50] bg-[#EEF5F0]" : "hairline bg-surface"}`}>

            {i.photo && <img src={i.photo} alt="" className="h-16 w-12 rounded-sm object-cover" />}
            <div><div className="font-medium">{i.title}</div><div className="text-sm num">shelf <strong>{i.location ?? "-"}</strong> · {i.code ?? "no label"}</div></div>
          </li>
        ))}
      </ul>
      {g.bundles.some((b) => b.sealedCode) && <Notice>Sealed lots: scan the lot seal once instead of each piece.</Notice>}
      {!g.packVerifiedAt ? (<><ScanInput onScan={scan} />{msg && <Notice tone={msg.tone}>{msg.text}</Notice>}</>) : (
        <section className="space-y-3">
          <Notice tone="good">Pack verified.</Notice>
          {!g.shipments.length && <div className="flex items-end gap-3"><label className="text-sm">Parcels <input type="number" min={1} max={10} value={parcels} onChange={(e) => setParcels(Number(e.target.value))} className="ml-2 h-11 w-20 rounded-md border hairline px-2" /></label><Button size="lg" onClick={async () => { try { await call(`/v1/ops/groups/${groupId}/dispatch`, { body: { parcels } }); await reload(); } catch (e) { toast((e as Error).message, "bad"); } }}>Book courier & issue dispatch codes</Button></div>}
          {g.shipments.map((s) => (
            <div key={s.id} className="flex flex-wrap items-center justify-between gap-3 rounded-md border hairline bg-surface p-4">
              <span>{s.courier} · <strong className="num">{s.trackingNo}</strong> · <span className="num">{s.code}</span></span>
              <span className="flex items-center gap-2"><StatusPill state={s.state} />{s.state === "READY" && <Button size="sm" variant="secondary" onClick={() => openGet(`/v1/ops/shipments/${s.id}/label`)}>Print dispatch label</Button>}</span>
            </div>
          ))}
        </section>
      )}
    </div>
  );
}
