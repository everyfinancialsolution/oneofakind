"use client";
import Link from "next/link";
import { use } from "react";
import { useApi } from "@/lib/useApi";
import { PageHeader } from "@/components/chrome/PortalShell";
import { EmptyState, Price } from "@/components/ui/misc";
import { handlingLabel, stateLabel } from "@/lib/format";

interface I { id: string; sku: string; title: string; seller: string; category: string; arrangement: string; ownerType: string; stockState: string; location: string | null; code: string | null; photo: string | null; proposedPriceMinor: number | null; priceMinor: number }
const TITLES: Record<string, [string, string]> = {
  inspection: ["Inspection", "Grade, measure and shelve each received piece."],
  photography: ["Photos & catalogue", "Studio photos, title and price, then send for review."],
  "price-approval": ["Waiting for seller price", "The seller must approve these prices themselves."],
  rejected: ["Back to sellers", "Rejected or withdrawn pieces still on our shelves."],
};

export default function Queue({ params }: { params: Promise<{ name: string }> }) {
  const { name } = use(params);
  const { data } = useApi<{ items: I[] }>(`/v1/ops/queue/${name}`);
  const [title, sub] = TITLES[name] ?? [name, ""];
  return (
    <div>
      <PageHeader title={title} sub={sub} />
      {data && !data.items.length && <EmptyState title="Queue is empty" />}
      <ul className="grid gap-3 md:grid-cols-2">
        {data?.items.map((i) => (
          <li key={i.id}>
            <Link href={`/ops/items/${i.id}`} className="flex gap-4 rounded-md border hairline bg-surface p-4 hover:border-ink">

              {i.photo ? <img src={i.photo} alt="" className="h-20 w-16 rounded-sm object-cover" /> : <div className="h-20 w-16 rounded-sm bg-ivory-deep" />}
              <div className="flex-1"><div className="font-medium">{i.title}</div><div className="text-sm text-muted num">{i.sku} · {i.seller} · {handlingLabel(i.arrangement, i.ownerType)}</div><div className="text-sm">{stateLabel(i.stockState)}{i.location ? ` · shelf ${i.location}` : ""}</div>{i.proposedPriceMinor && <div className="text-sm">Proposed <Price minor={i.proposedPriceMinor} size="sm" /></div>}</div>
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
