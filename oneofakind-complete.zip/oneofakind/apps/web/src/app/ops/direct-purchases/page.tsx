"use client";
import { useState } from "react";
import { call } from "@/lib/client";
import { useApi } from "@/lib/useApi";
import { PageHeader } from "@/components/chrome/PortalShell";
import { Button } from "@/components/ui/Button";
import { EmptyState, Notice, Price } from "@/components/ui/misc";
import { useToast } from "@/components/ui/Toast";

interface S { id: string; title: string; seller: string; offerMinor: number; items: Array<{ id: string; sku: string; title: string; stockState: string }> }

export default function DPHandover() {
  const { data, reload } = useApi<{ submissions: S[] }>("/v1/ops/direct-purchases");
  const [sel, setSel] = useState<Record<string, Set<string>>>({});
  const toast = useToast();
  return (
    <div className="max-w-3xl space-y-4">
      <PageHeader title="Bought pieces: handover" sub="The seller accepted our offer. Tick each piece you received and checked. They still belong to the seller until finance pays." />
      {data && !data.submissions.length && <EmptyState title="Nothing to receive" />}
      {data?.submissions.map((s) => (
        <section key={s.id} className="rounded-md border hairline bg-surface p-4">
          <div className="flex justify-between"><span className="font-medium">{s.title} · {s.seller}</span><Price minor={s.offerMinor} size="sm" /></div>
          <ul className="mt-2 space-y-1">{s.items.map((i) => <li key={i.id}><label className="flex items-center gap-2 text-[15px]"><input type="checkbox" className="h-5 w-5" checked={sel[s.id]?.has(i.id) ?? false} onChange={(e) => setSel((x) => { const n = new Set(x[s.id] ?? []); if (e.target.checked) n.add(i.id); else n.delete(i.id); return { ...x, [s.id]: n }; })} />{i.title} <span className="text-muted num">{i.sku}</span></label></li>)}</ul>
          <Notice className="mt-3">Pieces not ticked are marked as not handed over.</Notice>
          <Button className="mt-3" onClick={async () => { try { await call(`/v1/ops/direct-purchases/${s.id}/receive`, { body: { itemIds: [...(sel[s.id] ?? [])] } }); toast("Received. Finance can now pay the seller", "good"); await reload(); } catch (e) { toast((e as Error).message, "bad"); } }} disabled={!sel[s.id]?.size}>Confirm received</Button>
        </section>
      ))}
    </div>
  );
}
