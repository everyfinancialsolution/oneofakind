"use client";
import { call } from "@/lib/client";
import { useApi } from "@/lib/useApi";
import { PageHeader } from "@/components/chrome/PortalShell";
import { StatusPill } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { EmptyState } from "@/components/ui/misc";

export default function Returns() {
  const { data, reload } = useApi<{ returns: Array<{ id: string; state: string; orderRef: string; item: string; sku: string }> }>("/v1/ops/returns");
  return (
    <div className="max-w-3xl">
      <PageHeader title="Returns" sub="Approved damage claims coming back. Receiving one sends the buyer's refund." />
      {data && !data.returns.length && <EmptyState title="No returns due" />}
      <ul className="space-y-3">{data?.returns.map((r) => (
        <li key={r.id} className="flex flex-wrap items-center justify-between gap-3 rounded-md border hairline bg-surface p-4">
          <span>{r.item} <span className="text-muted num">{r.sku} · {r.orderRef}</span></span>
          <span className="flex items-center gap-2"><StatusPill state={r.state} />
            {r.state === "APPROVED" && <Button size="sm" variant="secondary" onClick={async () => { await call(`/v1/ops/returns/${r.id}/in-transit`, { method: "POST" }); await reload(); }}>Courier collected</Button>}
            {r.state === "IN_TRANSIT" && <Button size="sm" onClick={async () => { await call(`/v1/ops/returns/${r.id}/received`, { method: "POST" }); await reload(); }}>Received</Button>}
          </span>
        </li>
      ))}</ul>
    </div>
  );
}
