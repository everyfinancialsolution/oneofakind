"use client";
import { useApi } from "@/lib/useApi";
import { PageHeader } from "@/components/chrome/PortalShell";
import { dateTime } from "@/lib/format";

export default function Movements() {
  const { data } = useApi<{ events: Array<{ id: string; at: string; sku: string; title: string; from: string; to: string; note: string | null }> }>("/v1/ops/movements");
  return (
    <div>
      <PageHeader title="Movements" sub="Every custody handover, newest first." />
      <div className="overflow-x-auto rounded-md border hairline bg-surface"><table className="table-dense w-full min-w-[700px]"><thead><tr><th>When</th><th>SKU</th><th>Item</th><th>From</th><th>To</th><th>Note</th></tr></thead>
        <tbody>{data?.events.map((e) => <tr key={e.id}><td>{dateTime(e.at)}</td><td className="num">{e.sku}</td><td>{e.title}</td><td>{e.from}</td><td>{e.to}</td><td>{e.note}</td></tr>)}</tbody></table></div>
    </div>
  );
}
