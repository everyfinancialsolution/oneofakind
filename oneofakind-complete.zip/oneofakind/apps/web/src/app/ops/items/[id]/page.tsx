"use client";
import { use, useEffect, useState } from "react";
import clsx from "clsx";
import { GRADE_CRITERIA } from "@ooak/shared";
import { call } from "@/lib/client";
import { openPdf, useApi } from "@/lib/useApi";
import { PageHeader } from "@/components/chrome/PortalShell";
import { StatusPill } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { TextArea, TextField } from "@/components/ui/Field";
import { Notice } from "@/components/ui/misc";
import { useToast } from "@/components/ui/Toast";
import { dateTime, handlingLabel, measureLabel, stateLabel } from "@/lib/format";

interface Item { id: string; sku: string; title: string; description: string | null; seller: string; category: { name: string; measurements: string[] }; brand: string | null; styleId: string | null; size: string | null; color: string | null; material: string | null; measurements: Record<string, number> | null; weightGrams: number | null; priceMinor: number; proposedPriceMinor: number | null; arrangement: string; ownerType: string; stockState: string; location: string | null; grade: string | null; gradeLetter: string | null; defects: Array<{ type: string; location: string; severity: string }>; photos: Array<{ id: string; url: string; approved: boolean }>; custody: Array<{ id: string; fromParty: string; toParty: string; note: string | null; createdAt: string }>; codes: Array<{ code: string; kind: string }>; listing: { state: string; slug: string } | null; directPurchase: { state: string; title: string } | null }
const GRADES = [["NEW_WITH_TAGS", "A", "New with tags"], ["EXCELLENT", "A", "Excellent"], ["VERY_GOOD", "B", "Very good"], ["GOOD", "C", "Good"], ["FAIR", "D", "Fair"]] as const;

/** Warehouse item workbench: inspect → shelve → photograph → catalogue (or reject / return to seller). Big targets for tablets. */
export default function Workbench({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const { data, reload } = useApi<{ item: Item }>(`/v1/ops/items/${id}`);
  const toast = useToast();
  const [grade, setGrade] = useState("");
  const [m, setM] = useState<Record<string, string>>({});
  const [f, setF] = useState({ size: "", color: "", material: "", weightGrams: "", location: "", notes: "", reject: "" });
  const [defects, setDefects] = useState<Array<{ type: string; location: string; severity: string }>>([]);
  const [cat, setCat] = useState({ title: "", description: "", price: "" });
  useEffect(() => {
    if (!data) return;
    const i = data.item;
    setGrade(i.grade ?? ""); setM(Object.fromEntries(Object.entries(i.measurements ?? {}).map(([k, v]) => [k, String(v)])));
    setF((x) => ({ ...x, size: i.size ?? "", color: i.color ?? "", material: i.material ?? "", weightGrams: i.weightGrams ? String(i.weightGrams) : "", location: i.location ?? "" }));
    setCat({ title: i.title, description: i.description ?? "", price: String(Math.round((i.proposedPriceMinor ?? i.priceMinor) / 100)) });
  }, [data]);
  if (!data) return <p className="text-muted">Loading…</p>;
  const i = data.item;
  const run = async (fn: () => Promise<unknown>, ok: string) => { try { await fn(); toast(ok, "good"); await reload(); } catch (e) { toast((e as Error).message, "bad"); } };
  const inspect = (pass: boolean) => run(() => call(`/v1/ops/items/${id}/inspect`, { body: {
    pass, grade: grade || undefined, defects: defects.filter((d) => d.type), measurements: Object.fromEntries(Object.entries(m).filter(([, v]) => v).map(([k, v]) => [k, Number(v)])),
    size: f.size || undefined, color: f.color || undefined, material: f.material || undefined, weightGrams: f.weightGrams ? Number(f.weightGrams) : undefined, locationCode: f.location || undefined, notes: f.notes || undefined, rejectReason: f.reject || undefined,
  } }), pass ? "Inspected and shelved" : "Rejected. It goes back to the seller");
  const upload = (files: FileList | null) => run(async () => { for (const file of Array.from(files ?? [])) { const fd = new FormData(); fd.set("file", file); await call(`/v1/ops/items/${id}/photos`, { form: fd }); } }, "Photo added");
  const label = (k: string) => measureLabel(k);
  return (
    <div className="max-w-5xl space-y-8">
      <PageHeader title={i.title} sub={<span className="num">{i.sku} · {i.seller} · {handlingLabel(i.arrangement, i.ownerType)} · {stateLabel(i.stockState)}{i.location ? ` · shelf ${i.location}` : ""}</span>}
        actions={<Button variant="secondary" onClick={() => openPdf("/v1/ops/labels", { itemIds: [id], format: "thermal" }).catch((e) => toast(e.message, "bad"))}>Print label</Button>} />
      {i.directPurchase && <Notice>{i.directPurchase.state === "TRANSFERRED" ? "Owned by ONEOFAKIND (direct purchase)." : `Direct purchase in progress (${stateLabel(i.directPurchase.state)}). Still the seller's, so don't list it yet.`}</Notice>}
      {["RECEIVED", "RETURNED_TO_STOCK"].includes(i.stockState) && (
        <section className="space-y-5 rounded-md border hairline bg-surface p-5">
          <h2 className="font-display text-2xl">Inspect</h2>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-5">
            {GRADES.map(([code, letter, lbl]) => <button key={code} onClick={() => setGrade(code)} className={clsx("rounded-md border-2 p-4 text-left", grade === code ? "border-ink bg-ivory-deep" : "hairline")}><span className="block font-display text-2xl">{letter}</span>{lbl}</button>)}
          </div>
          {grade && <p className="text-sm text-muted">{GRADE_CRITERIA[GRADES.find((g) => g[0] === grade)![1]].rule}</p>}
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">{i.category.measurements.map((k) => <TextField key={k} label={`${label(k)} (cm)`} inputMode="decimal" value={m[k] ?? ""} onChange={(e) => setM({ ...m, [k]: e.target.value.replace(/[^\d.]/g, "") })} />)}</div>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            <TextField label="Size label" value={f.size} onChange={(e) => setF({ ...f, size: e.target.value })} /><TextField label="Colour" value={f.color} onChange={(e) => setF({ ...f, color: e.target.value })} />
            <TextField label="Material (care label)" value={f.material} onChange={(e) => setF({ ...f, material: e.target.value })} /><TextField label="Weight (g)" inputMode="numeric" value={f.weightGrams} onChange={(e) => setF({ ...f, weightGrams: e.target.value.replace(/\D/g, "") })} />
            <TextField label="Shelf" value={f.location} onChange={(e) => setF({ ...f, location: e.target.value.toUpperCase() })} placeholder="LHR-A-01-1" />
          </div>
          <div className="space-y-2">
            <p className="text-sm font-medium">Flaws (photograph each)</p>
            {defects.map((d, idx) => (
              <div key={idx} className="grid grid-cols-[1fr_1fr_auto] gap-2"><input className="h-11 rounded-md border hairline px-2" placeholder="flaw" value={d.type} onChange={(e) => setDefects(defects.map((x, j) => (j === idx ? { ...x, type: e.target.value } : x)))} /><input className="h-11 rounded-md border hairline px-2" placeholder="where" value={d.location} onChange={(e) => setDefects(defects.map((x, j) => (j === idx ? { ...x, location: e.target.value } : x)))} /><select className="h-11 rounded-md border hairline px-2" value={d.severity} onChange={(e) => setDefects(defects.map((x, j) => (j === idx ? { ...x, severity: e.target.value } : x)))}><option>minor</option><option>moderate</option><option>major</option></select></div>
            ))}
            <button className="link text-sm" onClick={() => setDefects([...defects, { type: "", location: "", severity: "minor" }])}>+ Add flaw</button>
          </div>
          <TextField label="Inspector notes" value={f.notes} onChange={(e) => setF({ ...f, notes: e.target.value })} />
          <div className="flex flex-wrap items-end gap-3">
            <Button size="lg" onClick={() => inspect(true)} disabled={!grade}>Pass & shelve</Button>
            <TextField label="Reject reason" value={f.reject} onChange={(e) => setF({ ...f, reject: e.target.value })} />
            <Button size="lg" variant="danger" onClick={() => inspect(false)} disabled={!f.reject}>Reject</Button>
          </div>
        </section>
      )}
      <section className="space-y-3">
        <h2 className="font-display text-2xl">Photos</h2>
        <ul className="grid grid-cols-3 gap-3 sm:grid-cols-6">

          {i.photos.map((p) => <li key={p.id}><img src={p.url} alt="" className="aspect-[4/5] w-full rounded-sm object-cover" /><button className="link mt-1 text-xs" onClick={() => run(() => call(`/v1/ops/items/${id}/photos/${p.id}`, { method: "DELETE" }), "Removed")}>Remove</button></li>)}
          {i.arrangement !== "SELF_MANAGED" && <li><label className="flex aspect-[4/5] cursor-pointer items-center justify-center rounded-sm border-2 border-dashed hairline text-sm">+ Add<input type="file" accept="image/*" multiple className="sr-only" onChange={(e) => { void upload(e.target.files); e.target.value = ""; }} /></label></li>}
        </ul>
      </section>
      {i.stockState === "READY_TO_LIST" && i.arrangement !== "SELF_MANAGED" && (!i.listing || ["DRAFT", "CHANGES_REQUESTED", "REMOVED"].includes(i.listing.state)) && (
        <section className="space-y-4 rounded-md border hairline bg-surface p-5">
          <h2 className="font-display text-2xl">Catalogue</h2>
          <TextField label="Title" value={cat.title} onChange={(e) => setCat({ ...cat, title: e.target.value })} />
          <TextArea label="Description" value={cat.description} onChange={(e) => setCat({ ...cat, description: e.target.value })} help="Facts only: fit, feel, provenance. Never guess material or authenticity." />
          <TextField label="Price (PKR)" inputMode="numeric" value={cat.price} onChange={(e) => setCat({ ...cat, price: e.target.value.replace(/\D/g, "") })} />
          <Button size="lg" onClick={() => run(() => call(`/v1/ops/items/${id}/catalogue`, { body: { title: cat.title, description: cat.description || undefined, priceMinor: Number(cat.price) * 100 } }), "Sent for review (or to the seller for price approval)")}>Send to review</Button>
        </section>
      )}
      <section className="flex flex-wrap gap-3">
        <form className="flex items-end gap-2" onSubmit={(e) => { e.preventDefault(); const code = new FormData(e.currentTarget).get("code") as string; void run(() => call(`/v1/ops/items/${id}/move`, { body: { code: code.toUpperCase() } }), "Moved"); }}>
          <TextField name="code" label="Move to shelf" placeholder="LHR-B-01-1" /><Button type="submit" variant="secondary">Move</Button>
        </form>
        {["REJECTED", "WITHDRAWN", "AVAILABLE", "READY_TO_LIST"].includes(i.stockState) && i.arrangement === "MANAGED_RESALE" && <Button variant="ghost" onClick={() => { if (confirm("Send this piece back to the seller?")) void run(() => call(`/v1/ops/items/${id}/return-to-seller`, { body: {} }), "Returned to seller"); }}>Return to seller</Button>}
      </section>
      <section>
        <h2 className="mb-2 font-display text-2xl">Custody trail</h2>
        <ol className="space-y-1 text-[15px]">{i.custody.map((c) => <li key={c.id}><span className="text-sm text-muted">{dateTime(c.createdAt)}</span>: {c.fromParty} → {c.toParty}{c.note ? ` (${c.note})` : ""}</li>)}</ol>
        <p className="mt-2 text-sm text-muted">Codes: {i.codes.map((c) => `${c.code} (${c.kind.toLowerCase()})`).join(", ") || "none"} {i.listing && <> · listing <StatusPill state={i.listing.state} /></>}</p>
      </section>
    </div>
  );
}
