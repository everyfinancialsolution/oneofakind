"use client";
import { useState } from "react";
import { call } from "@/lib/client";
import { PageHeader } from "@/components/chrome/PortalShell";
import { ScanInput } from "@/components/ScanInput";
import { Notice } from "@/components/ui/misc";

export default function Dispatch() {
  const [log, setLog] = useState<Array<{ ok: boolean; text: string }>>([]);
  const scan = async (code: string) => {
    try { const r = await call<{ orderRef: string; parcel: string }>("/v1/ops/handover", { body: { code } }); setLog((l) => [{ ok: true, text: `${r.orderRef} parcel ${r.parcel} handed over` }, ...l]); }
    catch (e) { setLog((l) => [{ ok: false, text: `${code}: ${(e as Error).message}` }, ...l]); }
  };
  return (
    <div className="max-w-3xl space-y-6">
      <PageHeader title="Courier handover" sub="Scan each parcel's dispatch label as the courier takes it. Parcels that weren't fully pack-verified are refused." />
      <ScanInput onScan={scan} label="Scan dispatch label" />
      <ul className="space-y-2">{log.map((l, i) => <li key={i}><Notice tone={l.ok ? "good" : "bad"}>{l.text}</Notice></li>)}</ul>
    </div>
  );
}
