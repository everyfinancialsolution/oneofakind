"use client";
import Link from "next/link";
import { useApi } from "@/lib/useApi";
import { PageHeader } from "@/components/chrome/PortalShell";

interface O { inTransit: number; receiving: number; toInspect: number; toCatalogue: number; toPack: number; toHandover: number; returnsDue: number; priceWaiting: number; dpHandover: number; unsealed: number }
const TILES: Array<[keyof O, string, string]> = [
  ["toPack", "Orders to pick & pack", "/ops/pick-pack"], ["toHandover", "Parcels for the courier", "/ops/dispatch"], ["inTransit", "Parcels on the way to us", "/ops/receiving"],
  ["receiving", "Manifests being received", "/ops/receiving"], ["toInspect", "Pieces to inspect", "/ops/queue/inspection"], ["toCatalogue", "Pieces to photograph & list", "/ops/queue/photography"],
  ["unsealed", "Lots to seal", "/ops/bundling"], ["returnsDue", "Returns coming back", "/ops/returns"], ["dpHandover", "Bought pieces to receive", "/ops/direct-purchases"], ["priceWaiting", "Waiting for seller's price OK", "/ops/queue/price-approval"],
];

export default function OpsHome() {
  const { data } = useApi<O>("/v1/ops/overview");
  return (
    <div>
      <PageHeader title="Today" />
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-5">
        {TILES.map(([k, label, href]) => (
          <Link key={k} href={href} className="rounded-md border hairline bg-surface p-5 hover:border-ink">
            <div className="font-display text-4xl num">{data ? data[k] : "…"}</div>
            <div className="mt-1 text-[15px]">{label}</div>
          </Link>
        ))}
      </div>
    </div>
  );
}
