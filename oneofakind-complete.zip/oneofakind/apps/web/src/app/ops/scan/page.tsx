"use client";
import Link from "next/link";
import { useState } from "react";
import { call } from "@/lib/client";
import { PageHeader } from "@/components/chrome/PortalShell";
import { ScanInput } from "@/components/ScanInput";
import { Notice } from "@/components/ui/misc";
import { stateLabel } from "@/lib/format";

interface R { code: string; kind: string; voided: boolean; voidReason: string | null; item: { id: string; sku: string; title: string; stockState: string; size: string | null; location: { code: string } | null } | null; bundle: { id: string; sku: string; title: string; state: string } | null; group: { id: string; orderRef: string } | null; shipment: { id: string; trackingNo: string | null; state: string } | null }

export default function Scan() {
  const [r, setR] = useState<R | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const resolve = async (raw: string) => { setErr(null); try { setR(await call<R>(`/v1/ops/scan/${encodeURIComponent(raw)}`)); } catch (e) { setR(null); setErr((e as Error).message); } };
  return (
    <div className="max-w-3xl space-y-6">
      <PageHeader title="Scan anything" sub="Item labels, lot seals, pack slips or dispatch labels." />
      <ScanInput onScan={resolve} />
      {err && <Notice tone="bad">{err}</Notice>}
      {r && (
        <div className="space-y-3 rounded-md border hairline bg-surface p-5 text-[15px]">
          <p className="font-mono text-lg">{r.code} · {r.kind.replace("_", " ").toLowerCase()}</p>
          {r.voided && <Notice tone="bad">This code was voided ({r.voidReason}). Use the replacement label.</Notice>}
          {r.item && <p>Item <Link className="link" href={`/ops/items/${r.item.id}`}>{r.item.title}</Link> · <span className="num">{r.item.sku}</span> · {stateLabel(r.item.stockState)}{r.item.location ? ` · shelf ${r.item.location.code}` : ""}</p>}
          {r.bundle && <p>Lot <Link className="link" href="/ops/bundling">{r.bundle.title}</Link> · {stateLabel(r.bundle.state)}</p>}
          {r.group && <p>Order <Link className="link" href={`/ops/pack/${r.group.id}`}>{r.group.orderRef}</Link></p>}
          {r.shipment && <p>Parcel · {r.shipment.trackingNo} · {stateLabel(r.shipment.state)} <Link className="link" href="/ops/dispatch">Hand over</Link></p>}
        </div>
      )}
    </div>
  );
}
