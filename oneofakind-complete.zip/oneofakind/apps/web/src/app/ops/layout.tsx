import type { ReactNode } from "react";
import { requireUser } from "@/lib/guard";
import { PortalShell, type NavGroup } from "@/components/chrome/PortalShell";

export const dynamic = "force-dynamic";
const NAV: NavGroup[] = [
  { items: [{ href: "/ops", label: "Today", exact: true }, { href: "/ops/scan", label: "Scan anything" }] },
  { title: "Incoming", items: [{ href: "/ops/receiving", label: "Receiving" }, { href: "/ops/direct-purchases", label: "Bought pieces (handover)" }, { href: "/ops/queue/inspection", label: "Inspection" }, { href: "/ops/queue/photography", label: "Photos & catalogue" }, { href: "/ops/queue/price-approval", label: "Waiting for seller price" }] },
  { title: "Outgoing", items: [{ href: "/ops/pick-pack", label: "Pick & pack" }, { href: "/ops/dispatch", label: "Courier handover" }, { href: "/ops/bundling", label: "Bundling" }] },
  { title: "Stock", items: [{ href: "/ops/locations", label: "Shelves" }, { href: "/ops/movements", label: "Movements" }, { href: "/ops/labels", label: "Label queue" }, { href: "/ops/returns", label: "Returns" }, { href: "/ops/unsold", label: "Unsold" }, { href: "/ops/queue/rejected", label: "Back to sellers" }] },
];

export default async function OpsLayout({ children }: { children: ReactNode }) {
  const { allowed } = await requireUser("/ops", ["WAREHOUSE", "ADMIN"]);
  if (!allowed) return <main className="page py-24"><h1 className="font-display text-3xl">Warehouse only</h1><p className="mt-2 text-muted">This area is for the warehouse team.</p></main>;
  return <PortalShell title="Warehouse · Lahore" nav={NAV} tone="ink">{children}</PortalShell>;
}
