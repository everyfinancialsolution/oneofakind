"use client";
import { useState } from "react";
import { call } from "@/lib/client";
import { useApi } from "@/lib/useApi";
import { PageHeader } from "@/components/chrome/PortalShell";
import { Button } from "@/components/ui/Button";
import { TextField } from "@/components/ui/Field";
import { useToast } from "@/components/ui/Toast";

export default function Locations() {
  const { data, reload } = useApi<{ locations: Array<{ id: string; code: string; label: string | null; items: number; active: boolean }> }>("/v1/ops/locations");
  const [code, setCode] = useState("");
  const toast = useToast();
  return (
    <div className="max-w-3xl space-y-6">
      <PageHeader title="Shelves" />
      <form className="flex items-end gap-2" onSubmit={async (e) => { e.preventDefault(); try { await call("/v1/ops/locations", { body: { code } }); setCode(""); await reload(); } catch (x) { toast((x as Error).message, "bad"); } }}>
        <TextField label="New shelf code" value={code} onChange={(e) => setCode(e.target.value.toUpperCase())} placeholder="LHR-C-01-2" /><Button type="submit">Add</Button>
      </form>
      <ul className="grid gap-2 sm:grid-cols-3">{data?.locations.map((l) => <li key={l.id} className="rounded-md border hairline bg-surface p-3"><div className="font-mono">{l.code}</div><div className="text-sm text-muted">{l.items} pieces</div></li>)}</ul>
    </div>
  );
}
