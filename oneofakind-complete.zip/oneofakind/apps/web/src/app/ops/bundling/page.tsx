"use client";
import { useState } from "react";
import { call } from "@/lib/client";
import { useApi } from "@/lib/useApi";
import { PageHeader } from "@/components/chrome/PortalShell";
import { ScanInput } from "@/components/ScanInput";
import { StatusPill } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { Notice } from "@/components/ui/misc";
import { useToast } from "@/components/ui/Toast";

interface B { id: string; sku: string; title: string; state: string; size: number; sealedCode: string | null; pieces: Array<{ itemId: string; sku: string; title: string; size: string | null; location: string | null; code: string | null; stockState: string }> }
const openGet = async (u: string) => { const w = window.open("", "_blank"); const r = await fetch(u, { credentials: "same-origin" }); if (!r.ok) { w?.close(); return; } if (w) w.location.href = URL.createObjectURL(await r.blob()); };

export default function Bundling() {
  const { data, reload } = useApi<{ bundles: B[] }>("/v1/ops/bundling");
  const [active, setActive] = useState<string | null>(null);
  const [scans, setScans] = useState<string[]>([]);
  const [res, setRes] = useState<{ sealed: boolean; missing?: string[]; extra?: string[] } | null>(null);
  const toast = useToast();
  const seal = async (b: B) => { const r = await call<{ sealed: boolean; missing?: string[]; extra?: string[]; code?: string }>(`/v1/ops/bundles/${b.id}/seal`, { body: { scans } }); setRes(r); if (r.sealed) { toast(`Lot sealed: ${r.code}`, "good"); setScans([]); setActive(null); await reload(); await openGet(`/v1/ops/bundles/${b.id}/lot-label`); } };
  return (
    <div className="space-y-6">
      <PageHeader title="Bundling" sub="Gather every piece of a lot, scan all of them, seal the bag, stick the lot label. A sealed lot is scanned once when packing." />
      {data?.bundles.map((b) => (
        <section key={b.id} className="rounded-md border hairline bg-surface p-4">
          <div className="flex flex-wrap items-center justify-between gap-2"><span className="text-lg">{b.title} <span className="text-sm text-muted num">{b.sku}</span></span><span className="flex items-center gap-2"><StatusPill state={b.state} />{b.sealedCode ? <span className="font-mono text-sm">sealed {b.sealedCode}</span> : <Button size="sm" onClick={() => { setActive(b.id); setScans([]); setRes(null); }}>Seal this lot</Button>}</span></div>
          <ul className="mt-3 grid gap-1 text-sm sm:grid-cols-2 lg:grid-cols-3">{b.pieces.map((p) => <li key={p.itemId} className={scans.some((s) => s.endsWith(p.code ?? "x")) ? "text-[#2F5D50]" : ""}><span className="mr-2 rounded-sm bg-ink px-1 font-mono text-xs text-ivory">{p.location ?? "-"}</span>{p.sku} · {p.size} · {p.code ?? "no label"}</li>)}</ul>
          {active === b.id && (
            <div className="mt-4 space-y-3">
              <ScanInput onScan={(c) => setScans((s) => [...s, c])} label={`Scan pieces (${scans.length}/${b.size})`} />
              <div className="flex gap-3"><Button onClick={() => seal(b)} disabled={scans.length !== b.size}>Seal lot</Button><Button variant="ghost" onClick={() => setScans([])}>Clear scans</Button></div>
              {res && !res.sealed && <Notice tone="bad">Not sealed. {res.missing?.length ? `Missing: ${res.missing.join(", ")}. ` : ""}{res.extra?.length ? `Not in this lot: ${res.extra.join(", ")}.` : ""}</Notice>}
            </div>
          )}
        </section>
      ))}
    </div>
  );
}
