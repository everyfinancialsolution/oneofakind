"use client";
import Link from "next/link";
import { useApi } from "@/lib/useApi";
import { PageHeader } from "@/components/chrome/PortalShell";
import { EmptyState, Price } from "@/components/ui/misc";

export default function Unsold() {
  const { data } = useApi<{ items: Array<{ id: string; sku: string; title: string; priceMinor: number; daysListed: number; storageDays: number; location: string | null; seller: string; suggestion: string }> }>("/v1/ops/unsold");
  return (
    <div>
      <PageHeader title="Unsold managed pieces" sub="Markdown suggestions at day 45 (−15%) and 75 (−25%); at the end of storage the seller decides: collect, extend or donate." />
      {data && !data.items.length && <EmptyState title="Nothing overdue" />}
      <div className="overflow-x-auto rounded-md border hairline bg-surface"><table className="table-dense w-full min-w-[700px]"><thead><tr><th>Item</th><th>Seller</th><th>Shelf</th><th>Days</th><th>Price</th><th>Suggestion</th></tr></thead>
        <tbody>{data?.items.map((i) => <tr key={i.id}><td><Link className="link" href={`/ops/items/${i.id}`}>{i.title}</Link><div className="text-xs text-muted num">{i.sku}</div></td><td>{i.seller}</td><td className="num">{i.location}</td><td className="num">{i.daysListed}/{i.storageDays}</td><td><Price minor={i.priceMinor} size="sm" /></td><td>{i.suggestion === "DECIDE" ? "Seller to decide" : i.suggestion.replace("MARKDOWN_", "−") + "%"}</td></tr>)}</tbody></table></div>
    </div>
  );
}
