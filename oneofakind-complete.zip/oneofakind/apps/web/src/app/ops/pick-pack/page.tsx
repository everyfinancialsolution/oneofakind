"use client";
import Link from "next/link";
import { useApi } from "@/lib/useApi";
import { PageHeader } from "@/components/chrome/PortalShell";
import { StatusPill } from "@/components/ui/Badge";
import { EmptyState } from "@/components/ui/misc";
import { dateTime } from "@/lib/format";

interface G { id: string; orderRef: string; state: string; paidAt: string; packVerified: boolean; city: string; picks: Array<{ sku: string; title: string; location: string }> }

export default function PickPack() {
  const { data } = useApi<{ groups: G[] }>("/v1/ops/packing");
  return (
    <div>
      <PageHeader title="Pick & pack" sub="Oldest paid first. Pick from the shelf shown, then scan into the parcel." />
      {data && !data.groups.length && <EmptyState title="Nothing to pack" />}
      <ul className="space-y-3">
        {data?.groups.map((g) => (
          <li key={g.id}><Link href={`/ops/pack/${g.id}`} className="block rounded-md border hairline bg-surface p-4 hover:border-ink">
            <div className="flex flex-wrap items-center justify-between gap-2"><span className="text-lg font-medium num">{g.orderRef}</span><span className="flex items-center gap-2 text-sm text-muted">paid {dateTime(g.paidAt)} · to {g.city} <StatusPill state={g.state} /></span></div>
            <ul className="mt-2 grid gap-1 text-[15px] sm:grid-cols-2">{g.picks.map((p) => <li key={p.sku}><span className="mr-2 rounded-sm bg-ink px-1.5 py-0.5 font-mono text-xs text-ivory">{p.location}</span>{p.title} <span className="text-muted num">{p.sku}</span></li>)}</ul>
          </Link></li>
        ))}
      </ul>
    </div>
  );
}
