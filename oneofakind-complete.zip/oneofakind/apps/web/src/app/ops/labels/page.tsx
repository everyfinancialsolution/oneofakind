"use client";
import { openPdf, useApi } from "@/lib/useApi";
import { PageHeader } from "@/components/chrome/PortalShell";
import { Button } from "@/components/ui/Button";
import { EmptyState } from "@/components/ui/misc";
import { useToast } from "@/components/ui/Toast";

export default function LabelQueue() {
  const { data, reload } = useApi<{ pending: Array<{ code: string; itemId: string; sku: string; title: string }> }>("/v1/ops/labels/queue");
  const toast = useToast();
  return (
    <div className="max-w-3xl">
      <PageHeader title="Label queue" sub="Codes issued but never printed." actions={data?.pending.length ? <Button onClick={async () => { try { await openPdf("/v1/ops/labels", { itemIds: data.pending.map((p) => p.itemId), format: "thermal" }); await reload(); } catch (e) { toast((e as Error).message, "bad"); } }}>Print all ({data.pending.length})</Button> : undefined} />
      {data && !data.pending.length && <EmptyState title="All labels printed" />}
      <ul className="divide-y rounded-md border hairline bg-surface">{data?.pending.map((p) => <li key={p.code} className="flex justify-between px-4 py-2 text-[15px]"><span>{p.title} <span className="text-muted num">{p.sku}</span></span><span className="font-mono">{p.code}</span></li>)}</ul>
    </div>
  );
}
