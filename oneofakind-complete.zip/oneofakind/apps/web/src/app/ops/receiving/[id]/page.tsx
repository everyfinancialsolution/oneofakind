"use client";
import { use } from "react";
import { call } from "@/lib/client";
import { openPdf, useApi } from "@/lib/useApi";
import { PageHeader } from "@/components/chrome/PortalShell";
import { StatusPill } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { Notice, Price } from "@/components/ui/misc";
import { useToast } from "@/components/ui/Toast";

interface L { id: string; description: string; brandName: string | null; expectedPriceMinor: number | null; state: string; note: string | null; itemId: string; sku: string; code: string | null }
interface M { id: string; state: string; seller: string; notes: string | null; courier: string | null; trackingNo: string | null; lines: L[] }

export default function ReceiveManifest({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const { data, reload } = useApi<{ manifest: M }>(`/v1/ops/manifests/${id}`);
  const toast = useToast();
  if (!data) return <p className="text-muted">Loading…</p>;
  const m = data.manifest;
  const outcome = async (l: L, o: string) => {
    const note = o === "RECEIVED" ? undefined : prompt("Note (what's wrong?)") ?? undefined;
    try { await call(`/v1/ops/manifests/${id}/lines/${l.id}`, { body: { outcome: o, note } }); await reload(); if (o === "RECEIVED") await openPdf("/v1/ops/labels", { itemIds: [l.itemId], format: "thermal" }); }
    catch (e) { toast((e as Error).message, "bad"); }
  };
  const open = m.lines.filter((l) => l.state === "EXPECTED").length;
  return (
    <div className="max-w-4xl space-y-6">
      <PageHeader title={`Receive · ${m.seller}`} sub={<><StatusPill state={m.state} /> {m.courier} {m.trackingNo}</>} actions={open === 0 && m.state === "RECEIVING" ? <Button size="lg" onClick={async () => { await call(`/v1/ops/manifests/${id}/reconcile`, { method: "POST" }); toast("Reconciled, seller notified", "good"); await reload(); }}>Finish & notify seller</Button> : undefined} />
      {m.notes && <Notice>Seller note: {m.notes}</Notice>}
      <p className="text-sm text-muted">Take each piece out of the carton and match it to a line. &ldquo;Received&rdquo; prints its label immediately. Stick it on the bag.</p>
      <ul className="space-y-3">
        {m.lines.map((l) => (
          <li key={l.id} className="rounded-md border hairline bg-surface p-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div><div className="text-lg">{l.description}</div><div className="text-sm text-muted num">{l.sku}{l.brandName ? ` · ${l.brandName}` : ""}{l.expectedPriceMinor ? <> · expected <Price minor={l.expectedPriceMinor} size="sm" /></> : null}{l.code ? ` · label ${l.code}` : ""}</div>{l.note && <div className="text-sm text-[#7A5A1F]">{l.note}</div>}</div>
              {l.state === "EXPECTED" ? (
                <div className="flex flex-wrap gap-2">
                  <Button size="lg" onClick={() => outcome(l, "RECEIVED")}>Received</Button>
                  <Button size="lg" variant="secondary" onClick={() => outcome(l, "MISSING")}>Missing</Button>
                  <Button size="lg" variant="secondary" onClick={() => outcome(l, "DISPUTED")}>Not as described</Button>
                  <Button size="lg" variant="ghost" onClick={() => outcome(l, "DECLINED")}>Decline</Button>
                </div>
              ) : <StatusPill state={l.state} />}
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}
