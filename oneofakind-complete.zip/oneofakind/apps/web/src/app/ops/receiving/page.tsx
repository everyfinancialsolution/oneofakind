"use client";
import { useApi } from "@/lib/useApi";
import { call } from "@/lib/client";
import { PageHeader } from "@/components/chrome/PortalShell";
import { StatusPill } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { EmptyState } from "@/components/ui/misc";
import { dateShort } from "@/lib/format";

interface M { id: string; state: string; seller: string; expectedCount: number; received: number; open: number; courier: string | null; trackingNo: string | null; createdAt: string }

export default function Receiving() {
  const { data, reload } = useApi<{ manifests: M[] }>("/v1/ops/manifests");
  return (
    <div>
      <PageHeader title="Receiving" sub="Managed-resale parcels from sellers." />
      {data && !data.manifests.length && <EmptyState title="Nothing expected" />}
      <ul className="space-y-3">
        {data?.manifests.map((m) => (
          <li key={m.id} className="flex flex-wrap items-center gap-4 rounded-md border hairline bg-surface p-4">
            <div className="flex-1"><div className="text-lg font-medium">{m.seller}</div><div className="text-sm text-muted">{m.expectedCount} pieces · {m.courier ?? "-"} {m.trackingNo ?? ""} · {dateShort(m.createdAt)}</div></div>
            <StatusPill state={m.state} />
            {m.state === "SUBMITTED" ? <Button onClick={async () => { await call(`/v1/ops/manifests/${m.id}/approve`, { method: "POST" }); await reload(); }}>Approve intake</Button> : <Button href={`/ops/receiving/${m.id}`} size="lg">Receive ({m.open} open)</Button>}
          </li>
        ))}
      </ul>
    </div>
  );
}
