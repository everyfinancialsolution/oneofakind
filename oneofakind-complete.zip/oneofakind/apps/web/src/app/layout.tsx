import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { SessionProvider } from "@/components/session";
import { ToastProvider } from "@/components/ui/Toast";

const SITE = process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000";

export const metadata: Metadata = {
  metadataBase: new URL(SITE),
  title: { default: "ONEOFAKIND | Secondhand pieces, one of one", template: "%s · ONEOFAKIND" },
  description: "Pakistan's marketplace for inspected, graded and measured secondhand fashion. Prepaid, tracked delivery.",
  openGraph: { siteName: "ONEOFAKIND", type: "website", locale: "en_PK" },
  robots: process.env.STAGING_NOINDEX === "true" ? { index: false, follow: false } : undefined,
};
export const viewport: Viewport = { themeColor: "#F7F3EA", width: "device-width", initialScale: 1 };

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen antialiased">
        <SessionProvider>
          <ToastProvider>{children}</ToastProvider>
        </SessionProvider>
      </body>
    </html>
  );
}
