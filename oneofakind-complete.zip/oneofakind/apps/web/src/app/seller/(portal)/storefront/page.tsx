"use client";
import { useEffect, useState } from "react";
import { call } from "@/lib/client";
import { useApi } from "@/lib/useApi";
import { PageHeader } from "@/components/chrome/PortalShell";
import { Button } from "@/components/ui/Button";
import { TextArea, TextField } from "@/components/ui/Field";
import { useToast } from "@/components/ui/Toast";

interface SF { slug: string; displayName: string; bio: string | null; city: string | null }

export default function Storefront() {
  const { data } = useApi<SF>("/v1/seller/storefront");
  const [v, setV] = useState<SF | null>(null);
  const [busy, setBusy] = useState(false);
  const toast = useToast();
  useEffect(() => { if (data) setV(data); }, [data]);
  if (!v) return <p className="text-muted">Loading…</p>;
  const save = async () => { setBusy(true); try { await call("/v1/seller/storefront", { method: "PATCH", body: { displayName: v.displayName, bio: v.bio, city: v.city ?? undefined } }); toast("Saved", "good"); } catch (e) { toast((e as Error).message, "bad"); } finally { setBusy(false); } };
  return (
    <div className="max-w-xl space-y-5">
      <PageHeader title="Storefront" sub={<a className="link" href={`/sellers/${v.slug}`} target="_blank">oneofakind.pk/sellers/{v.slug}</a>} />
      <TextField label="Shop name" value={v.displayName} onChange={(e) => setV({ ...v, displayName: e.target.value })} />
      <TextField label="City" value={v.city ?? ""} onChange={(e) => setV({ ...v, city: e.target.value })} />
      <TextArea label="About your shop" value={v.bio ?? ""} onChange={(e) => setV({ ...v, bio: e.target.value })} maxLength={600} help="What you sell, how you source, what makes your pieces special." />
      <Button onClick={save} loading={busy}>Save</Button>
    </div>
  );
}
