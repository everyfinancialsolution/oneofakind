"use client";
import { useState } from "react";
import { call } from "@/lib/client";
import { useApi } from "@/lib/useApi";
import { PageHeader } from "@/components/chrome/PortalShell";
import { Button } from "@/components/ui/Button";
import { Checkbox, SelectField, TextField } from "@/components/ui/Field";
import { Notice } from "@/components/ui/misc";
import { useToast } from "@/components/ui/Toast";
import { dateShort } from "@/lib/format";

interface Settings { payoutMethod: { kind: string; bank: string; accountMasked: string } | null; payoutAccountTitle: string | null; payoutVerifiedAt: string | null; allowStaffListing: boolean; cnicLast4: string | null }

export default function SellerSettings() {
  const { data, reload } = useApi<Settings>("/v1/seller/settings");
  const [form, setForm] = useState({ kind: "BANK", provider: "", accountTitle: "", accountNumber: "" });
  const [code, setCode] = useState("");
  const [devCode, setDevCode] = useState<string | null>(null);
  const [codeSent, setCodeSent] = useState(false);
  const [busy, setBusy] = useState(false);
  const toast = useToast();
  if (!data) return <p className="text-muted">Loading…</p>;
  const sendCode = async () => { const r = await call<{ devCode?: string }>("/v1/auth/confirm/request", { method: "POST" }); setDevCode(r.devCode ?? null); setCodeSent(true); };
  const savePayout = async () => {
    setBusy(true);
    try { const r = await call<{ message: string }>("/v1/seller/settings/payout", { body: { ...form, code } }); toast(r.message, "good"); setCode(""); setCodeSent(false); await reload(); }
    catch (e) { toast((e as Error).message, "bad"); } finally { setBusy(false); }
  };
  const toggleConsent = async (allow: boolean) => { await call("/v1/seller/settings", { method: "PATCH", body: { allowStaffListing: allow } }); await reload(); toast("Saved", "good"); };
  return (
    <div className="max-w-2xl space-y-10">
      <PageHeader title="Settings & payouts" />
      <section className="space-y-4">
        <h2 className="font-display text-2xl">Payout account</h2>
        {data.payoutMethod ? (
          <div className="rounded-md border hairline bg-surface p-4 text-[15px]">
            <p><strong className="font-medium">{data.payoutMethod.bank}</strong> {data.payoutMethod.accountMasked} · {data.payoutAccountTitle}</p>
            <p className="mt-1 text-sm">{data.payoutVerifiedAt ? <span className="text-[#2F5D50]">Verified on {dateShort(data.payoutVerifiedAt)}</span> : <span className="text-[#7A5A1F]">Waiting for our team to check it is in your own name. Payouts start once verified.</span>}</p>
          </div>
        ) : <Notice tone="warn">No payout account yet.</Notice>}
        <details className="rounded-md border hairline p-4">
          <summary className="cursor-pointer font-medium">{data.payoutMethod ? "Change payout account" : "Add payout account"}</summary>
          <div className="mt-4 grid gap-4 sm:grid-cols-2">
            <SelectField label="Type" value={form.kind} onChange={(e) => setForm({ ...form, kind: e.target.value })}><option value="BANK">Bank account</option><option value="WALLET">Mobile wallet</option></SelectField>
            <TextField label={form.kind === "BANK" ? "Bank" : "Wallet"} value={form.provider} onChange={(e) => setForm({ ...form, provider: e.target.value })} placeholder={form.kind === "BANK" ? "e.g. Meezan Bank" : "e.g. JazzCash"} />
            <TextField label="Account title (must be your own name)" className="sm:col-span-2" value={form.accountTitle} onChange={(e) => setForm({ ...form, accountTitle: e.target.value })} />
            <TextField label={form.kind === "BANK" ? "IBAN or account number" : "Wallet number"} className="sm:col-span-2" value={form.accountNumber} onChange={(e) => setForm({ ...form, accountNumber: e.target.value })} />
          </div>
          <p className="mt-3 text-sm text-muted">For your protection, changing payout details needs a code sent to your phone, and our team re-checks the account before the next payout. Our staff can never change this for you.</p>
          {!codeSent ? <Button className="mt-3" variant="secondary" onClick={sendCode} disabled={!form.provider || !form.accountTitle || !form.accountNumber}>Send me a code</Button> : (
            <div className="mt-3 flex flex-wrap items-end gap-3">
              <TextField label="Code" inputMode="numeric" maxLength={6} value={code} onChange={(e) => setCode(e.target.value.replace(/\D/g, ""))} help={devCode ? `Development code: ${devCode}` : undefined} />
              <Button onClick={savePayout} loading={busy} disabled={code.length !== 6}>Save payout account</Button>
            </div>
          )}
        </details>
      </section>
      <section className="space-y-3">
        <h2 className="font-display text-2xl">Help from our team</h2>
        <Checkbox checked={data.allowStaffListing} onChange={(e) => toggleConsent(e.target.checked)} label="Allow authorised ONEOFAKIND team members to prepare draft listings for me from photos I send on WhatsApp." />
        <p className="text-sm text-muted">Everything they do appears in your <a href="/seller/activity" className="link">activity</a>. They can never change your payout account or phone, accept offers or approve prices for you.</p>
      </section>
      {data.cnicLast4 && <p className="text-sm text-muted">ID on file: •••• {data.cnicLast4}. Your ID images are deleted 90 days after approval.</p>}
    </div>
  );
}
