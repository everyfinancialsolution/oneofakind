"use client";
import Link from "next/link";
import { useApi } from "@/lib/useApi";
import { PageHeader } from "@/components/chrome/PortalShell";
import { StatusPill } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { EmptyState, Price } from "@/components/ui/misc";
import { dateShort, stateLabel } from "@/lib/format";

interface S { id: string; title: string; state: string; pieces: number; sellerAskMinor: number | null; offerMinor: number | null; createdAt: string }

export default function DirectPurchase() {
  const { data } = useApi<{ submissions: S[] }>("/v1/seller/direct-purchase");
  return (
    <div className="max-w-3xl">
      <PageHeader title="Sell to us" sub="Want money now instead of waiting for a buyer? Send photos and our buyers may make an offer. Pieces become ours only after we receive them, check them and pay you." actions={<Button href="/seller/direct-purchase/new">Ask for an offer</Button>} />
      {data && !data.submissions.length && <EmptyState title="No offers yet" action={<Button href="/seller/direct-purchase/new">Ask for an offer</Button>} />}
      <ul className="space-y-3">{data?.submissions.map((s) => (
        <li key={s.id}><Link href={`/seller/direct-purchase/${s.id}`} className="flex flex-wrap items-center gap-3 rounded-md border hairline bg-surface p-4 hover:border-ink">
          <span className="flex-1"><span className="font-medium">{s.title}</span><span className="block text-sm text-muted">{s.pieces} piece(s) · {dateShort(s.createdAt)} · {stateLabel(s.state)}</span></span>
          {s.offerMinor ? <span className="text-sm">Offer <Price minor={s.offerMinor} size="sm" /></span> : null}<StatusPill state={s.state} label={stateLabel(s.state)} />
        </Link></li>
      ))}</ul>
    </div>
  );
}
