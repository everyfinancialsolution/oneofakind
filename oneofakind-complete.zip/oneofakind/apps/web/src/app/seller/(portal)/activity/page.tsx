"use client";
import { useApi } from "@/lib/useApi";
import { PageHeader } from "@/components/chrome/PortalShell";
import { Badge } from "@/components/ui/Badge";
import { dateTime } from "@/lib/format";

interface E { id: string; action: string; entity: string; at: string; byTeam: boolean; actor: string }
const words = (a: string) => a.replace(/_/g, " ").toLowerCase().replace(/^\w/, (c) => c.toUpperCase());

export default function Activity() {
  const { data } = useApi<{ events: E[] }>("/v1/seller/activity");
  return (
    <div className="max-w-3xl">
      <PageHeader title="Activity" sub="Everything that happened on your account, including work our team did for you." />
      <ul className="divide-y rounded-md border hairline bg-surface">
        {data?.events.map((e) => (
          <li key={e.id} className="flex items-center justify-between gap-3 px-4 py-3 text-[15px]">
            <span>{words(e.action)} {e.byTeam && <Badge tone="champagne">Done by ONEOFAKIND team for you</Badge>}</span>
            <span className="shrink-0 text-sm text-muted">{e.actor} · {dateTime(e.at)}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}
