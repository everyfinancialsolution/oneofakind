"use client";
import { useRouter } from "next/navigation";
import { useMemo, useState } from "react";
import clsx from "clsx";
import { BUNDLE_PRICE_POLICY } from "@ooak/shared";
import { call, ClientApiError } from "@/lib/client";
import { useApi } from "@/lib/useApi";
import { PageHeader } from "@/components/chrome/PortalShell";
import { Button } from "@/components/ui/Button";
import { TextField } from "@/components/ui/Field";
import { Notice, Steps } from "@/components/ui/misc";
import { useToast } from "@/components/ui/Toast";
import { pkr } from "@/lib/format";

interface Opt { brandId: string; styleId: string; brand: string; style: string; eligibleCount: number }
interface Piece { id: string; sku: string; title: string; size: string | null; color: string | null; grade: string | null; priceMinor: number; photo: string | null; missingWeight: boolean }

/** Bundle builder: brand + style → pick exactly 5/10/15 eligible pieces → price → submit for review. */
export default function NewBundle() {
  const { data: opts } = useApi<{ options: Opt[] }>("/v1/seller/bundles/options");
  const [pick, setPick] = useState<Opt | null>(null);
  const { data: el } = useApi<{ items: Piece[]; sizes: number[] }>(pick ? `/v1/seller/bundles/eligible?brandId=${pick.brandId}&styleId=${pick.styleId}` : null);
  const [sel, setSel] = useState<string[]>([]);
  const [price, setPrice] = useState("");
  const [err, setErr] = useState<string[] | null>(null);
  const [busy, setBusy] = useState(false);
  const router = useRouter();
  const toast = useToast();
  const chosen = useMemo(() => (el?.items ?? []).filter((p) => sel.includes(p.id)), [el, sel]);
  const retail = chosen.reduce((a, p) => a + p.priceMinor, 0);
  const sizes = el?.sizes ?? [5, 10, 15];
  const sizeOk = sizes.includes(sel.length);
  const floor = BUNDLE_PRICE_POLICY.minPricePerPieceMinor * sel.length;
  const ceiling = Math.floor((retail * (10_000 - BUNDLE_PRICE_POLICY.minDiscountBps)) / 10_000);
  const priceMinor = Math.round(Number(price || 0) * 100);
  const priceOk = priceMinor >= floor && priceMinor <= ceiling;

  const create = async () => {
    setErr(null); setBusy(true);
    try {
      const r = await call<{ id: string }>("/v1/seller/bundles", { body: { brandId: pick!.brandId, styleId: pick!.styleId, itemIds: sel, priceMinor } });
      await call(`/v1/seller/bundles/${r.id}/submit`, { method: "POST" });
      toast("Lot sent for review", "good");
      router.push("/seller/bundles");
    } catch (e) {
      const ex = e as ClientApiError;
      setErr((ex.problem?.errors as unknown as { issues?: Array<{ message: string }> })?.issues?.map((i) => i.message) ?? [ex.message]);
    } finally { setBusy(false); }
  };

  return (
    <div className="max-w-5xl space-y-6">
      <PageHeader title="Build a lot" />
      <Steps steps={["Brand and style", "Pick pieces", "Price"]} current={!pick ? 0 : !sizeOk ? 1 : 2} />
      {err && <Notice tone="bad"><ul className="list-disc pl-5">{[...new Set(err)].map((m) => <li key={m}>{m}</li>)}</ul></Notice>}
      <section>
        <h2 className="mb-2 font-display text-xl">1. Brand and style</h2>
        {opts && !opts.options.length && <Notice>You need at least 5 grade A/B pieces of the same brand and style (with a style set) that aren't live as single items.</Notice>}
        <div className="flex flex-wrap gap-2">
          {opts?.options.map((o) => (
            <button key={`${o.brandId}-${o.styleId}`} onClick={() => { setPick(o); setSel([]); }} className={clsx("rounded-pill border px-4 py-2 text-sm", pick?.brandId === o.brandId && pick?.styleId === o.styleId ? "border-ink bg-ink text-ivory" : "hairline hover:border-ink")}>
              {o.brand} · {o.style} <span className="opacity-70">({o.eligibleCount})</span>
            </button>
          ))}
        </div>
      </section>
      {pick && el && (
        <section>
          <h2 className="mb-2 font-display text-xl">2. Pick exactly {sizes.join(", ")} pieces <span className={clsx("text-base num", sizeOk ? "text-[#2F5D50]" : "text-muted")}>({sel.length} selected)</span></h2>
          <ul className="grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-6">
            {el.items.map((p) => {
              const on = sel.includes(p.id);
              return (
                <li key={p.id}>
                  <button disabled={p.missingWeight} onClick={() => setSel((s) => (on ? s.filter((x) => x !== p.id) : [...s, p.id]))} aria-pressed={on} className={clsx("w-full rounded-sm border-2 p-1 text-left text-xs disabled:opacity-50", on ? "border-ink" : "border-transparent hover:border-stone")}>
                    {p.photo ? <img src={p.photo} alt="" className="aspect-[4/5] w-full rounded-sm object-cover" /> : <div className="aspect-[4/5] bg-ivory-deep" />}
                    <span className="mt-1 block font-medium">{p.size ?? "-"} · grade {p.grade}</span><span className="block text-muted">{p.color} · {pkr(p.priceMinor)}</span>
                    {p.missingWeight && <span className="block text-[#8A2E25]">Add a weight first</span>}
                  </button>
                </li>
              );
            })}
          </ul>
        </section>
      )}
      {pick && sizeOk && (
        <section className="max-w-md space-y-3">
          <h2 className="font-display text-xl">3. Lot price</h2>
          <p className="text-sm text-muted">Retail value of these pieces: {pkr(retail)}. The lot must be at least {BUNDLE_PRICE_POLICY.minDiscountBps / 100}% below retail value and at least {pkr(BUNDLE_PRICE_POLICY.minPricePerPieceMinor)} per piece. Suggested: about 60% of retail ({pkr(Math.round(retail * 0.6 / 10000) * 10000)}).</p>
          <TextField label="Lot price (PKR)" inputMode="numeric" value={price} onChange={(e) => setPrice(e.target.value.replace(/\D/g, ""))} error={price && !priceOk ? `Between ${pkr(floor)} and ${pkr(ceiling)}` : null} help={priceMinor ? `${pkr(Math.round(priceMinor / sel.length))} per piece` : undefined} />
          <Button onClick={create} disabled={!priceOk} loading={busy}>Create lot and send for review</Button>
        </section>
      )}
    </div>
  );
}
