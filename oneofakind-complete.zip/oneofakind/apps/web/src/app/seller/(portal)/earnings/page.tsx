"use client";
import Link from "next/link";
import { useApi } from "@/lib/useApi";
import { PageHeader } from "@/components/chrome/PortalShell";
import { StatusPill } from "@/components/ui/Badge";
import { Notice, Price, Stat } from "@/components/ui/misc";
import { dateShort, pkr } from "@/lib/format";

interface E { balanceMinor: number; payableNowMinor: number; onHoldMinor: number; payoutVerified: boolean; entries: Array<{ id: string; at: string; amountMinor: number; refType: string; memo: string | null; status: string; orderRef: string | null; item: string | null; grossMinor: number | null; commissionBps: number | null; releaseAt: string | null }>; statements: Array<{ id: string; periodStart: string; periodEnd: string; state: string; netMinor: number; paidAt: string | null; payoutRef: string | null }> }
const STATUS: Record<string, string> = { PAYABLE: "Ready for next payout", ON_HOLD: "On hold (7 days after delivery)", SETTLED: "In a statement", PAID_OUT: "Paid out", REFUND: "Refund" };

export default function Earnings() {
  const { data: e } = useApi<E>("/v1/seller/earnings");
  if (!e) return <p className="text-muted">Loading…</p>;
  return (
    <div className="space-y-8">
      <PageHeader title="Earnings" sub="Money becomes payable 7 days after the buyer receives the order, and is paid weekly to your own-name account." />
      {!e.payoutVerified && <Notice tone="warn">We can&apos;t pay you until your payout account is verified. <Link href="/seller/settings" className="link">Add or check it</Link></Notice>}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <Stat label="Ready for next payout" value={pkr(e.payableNowMinor)} />
        <Stat label="On hold" value={pkr(e.onHoldMinor)} sub="Released 7 days after delivery" />
        <Stat label="Total owed to you" value={pkr(e.balanceMinor)} />
      </div>
      <section>
        <h2 className="mb-3 font-display text-2xl">Statements</h2>
        {e.statements.length ? (
          <ul className="space-y-2">{e.statements.map((s) => <li key={s.id} className="flex flex-wrap items-center justify-between gap-3 rounded-md border hairline bg-surface px-4 py-3 text-[15px]"><span>{dateShort(s.periodStart)} - {dateShort(s.periodEnd)}</span><span className="flex items-center gap-3"><Price minor={s.netMinor} size="sm" /><StatusPill state={s.state} />{s.payoutRef && <span className="text-sm text-muted num">{s.payoutRef}</span>}</span></li>)}</ul>
        ) : <p className="text-muted">Your first statement appears after your first payout week.</p>}
      </section>
      <section>
        <h2 className="mb-3 font-display text-2xl">Sales and adjustments</h2>
        <div className="overflow-x-auto rounded-md border hairline bg-surface">
          <table className="table-dense w-full min-w-[760px]">
            <thead><tr><th>Date</th><th>Order</th><th>Item</th><th className="text-right">Sale</th><th className="text-right">Fee</th><th className="text-right">You get</th><th>Status</th></tr></thead>
            <tbody>{e.entries.map((x) => (
              <tr key={x.id}><td>{dateShort(x.at)}</td><td className="num">{x.orderRef ?? "-"}</td><td>{x.item ?? x.memo}</td><td className="num text-right">{x.grossMinor ? pkr(x.grossMinor) : ""}</td><td className="num text-right">{x.commissionBps !== null && x.grossMinor ? `${x.commissionBps / 100}%` : ""}</td><td className={`num text-right ${x.amountMinor < 0 ? "text-[#8A2E25]" : ""}`}>{pkr(x.amountMinor)}</td><td className="text-sm">{STATUS[x.status] ?? x.status}</td></tr>
            ))}</tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
