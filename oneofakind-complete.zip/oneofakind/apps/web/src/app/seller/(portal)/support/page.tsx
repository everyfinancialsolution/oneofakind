"use client";
import { useState } from "react";
import { call } from "@/lib/client";
import { useApi } from "@/lib/useApi";
import { dateTime, stateLabel } from "@/lib/format";
import { PageHeader } from "@/components/chrome/PortalShell";
import { Panel } from "@/components/admin/kit";
import { StatusPill } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { TextArea, TextField } from "@/components/ui/Field";
import { Notice } from "@/components/ui/misc";
import { useToast } from "@/components/ui/Toast";
import { WhatsAppLink } from "@/components/WhatsApp";

interface Msg { from: string; by: string; at: string; text: string }
interface T { id: string; subject: string; state: string; createdAt: string; messages: Msg[] }
interface R { id: string; reason: string; state: string; appealNote: string | null; title?: string }

export default function SellerSupport() {
  const tickets = useApi<{ tickets: T[] }>("/v1/support/tickets");
  const reports = useApi<{ reports: R[] }>("/v1/seller/reports");
  const [n, setN] = useState({ subject: "", message: "", orderRef: "" });
  const [reply, setReply] = useState<Record<string, string>>({});
  const [appeal, setAppeal] = useState<Record<string, string>>({});
  const toast = useToast();
  const run = async (fn: () => Promise<unknown>, ok: string, after: () => Promise<void>) => { try { await fn(); toast(ok, "good"); await after(); } catch (e) { toast((e as Error).message, "bad"); } };
  return (
    <div className="max-w-3xl space-y-5">
      <PageHeader title="Support" sub={<>Message us here, or on <WhatsAppLink message="Hello ONEOFAKIND, I need help with my seller account." className="underline">WhatsApp</WhatsAppLink> any time.</>} />
      {reports.data && reports.data.reports.length > 0 && (
        <Panel title="Removed listings">
          <ul className="space-y-3 text-sm">{reports.data.reports.map((r) => (
            <li key={r.id} className="border-b hairline pb-3">
              <div className="flex flex-wrap items-center justify-between gap-2"><span><strong>{r.title}</strong>: {stateLabel(r.reason)}</span><StatusPill state={r.state} /></div>
              {r.state === "UPHELD" && <div className="mt-2 space-y-2"><TextArea label="Appeal (explain why the listing is fine, e.g. proof it is genuine)" rows={2} value={appeal[r.id] ?? ""} onChange={(e) => setAppeal((a) => ({ ...a, [r.id]: e.target.value }))} /><Button size="sm" disabled={(appeal[r.id] ?? "").trim().length < 10} onClick={() => run(() => call(`/v1/seller/reports/${r.id}/appeal`, { body: { note: appeal[r.id] } }), "Appeal sent", reports.reload)}>Send appeal</Button></div>}
              {r.appealNote && <p className="mt-1 text-muted">Your appeal: {r.appealNote}</p>}
            </li>
          ))}</ul>
        </Panel>
      )}
      <Panel title="New message">
        <div className="grid gap-3"><TextField label="Subject" value={n.subject} onChange={(e) => setN((x) => ({ ...x, subject: e.target.value }))} /><TextField label="Order reference" optional value={n.orderRef} onChange={(e) => setN((x) => ({ ...x, orderRef: e.target.value.toUpperCase() }))} /><TextArea label="Message" rows={4} value={n.message} onChange={(e) => setN((x) => ({ ...x, message: e.target.value }))} /></div>
        <Button className="mt-3" disabled={n.subject.length < 3 || n.message.length < 5} onClick={() => run(() => call("/v1/support/tickets", { body: { subject: n.subject, message: n.message, orderRef: n.orderRef || undefined } }), "Sent. We usually reply within a few hours", async () => { setN({ subject: "", message: "", orderRef: "" }); await tickets.reload(); })}>Send</Button>
      </Panel>
      {tickets.error && <Notice tone="bad">{tickets.error.message}</Notice>}
      {tickets.data?.tickets.map((t) => (
        <Panel key={t.id} title={t.subject} actions={<StatusPill state={t.state} />}>
          <ol className="space-y-2 text-sm">{(t.messages ?? []).map((m, i) => <li key={i} className={m.from === "STAFF" ? "mr-8 rounded-md bg-ivory-deep p-2" : "ml-8 rounded-md border hairline p-2"}><div className="text-xs text-muted">{m.from === "STAFF" ? "ONEOFAKIND" : "You"} · {dateTime(m.at)}</div><p className="whitespace-pre-line">{m.text}</p></li>)}</ol>
          {!["RESOLVED", "CLOSED"].includes(t.state) && <div className="mt-3 flex gap-2"><input className="h-10 flex-1 rounded-md border hairline bg-surface px-3 text-sm" placeholder="Reply" value={reply[t.id] ?? ""} onChange={(e) => setReply((r) => ({ ...r, [t.id]: e.target.value }))} aria-label="Reply" /><Button size="sm" disabled={!reply[t.id]?.trim()} onClick={() => run(() => call(`/v1/support/tickets/${t.id}/messages`, { body: { text: reply[t.id] } }), "Sent", async () => { setReply((r) => ({ ...r, [t.id]: "" })); await tickets.reload(); })}>Send</Button></div>}
        </Panel>
      ))}
    </div>
  );
}
