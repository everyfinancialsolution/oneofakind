"use client";
import { useEffect, useState } from "react";
import { MANAGED_MIN_ITEM_PRICE_MINOR } from "@ooak/shared";
import { call } from "@/lib/client";
import { useApi } from "@/lib/useApi";
import { PageHeader } from "@/components/chrome/PortalShell";
import { StatusPill } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { TextArea } from "@/components/ui/Field";
import { Notice, Price } from "@/components/ui/misc";
import { useToast } from "@/components/ui/Toast";
import { dateShort, stateLabel } from "@/lib/format";
import type { Category } from "@/lib/types";

interface Data {
  agreements: Array<{ id: string; status: string; commissionBps: number; requiresPriceApproval: boolean; storageDays: number; unsoldPolicy: string; createdAt: string }>;
  manifests: Array<{ id: string; state: string; expectedCount: number; createdAt: string; trackingNo: string | null; lines: Array<{ id: string; description: string; state: string; note: string | null; sku: string; itemState: string; expectedPriceMinor: number | null }> }>;
  itemsByState: Array<{ state: string; count: number }>;
  priceProposals: Array<{ id: string; sku: string; title: string; proposedPriceMinor: number; photo: string | null }>;
  unsold: Array<{ id: string; sku: string; title: string; priceMinor: number; daysListed: number; storageDays: number; suggestion: string }>;
}

export default function ManagedResale() {
  const { data, reload } = useApi<Data>("/v1/seller/managed-resale");
  const [cats, setCats] = useState<Category[]>([]);
  const [lines, setLines] = useState([{ description: "", categoryId: "", brandName: "", price: "" }]);
  const [note, setNote] = useState("");
  const toast = useToast();
  useEffect(() => { fetch("/v1/catalog/categories").then((r) => r.json()).then((d) => setCats(d.categories)); }, []);
  if (!data) return <p className="text-muted">Loading…</p>;
  const active = data.agreements.find((a) => a.status === "ACTIVE");
  const requested = data.agreements.find((a) => a.status === "REQUESTED");
  const leaves = cats.filter((c) => !cats.some((x) => x.parentId === c.id));
  const run = async (fn: () => Promise<unknown>, ok: string) => { try { await fn(); toast(ok, "good"); await reload(); } catch (e) { toast((e as Error).message, "bad"); } };
  return (
    <div className="max-w-4xl space-y-10">
      <PageHeader title="Managed resale" sub="Hand your pieces to us. We inspect, grade, measure, photograph, list, store, pack and ship. You see every step." />
      {!active && !requested && (
        <section className="space-y-3 rounded-md border hairline bg-surface p-5">
          <p className="text-[15px]">Commission: 35% up to PKR 5,000 · 30% up to PKR 20,000 · 25% above. Minimum item price PKR {MANAGED_MIN_ITEM_PRICE_MINOR / 100}. Storage free for 90 days.</p>
          <TextArea label="Tell us about your stock" value={note} onChange={(e) => setNote(e.target.value)} placeholder="About 40 winter jackets and sweatshirts" />
          <Button onClick={() => run(() => call("/v1/seller/managed-resale/request", { body: { note } }), "Request sent")}>Request managed resale</Button>
        </section>
      )}
      {requested && <Notice>Your request is being reviewed. We&apos;ll message you when it&apos;s active.</Notice>}
      {active && <Notice tone="good">Active · {active.commissionBps / 100}% commission · {active.requiresPriceApproval ? "you approve each price" : "we set prices"} · {active.storageDays} days storage · unsold: {active.unsoldPolicy.toLowerCase()}</Notice>}
      {data.priceProposals.length > 0 && (
        <section><h2 className="mb-3 font-display text-2xl">Prices to approve</h2>
          <ul className="space-y-3">{data.priceProposals.map((p) => (
            <li key={p.id} className="flex flex-wrap items-center gap-4 rounded-md border hairline bg-surface p-4">

              {p.photo && <img src={p.photo} alt="" className="h-16 w-12 rounded-sm object-cover" />}
              <span className="flex-1">{p.title} <span className="text-sm text-muted num">{p.sku}</span></span>
              <Price minor={p.proposedPriceMinor} />
              <Button size="sm" onClick={() => run(() => call(`/v1/seller/managed-resale/items/${p.id}/price`, { body: { approve: true } }), "Approved. It goes live after a final check")}>Approve</Button>
              <Button size="sm" variant="ghost" onClick={() => { const v = prompt("Your price in PKR"); if (v) void run(() => call(`/v1/seller/managed-resale/items/${p.id}/price`, { body: { approve: false, counterMinor: Number(v.replace(/\D/g, "")) * 100 } }), "Sent your price"); }}>Suggest another</Button>
            </li>
          ))}</ul>
        </section>
      )}
      {active && (
        <section className="space-y-3">
          <h2 className="font-display text-2xl">Send us pieces</h2>
          <p className="text-sm text-muted">List what's in the parcel. We check each piece against this list when it arrives.</p>
          {lines.map((l, i) => (
            <div key={i} className="grid gap-2 sm:grid-cols-[2fr_1fr_1fr_1fr_auto]">
              <input aria-label="Description" className="h-11 rounded-md border hairline bg-surface px-2" placeholder="e.g. Levi's trucker jacket, blue, M" value={l.description} onChange={(e) => setLines(lines.map((x, j) => (j === i ? { ...x, description: e.target.value } : x)))} />
              <select aria-label="Category" className="h-11 rounded-md border hairline bg-surface px-2" value={l.categoryId} onChange={(e) => setLines(lines.map((x, j) => (j === i ? { ...x, categoryId: e.target.value } : x)))}><option value="">Category</option>{leaves.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select>
              <input aria-label="Brand" className="h-11 rounded-md border hairline bg-surface px-2" placeholder="Brand" value={l.brandName} onChange={(e) => setLines(lines.map((x, j) => (j === i ? { ...x, brandName: e.target.value } : x)))} />
              <input aria-label="Expected price" inputMode="numeric" className="h-11 rounded-md border hairline bg-surface px-2" placeholder="PKR" value={l.price} onChange={(e) => setLines(lines.map((x, j) => (j === i ? { ...x, price: e.target.value.replace(/\D/g, "") } : x)))} />
              <button className="text-sm underline" onClick={() => setLines(lines.filter((_, j) => j !== i))}>Remove</button>
            </div>
          ))}
          <div className="flex gap-3"><Button variant="ghost" onClick={() => setLines([...lines, { description: "", categoryId: "", brandName: "", price: "" }])}>+ Add piece</Button>
            <Button onClick={() => run(async () => { const m = await call<{ id: string }>("/v1/seller/managed-resale/manifests", { body: { lines: lines.filter((l) => l.description).map((l) => ({ description: l.description, categoryId: l.categoryId, brandName: l.brandName || null, expectedPriceMinor: Number(l.price) * 100 })) } }); await call(`/v1/seller/managed-resale/manifests/${m.id}/submit`, { method: "POST" }); setLines([{ description: "", categoryId: "", brandName: "", price: "" }]); }, "Manifest sent. We'll confirm when to send the parcel")}>Send list to our team</Button></div>
        </section>
      )}
      {data.manifests.length > 0 && (
        <section><h2 className="mb-3 font-display text-2xl">Your parcels</h2>
          <ul className="space-y-3">{data.manifests.map((m) => (
            <li key={m.id} className="rounded-md border hairline bg-surface p-4">
              <div className="flex flex-wrap items-center justify-between gap-2"><span>{m.expectedCount} pieces · {dateShort(m.createdAt)}{m.trackingNo ? ` · tracking ${m.trackingNo}` : ""}</span><span className="flex items-center gap-2"><StatusPill state={m.state} />
                {m.state === "APPROVED" && <Button size="sm" onClick={() => { const t = prompt("Courier tracking number (leave empty if you'll drop it off)") ?? ""; void run(() => call(`/v1/seller/managed-resale/manifests/${m.id}/ship`, { body: t ? { courier: "Courier", trackingNo: t } : {} }), "Marked as sent"); }}>I&apos;ve sent it</Button>}</span></div>
              <ul className="mt-2 text-sm">{m.lines.map((l) => <li key={l.id} className="flex justify-between border-t hairline py-1"><span>{l.description} <span className="text-muted num">{l.sku}</span>{l.note ? `: ${l.note}` : ""}</span><span>{stateLabel(l.itemState)}</span></li>)}</ul>
            </li>
          ))}</ul>
        </section>
      )}
      {data.unsold.length > 0 && (
        <section><h2 className="mb-3 font-display text-2xl">Not sold yet</h2>
          <ul className="space-y-2">{data.unsold.map((u) => (
            <li key={u.id} className="flex flex-wrap items-center gap-3 rounded-md border hairline bg-surface p-3 text-[15px]">
              <span className="flex-1">{u.title} · {u.daysListed} days · <Price minor={u.priceMinor} size="sm" /> {u.suggestion !== "DECIDE" && <span className="text-champagne-ink">suggest {u.suggestion.replace("MARKDOWN_", "−")}%</span>}</span>
              <Button size="sm" variant="secondary" onClick={() => { const v = prompt("New price in PKR"); if (v) void run(() => call(`/v1/seller/managed-resale/items/${u.id}/unsold`, { body: { action: "REPRICE", priceMinor: Number(v.replace(/\D/g, "")) * 100 } }), "Price updated"); }}>Lower price</Button>
              <Button size="sm" variant="ghost" onClick={() => run(() => call(`/v1/seller/managed-resale/items/${u.id}/unsold`, { body: { action: "RETURN" } }), "We'll send it back to you")}>Send it back</Button>
            </li>
          ))}</ul>
        </section>
      )}
      {data.itemsByState.length > 0 && <p className="text-sm text-muted">Your managed pieces: {data.itemsByState.map((s) => `${stateLabel(s.state)} ${s.count}`).join(" · ")}</p>}
    </div>
  );
}
