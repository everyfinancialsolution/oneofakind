"use client";
import { useState } from "react";
import { openPdf, useApi } from "@/lib/useApi";
import { PageHeader } from "@/components/chrome/PortalShell";
import { Button } from "@/components/ui/Button";
import { Notice } from "@/components/ui/misc";
import { useToast } from "@/components/ui/Toast";
import { stateLabel } from "@/lib/format";

interface Row { id: string; sku: string; title: string; size: string | null; stockState: string; listingState: string | null; labelCode: string | null; arrangement: string }

export default function Labels() {
  const { data, error, reload } = useApi<{ items: Row[] }>("/v1/seller/listings?limit=100&arrangement=SELF_MANAGED");
  const [sel, setSel] = useState<Set<string>>(new Set());
  const [busy, setBusy] = useState(false);
  const toast = useToast();
  const rows = (data?.items ?? []).filter((r) => !["WITHDRAWN", "RETURNED_TO_SELLER", "DELIVERED"].includes(r.stockState));
  const print = async (format: "thermal" | "a4") => {
    setBusy(true);
    try { await openPdf("/v1/seller/labels", { itemIds: [...sel], format }); await reload(); } catch (e) { toast((e as Error).message, "bad"); } finally { setBusy(false); }
  };
  const toggle = (id: string) => setSel((s) => { const n = new Set(s); if (n.has(id)) n.delete(id); else n.add(id); return n; });
  return (
    <div>
      <PageHeader title="Labels" sub="Each item gets one barcode + QR code. Stick it on the bag with the item; we scan it when packing. Labels show no price." />
      <div className="sticky top-0 z-10 mb-4 flex flex-wrap items-center gap-3 border-b hairline bg-ivory py-3">
        <span className="text-sm text-muted num">{sel.size} selected</span>
        <Button size="sm" onClick={() => print("thermal")} disabled={!sel.size} loading={busy}>Print on thermal printer (50×30 mm)</Button>
        <Button size="sm" variant="secondary" onClick={() => print("a4")} disabled={!sel.size} loading={busy}>Print on A4 sheet (24 per page)</Button>
        <button className="link text-sm" onClick={() => setSel(new Set(rows.filter((r) => !r.labelCode).map((r) => r.id)))}>Select items without a label</button>
      </div>
      {error && <Notice tone="bad">{error.message}</Notice>}
      <ul className="divide-y rounded-md border hairline bg-surface">
        {rows.map((r) => (
          <li key={r.id} className="flex items-center gap-3 px-4 py-2">
            <input type="checkbox" aria-label={`Select ${r.title}`} checked={sel.has(r.id)} onChange={() => toggle(r.id)} className="h-4 w-4 accent-[var(--ooak-ink)]" />
            <span className="flex-1"><span className="font-medium">{r.title}</span><span className="block text-xs text-muted num">{r.sku} · {r.size ?? "-"} · {stateLabel(r.listingState ?? r.stockState)}</span></span>
            <span className="text-sm num">{r.labelCode ?? <span className="text-muted">No label yet</span>}</span>
          </li>
        ))}
      </ul>
      <p className="mt-4 text-sm text-muted">Thermal printers: set the paper size to 50×30 mm once in your printer settings, then print at 100% (no scaling). No thermal printer? Use A4 label sheets (3×8).</p>
    </div>
  );
}
