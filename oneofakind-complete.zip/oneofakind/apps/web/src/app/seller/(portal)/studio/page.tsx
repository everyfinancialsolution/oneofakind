"use client";
import { useCallback, useEffect, useState } from "react";
import { call } from "@/lib/client";
import { useApi } from "@/lib/useApi";
import { stateLabel } from "@/lib/format";
import { PageHeader } from "@/components/chrome/PortalShell";
import { Model3D } from "@/components/Model3D";
import { Badge, StatusPill } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { EmptyState, Notice } from "@/components/ui/misc";
import { useToast } from "@/components/ui/Toast";

interface Photo { id: string; url: string; kind: string; aiLabel: boolean; sourceAssetId: string | null; useInListing: boolean; live: boolean }
interface Item { id: string; sku: string; title: string; description: string | null; listingState: string | null; photos: Photo[]; model3d: { id: string; url: string; live: boolean } | null }
interface Job { id: string; kind: string; state: string; error: string | null; input: { itemId: string; assetId?: string }; output: { assetId?: string; title?: string; description?: string; missing?: string[] } | null; createdAt: string }

/**
 * Photo studio (AI). Everything runs on our server; your original photos are never changed. AI results are separate copies,
 * always labelled "AI-edited" to buyers, and only go live if you choose them and our team approves the listing.
 */
export default function Studio() {
  const items = useApi<{ items: Item[] }>("/v1/seller/studio/items");
  const [sel, setSel] = useState<string | null>(null);
  const item = items.data?.items.find((i) => i.id === sel) ?? null;
  const jobs = useApi<{ jobs: Job[]; quota: { used: number; limit: number } }>(sel ? `/v1/seller/studio/jobs?itemId=${sel}` : null);
  const toast = useToast();
  const pending = jobs.data?.jobs.some((j) => j.state === "QUEUED" || j.state === "RUNNING");
  const refresh = useCallback(async () => { await Promise.all([jobs.reload(), items.reload()]); }, [jobs, items]);
  useEffect(() => { if (!pending) return; const t = setTimeout(() => { void refresh(); }, 1500); return () => clearTimeout(t); }, [pending, refresh, jobs.data]);
  useEffect(() => { if (!sel && items.data?.items[0]) setSel(items.data.items[0].id); }, [items.data, sel]);
  const act = async (fn: () => Promise<unknown>, ok?: string) => { try { await fn(); if (ok) toast(ok, "good"); await refresh(); } catch (e) { toast((e as Error).message, "bad"); } };
  const textJob = jobs.data?.jobs.find((j) => j.kind === "LISTING_TEXT");
  const originals = item?.photos.filter((p) => !p.aiLabel) ?? [];
  const variantsOf = (id: string) => item?.photos.filter((p) => p.sourceAssetId === id && p.aiLabel) ?? [];
  const jobFor = (assetId: string) => jobs.data?.jobs.find((j) => j.kind === "BACKGROUND_REMOVAL" && j.input.assetId === assetId);

  return (
    <div className="space-y-5">
      <PageHeader title="Photo studio" sub="Clean backgrounds and a first draft of your title and description, from what you've already entered." />
      <Notice>Your original photos are never changed. AI results are separate copies, shown to buyers with an “AI-edited” label, and go live only if you choose them and our team approves. The text helper never adds facts you haven&apos;t entered (no guessing material, measurements or authenticity).</Notice>
      {items.data?.items.length === 0 && <EmptyState title="No pieces to edit" body="The studio works on pieces you list and ship yourself. Pieces we manage are photographed by our studio." />}
      {!!items.data?.items.length && (
        <div className="grid gap-5 lg:grid-cols-[260px_1fr]">
          <ul className="max-h-[70vh] space-y-1 overflow-y-auto rounded-md border hairline bg-surface p-2" aria-label="Your pieces">
            {items.data.items.map((i) => (
              <li key={i.id}><button onClick={() => setSel(i.id)} aria-current={i.id === sel} className={`flex w-full items-center gap-2 rounded-md p-2 text-left text-sm ${i.id === sel ? "bg-ink text-ivory" : "hover:bg-ivory-deep"}`}>
                {i.photos[0] ? <img src={i.photos[0].url} alt="" className="h-12 w-10 shrink-0 rounded-sm object-cover" /> : <span className="h-12 w-10 shrink-0 rounded-sm bg-ivory-deep" />}
                <span className="min-w-0"><span className="block truncate">{i.title}</span><span className="num text-xs opacity-70">{i.sku}</span></span>
              </button></li>
            ))}
          </ul>
          {item && (
            <div className="space-y-5">
              <div className="flex flex-wrap items-center justify-between gap-2"><h2 className="text-xl font-medium">{item.title}</h2><div className="flex items-center gap-2">{item.listingState && <StatusPill state={item.listingState} />}{jobs.data && <span className="text-xs text-muted">AI today: {jobs.data.quota.used}/{jobs.data.quota.limit}</span>}</div></div>

              <section className="rounded-md border hairline bg-surface p-4">
                <h3 className="font-semibold">Clean background</h3>
                <p className="mb-3 text-sm text-muted">Works best on photos taken on a plain wall or sheet.</p>
                <div className="space-y-4">{originals.map((p) => { const j = jobFor(p.id); const busy = j && (j.state === "QUEUED" || j.state === "RUNNING"); return (
                  <div key={p.id} className="flex flex-wrap items-start gap-3 border-b hairline pb-4 last:border-0">
                    <figure className="w-32"><img src={p.url} alt="Original" className="aspect-[4/5] w-full rounded-sm object-cover" /><figcaption className="mt-1 text-xs text-muted">Original</figcaption></figure>
                    {variantsOf(p.id).map((v) => (
                      <figure key={v.id} className="w-32">
                        <div className="relative"><img src={v.url} alt="AI-edited version" className="aspect-[4/5] w-full rounded-sm object-cover" /><span className="absolute left-1 top-1 rounded bg-ink px-1 text-[10px] text-ivory">AI-edited</span></div>
                        <figcaption className="mt-1 space-y-1 text-xs">
                          {v.useInListing ? <Badge tone="good">{v.live ? "Live" : "Chosen, live after review"}</Badge> : <span className="text-muted">Not used</span>}
                          <div className="flex gap-2"><button className="underline" onClick={() => act(() => call(`/v1/seller/studio/assets/${v.id}/use`, { body: { use: !v.useInListing } }), v.useInListing ? "Removed from listing" : "Chosen. It goes live after our team reviews the listing")}>{v.useInListing ? "Don't use" : "Use in listing"}</button><button className="text-muted underline" onClick={() => act(() => call(`/v1/seller/studio/assets/${v.id}`, { method: "DELETE" }))}>Discard</button></div>
                        </figcaption>
                      </figure>
                    ))}
                    <div className="space-y-1 self-center">
                      <Button size="sm" variant="secondary" loading={!!busy} disabled={!!busy} onClick={() => act(() => call(`/v1/seller/studio/items/${item.id}/background`, { body: { assetId: p.id } }))}>{busy ? "Working…" : "Remove background"}</Button>
                      {j && (j.state === "FAILED" || j.state === "TIMED_OUT") && <p className="max-w-xs text-xs text-[#8A2E25]">{j.error}</p>}
                    </div>
                  </div>
                ); })}</div>
                {!originals.length && <p className="text-sm text-muted">Add photos to this piece first.</p>}
              </section>

              <section className="rounded-md border hairline bg-surface p-4">
                <h3 className="font-semibold">Title & description helper</h3>
                <p className="mb-3 text-sm text-muted">Writes a draft only from the details you entered. Check it before using it.</p>
                <Button size="sm" variant="secondary" loading={textJob?.state === "QUEUED" || textJob?.state === "RUNNING"} onClick={() => act(() => call(`/v1/seller/studio/items/${item.id}/text`, { method: "POST" }))}>Suggest title & description</Button>
                {textJob?.state === "SUCCEEDED" && textJob.output && (
                  <div className="mt-4 space-y-2 text-sm">
                    <div><div className="text-xs text-muted">Suggested title</div><p className="font-medium">{textJob.output.title}</p></div>
                    <div><div className="text-xs text-muted">Suggested description</div><p>{textJob.output.description}</p></div>
                    {!!textJob.output.missing?.length && <Notice tone="warn">Add these to your listing for a better description: {textJob.output.missing.join(", ")}.</Notice>}
                    <Button size="sm" onClick={() => act(() => call(`/v1/seller/listings/${item.id}`, { method: "PATCH", body: { title: textJob.output!.title, description: textJob.output!.description } }), "Listing updated")}>Use this text</Button>
                  </div>
                )}
                {textJob && (textJob.state === "FAILED" || textJob.state === "TIMED_OUT") && <p className="mt-2 text-sm text-[#8A2E25]">{textJob.error}</p>}
              </section>

              <section className="rounded-md border hairline bg-surface p-4">
                <h3 className="font-semibold">3D model (optional)</h3>
                <p className="mb-3 text-sm text-muted">Upload a .glb file (up to 10 MB) if you have a 3D scan of the piece. Buyers can rotate it on the product page after our team approves it.</p>
                {item.model3d && <div className="mb-3 max-w-md"><Model3D url={item.model3d.url} title={item.title} /><p className="mt-1 text-xs">{item.model3d.live ? <Badge tone="good">Live</Badge> : <Badge>Live after review</Badge>} <button className="ml-2 text-muted underline" onClick={() => act(() => call(`/v1/seller/studio/items/${item.id}/model3d`, { method: "DELETE" }), "3D model removed")}>Remove</button></p></div>}
                <input type="file" accept=".glb,model/gltf-binary" aria-label="Upload 3D model" onChange={(e) => { const file = e.target.files?.[0]; if (!file) return; const fd = new FormData(); fd.set("file", file); void act(() => call(`/v1/seller/studio/items/${item.id}/model3d`, { form: fd }), "3D model uploaded. It goes live after review"); e.target.value = ""; }} />
              </section>
              <p className="text-xs text-muted">Jobs: {jobs.data?.jobs.slice(0, 5).map((j) => `${stateLabel(j.kind)} ${stateLabel(j.state)}`).join(" · ") || "none yet"}</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
