"use client";
import { use, useState } from "react";
import { call } from "@/lib/client";
import { useApi } from "@/lib/useApi";
import { PageHeader } from "@/components/chrome/PortalShell";
import { StatusPill } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { TextField } from "@/components/ui/Field";
import { Notice, Price } from "@/components/ui/misc";
import { useToast } from "@/components/ui/Toast";
import { dateTime, stateLabel } from "@/lib/format";

interface Sub { id: string; title: string; description: string; state: string; sellerAskMinor: number | null; offerMinor: number | null; offerExpiresAt: string | null; decisionNote: string | null; paymentRef: string | null; pieces: Array<{ id: string; sku: string; title: string; category: string; stockState: string; photos: Array<{ id: string; url: string }> }> }

export default function DPDetail({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const { data, reload } = useApi<{ submission: Sub }>(`/v1/seller/direct-purchase/${id}`);
  const [code, setCode] = useState("");
  const [dev, setDev] = useState<string | null>(null);
  const [sent, setSent] = useState(false);
  const toast = useToast();
  if (!data) return <p className="text-muted">Loading…</p>;
  const s = data.submission;
  const respond = async (accept: boolean) => { try { await call(`/v1/seller/direct-purchase/${id}/respond`, { body: { accept, code: accept ? code : undefined } }); toast(accept ? "Offer accepted. Next: hand over the pieces." : "Offer declined", "good"); await reload(); } catch (e) { toast((e as Error).message, "bad"); } };
  return (
    <div className="max-w-3xl space-y-6">
      <PageHeader title={s.title} sub={<StatusPill state={s.state} label={stateLabel(s.state)} />} />
      <p className="text-[15px]">{s.description}</p>
      {s.state === "OFFER_MADE" && s.offerMinor && (
        <section className="space-y-3 rounded-md border-2 border-champagne bg-surface p-5">
          <p className="text-sm text-muted">Our offer{s.sellerAskMinor ? <> (you asked <Price minor={s.sellerAskMinor} size="sm" />)</> : null}</p>
          <Price minor={s.offerMinor} size="xl" className="block" />
          <p className="text-sm text-muted">Valid until {dateTime(s.offerExpiresAt)}. If you accept, send or bring the pieces to our Lahore warehouse. We check them and then pay you. Until we pay, the pieces are still yours.</p>
          {!sent ? <Button onClick={async () => { const r = await call<{ devCode?: string }>("/v1/auth/confirm/request", { method: "POST" }); setDev(r.devCode ?? null); setSent(true); }}>Accept and send me a code</Button> : (
            <div className="flex flex-wrap items-end gap-3"><TextField label="Code from SMS" inputMode="numeric" maxLength={6} value={code} onChange={(e) => setCode(e.target.value.replace(/\D/g, ""))} help={dev ? `Development code: ${dev}` : undefined} /><Button onClick={() => respond(true)} disabled={code.length !== 6}>Confirm acceptance</Button></div>
          )}
          <Button variant="ghost" onClick={() => respond(false)}>Decline</Button>
        </section>
      )}
      {["AWAITING_HANDOVER"].includes(s.state) && <Notice>Offer accepted, awaiting handover. Please send or bring the pieces to our Lahore warehouse.</Notice>}
      {s.state === "AWAITING_PAYMENT" && <Notice>We&apos;ve received and checked your pieces. Your payment of <Price minor={s.offerMinor} size="sm" /> is being sent.</Notice>}
      {s.state === "TRANSFERRED" && <Notice tone="good">Paid (reference {s.paymentRef}). These pieces now belong to ONEOFAKIND. Thank you!</Notice>}
      {s.decisionNote && ["REJECTED_BY_BUYER_TEAM", "CANCELLED"].includes(s.state) && <Notice tone="warn">{s.decisionNote}</Notice>}
      <ul className="grid gap-3 sm:grid-cols-2">{s.pieces.map((p) => (
        <li key={p.id} className="rounded-md border hairline bg-surface p-3">
          <div className="flex gap-2">{p.photos.slice(0, 3).map((ph) => <img key={ph.id} src={ph.url} alt="" className="h-20 w-16 rounded-sm object-cover" />)}</div>
          <div className="mt-2 font-medium">{p.title}</div><div className="text-sm text-muted num">{p.sku} · {p.category} · {stateLabel(p.stockState)}</div>
        </li>
      ))}</ul>
    </div>
  );
}
