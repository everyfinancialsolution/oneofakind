"use client";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { call } from "@/lib/client";
import { PageHeader } from "@/components/chrome/PortalShell";
import { Button } from "@/components/ui/Button";
import { TextArea, TextField } from "@/components/ui/Field";
import { Notice } from "@/components/ui/misc";
import type { Category } from "@/lib/types";

interface P { title: string; categoryId: string; brandName: string; size: string; files: File[] }

export default function NewDP() {
  const router = useRouter();
  const [cats, setCats] = useState<Category[]>([]);
  const [title, setTitle] = useState("");
  const [desc, setDesc] = useState("");
  const [ask, setAsk] = useState("");
  const [pieces, setPieces] = useState<P[]>([{ title: "", categoryId: "", brandName: "", size: "", files: [] }]);
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  useEffect(() => { fetch("/v1/catalog/categories").then((r) => r.json()).then((d) => setCats(d.categories)); }, []);
  const leaves = cats.filter((c) => !cats.some((x) => x.parentId === c.id));
  const submit = async () => {
    setBusy(true); setErr(null);
    try {
      const r = await call<{ id: string }>("/v1/seller/direct-purchase", { body: { title, description: desc, sellerAskMinor: ask ? Number(ask) * 100 : undefined, pieces: pieces.map((p) => ({ title: p.title, categoryId: p.categoryId, brandName: p.brandName || null, size: p.size || null })) } });
      const d = await call<{ submission: { pieces: Array<{ id: string }> } }>(`/v1/seller/direct-purchase/${r.id}`);
      for (const [i, p] of pieces.entries()) for (const f of p.files) { const fd = new FormData(); fd.set("file", f); await call(`/v1/seller/direct-purchase/${r.id}/items/${d.submission.pieces[i]!.id}/photos`, { form: fd }); }
      router.push(`/seller/direct-purchase/${r.id}`);
    } catch (e) { setErr((e as Error).message); } finally { setBusy(false); }
  };
  return (
    <div className="max-w-3xl space-y-6">
      <PageHeader title="Ask for an offer" />
      {err && <Notice tone="bad">{err}</Notice>}
      <TextField label="What are you selling?" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. 5 Carhartt work jackets" />
      <TextArea label="Describe condition and anything we should know" value={desc} onChange={(e) => setDesc(e.target.value)} />
      <TextField label="Your asking price for everything (PKR)" optional inputMode="numeric" value={ask} onChange={(e) => setAsk(e.target.value.replace(/\D/g, ""))} />
      <h2 className="font-display text-xl">Pieces</h2>
      {pieces.map((p, i) => (
        <div key={i} className="grid gap-2 rounded-md border hairline bg-surface p-3 sm:grid-cols-4">
          <input aria-label="Title" className="h-11 rounded-md border hairline px-2 sm:col-span-2" placeholder="Title" value={p.title} onChange={(e) => setPieces(pieces.map((x, j) => (j === i ? { ...x, title: e.target.value } : x)))} />
          <select aria-label="Category" className="h-11 rounded-md border hairline px-2" value={p.categoryId} onChange={(e) => setPieces(pieces.map((x, j) => (j === i ? { ...x, categoryId: e.target.value } : x)))}><option value="">Category</option>{leaves.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select>
          <input aria-label="Brand" className="h-11 rounded-md border hairline px-2" placeholder="Brand" value={p.brandName} onChange={(e) => setPieces(pieces.map((x, j) => (j === i ? { ...x, brandName: e.target.value } : x)))} />
          <label className="text-sm sm:col-span-4">Photos <input type="file" accept="image/*" multiple onChange={(e) => setPieces(pieces.map((x, j) => (j === i ? { ...x, files: Array.from(e.target.files ?? []).slice(0, 6) } : x)))} /></label>
        </div>
      ))}
      <div className="flex gap-3"><Button variant="ghost" onClick={() => setPieces([...pieces, { title: "", categoryId: "", brandName: "", size: "", files: [] }])}>+ Add piece</Button><Button onClick={submit} loading={busy} disabled={!title || desc.length < 5 || pieces.some((p) => !p.title || !p.categoryId)}>Send for an offer</Button></div>
    </div>
  );
}
