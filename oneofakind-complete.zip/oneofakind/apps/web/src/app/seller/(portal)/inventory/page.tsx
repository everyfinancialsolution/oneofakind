"use client";
import { useState } from "react";
import { useApi } from "@/lib/useApi";
import { PageHeader } from "@/components/chrome/PortalShell";
import { buttonClass } from "@/components/ui/Button";
import { Notice, Stat } from "@/components/ui/misc";
import { handlingLabel, pkr, stateLabel } from "@/lib/format";

interface Row { sku: string; title: string; brand: string; category: string; size: string; arrangement: string; owner: string; stockState: string; listing: string; channel: string; priceMinor: number; location: string }

export default function Inventory() {
  const [arr, setArr] = useState("");
  const { data, error } = useApi<{ items: Row[]; summary: Record<string, number> }>(`/v1/seller/inventory${arr ? `?arrangement=${arr}` : ""}`);
  return (
    <div>
      <PageHeader title="Inventory" sub="Every piece you own on ONEOFAKIND, wherever it is." actions={<a className={buttonClass("secondary")} href={`/v1/seller/inventory?format=csv${arr ? `&arrangement=${arr}` : ""}`}>Download CSV</a>} />
      <label className="mb-4 inline-flex items-center gap-2 text-sm"><span className="text-muted">Show</span>
        <select value={arr} onChange={(e) => setArr(e.target.value)} className="h-9 rounded-md border hairline bg-surface px-2"><option value="">All handling</option><option value="SELF_MANAGED">You ship</option><option value="MANAGED_RESALE">Managed by us</option><option value="DIRECT_PURCHASE">Sold or offered to us</option></select>
      </label>
      {error && <Notice tone="bad">{error.message}</Notice>}
      {data && (
        <>
          <div className="mb-6 grid grid-cols-2 gap-3 md:grid-cols-5">{Object.entries(data.summary).map(([k, n]) => <Stat key={k} label={stateLabel(k)} value={n} />)}</div>
          <div className="overflow-x-auto rounded-md border hairline bg-surface">
            <table className="table-dense w-full min-w-[900px]">
              <thead><tr><th>SKU</th><th>Item</th><th>Category</th><th>Size</th><th>Handling</th><th>Owner</th><th>Stock</th><th>Listing</th><th>Shelf</th><th className="text-right">Price</th></tr></thead>
              <tbody>{data.items.map((r) => (
                <tr key={r.sku}><td className="num">{r.sku}</td><td>{r.title}<div className="text-xs text-muted">{r.brand}</div></td><td>{r.category}</td><td>{r.size}</td><td>{handlingLabel(r.arrangement, r.owner)}</td><td>{r.owner === "PLATFORM" ? "ONEOFAKIND" : "You"}</td><td>{stateLabel(r.stockState)}</td><td>{r.channel === "BUNDLE" ? "Bundle" : stateLabel(r.listing)}</td><td className="num">{r.location}</td><td className="num text-right">{pkr(r.priceMinor)}</td></tr>
              ))}</tbody>
            </table>
          </div>
        </>
      )}
    </div>
  );
}
