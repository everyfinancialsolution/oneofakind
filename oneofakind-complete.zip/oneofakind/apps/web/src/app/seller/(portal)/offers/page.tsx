"use client";
import { call } from "@/lib/client";
import { useApi } from "@/lib/useApi";
import { PageHeader } from "@/components/chrome/PortalShell";
import { StatusPill } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { EmptyState, Price } from "@/components/ui/misc";
import { useToast } from "@/components/ui/Toast";
import { dateTime } from "@/lib/format";

interface O { id: string; state: string; amountMinor: number; listPriceMinor: number; title: string; sku: string; buyer: string; expiresAt: string }

export default function Offers() {
  const { data, reload } = useApi<{ offers: O[] }>("/v1/seller/offers");
  const toast = useToast();
  const act = async (id: string, a: "accept" | "decline") => { try { await call(`/v1/seller/offers/${id}/${a}`, { method: "POST" }); toast(a === "accept" ? "Accepted. The buyer has 24 hours to pay" : "Declined", "good"); await reload(); } catch (e) { toast((e as Error).message, "bad"); } };
  return (
    <div className="max-w-3xl">
      <PageHeader title="Offers" sub="Buyers can offer below your price. If you accept, they have 24 hours to pay. First to pay wins." />
      {data && !data.offers.length && <EmptyState title="No offers yet" />}
      <ul className="space-y-3">
        {data?.offers.map((o) => (
          <li key={o.id} className="flex flex-wrap items-center gap-4 rounded-md border hairline bg-surface p-4">
            <div className="flex-1"><div className="font-medium">{o.title}</div><div className="text-sm text-muted">{o.buyer} offered <Price minor={o.amountMinor} size="sm" /> (your price <Price minor={o.listPriceMinor} size="sm" />) · expires {dateTime(o.expiresAt)}</div></div>
            <StatusPill state={o.state} />
            {o.state === "PENDING" && <div className="flex gap-2"><Button size="sm" onClick={() => act(o.id, "accept")}>Accept</Button><Button size="sm" variant="ghost" onClick={() => act(o.id, "decline")}>Decline</Button></div>}
          </li>
        ))}
      </ul>
    </div>
  );
}
