"use client";
import Link from "next/link";
import { useSearchParams, useRouter } from "next/navigation";
import { Suspense, useState } from "react";
import clsx from "clsx";
import { useApi } from "@/lib/useApi";
import { PageHeader } from "@/components/chrome/PortalShell";
import { Button } from "@/components/ui/Button";
import { StatusPill } from "@/components/ui/Badge";
import { EmptyState, Notice } from "@/components/ui/misc";
import { handlingLabel, pkr, stateLabel } from "@/lib/format";

interface Row { id: string; sku: string; title: string; brand: string | null; size: string | null; priceMinor: number; arrangement: string; ownerType: string; stockState: string; channel: string; listingState: string | null; listingSlug: string | null; moderationNote: string | null; photo: string | null; labelCode: string | null }
const TABS = [["", "All"], ["PUBLISHED", "Live"], ["PENDING_REVIEW", "In review"], ["CHANGES_REQUESTED", "Needs changes"], ["DRAFT", "Drafts"], ["PAUSED", "Paused"], ["SOLD_OUT", "Sold"], ["BUNDLED", "In bundles"]];

function Listings() {
  const sp = useSearchParams();
  const router = useRouter();
  const state = sp.get("state") ?? "";
  const [q, setQ] = useState(sp.get("q") ?? "");
  const { data, error, loading } = useApi<{ items: Row[]; nextCursor: string | null }>(`/v1/seller/listings?limit=100${state ? `&state=${state}` : ""}${sp.get("q") ? `&q=${encodeURIComponent(sp.get("q")!)}` : ""}`);
  return (
    <div>
      <PageHeader title="My items" actions={<Button href="/seller/listings/new">Add item</Button>} />
      <div className="mb-4 flex flex-wrap items-center gap-2">
        {TABS.map(([k, l]) => <Link key={k} href={`/seller/listings${k ? `?state=${k}` : ""}`} className={clsx("rounded-pill border px-3 py-1 text-sm", state === k ? "border-ink bg-ink text-ivory" : "hairline hover:border-ink")}>{l}</Link>)}
        <form className="ml-auto" onSubmit={(e) => { e.preventDefault(); router.replace(`/seller/listings?${state ? `state=${state}&` : ""}q=${encodeURIComponent(q)}`); }}>
          <input aria-label="Search your items" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search title or SKU" className="h-9 rounded-md border hairline bg-surface px-3 text-sm" />
        </form>
      </div>
      {error && <Notice tone="bad">{error.message}</Notice>}
      {loading && <p className="text-muted">Loading…</p>}
      {data && !data.items.length && <EmptyState title="No items here" action={<Button href="/seller/listings/new">Add your first item</Button>} />}
      {data && data.items.length > 0 && (
        <div className="overflow-x-auto rounded-md border hairline bg-surface">
          <table className="table-dense w-full min-w-[720px]">
            <thead><tr><th /><th>Item</th><th>Price</th><th>Status</th><th>Stock</th><th>Handling</th><th /></tr></thead>
            <tbody>
              {data.items.map((r) => (
                <tr key={r.id}>
                  <td className="w-14">{r.photo ? <img src={r.photo} alt="" className="h-14 w-11 rounded-sm object-cover" /> : <div className="h-14 w-11 rounded-sm bg-ivory-deep" />}</td>
                  <td><Link href={`/seller/listings/${r.id}`} className="font-medium hover:underline">{r.title}</Link><div className="text-xs text-muted num">{r.sku} · {r.brand ?? "No brand"} · {r.size ?? "-"}</div>{r.moderationNote && r.listingState === "CHANGES_REQUESTED" && <div className="text-xs text-[#7A5A1F]">To fix: {r.moderationNote}</div>}</td>
                  <td className="num">{pkr(r.priceMinor)}</td>
                  <td>{r.channel === "BUNDLE" ? <StatusPill state="PENDING" label="In a bundle" /> : r.listingState ? <StatusPill state={r.listingState} /> : "-"}</td>
                  <td className="text-sm">{stateLabel(r.stockState)}</td>
                  <td className="text-sm">{handlingLabel(r.arrangement, r.ownerType)}</td>
                  <td className="text-right"><Link href={`/seller/listings/${r.id}`} className="link text-sm">Open</Link></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export default function Page() { return <Suspense><Listings /></Suspense>; }
