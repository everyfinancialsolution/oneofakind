import type { ReactNode } from "react";
import Link from "next/link";
import { requireUser } from "@/lib/guard";
import { PortalShell, type NavGroup } from "@/components/chrome/PortalShell";
import { Button } from "@/components/ui/Button";

export const dynamic = "force-dynamic";

const NAV: NavGroup[] = [
  { items: [{ href: "/seller", label: "Overview", exact: true }, { href: "/seller/listings/new", label: "Add item" }, { href: "/seller/listings", label: "My items" }, { href: "/seller/orders", label: "Orders to send" }, { href: "/seller/offers", label: "Offers" }] },
  { title: "Money", items: [{ href: "/seller/earnings", label: "Earnings" }] },
  { title: "More ways to sell", items: [{ href: "/seller/bundles", label: "Bundles" }, { href: "/seller/managed-resale", label: "Managed resale" }, { href: "/seller/direct-purchase", label: "Sell to us" }] },
  { title: "Tools", items: [{ href: "/seller/labels", label: "Labels" }, { href: "/seller/inventory", label: "Inventory" }, { href: "/seller/studio", label: "Photo studio (AI)" }, { href: "/seller/analytics", label: "Analytics" }] },
  { title: "Shop", items: [{ href: "/seller/storefront", label: "Storefront" }, { href: "/seller/settings", label: "Settings & payouts" }, { href: "/seller/activity", label: "Activity" }, { href: "/seller/support", label: "Support" }] },
];

export default async function SellerPortal({ children }: { children: ReactNode }) {
  const { user } = await requireUser("/seller");
  if (!user.seller) {
    return (
      <main className="page max-w-xl py-24">
        <h1 className="font-display text-4xl">Seller hub</h1>
        <p className="mt-3 text-muted">You need an approved seller account to use the seller hub.</p>
        <div className="mt-6 flex gap-3"><Button href="/seller/apply">Apply to sell</Button><Link href="/sell" className="link self-center">How selling works</Link></div>
      </main>
    );
  }
  const ref = user.applications.find((a) => a.kind === "SELLER")?.reference;
  return <PortalShell title={`Seller hub · ${user.seller.displayName}`} nav={NAV} help={`Hello ONEOFAKIND, I need help with my seller account.${ref ? ` Reference ${ref}` : ""}`}>{children}</PortalShell>;
}
