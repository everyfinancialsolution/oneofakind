"use client";
import Link from "next/link";
import { useApi } from "@/lib/useApi";
import { PageHeader } from "@/components/chrome/PortalShell";
import { Button } from "@/components/ui/Button";
import { Notice, Stat } from "@/components/ui/misc";
import { pkr, dateTime } from "@/lib/format";

interface Dash {
  seller: { displayName: string; slug: string; status: string; payoutVerified: boolean; allowStaffListing: boolean };
  listings: { live: number; drafts: number; inReview: number; changesRequested: number; paused: number };
  ordersToShip: number; pendingOffers: number; soldThisMonth: { count: number; grossMinor: number }; payableBalanceMinor: number;
  notifications: Array<{ id: string; body: string; createdAt: string; read: boolean }>;
}

export default function SellerHome() {
  const { data: d, error } = useApi<Dash>("/v1/seller/dashboard");
  if (error) return <Notice tone="bad">{error.message}</Notice>;
  if (!d) return <p className="text-muted">Loading…</p>;
  return (
    <div className="space-y-8">
      <PageHeader title={`Hello, ${d.seller.displayName}`} sub={<Link href={`/sellers/${d.seller.slug}`} className="link">View your storefront</Link>} actions={<Button href="/seller/listings/new" size="lg">Add item</Button>} />
      {!d.seller.payoutVerified && <Notice tone="warn">Add a bank or wallet account in your own name so we can pay you. <Link href="/seller/settings" className="link">Add payout account</Link></Notice>}
      {d.ordersToShip > 0 && <Notice tone="warn"><strong>{d.ordersToShip} {d.ordersToShip === 1 ? "order needs" : "orders need"} sending.</strong> <Link href="/seller/orders" className="link">Pack and send</Link></Notice>}
      {d.listings.changesRequested > 0 && <Notice>{d.listings.changesRequested} item(s) need small changes before they can go live. <Link href="/seller/listings?state=CHANGES_REQUESTED" className="link">See what to fix</Link></Notice>}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <Stat label="Live items" value={d.listings.live} sub={`${d.listings.inReview} in review · ${d.listings.drafts} drafts`} />
        <Stat label="Sold this month" value={d.soldThisMonth.count} sub={pkr(d.soldThisMonth.grossMinor)} />
        <Stat label="Money on its way" value={pkr(d.payableBalanceMinor)} sub="Paid weekly, 7 days after delivery" />
        <Stat label="Offers waiting" value={d.pendingOffers} sub={<Link href="/seller/offers" className="link">Reply</Link>} />
      </div>
      <section>
        <h2 className="mb-3 font-display text-2xl">Latest updates</h2>
        {d.notifications.length ? (
          <ul className="divide-y rounded-md border hairline bg-surface">
            {d.notifications.map((n) => <li key={n.id} className="flex justify-between gap-4 px-4 py-3 text-[15px]"><span>{n.body}</span><span className="shrink-0 text-sm text-muted">{dateTime(n.createdAt)}</span></li>)}
          </ul>
        ) : <p className="text-muted">Nothing new yet.</p>}
      </section>
      <section className="grid gap-4 md:grid-cols-3">
        {[
          ["Add an item", "4 photos and a few details. About 3 minutes.", "/seller/listings/new"],
          ["Hand it to us", "Managed resale: we photograph, list, store and ship.", "/seller/managed-resale"],
          ["Sell to us", "Get an offer for a piece or a whole collection.", "/seller/direct-purchase"],
        ].map(([t, b, h]) => <Link key={h} href={h!} className="rounded-md border hairline p-5 hover:border-ink"><h3 className="font-display text-xl">{t}</h3><p className="mt-1 text-sm text-muted">{b}</p></Link>)}
      </section>
    </div>
  );
}
