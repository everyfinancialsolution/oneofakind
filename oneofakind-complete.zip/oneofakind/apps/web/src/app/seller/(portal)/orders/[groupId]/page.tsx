"use client";
import { use, useState } from "react";
import { call } from "@/lib/client";
import { useApi } from "@/lib/useApi";
import { PageHeader } from "@/components/chrome/PortalShell";
import { ScanInput } from "@/components/ScanInput";
import { StatusPill } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { TextField } from "@/components/ui/Field";
import { Notice, Price, Steps } from "@/components/ui/misc";
import { useToast } from "@/components/ui/Toast";
import { dateTime, stateLabel } from "@/lib/format";

interface G {
  id: string; orderRef: string; state: string; mode: string; packVerifiedAt: string | null; warehouseHandles?: boolean;
  shipTo?: Record<string, string | null>; items: Array<{ id: string; title: string; sku: string; size?: string | null; priceMinor: number; code?: string | null; photo?: string | null }>;
  expectedCodes?: string[]; shipments: Array<{ id?: string; courier?: string; trackingNo: string | null; state: string; code?: string | null; events?: Array<{ status: string; at: string }> }>;
}
interface PackCheck { status: string; missing: string[]; unexpected: string[]; invalid: string[] }

const openPdfGet = async (url: string) => { const w = window.open("", "_blank"); const r = await fetch(url, { credentials: "same-origin" }); const b = await r.blob(); const u = URL.createObjectURL(b); if (w) w.location.href = u; };

export default function SellerOrder({ params }: { params: Promise<{ groupId: string }> }) {
  const { groupId } = use(params);
  const { data, reload } = useApi<{ group: G }>(`/v1/seller/orders/${groupId}`);
  const [scans, setScans] = useState<string[]>([]);
  const [check, setCheck] = useState<PackCheck | null>(null);
  const [manual, setManual] = useState({ courier: "", trackingNo: "" });
  const [busy, setBusy] = useState(false);
  const toast = useToast();
  if (!data) return <p className="text-muted">Loading…</p>;
  const g = data.group;
  if (g.warehouseHandles) return (<div><PageHeader title={`Order ${g.orderRef}`} /><Notice>Our warehouse packs and sends this order for you. You'll be paid 7 days after delivery.</Notice></div>);
  const step = !g.packVerifiedAt ? 1 : !g.shipments.length ? 2 : g.shipments.some((s) => s.state === "READY") ? 3 : 4;
  const scan = async (code: string) => {
    const next = [...scans, code];
    setScans(next);
    const r = await call<PackCheck>(`/v1/seller/orders/${groupId}/pack`, { body: { scans: next } });
    setCheck(r);
    if (r.status === "COMPLETE") { toast("All pieces checked. Ready to send.", "good"); await reload(); }
    else if (r.status === "MISMATCH") toast("That code isn't part of this order. Take it out of the parcel.", "bad");
  };
  const dispatch = async (useManual: boolean) => {
    setBusy(true);
    try { await call(`/v1/seller/orders/${groupId}/dispatch`, { body: useManual ? { manual } : {} }); toast("Courier booked", "good"); await reload(); }
    catch (e) { toast((e as Error).message, "bad"); } finally { setBusy(false); }
  };
  const handover = async (code: string) => {
    try { await call("/v1/seller/orders/handover", { body: { code } }); toast("Handed to courier. The buyer gets the tracking link.", "good"); await reload(); }
    catch (e) { toast((e as Error).message, "bad"); }
  };
  return (
    <div className="max-w-4xl space-y-8">
      <PageHeader title={`Order ${g.orderRef}`} sub={<StatusPill state={g.state} />} />
      <Steps steps={["Print pack slip", "Scan pieces into the parcel", "Book courier & print label", "Hand to courier"]} current={step === 1 ? (scans.length ? 1 : 0) : step} />
      <div className="grid gap-6 md:grid-cols-2">
        <section className="rounded-md border hairline bg-surface p-4 text-[15px]">
          <h2 className="mb-2 font-display text-xl">Send to</h2>
          <p>{g.shipTo?.recipient}<br />{g.shipTo?.line1}{g.shipTo?.line2 ? <><br />{g.shipTo.line2}</> : null}<br />{g.shipTo?.city} {g.shipTo?.postalCode}<br /><span className="num">{g.shipTo?.phone}</span></p>
        </section>
        <section className="rounded-md border hairline bg-surface p-4">
          <h2 className="mb-2 font-display text-xl">Pieces</h2>
          <ul className="space-y-2 text-sm">{g.items.map((i) => <li key={i.id} className="flex items-center gap-3">{i.photo && <img src={i.photo} alt="" className="h-12 w-9 rounded-sm object-cover" />}<span className="flex-1">{i.title}<span className="block text-xs text-muted num">{i.sku} · label {i.code ?? "-"}</span></span><Price minor={i.priceMinor} size="sm" /></li>)}</ul>
        </section>
      </div>
      {step === 1 && (
        <section className="space-y-4">
          <div className="flex flex-wrap items-center gap-3"><Button variant="secondary" onClick={() => openPdfGet(`/v1/seller/orders/${groupId}/pack-slip`)}>Print pack slip</Button><span className="text-sm text-muted">It lists the codes to scan. Put the slip in the parcel.</span></div>
          <h2 className="font-display text-xl">Scan each piece&apos;s label as you put it in the parcel</h2>
          <ScanInput onScan={scan} />
          {check && check.status !== "COMPLETE" && (
            <Notice tone={check.status === "MISMATCH" ? "bad" : "warn"}>
              {check.missing.length > 0 && <p>Still to scan: <span className="num">{check.missing.join(", ")}</span></p>}
              {check.unexpected.length > 0 && <p>Not in this order: <span className="num">{check.unexpected.join(", ")}</span>. Take it out and <button className="link" onClick={() => { setScans([]); setCheck(null); }}>start again</button>.</p>}
              {check.invalid.length > 0 && <p>Unreadable: {check.invalid.join(", ")}</p>}
            </Notice>
          )}
        </section>
      )}
      {step === 2 && (
        <section className="space-y-4">
          <Notice tone="good">Packing checked on {dateTime(g.packVerifiedAt)}.</Notice>
          <div className="flex flex-wrap gap-3"><Button onClick={() => dispatch(false)} loading={busy}>Book our courier</Button></div>
          <details className="rounded-md border hairline p-4"><summary className="cursor-pointer text-sm">I booked my own courier</summary>
            <div className="mt-3 grid gap-3 sm:grid-cols-3"><TextField label="Courier" value={manual.courier} onChange={(e) => setManual({ ...manual, courier: e.target.value })} /><TextField label="Tracking number" value={manual.trackingNo} onChange={(e) => setManual({ ...manual, trackingNo: e.target.value })} /><div className="self-end"><Button variant="secondary" onClick={() => dispatch(true)} disabled={!manual.courier || !manual.trackingNo}>Save</Button></div></div>
          </details>
        </section>
      )}
      {g.shipments.length > 0 && (
        <section className="space-y-3">
          {g.shipments.map((s) => (
            <div key={s.id} className="rounded-md border hairline bg-surface p-4">
              <div className="flex flex-wrap items-center justify-between gap-2"><span>{s.courier} · <strong className="num">{s.trackingNo}</strong> · dispatch code <span className="num">{s.code}</span></span><StatusPill state={s.state} /></div>
              {s.state === "READY" && (
                <div className="mt-3 flex flex-wrap gap-3">
                  <Button variant="secondary" size="sm" onClick={() => openPdfGet(`/v1/seller/orders/shipments/${s.id}/label`)}>Print dispatch label (100×150)</Button>
                  <Button size="sm" onClick={() => handover(s.code!)}>Handed to courier</Button>
                </div>
              )}
              {!!s.events?.length && <ol className="mt-2 text-sm text-muted">{s.events.map((e, i) => <li key={i}>{dateTime(e.at)}: {stateLabel(e.status)}</li>)}</ol>}
            </div>
          ))}
          {step === 3 && <div><p className="mb-2 text-sm text-muted">Or scan the dispatch label when the courier collects it:</p><ScanInput onScan={handover} label="Scan dispatch code" autoFocus={false} /></div>}
        </section>
      )}
    </div>
  );
}
