"use client";
import Link from "next/link";
import { useApi } from "@/lib/useApi";
import { call } from "@/lib/client";
import { PageHeader } from "@/components/chrome/PortalShell";
import { Button } from "@/components/ui/Button";
import { StatusPill } from "@/components/ui/Badge";
import { EmptyState, Notice } from "@/components/ui/misc";
import { useToast } from "@/components/ui/Toast";
import { pkr } from "@/lib/format";

interface B { id: string; sku: string; slug: string; title: string; state: string; size: number; priceMinor: number; retailValueMinor: number; brand: string; style: string; thumbs: Array<string | null> }

export default function Bundles() {
  const { data, error, reload } = useApi<{ bundles: B[] }>("/v1/seller/bundles");
  const toast = useToast();
  const act = async (id: string, a: string) => { try { await call(`/v1/seller/bundles/${id}/${a}`, { method: "POST" }); await reload(); toast("Done", "good"); } catch (e) { toast((e as Error).message, "bad"); } };
  return (
    <div>
      <PageHeader title="Bundles" sub="Lots of exactly 5, 10 or 15 pieces, same brand and same style, grade A or B. Sold to verified resellers." actions={<Button href="/seller/bundles/new">Build a lot</Button>} />
      {error && <Notice tone="bad">{error.message}</Notice>}
      {data && !data.bundles.length && <EmptyState title="No lots yet" body="Group pieces of one brand and style into a lot. Resellers buy the whole lot at once." action={<Button href="/seller/bundles/new">Build your first lot</Button>} />}
      <ul className="space-y-3">
        {data?.bundles.map((b) => (
          <li key={b.id} className="flex flex-wrap items-center gap-4 rounded-md border hairline bg-surface p-4">
            <div className="flex gap-1">{b.thumbs.map((t, i) => (t ? <img key={i} src={t} alt="" className="h-14 w-11 rounded-sm object-cover" /> : null))}</div>
            <div className="flex-1"><div className="font-medium">{b.title}</div><div className="text-sm text-muted num">{b.sku} · {pkr(b.priceMinor)} (retail value {pkr(b.retailValueMinor)})</div></div>
            <StatusPill state={b.state} />
            <div className="flex gap-2">
              {["DRAFT", "CHANGES_REQUESTED"].includes(b.state) && <Button size="sm" onClick={() => act(b.id, "submit")}>Send for review</Button>}
              {b.state === "PUBLISHED" && <><Link className="link self-center text-sm" href={`/bundles/${b.slug}`}>View</Link><Button size="sm" variant="secondary" onClick={() => act(b.id, "pause")}>Pause</Button></>}
              {b.state === "PAUSED" && <Button size="sm" onClick={() => act(b.id, "resume")}>Resume</Button>}
              {!["SOLD", "REMOVED", "RESERVED"].includes(b.state) && <Button size="sm" variant="ghost" onClick={() => { if (confirm("Break up this lot? Pieces go back to single items.")) void act(b.id, "remove"); }}>Break up</Button>}
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}
