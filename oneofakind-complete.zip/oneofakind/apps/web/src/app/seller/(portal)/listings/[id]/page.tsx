"use client";
import Link from "next/link";
import { use, useEffect, useState } from "react";
import { call, ClientApiError } from "@/lib/client";
import { openPdf, useApi } from "@/lib/useApi";
import { PageHeader } from "@/components/chrome/PortalShell";
import { ListingForm, toPayload, type ListingValues } from "@/components/seller/ListingForm";
import { Button } from "@/components/ui/Button";
import { StatusPill } from "@/components/ui/Badge";
import { Notice } from "@/components/ui/misc";
import { useToast } from "@/components/ui/Toast";
import { dateTime, stateLabel } from "@/lib/format";

interface ItemView {
  id: string; sku: string; title: string; description: string | null; size: string | null; color: string | null; material: string | null; measurements: Record<string, number> | null;
  conditionGrade: string | null; defects: Array<{ type: string; location: string; severity: string }>; priceMinor: number; weightGrams: number | null; arrangement: string; stockState: string; channel: string;
  category: { id: string; name: string }; brandName: string | null; styleId: string | null; location: string | null;
  listing: { id: string; slug: string; state: string; moderationNote: string | null; publishedAt: string | null } | null;
  photos: Array<{ id: string; url: string; kind: string; aiLabel: boolean; approved: boolean }>; bundle: { slug: string; title: string; state: string } | null;
  custody: Array<{ id: string; fromParty: string; toParty: string; note: string | null; createdAt: string }>; labelCode: string | null; readiness: string[];
}

const toValues = (i: ItemView): ListingValues => ({
  title: i.title, categoryId: i.category.id, brandName: i.brandName ?? "", styleId: i.styleId ?? "", size: i.size ?? "", color: i.color ?? "", material: i.material ?? "",
  measurements: Object.fromEntries(Object.entries(i.measurements ?? {}).map(([k, v]) => [k, String(v)])), conditionGrade: i.conditionGrade ?? "", defects: i.defects ?? [],
  description: i.description ?? "", priceRupees: String(Math.round(i.priceMinor / 100)), weightGrams: i.weightGrams ? String(i.weightGrams) : "",
});

export default function EditListing({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const { data: item, error, reload } = useApi<ItemView>(`/v1/seller/listings/${id}`);
  const [v, setV] = useState<ListingValues | null>(null);
  const [busy, setBusy] = useState(false);
  const toast = useToast();
  useEffect(() => { if (item) setV(toValues(item)); }, [item]);
  if (error) return <Notice tone="bad">{error.message}</Notice>;
  if (!item || !v) return <p className="text-muted">Loading…</p>;
  const l = item.listing;
  const locked = ["RESERVED", "SOLD", "PACKED", "DISPATCHED", "DELIVERED"].includes(item.stockState) || l?.state === "REMOVED";
  const managed = item.arrangement !== "SELF_MANAGED";

  const act = async (fn: () => Promise<unknown>, ok: string) => {
    setBusy(true);
    try { await fn(); toast(ok, "good"); await reload(); } catch (e) { toast((e as ClientApiError).message, "bad"); } finally { setBusy(false); }
  };
  const save = () => act(async () => {
    const p = toPayload(v);
    const r = await call<{ sentToReview: boolean }>(`/v1/seller/listings/${id}`, { method: "PATCH", body: managed ? { title: p.title, description: p.description, priceMinor: p.priceMinor } : p });
    if (r.sentToReview) toast("Changes saved. Because you changed details buyers rely on, the item goes back to review.", "info");
  }, "Saved");
  const upload = (files: FileList | null) => act(async () => { for (const f of Array.from(files ?? [])) { const fd = new FormData(); fd.set("file", f); await call(`/v1/seller/listings/${id}/photos`, { form: fd }); } }, "Photo added");

  return (
    <div className="max-w-4xl space-y-8">
      <PageHeader title={item.title} sub={<span className="num">{item.sku} · {stateLabel(item.stockState)}{item.location ? ` · shelf ${item.location}` : ""}</span>}
        actions={<>{l?.slug && (l.state === "PUBLISHED" || l.state === "SOLD_OUT") && <Button href={`/product/${l.slug}`} variant="ghost">View live page</Button>}
          <Button variant="secondary" onClick={() => openPdf("/v1/seller/labels", { itemIds: [id], format: "thermal" }).catch((e) => toast(e.message, "bad"))}>Print label</Button></>} />

      <div className="flex flex-wrap items-center gap-3 rounded-md border hairline bg-surface p-4">
        {l && <StatusPill state={l.state} />}
        {l?.state === "CHANGES_REQUESTED" && <span className="text-[15px]">To fix: {l.moderationNote}</span>}
        {l?.state === "PENDING_REVIEW" && <span className="text-sm text-muted">Our team is checking this item.</span>}
        <span className="ml-auto flex flex-wrap gap-2">
          {l && ["DRAFT", "CHANGES_REQUESTED"].includes(l.state) && <Button size="sm" onClick={() => act(() => call(`/v1/seller/listings/${id}/submit`, { method: "POST" }), "Sent for review")} loading={busy} disabled={item.readiness.length > 0}>Send for review</Button>}
          {l?.state === "PUBLISHED" && item.stockState === "AVAILABLE" && <Button size="sm" variant="secondary" onClick={() => act(() => call(`/v1/seller/listings/${id}/pause`, { method: "POST" }), "Paused and hidden from buyers")}>Pause</Button>}
          {l?.state === "PAUSED" && <Button size="sm" onClick={() => act(() => call(`/v1/seller/listings/${id}/resume`, { method: "POST" }), "Live again")}>Resume</Button>}
          {l && !locked && !["REMOVED", "SOLD_OUT"].includes(l.state) && <Button size="sm" variant="ghost" onClick={() => { if (confirm("Remove this item? It will no longer be for sale.")) void act(() => call(`/v1/seller/listings/${id}/remove`, { method: "POST" }), "Removed"); }}>Remove</Button>}
        </span>
      </div>
      {item.readiness.length > 0 && <Notice tone="warn"><strong>Before you can send it for review:</strong><ul className="mt-1 list-disc pl-5">{item.readiness.map((r) => <li key={r}>{r}</li>)}</ul></Notice>}
      {item.bundle && <Notice>This piece is in the lot <Link className="link" href={`/seller/bundles`}>{item.bundle.title}</Link> ({stateLabel(item.bundle.state)}).</Notice>}
      {managed && <Notice>{item.arrangement === "MANAGED_RESALE" ? "This is a managed piece. Grade, measurements and photos are set by our inspection team; you can change the title, description and price." : "This piece is part of a sell-to-us offer. It stays yours until we have received it, checked it and paid you."}</Notice>}

      <section>
        <h2 className="mb-3 font-display text-2xl">Photos</h2>
        <ul className="grid grid-cols-3 gap-3 sm:grid-cols-6">
          {item.photos.map((p) => (
            <li key={p.id} className="text-xs">

              <img src={p.url} alt="" className="aspect-[4/5] w-full rounded-sm object-cover" />
              <div className="mt-1 flex justify-between">
                <span className={p.approved ? "text-[#2F5D50]" : "text-muted"}>{p.aiLabel ? "AI edit" : p.approved ? "Approved" : "Pending check"}</span>
                {!managed && !locked && <button className="underline" onClick={() => act(() => call(`/v1/seller/listings/${id}/photos/${p.id}`, { method: "DELETE" }), "Photo removed")}>Remove</button>}
              </div>
            </li>
          ))}
          {!managed && !locked && (
            <li><label className="flex aspect-[4/5] cursor-pointer items-center justify-center rounded-sm border-2 border-dashed hairline text-sm hover:border-ink">+ Add<input type="file" accept="image/*" multiple className="sr-only" onChange={(e) => { void upload(e.target.files); e.target.value = ""; }} /></label></li>
          )}
        </ul>
        {!managed && <p className="mt-2 text-sm"><Link href={`/seller/studio?item=${id}`} className="link">Clean up backgrounds in the AI photo studio</Link>. Your original photos are always kept.</p>}
      </section>

      <section>
        <h2 className="mb-3 font-display text-2xl">Details</h2>
        <fieldset disabled={locked} className="space-y-5">
          <ListingForm value={v} onChange={setV} lockedCondition={managed} />
          {!locked && <Button onClick={save} loading={busy}>Save changes</Button>}
        </fieldset>
        {locked && <p className="mt-3 text-sm text-muted">This piece is in an order, so it can't be edited.</p>}
      </section>

      {item.custody.length > 0 && (
        <section>
          <h2 className="mb-3 font-display text-2xl">Where it has been</h2>
          <ol className="space-y-2 text-[15px]">{item.custody.map((c) => <li key={c.id}><span className="text-sm text-muted">{dateTime(c.createdAt)}</span>: {c.fromParty} → {c.toParty}{c.note ? ` (${c.note})` : ""}</li>)}</ol>
        </section>
      )}
    </div>
  );
}
