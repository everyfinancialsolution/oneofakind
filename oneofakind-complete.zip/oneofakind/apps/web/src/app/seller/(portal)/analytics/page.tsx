"use client";
import { useApi } from "@/lib/useApi";
import { PageHeader } from "@/components/chrome/PortalShell";
import { Stat } from "@/components/ui/misc";
import { pkr } from "@/lib/format";

interface A { soldCount: number; liveCount: number; grossMinor: number; sellThroughPct: number; avgDaysToSell: number | null; byMonth: Array<{ month: string; count: number; grossMinor: number }>; byCategory: Array<{ name: string; count: number }> }

export default function Analytics() {
  const { data: a } = useApi<A>("/v1/seller/analytics");
  if (!a) return <p className="text-muted">Loading…</p>;
  const max = Math.max(1, ...a.byMonth.map((m) => m.grossMinor));
  return (
    <div className="space-y-8">
      <PageHeader title="Analytics" />
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <Stat label="Items sold" value={a.soldCount} /><Stat label="Sales" value={pkr(a.grossMinor)} />
        <Stat label="Sell-through" value={`${a.sellThroughPct}%`} sub="Sold ÷ (sold + live)" /><Stat label="Average days to sell" value={a.avgDaysToSell ?? "-"} />
      </div>
      <section>
        <h2 className="mb-3 font-display text-2xl">Sales by month</h2>
        {a.byMonth.length ? (
          <ul className="space-y-2" aria-label="Sales by month">
            {a.byMonth.map((m) => (
              <li key={m.month} className="grid grid-cols-[80px_1fr_120px] items-center gap-3 text-sm">
                <span className="num">{m.month}</span>
                <span className="h-3 rounded-sm bg-ink" style={{ width: `${(m.grossMinor / max) * 100}%` }} aria-hidden />
                <span className="num text-right">{pkr(m.grossMinor)} · {m.count}</span>
              </li>
            ))}
          </ul>
        ) : <p className="text-muted">No sales yet.</p>}
      </section>
      <section>
        <h2 className="mb-3 font-display text-2xl">Best categories</h2>
        <ul className="space-y-1 text-[15px]">{a.byCategory.map((c) => <li key={c.name} className="flex justify-between border-b hairline py-1"><span>{c.name}</span><span className="num">{c.count}</span></li>)}</ul>
      </section>
    </div>
  );
}
