"use client";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { call, ClientApiError } from "@/lib/client";
import { PageHeader } from "@/components/chrome/PortalShell";
import { ListingForm, emptyListing, toPayload, type ListingValues } from "@/components/seller/ListingForm";
import { PhotoPicker, type LocalPhoto } from "@/components/seller/PhotoPicker";
import { Button } from "@/components/ui/Button";
import { Notice, Steps } from "@/components/ui/misc";
import { useToast } from "@/components/ui/Toast";

/** Photo-first listing wizard ("Seller Lite"): photos → details → check and send. */
export default function NewListing() {
  const [step, setStep] = useState(0);
  const [photos, setPhotos] = useState<LocalPhoto[]>([]);
  const [v, setV] = useState<ListingValues>(emptyListing);
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const router = useRouter();
  const toast = useToast();

  const save = async (submit: boolean) => {
    setErr(null); setBusy(true);
    try {
      const created = await call<{ itemId: string }>("/v1/seller/listings", { body: toPayload(v) });
      for (const p of photos) { const fd = new FormData(); fd.set("file", p.file); await call(`/v1/seller/listings/${created.itemId}/photos`, { form: fd }); }
      if (submit) {
        try { await call(`/v1/seller/listings/${created.itemId}/submit`, { method: "POST" }); toast("Sent for review. We usually check within a few hours.", "good"); }
        catch (e) { toast((e as Error).message, "bad"); }
      } else toast("Saved as a draft", "good");
      router.push(`/seller/listings/${created.itemId}`);
    } catch (e) {
      const ex = e as ClientApiError;
      setErr(ex.fieldError("title") ?? ex.fieldError("priceMinor") ?? ex.message);
    } finally { setBusy(false); }
  };

  return (
    <div className="max-w-3xl space-y-6">
      <PageHeader title="Add an item" sub="About 3 minutes. Good photos and measurements sell pieces." />
      <Steps steps={["Photos", "Details", "Check and send"]} current={step} />
      {err && <Notice tone="bad">{err}</Notice>}
      {step === 0 && (
        <div className="space-y-4">
          <p className="text-[15px] text-muted">Take 4 photos on a plain background in daylight: front, back, the label, and any marks.</p>
          <PhotoPicker photos={photos} onChange={setPhotos} />
          <Button onClick={() => setStep(1)} disabled={photos.length < 2}>Next: details</Button>
          {photos.length < 2 && <p className="text-sm text-muted">Add at least 2 photos to continue.</p>}
        </div>
      )}
      {step === 1 && (
        <div className="space-y-6">
          <ListingForm value={v} onChange={setV} />
          <div className="flex gap-3"><Button variant="ghost" onClick={() => setStep(0)}>Back</Button><Button onClick={() => setStep(2)} disabled={!v.title || !v.categoryId || !v.priceRupees || !v.conditionGrade}>Next: check</Button></div>
        </div>
      )}
      {step === 2 && (
        <div className="space-y-5">
          <div className="grid grid-cols-4 gap-2">{photos.map((p) => <img key={p.id} src={p.preview} alt="" className="aspect-[4/5] w-full rounded-sm object-cover" />)}</div>
          <dl className="grid gap-2 rounded-md border hairline bg-surface p-4 text-[15px] sm:grid-cols-2">
            <div><dt className="text-sm text-muted">Title</dt><dd>{v.title}</dd></div>
            <div><dt className="text-sm text-muted">Price</dt><dd className="num">PKR {Number(v.priceRupees).toLocaleString("en-PK")}</dd></div>
            <div><dt className="text-sm text-muted">Size</dt><dd>{v.size || "-"}</dd></div>
            <div><dt className="text-sm text-muted">Measurements</dt><dd>{Object.entries(v.measurements).filter(([, x]) => x).map(([k, x]) => `${k.replace("_cm", "")} ${x} cm`).join(", ") || "-"}</dd></div>
          </dl>
          <p className="text-sm text-muted">Our team checks every listing before it goes live. You'll get a message when it's live or if something needs changing.</p>
          <div className="flex flex-wrap gap-3"><Button variant="ghost" onClick={() => setStep(1)}>Back</Button><Button variant="secondary" onClick={() => save(false)} loading={busy}>Save as draft</Button><Button onClick={() => save(true)} loading={busy}>Send for review</Button></div>
        </div>
      )}
    </div>
  );
}
