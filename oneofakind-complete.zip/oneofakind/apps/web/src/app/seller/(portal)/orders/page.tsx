"use client";
import Link from "next/link";
import { useState } from "react";
import clsx from "clsx";
import { useApi } from "@/lib/useApi";
import { PageHeader } from "@/components/chrome/PortalShell";
import { StatusPill } from "@/components/ui/Badge";
import { EmptyState, Price } from "@/components/ui/misc";
import { dateTime } from "@/lib/format";

interface Row { groupId: string; orderRef: string; state: string; mode: string; paidAt: string; packVerified: boolean; city: string; subtotalMinor: number; pieces: number; thumbs: Array<string | null>; tracking: Array<string | null>; youShip: boolean }

export default function SellerOrders() {
  const [tab, setTab] = useState<"to-send" | "sent" | "all">("to-send");
  const { data } = useApi<{ orders: Row[] }>(`/v1/seller/orders?tab=${tab}`);
  return (
    <div>
      <PageHeader title="Orders" sub="Pack and send within 2 working days of payment." />
      <div className="mb-4 flex gap-2">{([["to-send", "To send"], ["sent", "Sent"], ["all", "All"]] as const).map(([k, l]) => <button key={k} onClick={() => setTab(k)} className={clsx("rounded-pill border px-3 py-1 text-sm", tab === k ? "border-ink bg-ink text-ivory" : "hairline")}>{l}</button>)}</div>
      {data && !data.orders.length && <EmptyState title={tab === "to-send" ? "Nothing to send right now" : "No orders yet"} />}
      <ul className="space-y-3">
        {data?.orders.map((o) => (
          <li key={o.groupId}>
            <Link href={`/seller/orders/${o.groupId}`} className="flex flex-wrap items-center gap-4 rounded-md border hairline bg-surface p-4 hover:border-ink">
              <div className="flex gap-1">{o.thumbs.map((t, i) => (t ? <img key={i} src={t} alt="" className="h-14 w-11 rounded-sm object-cover" /> : null))}</div>
              <div className="flex-1"><div className="font-medium num">{o.orderRef}</div><div className="text-sm text-muted">Paid {dateTime(o.paidAt)} · to {o.city} · {o.pieces} piece(s){o.youShip ? "" : " · our warehouse sends this"}</div></div>
              {o.youShip && o.state === "PAID" && <span className="text-sm text-[#7A5A1F]">Needs packing</span>}
              <StatusPill state={o.state} /><Price minor={o.subtotalMinor} />
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
