import type { ReactNode } from "react";
/** /seller/* : the portal shell lives in (portal); /seller/apply uses public chrome. */
export default function SellerRoot({ children }: { children: ReactNode }) { return children; }
