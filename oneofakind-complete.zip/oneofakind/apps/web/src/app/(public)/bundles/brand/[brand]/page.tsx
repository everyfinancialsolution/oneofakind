import { redirect } from "next/navigation";

/** /bundles/brand/[slug] is a shareable alias for the filtered bundle storefront. */
export default async function BundlesBrand({ params }: { params: Promise<{ brand: string }> }) {
  const { brand } = await params;
  redirect(`/bundles?brand=${encodeURIComponent(brand)}`);
}
