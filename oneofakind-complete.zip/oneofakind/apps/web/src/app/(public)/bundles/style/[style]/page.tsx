import { redirect } from "next/navigation";

/** /bundles/style/[slug] is a shareable alias for the filtered bundle storefront. */
export default async function BundlesStyle({ params }: { params: Promise<{ style: string }> }) {
  const { style } = await params;
  redirect(`/bundles?style=${encodeURIComponent(style)}`);
}
