import { Suspense } from "react";
import type { Metadata } from "next";
import { api } from "@/lib/api";
import type { BundleCard } from "@/lib/types";
import { BundleBrowser } from "@/components/bundles";
import { Button } from "@/components/ui/Button";
import { S } from "@/lib/strings";

export const metadata: Metadata = { title: "Bundles for resellers", description: "Lots of 5, 10 or 15 pieces, same brand, same style, every piece graded A or B." };

export default async function Bundles({ searchParams }: { searchParams: Promise<Record<string, string | undefined>> }) {
  const sp = await searchParams;
  const q = new URLSearchParams();
  for (const k of ["size", "brand", "style", "sort"]) if (sp[k]) q.set(k, sp[k]!);
  // Anonymous fetch: no prices in server HTML or cache. Price-sorts are refused for anonymous, so fall back.
  let query = q.toString();
  if (["price_asc", "price_desc", "savings"].includes(sp.sort ?? "")) { const q2 = new URLSearchParams(q); q2.delete("sort"); query = q2.toString(); }
  const initial = await api<{ bundles: BundleCard[]; canSeePrices: boolean; sorts: string[]; facets: { brands: Array<{ slug: string; name: string }>; styles: Array<{ slug: string; name: string }>; sizes: number[] } }>(`/v1/bundles?${query}`, { revalidate: 60 });
  return (
    <div className="page pt-10">
      <header className="mb-8 grid gap-6 md:grid-cols-[1fr_auto] md:items-end">
        <div>
          <p className="eyebrow">Bundles · for verified resellers</p>
          <h1 className="font-display text-display-lg">Lots of 5, 10 or 15</h1>
          <p className="mt-2 max-w-2xl text-muted">Every lot is one brand and one style, with mixed sizes and colours. Every piece is graded A or B, photographed and measured. Open a lot to see each one.</p>
        </div>
        <Button href="/reseller" variant="secondary">How reseller access works</Button>
      </header>
      <Suspense><BundleBrowser initial={initial} query={q.toString()} /></Suspense>
      <p className="mt-12 text-sm text-muted">{S.prepaidOnly}</p>
    </div>
  );
}
