import Link from "next/link";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { apiOrNull } from "@/lib/api";
import type { BundleDetail } from "@/lib/types";
import { BundleLotSheet } from "@/components/BundleLotSheet";
import { BundleBuyBox } from "@/components/bundles";
import { SellerChip } from "@/components/product";
import { ShareOnWhatsApp } from "@/components/WhatsApp";

export const revalidate = 60;
type P = { params: Promise<{ slug: string }> };
// Anonymous fetch => the API strips every price field. This page (and its OG data) is therefore price-free by construction.
const load = (slug: string) => apiOrNull<{ bundle: BundleDetail }>(`/v1/bundles/${encodeURIComponent(slug)}`, { revalidate: 60 });

export async function generateMetadata({ params }: P): Promise<Metadata> {
  const d = await load((await params).slug);
  if (!d) return { title: "Bundle" };
  const b = d.bundle;
  const desc = `${b.size} pieces · ${b.brand.name} · ${b.style.name} · grade A/B · mixed sizes. Verified resellers only.`;
  return { title: b.title, description: desc, openGraph: { title: b.title, description: desc, images: b.cover ? [{ url: b.cover.url }] : [] } };
}

export default async function BundlePage({ params }: P) {
  const { slug } = await params;
  const d = await load(slug);
  if (!d) notFound();
  const b = d.bundle;
  const tally = (r: Record<string, number>) => Object.entries(r).map(([k, v]) => `${k} × ${v}`).join(" · ");
  return (
    <div className="page pt-6">
      <nav aria-label="Breadcrumb" className="mb-6 text-sm text-muted"><Link href="/bundles" className="hover:underline">Bundles</Link> / <Link href={`/bundles/brand/${b.brand.slug}`} className="hover:underline">{b.brand.name}</Link> / <span className="text-ink">{b.title}</span></nav>
      <div className="grid gap-10 lg:grid-cols-[1fr_380px]">
        <header className="space-y-4">
          <p className="text-sm text-muted">Lot <span className="num">{b.sku}</span> · {b.brand.name} · {b.style.name}</p>
          <h1 className="font-display text-display-lg">{b.title}</h1>
          <p className="max-w-2xl text-[15px]">{b.description}</p>
          <dl className="grid max-w-2xl grid-cols-1 gap-3 text-[15px] sm:grid-cols-3">
            <div className="rounded-md border hairline p-3"><dt className="text-xs text-muted">Sizes</dt><dd>{tally(b.breakdown.sizes)}</dd></div>
            <div className="rounded-md border hairline p-3"><dt className="text-xs text-muted">Grades</dt><dd>{tally(b.breakdown.grades)}</dd></div>
            <div className="rounded-md border hairline p-3"><dt className="text-xs text-muted">Lot weight</dt><dd className="num">{(b.weightGrams / 1000).toFixed(1)} kg</dd></div>
          </dl>
          <div className="flex items-center gap-6 pt-2"><SellerChip seller={b.seller} /><ShareOnWhatsApp title={b.title} path={`/bundles/${b.slug}`} /></div>
        </header>
        <aside className="space-y-4 lg:sticky lg:top-28 lg:self-start">
          <BundleBuyBox slug={b.slug} initial={b} />
          <ul className="space-y-1 text-sm text-muted">
            <li>{b.fulfilment.buyers}</li><li>Ships from {b.fulfilment.shipsFrom}.</li><li>{b.fulfilment.shipping}</li><li>{b.fulfilment.returns}</li><li>A lot is never shipped partly. If a piece is found damaged before dispatch we swap it for an equal or better piece, or refund in full.</li>
          </ul>
        </aside>
      </div>
      <section className="mt-14" aria-labelledby="pieces-h">
        <h2 id="pieces-h" className="mb-6 border-b hairline pb-3 font-display text-2xl">Every piece in this lot <span className="text-muted num">({b.pieces.length})</span></h2>
        <BundleLotSheet pieces={b.pieces} />
      </section>
    </div>
  );
}
