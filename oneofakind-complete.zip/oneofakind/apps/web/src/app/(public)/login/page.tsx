import { Suspense } from "react";
import type { Metadata } from "next";
import { LoginForm } from "@/components/LoginForm";

export const metadata: Metadata = { title: "Log in", robots: { index: false } };

export default function Login() {
  return <div className="page py-16"><Suspense><LoginForm /></Suspense></div>;
}
