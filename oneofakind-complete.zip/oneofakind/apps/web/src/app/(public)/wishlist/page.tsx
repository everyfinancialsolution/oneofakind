"use client";
import Link from "next/link";
import { useApi } from "@/lib/useApi";
import { Button } from "@/components/ui/Button";
import { GradeBadge } from "@/components/ui/Badge";
import { EmptyState, Price } from "@/components/ui/misc";
import type { Grade } from "@/lib/types";

interface W { slug: string | null; title: string; brand: string | null; size: string | null; priceMinor: number; grade: Grade | null; image: string | null; availability: string }

export default function Wishlist() {
  const { data, error } = useApi<{ items: W[] }>("/v1/wishlist");
  if (error?.status === 401) return <div className="page py-16"><Button href="/login?next=/wishlist">Log in to see saved pieces</Button></div>;
  return (
    <div className="page pt-10">
      <h1 className="font-display text-display-lg">Saved</h1>
      {data && !data.items.length && <EmptyState title="Nothing saved yet" body="Tap Save on any piece to keep it here." action={<Button href="/shop">Browse</Button>} />}
      <ul className="mt-8 grid grid-cols-2 gap-6 md:grid-cols-4">
        {data?.items.map((w, i) => (
          <li key={i}>
            <Link href={w.slug ? `/product/${w.slug}` : "#"} className="block">

              {w.image ? <img src={w.image} alt="" className="aspect-[4/5] w-full rounded-sm object-cover" /> : <div className="aspect-[4/5] bg-ivory-deep" />}
              <div className="mt-2 text-xs text-muted">{w.brand} · {w.size}</div>
              <div className="text-[15px]">{w.title}</div>
              <div className="flex items-center justify-between"><Price minor={w.priceMinor} /><GradeBadge grade={w.grade} showLabel={false} /></div>
              {w.availability !== "AVAILABLE" && <div className="text-sm text-[#8A2E25]">{w.availability === "RESERVED" ? "Reserved" : "Sold"}</div>}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
