import type { Metadata } from "next";
import Link from "next/link";
import { api } from "@/lib/api";
import { ProductImage, SellerChip } from "@/components/product";
import type { Img } from "@/lib/types";

export const metadata: Metadata = { title: "Sellers" };
export const revalidate = 300;

interface SellerRow { slug: string; displayName: string; city: string | null; type: string; bio: string | null; ratingAvg: number; ratingCount: number; liveListings: number; preview: Array<Img | null> }

export default async function Sellers() {
  const { sellers } = await api<{ sellers: SellerRow[] }>("/v1/sellers");
  return (
    <div className="page pt-10">
      <h1 className="font-display text-display-lg">Sellers</h1>
      <p className="mt-2 max-w-xl text-muted">Verified thrift sellers and resellers from across Pakistan. Every seller is ID-checked before they can sell.</p>
      <ul className="mt-10 grid gap-10 md:grid-cols-2">
        {sellers.map((s) => (
          <li key={s.slug} className="grid grid-cols-[1fr_auto] gap-4 border-t hairline pt-5">
            <div className="space-y-2">
              <SellerChip seller={{ ...s, ratingAvg: s.ratingAvg, ratingCount: s.ratingCount }} />
              <p className="text-sm text-muted line-clamp-3">{s.bio}</p>
              <Link href={`/sellers/${s.slug}`} className="link text-sm">Visit store · {s.liveListings} pieces</Link>
            </div>
            <div className="grid w-48 grid-cols-3 gap-1">{s.preview.map((img, i) => <ProductImage key={i} img={img} />)}</div>
          </li>
        ))}
      </ul>
    </div>
  );
}
