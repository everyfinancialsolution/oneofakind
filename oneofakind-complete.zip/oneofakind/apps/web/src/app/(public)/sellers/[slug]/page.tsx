import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { apiOrNull } from "@/lib/api";
import type { ItemCard } from "@/lib/types";
import { ProductGrid } from "@/components/product";
import { ShareOnWhatsApp } from "@/components/WhatsApp";
import { dateShort } from "@/lib/format";

export const revalidate = 60;
type P = { params: Promise<{ slug: string }> };
interface Store { seller: { slug: string; displayName: string; type: string; city: string | null; bio: string | null; ratingAvg: number; ratingCount: number; memberSince: string; liveListings: number; soldCount: number; liveBundles: number }; items: ItemCard[]; nextCursor: string | null }
const load = (slug: string) => apiOrNull<Store>(`/v1/sellers/${encodeURIComponent(slug)}?limit=48`);

export async function generateMetadata({ params }: P): Promise<Metadata> {
  const d = await load((await params).slug);
  return d ? { title: `${d.seller.displayName}`, description: d.seller.bio ?? undefined } : { title: "Seller" };
}

export default async function Storefront({ params }: P) {
  const d = await load((await params).slug);
  if (!d) notFound();
  const s = d.seller;
  return (
    <div className="page pt-10">
      <header className="grid gap-6 border-b hairline pb-8 md:grid-cols-[1fr_auto] md:items-end">
        <div className="flex items-start gap-5">
          <div className="flex h-20 w-20 shrink-0 items-center justify-center rounded-full bg-ink font-display text-3xl text-ivory" aria-hidden>{s.displayName.slice(0, 1)}</div>
          <div>
            <h1 className="font-display text-display-lg">{s.displayName}</h1>
            <p className="mt-1 text-sm text-muted">{s.city} · {s.type === "INDIVIDUAL" ? "Individual seller" : s.type === "BUSINESS" ? "Business" : "Reseller"} · Verified · Selling since {dateShort(s.memberSince)}</p>
            {s.bio && <p className="mt-3 max-w-2xl">{s.bio}</p>}
          </div>
        </div>
        <dl className="grid grid-cols-3 gap-6 text-center">
          <div><dt className="text-xs text-muted">Rating</dt><dd className="font-display text-2xl num">★ {s.ratingAvg.toFixed(1)}</dd><dd className="text-xs text-muted">{s.ratingCount} reviews</dd></div>
          <div><dt className="text-xs text-muted">Live</dt><dd className="font-display text-2xl num">{s.liveListings}</dd></div>
          <div><dt className="text-xs text-muted">Sold</dt><dd className="font-display text-2xl num">{s.soldCount}</dd></div>
        </dl>
      </header>
      <div className="flex items-center justify-between py-4 text-sm">
        <span className="text-muted">{s.liveBundles > 0 ? <a className="link" href={`/bundles?seller=${s.slug}`}>{s.liveBundles} bundles for resellers</a> : null}</span>
        <ShareOnWhatsApp title={s.displayName} path={`/sellers/${s.slug}`} />
      </div>
      <ProductGrid items={d.items} priorityCount={2} />
    </div>
  );
}
