import type { ReactNode } from "react";
import { PublicHeader } from "@/components/chrome/PublicHeader";
import { PublicFooter } from "@/components/chrome/PublicFooter";

export default function PublicLayout({ children }: { children: ReactNode }) {
  return (
    <>
      <PublicHeader />
      <main id="main">{children}</main>
      <PublicFooter />
    </>
  );
}
