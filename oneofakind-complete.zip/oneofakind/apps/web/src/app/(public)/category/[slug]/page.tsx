import Link from "next/link";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { api } from "@/lib/api";
import type { Category } from "@/lib/types";
import { BrowsePage } from "@/components/BrowsePage";

type P = { params: Promise<{ slug: string }>; searchParams: Promise<Record<string, string | string[] | undefined>> };

async function load(slug: string) {
  const { categories } = await api<{ categories: Category[] }>("/v1/catalog/categories", { revalidate: 300 });
  return { categories, cat: categories.find((c) => c.slug === slug) };
}

export async function generateMetadata({ params }: P): Promise<Metadata> {
  const { cat } = await load((await params).slug);
  return { title: cat ? `Secondhand ${cat.name.toLowerCase()}` : "Category" };
}

export default async function CategoryPage({ params, searchParams }: P) {
  const { slug } = await params;
  const { categories, cat } = await load(slug);
  if (!cat) notFound();
  const parent = categories.find((c) => c.id === cat.parentId);
  const children = categories.filter((c) => c.parentId === cat.id);
  return (
    <BrowsePage title={cat.name} sp={await searchParams} fixed={{ category: slug }}
      header={
        <nav aria-label="Breadcrumb" className="mb-4 text-sm text-muted">
          <Link href="/shop" className="hover:underline">Shop</Link>{parent && <> / <Link href={`/category/${parent.slug}`} className="hover:underline">{parent.name}</Link></>} / <span className="text-ink">{cat.name}</span>
          {children.length > 0 && <div className="mt-4 flex flex-wrap gap-2">{children.map((c) => <Link key={c.slug} href={`/category/${c.slug}`} className="rounded-pill border hairline px-4 py-1.5 text-ink hover:border-ink">{c.name}</Link>)}</div>}
        </nav>
      } />
  );
}
