import type { Metadata } from "next";
import { CompareTable } from "@/components/CompareTable";

export const metadata: Metadata = { title: "Compare pieces", robots: { index: false } };

export default function Compare() {
  return (
    <div className="page pt-10">
      <h1 className="font-display text-display-lg">Compare</h1>
      <p className="mt-2 max-w-xl text-muted">Side by side: condition, price, measurements and delivery. Add up to four pieces with the Compare box on any product page.</p>
      <CompareTable />
    </div>
  );
}
