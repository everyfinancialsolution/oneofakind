import type { Metadata } from "next";
import { BrowsePage } from "@/components/BrowsePage";

export const metadata: Metadata = { title: "Search", robots: { index: false } };

export default async function Search({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const sp = await searchParams;
  const q = typeof sp.q === "string" ? sp.q : "";
  return <BrowsePage title={q ? `“${q}”` : sp.managed === "true" ? "Inspected by ONEOFAKIND" : "All pieces"} sp={sp} />;
}
