"use client";
import { useRouter } from "next/navigation";
import { use, useEffect, useState } from "react";
import { call } from "@/lib/client";
import { Button } from "@/components/ui/Button";
import { Notice, Price } from "@/components/ui/misc";

/**
 * SANDBOX hosted payment page - stands in for the payment gateway's own page until the real gateway is chosen.
 * Clicking a button makes the sandbox "gateway" send a SIGNED webhook to the API; the order is confirmed only by that webhook.
 */
export default function SandboxPay({ params }: { params: Promise<{ paymentId: string }> }) {
  const { paymentId } = use(params);
  const router = useRouter();
  const [p, setP] = useState<{ orderRef: string; amountMinor: number; method: string; state: string; orderState: string } | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  useEffect(() => { call<typeof p>(`/v1/sandbox/payments/${paymentId}`).then(setP).catch((e) => setErr(e.message)); }, [paymentId]);
  const go = async (outcome: "success" | "fail") => {
    setBusy(true);
    try { const r = await call<{ orderRef: string }>(`/v1/sandbox/payments/${paymentId}/complete`, { body: { outcome } }); router.replace(`/orders/${r.orderRef}?placed=1`); }
    catch (e) { setErr((e as Error).message); setBusy(false); }
  };
  return (
    <div className="page max-w-md py-16">
      <div className="rounded-md border-2 border-dashed border-[#C9A75E] bg-surface p-6">
        <p className="text-xs font-semibold uppercase tracking-wide text-[#7A5A1F]">Sandbox payment · test mode · no real money</p>
        <h1 className="mt-2 font-display text-3xl">Payment gateway</h1>
        {err && <Notice tone="bad" className="mt-4">{err}</Notice>}
        {p && (
          <div className="mt-4 space-y-4">
            <p className="text-[15px]">Order <strong className="num">{p.orderRef}</strong> · {p.method.replace("_", " ").toLowerCase()}</p>
            <Price minor={p.amountMinor} size="xl" className="block" />
            {p.state !== "INITIATED" ? <Notice>This payment is already {p.state.toLowerCase()}.</Notice> : (
              <div className="flex flex-col gap-3">
                <Button size="lg" onClick={() => go("success")} loading={busy}>Simulate successful payment</Button>
                <Button variant="secondary" onClick={() => go("fail")} disabled={busy}>Simulate failed payment</Button>
              </div>
            )}
            <p className="text-xs text-muted">In production this page belongs to the payment provider. Card details never touch ONEOFAKIND servers.</p>
          </div>
        )}
      </div>
    </div>
  );
}
