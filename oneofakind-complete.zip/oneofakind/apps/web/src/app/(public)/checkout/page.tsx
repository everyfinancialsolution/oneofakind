"use client";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useMemo, useState } from "react";
import { call, ClientApiError, newIdempotencyKey } from "@/lib/client";
import type { CartView } from "../cart/page";
import { useSession } from "@/components/session";
import { Button } from "@/components/ui/Button";
import { Checkbox, TextField } from "@/components/ui/Field";
import { Notice, Price } from "@/components/ui/misc";
import { S } from "@/lib/strings";

interface Address { id: string; label: string | null; recipient: string; phone: string; line1: string; line2: string | null; city: string; isDefault: boolean }
interface Quote { subtotalMinor: number; shippingMinor: number; totalMinor: number }

export default function Checkout() {
  const { me, loading, refreshCart } = useSession();
  const router = useRouter();
  const [cart, setCart] = useState<CartView | null>(null);
  const [addresses, setAddresses] = useState<Address[]>([]);
  const [addressId, setAddressId] = useState<string>("");
  const [addr, setAddr] = useState({ recipient: "", phone: "", line1: "", line2: "", city: "", province: "", postalCode: "" });
  const [save, setSave] = useState(true);
  const [method, setMethod] = useState<"CARD" | "WALLET" | "BANK_TRANSFER">("CARD");
  const [terms, setTerms] = useState(false);
  const [quote, setQuote] = useState<Quote | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const key = useMemo(() => newIdempotencyKey(), []);

  useEffect(() => {
    if (loading) return;
    if (!me) { router.replace("/login?next=/checkout"); return; }
    call<CartView>("/v1/cart").then(setCart);
    call<{ addresses: Address[] }>("/v1/account/addresses").then((r) => { setAddresses(r.addresses); const d = r.addresses.find((a) => a.isDefault) ?? r.addresses[0]; if (d) setAddressId(d.id); });
  }, [me, loading, router]);
  const city = addressId ? addresses.find((a) => a.id === addressId)?.city ?? "" : addr.city;
  useEffect(() => {
    if (city.trim().length < 2) { setQuote(null); return; }
    const t = setTimeout(() => call<Quote>("/v1/cart/quote", { body: { city } }).then(setQuote).catch(() => {}), 300);
    return () => clearTimeout(t);
  }, [city, cart]);

  const place = async () => {
    setErr(null); setBusy(true);
    try {
      const body = { paymentMethod: method, acceptTerms: terms, ...(addressId ? { addressId } : { address: { ...addr, line2: addr.line2 || null, province: addr.province || null, postalCode: addr.postalCode || null }, saveAddress: save }) };
      const r = await call<{ orderRef: string; checkoutUrl: string }>("/v1/checkout", { body, idempotencyKey: key });
      await refreshCart();
      window.location.href = r.checkoutUrl;
    } catch (e) {
      const ex = e as ClientApiError;
      setErr(ex.code === "ITEMS_UNAVAILABLE" ? ex.message : ex.fieldError("acceptTerms") ?? ex.message);
    } finally { setBusy(false); }
  };

  if (!cart) return <div className="page py-16 text-muted">Loading…</div>;
  if (!cart.lines.length) return <div className="page py-16"><Notice>Your cart is empty. <Link href="/shop" className="link">Keep shopping</Link></Notice></div>;
  const ready = (addressId || (addr.recipient && addr.phone && addr.line1 && addr.city)) && terms && quote;
  return (
    <div className="page grid gap-10 pt-10 lg:grid-cols-[1fr_380px]">
      <div className="space-y-10">
        <h1 className="font-display text-display-lg">Checkout</h1>
        {err && <Notice tone="bad">{err} {err.includes("no longer available") && <Link href="/cart" className="link">Back to cart</Link>}</Notice>}
        <section className="space-y-4">
          <h2 className="font-display text-2xl">Delivery address</h2>
          {addresses.length > 0 && (
            <div className="space-y-2">
              {addresses.map((a) => (
                <label key={a.id} className="flex cursor-pointer gap-3 rounded-md border hairline bg-surface p-3 text-[15px]">
                  <input type="radio" name="addr" checked={addressId === a.id} onChange={() => setAddressId(a.id)} className="mt-1 accent-[var(--ooak-ink)]" />
                  <span><strong className="font-medium">{a.recipient}</strong> · {a.line1}{a.line2 ? `, ${a.line2}` : ""}, {a.city} · <span className="num">{a.phone}</span></span>
                </label>
              ))}
              <label className="flex cursor-pointer gap-3 p-3 text-[15px]"><input type="radio" name="addr" checked={!addressId} onChange={() => setAddressId("")} className="accent-[var(--ooak-ink)]" />Use a new address</label>
            </div>
          )}
          {!addressId && (
            <div className="grid gap-4 sm:grid-cols-2">
              <TextField label="Full name" value={addr.recipient} onChange={(e) => setAddr({ ...addr, recipient: e.target.value })} autoComplete="name" />
              <TextField label="Mobile number (for the courier)" type="tel" value={addr.phone} onChange={(e) => setAddr({ ...addr, phone: e.target.value })} autoComplete="tel" />
              <TextField label="Address" className="sm:col-span-2" value={addr.line1} onChange={(e) => setAddr({ ...addr, line1: e.target.value })} autoComplete="address-line1" placeholder="House, street, area" />
              <TextField label="Landmark / apartment" optional className="sm:col-span-2" value={addr.line2} onChange={(e) => setAddr({ ...addr, line2: e.target.value })} />
              <TextField label="City" value={addr.city} onChange={(e) => setAddr({ ...addr, city: e.target.value })} autoComplete="address-level2" />
              <TextField label="Postal code" optional value={addr.postalCode} onChange={(e) => setAddr({ ...addr, postalCode: e.target.value })} />
              <Checkbox checked={save} onChange={(e) => setSave(e.target.checked)} label="Save this address" />
            </div>
          )}
        </section>
        <section className="space-y-3">
          <h2 className="font-display text-2xl">Payment</h2>
          <p className="text-sm text-muted">{S.prepaidOnly}</p>
          {([["CARD", "Debit or credit card"], ["WALLET", "Mobile wallet (JazzCash, Easypaisa)"], ["BANK_TRANSFER", "Bank transfer / Raast"]] as const).map(([k, l]) => (
            <label key={k} className="flex cursor-pointer gap-3 rounded-md border hairline bg-surface p-3 text-[15px]"><input type="radio" name="pm" checked={method === k} onChange={() => setMethod(k)} className="accent-[var(--ooak-ink)]" />{l}</label>
          ))}
        </section>
        <section className="rounded-md border-l-4 border-champagne bg-surface p-4 text-[15px]">
          <p className="font-medium">Before you pay</p>
          <p className="mt-1 text-muted">{S.damagedOnly} Please check measurements and condition notes. Returns aren&apos;t possible for size or change of mind.</p>
          <Checkbox className="mt-3" checked={terms} onChange={(e) => setTerms(e.target.checked)} label={<>I understand returns are for damaged or undisclosed flaws only (<Link href="/policies/returns" className="link" target="_blank">policy</Link>).</>} />
        </section>
      </div>
      <aside className="space-y-4 rounded-md border hairline bg-surface p-5 lg:sticky lg:top-28 lg:self-start">
        <h2 className="font-display text-xl">Order summary</h2>
        <ul className="space-y-2 text-sm">{cart.lines.filter((l) => l.available).map((l) => <li key={l.id} className="flex justify-between gap-3"><span className="line-clamp-1">{l.title}</span><Price minor={l.priceMinor} size="sm" /></li>)}</ul>
        <div className="space-y-1 border-t hairline pt-3 text-[15px]">
          <div className="flex justify-between"><span>Items</span><Price minor={cart.subtotalMinor} size="sm" /></div>
          <div className="flex justify-between"><span>Delivery ({cart.groups.length} parcel{cart.groups.length > 1 ? "s" : ""})</span>{quote ? <Price minor={quote.shippingMinor} size="sm" /> : <span className="text-muted">enter city</span>}</div>
          <div className="flex justify-between pt-2 text-lg"><span>Total</span>{quote ? <Price minor={quote.totalMinor} size="lg" /> : "-"}</div>
        </div>
        <Button full size="lg" onClick={place} loading={busy} disabled={!ready}>Pay {quote ? `PKR ${(quote.totalMinor / 100).toLocaleString("en-PK")}` : ""}</Button>
        <p className="text-xs text-muted">We hold your pieces for {cart.hasBundles ? cart.reservationMinutes.BUNDLE : cart.reservationMinutes.RETAIL} minutes while you pay. Your order is confirmed only when the payment provider confirms payment.</p>
      </aside>
    </div>
  );
}
