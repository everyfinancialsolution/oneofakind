import type { Metadata } from "next";
import { ApplyFlow, WhatsAppApplyButton } from "@/components/ApplyFlow";

export const metadata: Metadata = { title: "Apply as a verified reseller", robots: { index: false } };

export default function Apply() {
  return (
    <div className="page grid gap-12 py-12 lg:grid-cols-[1fr_340px]">
      <div className="space-y-6">
        <h1 className="font-display text-display-lg">Apply as a verified reseller</h1>
        <ApplyFlow kind="RESELLER" />
      </div>
      <aside className="space-y-4 rounded-md bg-surface p-6 lg:self-start">
        <h2 className="font-display text-xl">Prefer WhatsApp?</h2>
        <p className="text-[15px] text-muted">Tap below, send photos of your documents, and our team will fill in this form for you. We'll ask you to confirm that you agree, and you'll activate your account with a code on your own phone.</p>
        <WhatsAppApplyButton kind="RESELLER" />
        <p className="text-sm text-muted">Open 24/7. First reply within 1 hour.</p>
      </aside>
    </div>
  );
}
