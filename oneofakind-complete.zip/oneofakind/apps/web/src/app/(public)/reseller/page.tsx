import type { Metadata } from "next";
import { Button } from "@/components/ui/Button";
import { WhatsAppLink } from "@/components/WhatsApp";
import { S } from "@/lib/strings";

export const metadata: Metadata = { title: "Verified resellers", description: "Buy graded lots of 5, 10 or 15 pieces, same brand, same style." };

export default function Reseller() {
  return (
    <div className="page pt-10">
      <section className="grid gap-10 lg:grid-cols-[1.2fr_1fr] lg:items-end">
        <div><p className="eyebrow">For thrift stores and resellers</p><h1 className="font-display text-display-xl">Stock your shop with graded lots.</h1></div>
        <div className="space-y-4">
          <p className="text-lg text-muted">Bundles of exactly 5, 10 or 15 pieces. One brand and one style per lot, mixed sizes and colours, every piece graded A or B.</p>
          <div className="flex flex-wrap gap-3">
            <Button href="/reseller/apply" size="lg">{S.applyReseller}</Button>
            <WhatsAppLink button="secondary" message="Hello ONEOFAKIND, I want to become a verified reseller.">{S.whatsappApply}</WhatsAppLink>
          </div>
        </div>
      </section>
      <section className="mt-16 grid gap-6 md:grid-cols-3">
        {[
          ["See every piece", "Open any lot and you'll see each piece: photo, grade, size and measurements. Nothing hidden behind a carousel, no mystery bags."],
          ["Prices for verified resellers", "Lot prices, price per piece and the saving against retail are shown once you are verified. Until then you can browse everything else."],
          ["Damage protection per piece", "If a piece arrives damaged, claim within 48 hours. You're refunded that piece's share of the lot price; the rest of the lot is unaffected."],
        ].map(([t, b]) => <article key={t} className="rounded-md border hairline bg-surface p-6"><h2 className="font-display text-2xl">{t}</h2><p className="mt-2 text-[15px] text-muted">{b}</p></article>)}
      </section>
      <section className="mt-16 max-w-2xl">
        <h2 className="font-display text-3xl">What you need to apply</h2>
        <ul className="mt-4 space-y-2 text-[15px]">
          <li>Your national ID card, front and back</li>
          <li>Proof of your shop: a photo of your shop or signboard, or a link to your online store or social page with recent activity</li>
          <li>Optional: business registration or NTN</li>
        </ul>
        <p className="mt-4 text-sm text-muted">We review within 2 working days. ID images are deleted 90 days after we decide; we keep only the last 4 digits and the result.</p>
        <div className="mt-6"><Button href="/bundles" variant="secondary">Browse bundles</Button></div>
      </section>
    </div>
  );
}
