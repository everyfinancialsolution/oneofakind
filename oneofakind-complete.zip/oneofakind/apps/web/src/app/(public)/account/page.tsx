"use client";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { call } from "@/lib/client";
import { useApi } from "@/lib/useApi";
import { useSession } from "@/components/session";
import { Button } from "@/components/ui/Button";
import { StatusPill } from "@/components/ui/Badge";
import { TextField } from "@/components/ui/Field";
import { Notice, Price } from "@/components/ui/misc";
import { useToast } from "@/components/ui/Toast";
import { dateShort, dateTime } from "@/lib/format";

interface Address { id: string; recipient: string; line1: string; city: string; phone: string; isDefault: boolean }
interface Offer { id: string; state: string; amountMinor: number; listPriceMinor: number; title: string; slug: string | null; expiresAt: string }

export default function Account() {
  const { me, loading, refresh } = useSession();
  const router = useRouter();
  const toast = useToast();
  const { data: addr, reload: reloadAddr } = useApi<{ addresses: Address[] }>(me ? "/v1/account/addresses" : null);
  const { data: offers } = useApi<{ offers: Offer[] }>(me ? "/v1/offers/mine" : null);
  const [name, setName] = useState<string | null>(null);
  const [email, setEmail] = useState<string | null>(null);
  const [delCode, setDelCode] = useState("");
  const [devCode, setDevCode] = useState<string | null>(null);
  if (loading) return <div className="page py-16 text-muted">Loading…</div>;
  if (!me) return <div className="page py-16"><Button href="/login?next=/account">Log in</Button></div>;
  const saveProfile = async () => { await call("/v1/auth/me", { method: "PATCH", body: { name: name ?? me.name, email: (email ?? me.email) || null } }); await refresh(); toast("Saved", "good"); };
  const logout = async () => { await call("/v1/auth/logout", { method: "POST" }); await refresh(); router.push("/"); };
  const requestDelete = async () => {
    if (!devCode && !delCode) { const r = await call<{ devCode?: string }>("/v1/auth/confirm/request", { method: "POST" }); setDevCode(r.devCode ?? "sent"); return; }
    await call("/v1/auth/me/delete-request", { body: { code: delCode } }); await refresh(); toast("Deletion requested. Our team will confirm by SMS.", "info");
  };
  return (
    <div className="page max-w-3xl space-y-12 pt-10">
      <header className="flex items-end justify-between"><h1 className="font-display text-display-lg">Your account</h1><Button variant="ghost" onClick={logout}>Log out</Button></header>
      <nav className="flex flex-wrap gap-3 text-sm">
        <Link href="/orders" className="link">Orders</Link><Link href="/wishlist" className="link">Saved</Link>
        {me.seller && <Link href="/seller" className="link">Seller hub</Link>}
        {me.roles.includes("VERIFIED_RESELLER") ? <Link href="/bundles" className="link">Bundles (verified reseller)</Link> : <Link href="/reseller" className="link">Become a verified reseller</Link>}
        {!me.seller && <Link href="/sell" className="link">Start selling</Link>}
      </nav>
      <section className="grid gap-4 sm:grid-cols-2">
        <h2 className="font-display text-2xl sm:col-span-2">Profile</h2>
        <TextField label="Name" value={name ?? me.name} onChange={(e) => setName(e.target.value)} />
        <TextField label="Phone (your login)" value={me.phone ?? ""} disabled help="To change your phone number, contact support. We verify it's you first." />
        <TextField label="Email" optional type="email" value={email ?? me.email ?? ""} onChange={(e) => setEmail(e.target.value)} />
        <div className="sm:col-span-2"><Button onClick={saveProfile}>Save</Button></div>
      </section>
      {me.applications.length > 0 && (
        <section><h2 className="mb-3 font-display text-2xl">Applications</h2>
          <ul className="space-y-2">{me.applications.map((a) => <li key={a.reference} className="flex items-center justify-between rounded-md border hairline bg-surface px-4 py-3 text-[15px]"><span><span className="num">{a.reference}</span> · {a.kind === "SELLER" ? "Seller" : "Verified reseller"}</span><StatusPill state={a.status} /></li>)}</ul>
        </section>
      )}
      <section><h2 className="mb-3 font-display text-2xl">Addresses</h2>
        <ul className="space-y-2">{addr?.addresses.map((a) => <li key={a.id} className="flex items-center justify-between rounded-md border hairline bg-surface px-4 py-3 text-[15px]"><span>{a.recipient} · {a.line1}, {a.city}{a.isDefault ? " · default" : ""}</span><button className="link text-sm" onClick={async () => { await call(`/v1/account/addresses/${a.id}`, { method: "DELETE" }); await reloadAddr(); }}>Remove</button></li>)}</ul>
        {!addr?.addresses.length && <p className="text-muted">Addresses you save at checkout appear here.</p>}
      </section>
      {offers && offers.offers.length > 0 && (
        <section><h2 className="mb-3 font-display text-2xl">Your offers</h2>
          <ul className="space-y-2">{offers.offers.map((o) => <li key={o.id} className="flex flex-wrap items-center justify-between gap-2 rounded-md border hairline bg-surface px-4 py-3 text-[15px]"><span>{o.slug ? <Link className="link" href={`/product/${o.slug}`}>{o.title}</Link> : o.title} · <Price minor={o.amountMinor} size="sm" /> (list <Price minor={o.listPriceMinor} size="sm" />)</span><span className="flex items-center gap-2"><StatusPill state={o.state} />{o.state === "ACCEPTED" && <span className="text-sm">check out by {dateTime(o.expiresAt)}</span>}</span></li>)}</ul>
        </section>
      )}
      <section><h2 className="mb-3 font-display text-2xl">Privacy</h2>
        <ul className="space-y-1 text-sm text-muted">{me.consents.map((c, i) => <li key={i}>{c.type.toLowerCase()} v{c.version}, {c.granted ? "agreed" : "withdrawn"} {dateShort(c.createdAt)}</li>)}</ul>
        <div className="mt-4 rounded-md border hairline p-4">
          <h3 className="font-medium">Delete my account</h3>
          {me.deletionRequestedAt ? <Notice className="mt-2">Deletion requested on {dateShort(me.deletionRequestedAt)}. We keep order and payment records as the law requires.</Notice> : (
            <div className="mt-2 flex flex-wrap items-end gap-3">
              <p className="w-full text-sm text-muted">We&apos;ll send a code to your phone to confirm. Order and payment records are kept as required by law.</p>
              {devCode && <TextField label="Confirmation code" inputMode="numeric" maxLength={6} value={delCode} onChange={(e) => setDelCode(e.target.value.replace(/\D/g, ""))} help={devCode !== "sent" ? `Development code: ${devCode}` : undefined} />}
              <Button variant="danger" onClick={requestDelete}>{devCode ? "Confirm deletion request" : "Request deletion"}</Button>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
