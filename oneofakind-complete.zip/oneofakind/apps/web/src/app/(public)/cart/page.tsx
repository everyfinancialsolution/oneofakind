"use client";
import Link from "next/link";
import { useEffect, useState } from "react";
import { call } from "@/lib/client";
import { useSession } from "@/components/session";
import { Button } from "@/components/ui/Button";
import { GradeBadge } from "@/components/ui/Badge";
import { EmptyState, Notice, Price } from "@/components/ui/misc";
import { useToast } from "@/components/ui/Toast";
import { S } from "@/lib/strings";
import type { Grade } from "@/lib/types";

export interface CartLine { id: string; kind: "ITEM" | "BUNDLE"; slug: string | null; title: string; brand: string | null; size: string | null; grade: Grade | null; image: string | null; priceMinor: number; listPriceMinor: number; offerApplied: boolean; available: boolean; availability: string; groupKey: string; sellerName: string; shipsFrom: string }
export interface CartView { lines: CartLine[]; groups: Array<{ key: string; sellerName: string; shipsFrom: string; lineIds: string[] }>; subtotalMinor: number; hasBundles: boolean; reservationMinutes: { RETAIL: number; BUNDLE: number } }

export default function Cart() {
  const [cart, setCart] = useState<CartView | null>(null);
  const { me, setCartCount } = useSession();
  const toast = useToast();
  useEffect(() => { call<CartView>("/v1/cart").then((c) => { setCart(c); setCartCount(c.lines.length); }).catch(() => setCart(null)); }, [setCartCount]);
  const remove = async (id: string) => { const c = await call<CartView>(`/v1/cart/items/${id}`, { method: "DELETE" }); setCart(c); setCartCount(c.lines.length); toast("Removed", "info"); };
  if (!cart) return <div className="page py-16 text-muted">Loading your cart…</div>;
  const unavailable = cart.lines.filter((l) => !l.available);
  return (
    <div className="page pt-10">
      <h1 className="font-display text-display-lg">Cart</h1>
      {!cart.lines.length ? <EmptyState title="Your cart is empty" body="Every piece is one of one. When you find it, grab it." action={<Button href="/shop">Shop new arrivals</Button>} /> : (
        <div className="mt-8 grid gap-10 lg:grid-cols-[1fr_360px]">
          <div className="space-y-8">
            {unavailable.length > 0 && <Notice tone="warn">{unavailable.length} piece(s) are no longer available. Remove them to check out.</Notice>}
            {cart.groups.map((g) => (
              <section key={g.key} className="rounded-md border hairline bg-surface">
                <header className="flex flex-wrap justify-between gap-2 border-b hairline px-4 py-3 text-sm"><span className="font-medium">{g.sellerName}</span><span className="text-muted">Ships from {g.shipsFrom}</span></header>
                <ul className="divide-y">
                  {cart.lines.filter((l) => l.groupKey === g.key).map((l) => (
                    <li key={l.id} className="flex gap-4 p-4">

                      {l.image ? <img src={l.image} alt="" className="h-28 w-[88px] rounded-sm object-cover" /> : <div className="h-28 w-[88px] rounded-sm bg-ivory-deep" />}
                      <div className="flex flex-1 flex-col">
                        <Link href={l.kind === "BUNDLE" ? `/bundles/${l.slug}` : `/product/${l.slug}`} className="font-medium hover:underline">{l.title}</Link>
                        <span className="text-sm text-muted">{l.brand} · {l.size}</span>
                        {l.grade && <span className="mt-1"><GradeBadge grade={l.grade} /></span>}
                        {!l.available && <span className="mt-1 text-sm text-[#8A2E25]">{l.availability === "RESERVED" ? "Someone else is checking out with this right now" : "No longer available"}</span>}
                        {l.offerApplied && <span className="mt-1 text-sm text-[#2F5D50]">Your accepted offer price</span>}
                        <button onClick={() => remove(l.id)} className="link mt-auto self-start text-sm">Remove</button>
                      </div>
                      <div className="text-right">{l.offerApplied && <Price minor={l.listPriceMinor} size="sm" strike className="block" />}<Price minor={l.priceMinor} /></div>
                    </li>
                  ))}
                </ul>
              </section>
            ))}
          </div>
          <aside className="space-y-4 rounded-md border hairline bg-surface p-5 lg:sticky lg:top-28 lg:self-start">
            <div className="flex justify-between text-[15px]"><span>Items</span><Price minor={cart.subtotalMinor} size="md" /></div>
            <p className="text-sm text-muted">Delivery is calculated at checkout from your city (flat rate per parcel{cart.hasBundles ? "; lots by weight" : ""}).</p>
            {me ? <Button href="/checkout" full size="lg" disabled={!!unavailable.length}>Checkout</Button> : <Button href="/login?next=/checkout" full size="lg">Log in to check out</Button>}
            <p className="text-xs text-muted">Adding to cart doesn&apos;t hold a piece. When you check out we hold everything for {cart.hasBundles ? cart.reservationMinutes.BUNDLE : cart.reservationMinutes.RETAIL} minutes while you pay.</p>
            <p className="text-xs text-muted">{S.prepaidOnly}</p>
          </aside>
        </div>
      )}
    </div>
  );
}
