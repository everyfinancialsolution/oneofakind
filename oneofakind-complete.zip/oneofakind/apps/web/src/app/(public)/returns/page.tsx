import type { Metadata } from "next";
import Link from "next/link";
import { ArticleView } from "@/components/ArticleView";
import { HELP } from "@/lib/content";

export const metadata: Metadata = { title: "Damage claims" };

/** Claims are opened per piece from the order page (within 48 h of delivery). */
export default function Returns() {
  return (
    <div className="page pt-10">
      <ArticleView a={HELP.find((h) => h.slug === "damage-claims")!} />
      <p className="mx-auto mt-8 max-w-2xl"><Link href="/orders" className="link">Go to your orders to report damage</Link></p>
    </div>
  );
}
