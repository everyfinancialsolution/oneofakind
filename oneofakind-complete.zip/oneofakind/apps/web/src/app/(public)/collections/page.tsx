import Link from "next/link";
import type { Metadata } from "next";
import { api } from "@/lib/api";
import type { Img } from "@/lib/types";
import { ProductImage } from "@/components/product";

export const metadata: Metadata = { title: "Curated edits" };
export const revalidate = 300;

export default async function Collections() {
  const { collections } = await api<{ collections: Array<{ slug: string; title: string; description: string | null; count: number; covers: Array<Img | null> }> }>("/v1/collections");
  return (
    <div className="page pt-10">
      <h1 className="font-display text-display-lg">Curated edits</h1>
      <p className="mt-2 max-w-xl text-muted">Small edits put together by our team. Every piece is one of one, so edits change as things sell.</p>
      <div className="mt-10 grid gap-12 md:grid-cols-2">
        {collections.map((c) => (
          <Link key={c.slug} href={`/collections/${c.slug}`} className="group block">
            <div className="grid grid-cols-4 gap-1">{c.covers.map((img, i) => <ProductImage key={i} img={img} />)}</div>
            <h2 className="mt-4 font-display text-3xl group-hover:underline">{c.title}</h2>
            <p className="text-muted">{c.description} · <span className="num">{c.count}</span> pieces</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
