import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { apiOrNull } from "@/lib/api";
import type { ItemCard } from "@/lib/types";
import { ProductGrid } from "@/components/product";
import { ShareOnWhatsApp } from "@/components/WhatsApp";
import { EmptyState } from "@/components/ui/misc";

export const revalidate = 60;
type P = { params: Promise<{ slug: string }> };
const load = (slug: string) => apiOrNull<{ collection: { slug: string; title: string; description: string | null }; items: ItemCard[] }>(`/v1/collections/${encodeURIComponent(slug)}`);

export async function generateMetadata({ params }: P): Promise<Metadata> {
  const d = await load((await params).slug);
  return d ? { title: d.collection.title, description: d.collection.description ?? undefined } : { title: "Edit" };
}

export default async function CollectionPage({ params }: P) {
  const d = await load((await params).slug);
  if (!d) notFound();
  return (
    <div className="page pt-10">
      <header className="mb-10 flex flex-wrap items-end justify-between gap-4 border-b hairline pb-6">
        <div><p className="eyebrow">Curated edit</p><h1 className="font-display text-display-lg">{d.collection.title}</h1><p className="mt-2 max-w-xl text-muted">{d.collection.description}</p></div>
        <ShareOnWhatsApp title={d.collection.title} path={`/collections/${d.collection.slug}`} />
      </header>
      {d.items.length ? <ProductGrid items={d.items} priorityCount={2} /> : <EmptyState title="Everything in this edit has sold" body="Pieces are one of one. Have a look at new arrivals instead." />}
    </div>
  );
}
