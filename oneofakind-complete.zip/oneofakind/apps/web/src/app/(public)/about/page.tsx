import type { Metadata } from "next";
import { Button } from "@/components/ui/Button";

export const metadata: Metadata = { title: "About" };

export default function About() {
  return (
    <div className="page pt-10">
      <div className="grid gap-12 lg:grid-cols-[1fr_1fr]">
        <div>
          <p className="eyebrow">About ONEOFAKIND</p>
          <h1 className="font-display text-display-xl">Every piece has a history.</h1>
        </div>
        <div className="space-y-5 text-[17px] leading-relaxed">
          <p>Pakistan already runs on secondhand. Landa bazaars, Sunday markets and thousands of Instagram thrift stores move millions of garments every year. What's missing is trust: is it really in good condition, and will it fit?</p>
          <p>ONEOFAKIND is a marketplace built around that trust. Every piece is graded with objective rules, photographed with every mark visible, and measured flat in centimetres. Sellers are ID-verified and paid only to accounts in their own name.</p>
          <p>Sellers can list pieces themselves, hand them to our Lahore warehouse for managed resale, or sell to us outright. Resellers can buy graded lots of 5, 10 or 15 pieces of one brand and style.</p>
          <h2 className="pt-4 font-display text-2xl">Why it matters</h2>
          <p>Buying one garment secondhand instead of new saves the water, dye and energy that a new one would take, and keeps a good piece out of landfill. The most sustainable piece is the one that already exists.</p>
          <div className="flex gap-3 pt-4"><Button href="/shop">Start shopping</Button><Button href="/sell" variant="secondary">Sell with us</Button></div>
        </div>
      </div>
    </div>
  );
}
