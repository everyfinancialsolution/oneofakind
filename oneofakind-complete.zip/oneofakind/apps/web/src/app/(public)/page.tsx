import Link from "next/link";
import { api } from "@/lib/api";
import type { HomeData } from "@/lib/types";
import { BundleCard, ProductGrid, ProductImage, SellerChip } from "@/components/product";
import { GradeBadge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { Price, SectionHeading } from "@/components/ui/misc";
import { S } from "@/lib/strings";

export const revalidate = 60;

export default async function Home() {
  const d = await api<HomeData>("/v1/content/home", { revalidate: 60 });
  const hero = d.blocks.find((b) => b.key === "home.hero");
  const drops = d.blocks.filter((b) => b.key.startsWith("home.drop"));
  const plate = d.inspected[0] ?? d.newArrivals[0];

  return (
    <>
      {/* Hero: the one orchestrated motion moment on the site */}
      <section className="page grid items-end gap-10 pb-16 pt-10 lg:grid-cols-12 lg:pt-16">
        <div className="space-y-6 lg:col-span-5 lg:pb-10">
          <p className="eyebrow animate-reveal">Pakistan&apos;s secondhand fashion marketplace</p>
          <h1 className="font-display text-display-xl animate-reveal [animation-delay:120ms]">{hero?.title ?? "One of one."}</h1>
          <p className="max-w-md text-lg text-muted animate-reveal [animation-delay:240ms]">{hero?.body ?? S.tagline}</p>
          <div className="flex flex-wrap gap-3 animate-reveal [animation-delay:360ms]">
            <Button href={hero?.linkHref ?? "/shop"} size="lg">{hero?.linkLabel ?? "Shop new arrivals"}</Button>
            <Button href="/sell" variant="secondary" size="lg">Sell your pieces</Button>
          </div>
        </div>
        {plate && (
          <Link href={`/product/${plate.slug}`} className="group grid gap-5 sm:grid-cols-[1fr_220px] lg:col-span-7" aria-label={`Featured: ${plate.title}`}>
            <ProductImage img={plate.image} priority className="animate-plate" sizes="(min-width: 1024px) 45vw, 100vw" />
            <figcaption className="space-y-3 self-end border-t hairline pt-4 text-sm sm:border-l sm:border-t-0 sm:pl-5 sm:pt-0">
              <span className="block text-xs text-muted">{S.oneOfOne} · {plate.sku}</span>
              <span className="block font-display text-xl leading-tight group-hover:underline">{plate.title}</span>
              <span className="block text-muted">{plate.brand?.name} · Size {plate.size}</span>
              <GradeBadge grade={plate.grade} />
              <Price minor={plate.priceMinor} size="lg" className="block" />
              <span className="block text-xs text-muted">{plate.managed ? "Inspected and measured by our team" : `Ships from ${plate.seller.city}`}</span>
            </figcaption>
          </Link>
        )}
      </section>

      <section className="border-y hairline bg-surface">
        <ul className="page grid grid-cols-2 gap-6 py-8 md:grid-cols-4">
          {S.trust.map((t) => (
            <li key={t.title}><h2 className="font-body text-[15px] font-semibold">{t.title}</h2><p className="mt-1 text-sm text-muted">{t.body}</p></li>
          ))}
        </ul>
      </section>

      <section className="page mt-16">
        <SectionHeading title="New arrivals" href="/shop" linkLabel="Shop everything" sub="Fresh from sellers across Pakistan" />
        <ProductGrid items={d.newArrivals.slice(0, 8)} priorityCount={2} />
      </section>

      {d.collections.length > 0 && (
        <section className="page mt-20">
          <SectionHeading title="Curated edits" href="/collections" linkLabel="All edits" />
          <div className="grid gap-8 md:grid-cols-3">
            {d.collections.map((c, idx) => (
              <Link key={c.slug} href={`/collections/${c.slug}`} className="group block">
                <div className="grid grid-cols-3 gap-1">{c.covers.slice(0, 3).map((img, i) => <ProductImage key={i} img={img} />)}</div>
                <h3 className="mt-3 font-display text-2xl group-hover:underline">{c.title}</h3>
                <p className="text-sm text-muted">{drops[idx]?.body ?? c.description}</p>
              </Link>
            ))}
          </div>
        </section>
      )}

      {d.inspected.length > 0 && (
        <section className="page mt-20">
          <SectionHeading title="Inspected by ONEOFAKIND" sub="Managed pieces: graded, measured and photographed in our Lahore warehouse" href="/search?managed=true" />
          <ProductGrid items={d.inspected.slice(0, 4)} />
        </section>
      )}

      {d.bundles.length > 0 && (
        <section className="mt-20 bg-ivory-deep py-16">
          <div className="page">
            <div className="mb-8 grid gap-6 md:grid-cols-[1fr_auto] md:items-end">
              <div>
                <p className="eyebrow">For resellers</p>
                <h2 className="font-display text-display-lg">Bundles of 5, 10 or 15</h2>
                <p className="mt-2 max-w-xl text-muted">Same brand, same style, every piece graded A or B and photographed. Prices are visible to verified resellers.</p>
              </div>
              <div className="flex gap-3"><Button href="/bundles" variant="secondary">Browse bundles</Button><Button href="/reseller">{S.applyReseller}</Button></div>
            </div>
            <div className="grid gap-8 md:grid-cols-3">{d.bundles.map((b) => <BundleCard key={b.slug} bundle={b} />)}</div>
          </div>
        </section>
      )}

      <section className="page mt-20">
        <SectionHeading title="Featured sellers" href="/sellers" linkLabel="All sellers" />
        <ul className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {d.sellers.map((s) => (
            <li key={s.slug} className="space-y-3 border-t hairline pt-4">
              <SellerChip seller={{ ...s, ratingAvg: s.ratingAvg, ratingCount: s.ratingCount }} />
              <p className="line-clamp-3 text-sm text-muted">{s.bio}</p>
              <Link href={`/sellers/${s.slug}`} className="link text-sm">{s.liveListings} pieces live</Link>
            </li>
          ))}
        </ul>
      </section>

      <section className="page mt-20">
        <SectionHeading title="Shop by category" />
        <ul className="grid grid-cols-2 gap-x-6 gap-y-3 sm:grid-cols-4">
          {d.categories.flatMap((c) => (c.children.length ? c.children : [c])).map((c) => (
            <li key={c.slug}><Link href={`/category/${c.slug}`} className="font-display text-xl hover:underline">{c.name}</Link></li>
          ))}
        </ul>
      </section>

      <section className="page mt-20">
        <div className="grid gap-8 rounded-md bg-ink p-8 text-ivory md:grid-cols-2 md:p-12">
          <div>
            <h2 className="font-display text-display-lg">Have pieces to sell?</h2>
            <p className="mt-3 max-w-md text-stone">List them yourself, hand them to us for managed resale, or sell to us outright. Not comfortable with websites? Send your documents on WhatsApp and our team registers you.</p>
          </div>
          <div className="flex flex-wrap items-end gap-3 md:justify-end">
            <Button href="/sell" variant="inverse">How selling works</Button>
            <Button href="/seller/apply" variant="inverseOutline">{S.applySeller}</Button>
          </div>
        </div>
      </section>
    </>
  );
}
