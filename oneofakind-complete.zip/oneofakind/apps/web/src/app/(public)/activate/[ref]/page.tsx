import { Suspense } from "react";
import type { Metadata } from "next";
import { LoginForm } from "@/components/LoginForm";

export const metadata: Metadata = { title: "Activate your account", robots: { index: false } };

/** Link sent to people our team registered (WhatsApp/phone/in person). Activation = their own OTP + accepting the terms. */
export default async function Activate({ params }: { params: Promise<{ ref: string }> }) {
  const { ref } = await params;
  return (
    <div className="page py-16">
      <p className="mx-auto mb-6 max-w-md text-sm text-muted">Application reference <strong className="num text-ink">{decodeURIComponent(ref)}</strong></p>
      <Suspense><LoginForm heading="Activate your account" activation /></Suspense>
    </div>
  );
}
