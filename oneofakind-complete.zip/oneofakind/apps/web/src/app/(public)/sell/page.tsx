import type { Metadata } from "next";
import { COMMISSION_BPS, MANAGED_RETAIL_TIERS, PAYOUT_HOLD_DAYS, MANAGED_STORAGE_DAYS } from "@ooak/shared";
import { Button } from "@/components/ui/Button";
import { WhatsAppLink } from "@/components/WhatsApp";
import { S } from "@/lib/strings";

export const metadata: Metadata = { title: "Sell with ONEOFAKIND", description: "List it yourself, hand it to us, or sell to us outright." };
const pct = (bps: number) => `${bps / 100}%`;

const WAYS = [
  { id: "self", title: "List it yourself", who: "You keep the pieces and ship them when they sell.", fee: `${pct(COMMISSION_BPS.RETAIL_SELF_MANAGED)} when it sells`, points: ["Take 4 photos, fill in 6 fields", "Print a label, pack, hand to the courier", "No listing fees"] },
  { id: "managed", title: "Managed resale", who: "Hand your pieces to us. We do everything else.", fee: `${pct(MANAGED_RETAIL_TIERS[0].bps)} / ${pct(MANAGED_RETAIL_TIERS[1].bps)} / ${pct(MANAGED_RETAIL_TIERS[2].bps)} by price`, points: ["We inspect, grade, measure and photograph", `Stored free for ${MANAGED_STORAGE_DAYS} days in our Lahore warehouse`, "Track every piece from intake to sale"] },
  { id: "direct", title: "Sell to us outright", who: "Want money now? Send photos and our buyers may make an offer.", fee: "Offer valid 72 hours", points: ["Offers for single pieces or whole collections", "Ownership passes only after we receive, check and pay", "No waiting for a buyer"] },
];

export default function Sell() {
  return (
    <div className="page pt-10">
      <section className="grid gap-10 lg:grid-cols-[1.2fr_1fr] lg:items-end">
        <div>
          <p className="eyebrow">For sellers</p>
          <h1 className="font-display text-display-xl">Sell the pieces you no longer wear, or a whole shop's worth.</h1>
        </div>
        <div className="space-y-4">
          <p className="text-lg text-muted">Three ways to sell. Choose per piece; mix them however you like.</p>
          <div className="flex flex-wrap gap-3">
            <Button href="/seller/apply" size="lg">{S.applySeller}</Button>
            <WhatsAppLink button="secondary" message="Hello ONEOFAKIND, I want to register as a seller.">{S.whatsappApply}</WhatsAppLink>
          </div>
          <p className="text-sm text-muted">Not comfortable with websites? Send your documents on WhatsApp and our team will register you. You confirm with a code on your own phone. We never know your login.</p>
        </div>
      </section>
      <section className="mt-16 grid gap-6 md:grid-cols-3">
        {WAYS.map((w) => (
          <article key={w.id} id={w.id} className="flex flex-col rounded-md border hairline bg-surface p-6">
            <h2 className="font-display text-2xl">{w.title}</h2>
            <p className="mt-2 text-muted">{w.who}</p>
            <ul className="mt-4 flex-1 space-y-2 text-[15px]">{w.points.map((p) => <li key={p}>{p}</li>)}</ul>
            <p className="mt-6 border-t hairline pt-4 text-sm"><strong className="font-medium">Fee:</strong> {w.fee}</p>
          </article>
        ))}
      </section>
      <section className="mt-16 grid gap-10 md:grid-cols-2">
        <div>
          <h2 className="font-display text-3xl">How to register</h2>
          <ol className="mt-4 space-y-4 text-[15px]">
            <li><strong className="font-medium">1. Apply online</strong>: about 3 minutes: your name, phone, city, and photos of your ID (front and back) and a bank or wallet account in your own name.</li>
            <li><strong className="font-medium">2. Or apply on WhatsApp</strong>: tap the button, send your documents, and our team fills in the form for you.</li>
            <li><strong className="font-medium">3. We check</strong>: usually within 2 working days. We'll tell you in plain words if anything is missing.</li>
            <li><strong className="font-medium">4. Start selling</strong>: list pieces, or book a managed-resale drop-off.</li>
          </ol>
        </div>
        <div>
          <h2 className="font-display text-3xl">Getting paid</h2>
          <p className="mt-4 text-[15px]">Earnings become payable {PAYOUT_HOLD_DAYS} days after the buyer receives the order (the damage-claim window) and are paid weekly. Payouts go only to a bank or wallet account in your own name. It protects you from anyone else claiming your money.</p>
          <p className="mt-4 text-[15px]">You see every sale, fee and payout in your seller hub statement.</p>
        </div>
      </section>
    </div>
  );
}
