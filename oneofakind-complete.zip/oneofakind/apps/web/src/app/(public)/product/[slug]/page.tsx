import Link from "next/link";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { apiOrNull } from "@/lib/api";
import type { ItemCard, ItemDetail } from "@/lib/types";
import { Gallery } from "@/components/Gallery";
import { ProductGrid, SellerChip } from "@/components/product";
import { AddToCart, CompareToggle, TrackRecentlyViewed, WishlistButton } from "@/components/ProductActions";
import { ShareOnWhatsApp } from "@/components/WhatsApp";
import { GradeBadge } from "@/components/ui/Badge";
import { Price, SectionHeading } from "@/components/ui/misc";
import { measureLabel, measureValue } from "@/lib/format";
import { S } from "@/lib/strings";
import { Model3D } from "@/components/Model3D";

export const revalidate = 60;
type P = { params: Promise<{ slug: string }> };
const load = (slug: string) => apiOrNull<{ item: ItemDetail; similar: ItemCard[] }>(`/v1/listings/${encodeURIComponent(slug)}`, { revalidate: 60 });

export async function generateMetadata({ params }: P): Promise<Metadata> {
  const d = await load((await params).slug);
  if (!d) return { title: "Not found" };
  const it = d.item;
  const desc = `${it.brand?.name ?? ""} ${it.title}, size ${it.size ?? "-"}, grade ${it.grade?.letter ?? "-"}. Measured in cm. One of one.`;
  return { title: it.title, description: desc, openGraph: { title: it.title, description: desc, images: it.images[0] ? [{ url: it.images[0].url, width: 800, height: 1000 }] : [] } };
}

export default async function ProductPage({ params }: P) {
  const { slug } = await params;
  const d = await load(slug);
  if (!d) notFound();
  const it = d.item;
  const jsonLd = {
    "@context": "https://schema.org", "@type": "Product", name: it.title, sku: it.sku, brand: it.brand ? { "@type": "Brand", name: it.brand.name } : undefined,
    image: it.images.map((i) => i.url), itemCondition: "https://schema.org/UsedCondition", description: it.description ?? undefined,
    offers: { "@type": "Offer", priceCurrency: it.currency, price: (it.priceMinor / 100).toFixed(0), availability: it.availability === "AVAILABLE" ? "https://schema.org/InStock" : "https://schema.org/SoldOut" },
  };
  const card: ItemCard = { ...it };
  return (
    <div className="page pt-6">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd).replace(/</g, "\\u003c") }} />
      <TrackRecentlyViewed item={card} />
      <nav aria-label="Breadcrumb" className="mb-6 text-sm text-muted">
        <Link href="/shop" className="hover:underline">Shop</Link> / <Link href={`/category/${it.category.slug}`} className="hover:underline">{it.category.name}</Link> / <span className="text-ink">{it.title}</span>
      </nav>
      <div className="grid gap-10 lg:grid-cols-[minmax(0,1.25fr)_minmax(0,1fr)] lg:gap-16">
        <div className="lg:sticky lg:top-28 lg:self-start">
          <Gallery images={it.images} title={it.title} />
          {it.model3d && <div className="mt-6"><Model3D url={it.model3d.url} title={it.title} /></div>}
        </div>
        <div className="space-y-8">
          <header className="space-y-3">
            <p className="text-sm text-muted">{it.brand?.name} · {S.oneOfOne} · <span className="num">{it.sku}</span></p>
            <h1 className="font-display text-display-lg">{it.title}</h1>
            <Price minor={it.priceMinor} size="xl" className="block" />
            <div className="flex flex-wrap items-center gap-x-6 gap-y-2 text-[15px]">
              <span>Size <strong>{it.size ?? "-"}</strong></span>
              {it.color && <span>{it.color}</span>}
              <GradeBadge grade={it.grade} />
            </div>
          </header>

          <div className="space-y-3">
            <AddToCart slug={it.slug} initial={it.availability} />
            <WishlistButton slug={it.slug} />
            <div className="flex flex-wrap items-center justify-between gap-3 pt-1"><CompareToggle slug={it.slug} /><ShareOnWhatsApp title={it.title} path={`/product/${it.slug}`} /></div>
          </div>

          {it.measurements && Object.keys(it.measurements).length > 0 && (
            <section aria-labelledby="m-h">
              <h2 id="m-h" className="font-display text-xl">Measurements</h2>
              <p className="text-sm text-muted">{S.measuredFlat}. Compare with a piece you own. Thrift sizes vary.</p>
              <table className="mt-3 w-full text-[15px]">
                <tbody>{Object.entries(it.measurements).map(([k, v]) => (
                  <tr key={k} className="border-b hairline"><th scope="row" className="py-2 text-left font-normal text-muted">{measureLabel(k)}</th><td className="py-2 text-right num">{measureValue(k, v)}</td></tr>
                ))}</tbody>
              </table>
            </section>
          )}

          <section aria-labelledby="c-h" className="space-y-3">
            <h2 id="c-h" className="font-display text-xl">Condition</h2>
            {it.grade && (
              <div className="flex gap-4 rounded-md border hairline bg-surface p-4">
                <GradeBadge grade={it.grade} size="lg" showLabel={false} />
                <div><p className="font-medium">Grade {it.grade.letter} · {it.grade.label}</p><p className="text-sm text-muted">{it.grade.rule}</p></div>
              </div>
            )}
            {it.condition && (
              <div className="text-[15px]">
                {it.condition.defects.length ? (
                  <ul className="list-disc space-y-1 pl-5">{it.condition.defects.map((d, i) => <li key={i}>{d.type}, {d.location} ({d.severity})</li>)}</ul>
                ) : <p>No flaws found.</p>}
                <p className="mt-2 text-sm text-muted">Condition report by {it.condition.inspectedBy}.{it.condition.notes ? ` ${it.condition.notes}` : ""}</p>
              </div>
            )}
          </section>

          {it.description && <section aria-labelledby="d-h"><h2 id="d-h" className="font-display text-xl">Details</h2><p className="mt-2 whitespace-pre-line text-[15px]">{it.description}</p>{it.material && <p className="mt-2 text-sm">Material: {it.material}</p>}</section>}

          <section aria-labelledby="f-h" className="space-y-2 border-t hairline pt-6 text-[15px]">
            <h2 id="f-h" className="sr-only">Delivery and returns</h2>
            <p><strong className="font-medium">{it.fulfilment.handledBy}.</strong> Ships from {it.fulfilment.shipsFrom}; usually {it.fulfilment.deliveryEstimate}.</p>
            <p className="text-muted">{it.fulfilment.payment}</p>
            <p className="text-muted">{it.fulfilment.returns} <Link href="/policies/returns" className="link">Policy</Link></p>
          </section>

          <section className="border-t hairline pt-6"><SellerChip seller={it.seller} /></section>
        </div>
      </div>
      {d.similar.length > 0 && <section className="mt-24"><SectionHeading title="You might also like" /><ProductGrid items={d.similar} /></section>}
    </div>
  );
}
