"use client";
import Link from "next/link";
import { useApi } from "@/lib/useApi";
import { StatusPill } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { EmptyState, Price } from "@/components/ui/misc";
import { dateShort } from "@/lib/format";

interface O { reference: string; state: string; totalMinor: number; createdAt: string; pieces: number; thumbs: Array<string | null> }

export default function Orders() {
  const { data, error } = useApi<{ orders: O[] }>("/v1/orders");
  if (error?.status === 401) return <div className="page py-16"><Button href="/login?next=/orders">Log in to see your orders</Button></div>;
  return (
    <div className="page max-w-4xl pt-10">
      <h1 className="font-display text-display-lg">Your orders</h1>
      {data && !data.orders.length && <EmptyState title="No orders yet" action={<Button href="/shop">Start shopping</Button>} />}
      <ul className="mt-8 space-y-3">
        {data?.orders.map((o) => (
          <li key={o.reference}>
            <Link href={`/orders/${o.reference}`} className="flex flex-wrap items-center gap-4 rounded-md border hairline bg-surface p-4 hover:border-ink">
              <div className="flex gap-1">{o.thumbs.map((t, i) => (t ? <img key={i} src={t} alt="" className="h-16 w-12 rounded-sm object-cover" /> : null))}</div>
              <div className="flex-1"><div className="font-medium num">{o.reference}</div><div className="text-sm text-muted">{dateShort(o.createdAt)} · {o.pieces} piece{o.pieces > 1 ? "s" : ""}</div></div>
              <StatusPill state={o.state} /><Price minor={o.totalMinor} />
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
