"use client";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { Suspense, use, useState } from "react";
import { call } from "@/lib/client";
import { useApi } from "@/lib/useApi";
import { GradeBadge, StatusPill } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { SelectField, TextArea } from "@/components/ui/Field";
import { Notice, Price } from "@/components/ui/misc";
import { Sheet } from "@/components/ui/Sheet";
import { useToast } from "@/components/ui/Toast";
import { dateTime, stateLabel } from "@/lib/format";
import type { Grade } from "@/lib/types";

interface Item { id: string; title: string; brand: string | null; size: string | null; grade: Grade | null; priceMinor: number; bundleLineId: string | null; slug: string | null; image: string | null; stockState: string; voided: boolean; canClaim: boolean }
interface Group { id: string; state: string; seller: string; mode: string; shippingMinor: number; deliveredAt: string | null; claimDeadline: string | null; bundles: Array<{ id: string; title: string; slug: string; size: number; priceMinor: number }>; items: Item[]; shipments: Array<{ id: string; courier: string; trackingNo: string | null; state: string; parcel: string; events: Array<{ status: string; at: string }> }> }
interface Order { reference: string; state: string; createdAt: string; paidAt: string | null; subtotalMinor: number; shippingMinor: number; totalMinor: number; shippingAddress: Record<string, string>; payment: { id: string; state: string; method: string; checkoutUrl: string | null; refunds: Array<{ amountMinor: number; state: string; reason: string }> } | null; reservationExpiresAt: string | null; groups: Group[]; claims: Array<{ id: string; orderItemId: string; state: string; reason: string; decisionNote: string | null; refundMinor: number | null; createdAt: string }> }

function OrderView({ params }: { params: Promise<{ ref: string }> }) {
  const { ref } = use(params);
  const sp = useSearchParams();
  const { data, reload, error } = useApi<{ order: Order }>(`/v1/orders/${ref}`);
  const [claimFor, setClaimFor] = useState<Item | null>(null);
  const toast = useToast();
  if (error) return <div className="page py-16"><Notice tone="bad">{error.message}</Notice></div>;
  if (!data) return <div className="page py-16 text-muted">Loading…</div>;
  const o = data.order;
  const cancel = async () => { await call(`/v1/orders/${ref}/cancel`, { method: "POST" }); toast("Order cancelled; the pieces are back on sale.", "info"); await reload(); };
  return (
    <div className="page max-w-4xl space-y-8 pt-10">
      {sp.get("placed") && o.state === "PAID" && <Notice tone="good">Thank you. your payment is confirmed. We&apos;ll text you a tracking link when your order ships.</Notice>}
      {sp.get("placed") && o.state === "CANCELLED" && <Notice tone="bad">The payment didn&apos;t go through, so nothing was charged and the pieces were released. You can try again from your cart.</Notice>}
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div><p className="eyebrow">Order</p><h1 className="font-display text-display-lg num">{o.reference}</h1><p className="text-sm text-muted">Placed {dateTime(o.createdAt)}{o.paidAt ? ` · paid ${dateTime(o.paidAt)}` : ""}</p></div>
        <StatusPill state={o.state} />
      </header>
      {o.state === "PENDING_PAYMENT" && (
        <Notice tone="warn">
          Waiting for payment{o.reservationExpiresAt ? `. Pieces are held until ${dateTime(o.reservationExpiresAt)}` : ""}.
          <span className="mt-3 flex gap-3">{o.payment?.checkoutUrl && <Button size="sm" href={o.payment.checkoutUrl.replace(/^https?:\/\/[^/]+/, "")}>Complete payment</Button>}<Button size="sm" variant="ghost" onClick={cancel}>Cancel order</Button></span>
        </Notice>
      )}
      {o.groups.map((g) => (
        <section key={g.id} className="rounded-md border hairline bg-surface">
          <header className="flex flex-wrap items-center justify-between gap-2 border-b hairline px-4 py-3 text-sm">
            <span><strong className="font-medium">{g.seller}</strong> · {g.mode === "WAREHOUSE" ? "ships from our warehouse" : "ships from the seller"}</span>
            <span className="flex items-center gap-2"><StatusPill state={g.state} />{g.deliveredAt && <span className="text-muted">Delivered {dateTime(g.deliveredAt)}</span>}</span>
          </header>
          {g.bundles.map((b) => <div key={b.id} className="border-b hairline px-4 py-2 text-sm">Lot: <Link className="link" href={`/bundles/${b.slug}`}>{b.title}</Link> · <Price minor={b.priceMinor} size="sm" /></div>)}
          <ul className="divide-y">
            {g.items.map((i) => (
              <li key={i.id} className="flex gap-4 p-4">

                {i.image ? <img src={i.image} alt="" className="h-24 w-[72px] rounded-sm object-cover" /> : <div className="h-24 w-[72px] rounded-sm bg-ivory-deep" />}
                <div className="flex-1">
                  <div className="font-medium">{i.title}</div>
                  <div className="text-sm text-muted">{i.brand} · {i.size}{i.bundleLineId ? " · part of a lot (share of lot price)" : ""}</div>
                  <div className="mt-1 flex items-center gap-3 text-sm"><GradeBadge grade={i.grade} /><span className="text-muted">{stateLabel(i.stockState)}</span></div>
                  {o.claims.filter((c) => c.orderItemId === i.id).map((c) => <p key={c.id} className="mt-1 text-sm">Damage claim: <StatusPill state={c.state} /> {c.decisionNote ? `: ${c.decisionNote}` : ""}</p>)}
                  {i.canClaim && <button className="link mt-2 text-sm" onClick={() => setClaimFor(i)}>Report damage</button>}
                </div>
                <Price minor={i.priceMinor} />
              </li>
            ))}
          </ul>
          {g.shipments.map((s) => (
            <div key={s.id} className="border-t hairline px-4 py-3 text-sm">
              <div className="flex flex-wrap justify-between gap-2"><span>{s.courier} · tracking <strong className="num">{s.trackingNo}</strong> · parcel {s.parcel}</span><StatusPill state={s.state} /></div>
              <ol className="mt-2 space-y-1 text-muted">{s.events.map((e, idx) => <li key={idx}>{dateTime(e.at)}: {stateLabel(e.status)}</li>)}</ol>
            </div>
          ))}
          {g.claimDeadline && new Date(g.claimDeadline) > new Date() && <p className="border-t hairline px-4 py-2 text-xs text-muted">Something arrived damaged? Report it before {dateTime(g.claimDeadline)}.</p>}
        </section>
      ))}
      <section className="grid gap-6 sm:grid-cols-2">
        <div className="text-[15px]"><h2 className="mb-2 font-display text-xl">Delivery to</h2><p>{o.shippingAddress.recipient}<br />{o.shippingAddress.line1}{o.shippingAddress.line2 ? <><br />{o.shippingAddress.line2}</> : null}<br />{o.shippingAddress.city}</p></div>
        <div className="space-y-1 text-[15px]">
          <h2 className="mb-2 font-display text-xl">Payment</h2>
          <div className="flex justify-between"><span>Items</span><Price minor={o.subtotalMinor} size="sm" /></div>
          <div className="flex justify-between"><span>Delivery</span><Price minor={o.shippingMinor} size="sm" /></div>
          <div className="flex justify-between text-lg"><span>Total</span><Price minor={o.totalMinor} /></div>
          {o.payment && <p className="text-sm text-muted">{o.payment.method.replace("_", " ").toLowerCase()} · {stateLabel(o.payment.state)}</p>}
          {o.payment?.refunds.map((r, i) => <p key={i} className="text-sm">Refund <Price minor={r.amountMinor} size="sm" />: {r.state.toLowerCase()} ({r.reason})</p>)}
        </div>
      </section>
      <ClaimSheet orderRef={o.reference} item={claimFor} onClose={() => setClaimFor(null)} onDone={reload} />
    </div>
  );
}

function ClaimSheet({ orderRef, item, onClose, onDone }: { orderRef: string; item: Item | null; onClose: () => void; onDone: () => void }) {
  const [reason, setReason] = useState("DAMAGED_IN_TRANSIT");
  const [desc, setDesc] = useState("");
  const [files, setFiles] = useState<File[]>([]);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const toast = useToast();
  const submit = async () => {
    if (!item) return;
    setBusy(true); setErr(null);
    const fd = new FormData(); fd.set("orderItemId", item.id); fd.set("reason", reason); fd.set("description", desc); files.forEach((f) => fd.append("photos", f));
    try { await call(`/v1/orders/${orderRef}/claims`, { form: fd }); toast("Claim sent. We reply within 1 working day.", "good"); onClose(); onDone(); }
    catch (e) { setErr((e as Error).message); } finally { setBusy(false); }
  };
  return (
    <Sheet open={!!item} onClose={onClose} title="Report damage" side="center">
      <div className="space-y-4">
        <p className="text-sm text-muted">For damage in transit or a flaw that wasn&apos;t shown in the listing. Flaws listed in the condition report, size and change of mind aren&apos;t covered.</p>
        {err && <Notice tone="bad">{err}</Notice>}
        <SelectField label="What happened?" value={reason} onChange={(e) => setReason(e.target.value)}><option value="DAMAGED_IN_TRANSIT">It arrived damaged</option><option value="UNDISCLOSED_DEFECT">It has a flaw that wasn&apos;t disclosed</option></SelectField>
        <TextArea label="Describe the damage" value={desc} onChange={(e) => setDesc(e.target.value)} minLength={10} />
        <label className="block text-sm"><span className="font-medium">Photos (required)</span><input type="file" accept="image/*" multiple className="mt-1 block text-sm" onChange={(e) => setFiles(Array.from(e.target.files ?? []).slice(0, 6))} /></label>
        <Button full onClick={submit} loading={busy} disabled={desc.length < 10 || !files.length}>Send claim</Button>
      </div>
    </Sheet>
  );
}

export default function Page(props: { params: Promise<{ ref: string }> }) { return <Suspense><OrderView {...props} /></Suspense>; }
