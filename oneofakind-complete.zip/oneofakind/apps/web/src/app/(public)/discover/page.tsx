import Link from "next/link";
import type { Metadata } from "next";
import { api } from "@/lib/api";
import type { HomeData, SearchResult } from "@/lib/types";
import { ProductGrid, ProductImage } from "@/components/product";
import { SectionHeading } from "@/components/ui/misc";
import { RecentlyViewed } from "@/components/RecentlyViewed";

export const metadata: Metadata = { title: "Discover" };
export const revalidate = 60;

const STYLES = [
  { label: "90s denim", q: "denim" }, { label: "Workwear", q: "carhartt" }, { label: "Fleece", q: "fleece" }, { label: "Track jackets", q: "track jacket" },
  { label: "Graphic tees", q: "graphic tee" }, { label: "Polo shirts", q: "polo" }, { label: "Leather boots", q: "boots" }, { label: "Shoulder bags", q: "bag" },
];

export default async function Discover() {
  const [home, jackets, under] = await Promise.all([
    api<HomeData>("/v1/content/home"),
    api<SearchResult>("/v1/listings?category=jackets&limit=6"),
    api<SearchResult>("/v1/listings?maxPrice=300000&sort=newest&limit=6"),
  ]);
  return (
    <div className="page pt-10">
      <h1 className="font-display text-display-lg">Discover</h1>
      <p className="mt-2 max-w-xl text-muted">Edits from our team, styles worth hunting, and what just landed.</p>
      <nav aria-label="Styles" className="mt-8 flex flex-wrap gap-2">
        {STYLES.map((s) => <Link key={s.q} href={`/search?q=${encodeURIComponent(s.q)}`} className="rounded-pill border hairline px-4 py-2 text-sm hover:border-ink">{s.label}</Link>)}
      </nav>
      <RecentlyViewed />
      <section className="mt-14 grid gap-10 md:grid-cols-3">
        {home.collections.map((c) => (
          <Link key={c.slug} href={`/collections/${c.slug}`} className="group block">
            <ProductImage img={c.covers[0] ?? null} />
            <h2 className="mt-3 font-display text-2xl group-hover:underline">{c.title}</h2>
            <p className="text-sm text-muted">{c.description}</p>
          </Link>
        ))}
      </section>
      <section className="mt-16"><SectionHeading title="Outerwear, just in" href="/category/jackets" /><ProductGrid items={jackets.items} cols={3} /></section>
      <section className="mt-16"><SectionHeading title="Under PKR 3,000" href="/search?maxPrice=300000" /><ProductGrid items={under.items} cols={3} /></section>
    </div>
  );
}
