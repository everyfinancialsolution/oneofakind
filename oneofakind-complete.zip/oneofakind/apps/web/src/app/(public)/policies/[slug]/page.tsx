import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { POLICIES } from "@/lib/content";
import { ArticleView } from "@/components/ArticleView";

type P = { params: Promise<{ slug: string }> };
export const generateStaticParams = () => POLICIES.map((h) => ({ slug: h.slug }));
export async function generateMetadata({ params }: P): Promise<Metadata> { const { slug } = await params; const a = POLICIES.find((h) => h.slug === slug); return { title: a?.title ?? "Policy" }; }

export default async function Policy({ params }: P) {
  const { slug } = await params;
  const a = POLICIES.find((h) => h.slug === slug);
  if (!a) notFound();
  return <div className="page pt-10"><ArticleView a={a} /></div>;
}
