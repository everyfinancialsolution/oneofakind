import Link from "next/link";
import type { Metadata } from "next";
import { HELP } from "@/lib/content";
import { WhatsAppLink } from "@/components/WhatsApp";
import { S } from "@/lib/strings";

export const metadata: Metadata = { title: "Help centre" };

export default function Help() {
  return (
    <div className="page pt-10">
      <h1 className="font-display text-display-lg">Help centre</h1>
      <p className="mt-2 text-muted">Short answers about buying, selling, grades and delivery.</p>
      <ul className="mt-10 grid gap-6 md:grid-cols-2">
        {HELP.map((h) => <li key={h.slug} className="border-t hairline pt-4"><Link href={`/help/${h.slug}`} className="font-display text-2xl hover:underline">{h.title}</Link><p className="text-sm text-muted">{h.summary}</p></li>)}
      </ul>
      <div className="mt-14 rounded-md bg-surface p-6"><h2 className="font-display text-2xl">Still stuck?</h2><p className="mt-1 text-muted">Message us on WhatsApp any time. We reply within an hour.</p><div className="mt-4"><WhatsAppLink button="primary" message="Hello ONEOFAKIND, I need help.">{S.whatsappHelp}</WhatsAppLink></div></div>
    </div>
  );
}
