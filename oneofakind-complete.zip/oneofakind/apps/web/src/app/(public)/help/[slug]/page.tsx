import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { HELP } from "@/lib/content";
import { ArticleView } from "@/components/ArticleView";

type P = { params: Promise<{ slug: string }> };
export const generateStaticParams = () => HELP.map((h) => ({ slug: h.slug }));
export async function generateMetadata({ params }: P): Promise<Metadata> { const { slug } = await params; const a = HELP.find((h) => h.slug === slug); return { title: a?.title ?? "Help" }; }

export default async function HelpArticle({ params }: P) {
  const { slug } = await params;
  const a = HELP.find((h) => h.slug === slug);
  if (!a) notFound();
  return <div className="page pt-10"><ArticleView a={a} /></div>;
}
