import Link from "next/link";
import type { Metadata } from "next";
import { api } from "@/lib/api";
import type { Category } from "@/lib/types";
import { BrowsePage } from "@/components/BrowsePage";

export const metadata: Metadata = { title: "Shop secondhand fashion", description: "Every piece inspected, graded and measured in centimetres." };

export default async function Shop({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const sp = await searchParams;
  const { categories } = await api<{ categories: Category[] }>("/v1/catalog/categories", { revalidate: 300 });
  const leaves = categories.filter((c) => !categories.some((x) => x.parentId === c.id) && c.liveCount > 0);
  return (
    <BrowsePage title="Shop" intro="Single pieces from verified sellers and our own warehouse. Every item has a grade, photos and measurements in centimetres." sp={sp}
      header={
        <nav aria-label="Categories" className="-mx-4 mb-6 flex gap-2 overflow-x-auto px-4 pb-1">
          {leaves.map((c) => <Link key={c.slug} href={`/category/${c.slug}`} className="shrink-0 rounded-pill border hairline px-4 py-1.5 text-sm hover:border-ink">{c.name} <span className="text-muted num">{c.liveCount}</span></Link>)}
        </nav>
      } />
  );
}
