import Link from "next/link";
import { PublicHeader } from "@/components/chrome/PublicHeader";

export default function NotFound() {
  return (
    <>
      <PublicHeader />
      <main id="main" className="page py-24">
        <p className="eyebrow">404</p>
        <h1 className="font-display text-display-lg">This page doesn&apos;t exist, or it sold.</h1>
        <p className="mt-3 max-w-lg text-muted">Every piece is one of one, so pages for sold items can disappear.</p>
        <Link href="/shop" className="link mt-6 inline-block">Back to the shop</Link>
      </main>
    </>
  );
}
