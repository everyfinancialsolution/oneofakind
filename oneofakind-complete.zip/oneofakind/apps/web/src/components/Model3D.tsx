"use client";
import { useState } from "react";
import dynamic from "next/dynamic";
import { Button } from "./ui/Button";

// Three.js is only downloaded when a shopper asks for the 3D view (never on grids).
const Viewer = dynamic(() => import("./Model3DViewer").then((m) => m.Model3DViewer), { ssr: false, loading: () => <p className="text-sm text-muted">Loading 3D view…</p> });

export function Model3D({ url, title }: { url: string; title: string }) {
  const [open, setOpen] = useState(false);
  if (!open) return <Button variant="secondary" onClick={() => setOpen(true)}>View in 3D</Button>;
  return <Viewer url={url} title={title} />;
}
