"use client";
import clsx from "clsx";
import Link from "next/link";
import { useState, type ReactNode } from "react";
import { call } from "@/lib/client";
import { Button } from "../ui/Button";
import { TextArea, TextField } from "../ui/Field";
import { Sheet } from "../ui/Sheet";
import { useToast } from "../ui/Toast";

/** Dense admin table. Columns render cells; rows scroll horizontally on small screens (never the page). */
export function DataTable<T>({ rows, cols, empty = "Nothing here.", rowKey }: { rows: T[] | undefined | null; cols: Array<{ h: ReactNode; c: (r: T) => ReactNode; className?: string }>; empty?: string; rowKey: (r: T) => string }) {
  if (!rows) return <div className="py-10 text-center text-sm text-muted">Loading…</div>;
  if (!rows.length) return <div className="rounded-md border hairline bg-surface py-10 text-center text-sm text-muted">{empty}</div>;
  return (
    <div className="overflow-x-auto rounded-md border hairline bg-surface">
      <table className="w-full text-left text-sm">
        <thead className="border-b hairline bg-ivory-deep/60 text-xs uppercase tracking-wide text-muted">
          <tr>{cols.map((c, i) => <th key={i} scope="col" className={clsx("whitespace-nowrap px-3 py-2 font-semibold", c.className)}>{c.h}</th>)}</tr>
        </thead>
        <tbody className="divide-y divide-[color:var(--hairline,#e5e0d8)]">
          {rows.map((r) => <tr key={rowKey(r)} className="align-top hover:bg-ivory-deep/40">{cols.map((c, i) => <td key={i} className={clsx("px-3 py-2", c.className)}>{c.c(r)}</td>)}</tr>)}
        </tbody>
      </table>
    </div>
  );
}

export function Tabs<K extends string>({ value, onChange, tabs }: { value: K; onChange: (k: K) => void; tabs: Array<{ k: K; label: ReactNode }> }) {
  return (
    <div role="tablist" className="mb-4 flex flex-wrap gap-1 border-b hairline">
      {tabs.map((t) => (
        <button key={t.k} role="tab" aria-selected={value === t.k} onClick={() => onChange(t.k)}
          className={clsx("-mb-px border-b-2 px-3 py-2 text-sm", value === t.k ? "border-ink font-semibold" : "border-transparent text-muted hover:text-ink")}>{t.label}</button>
      ))}
    </div>
  );
}

/**
 * A staff action that posts to the API. With `note`, opens a sheet that requires a reason (stored in the audit log).
 * Errors from the API (problem+json detail) are shown verbatim - the server is the source of truth.
 */
export function ActionButton({ path, body = {}, label, note, noteLabel = "Reason (saved in the audit log)", variant = "secondary", size = "sm", onDone, confirm, extra, method }: {
  path: string; body?: Record<string, unknown>; label: ReactNode; note?: string; noteLabel?: string; variant?: "primary" | "secondary" | "ghost" | "danger"; size?: "sm" | "md";
  onDone?: () => void | Promise<void>; confirm?: string; extra?: Array<{ name: string; label: string; placeholder?: string }>; method?: string;
}) {
  const [open, setOpen] = useState(false);
  const [text, setText] = useState("");
  const [vals, setVals] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  const toast = useToast();
  const needsSheet = !!note || !!extra?.length;
  const go = async () => {
    if (confirm && !needsSheet && !window.confirm(confirm)) return;
    setBusy(true);
    try {
      await call(path, { method: method ?? "POST", body: { ...body, ...(note ? { [note]: text } : {}), ...vals } });
      toast("Done", "good"); setOpen(false); setText(""); setVals({});
      await onDone?.();
    } catch (e) { toast((e as Error).message, "bad"); }
    finally { setBusy(false); }
  };
  return (
    <>
      <Button size={size} variant={variant} loading={busy && !needsSheet} onClick={() => (needsSheet ? setOpen(true) : go())}>{label}</Button>
      {needsSheet && open && (
        <Sheet open={open} onClose={() => setOpen(false)} title={typeof label === "string" ? label : "Confirm"} side="center">
          <div className="space-y-4">
            {confirm && <p className="text-[15px]">{confirm}</p>}
            {extra?.map((x) => <TextField key={x.name} label={x.label} placeholder={x.placeholder} value={vals[x.name] ?? ""} onChange={(e) => setVals((v) => ({ ...v, [x.name]: e.target.value }))} />)}
            {note && <TextArea label={noteLabel} value={text} onChange={(e) => setText(e.target.value)} rows={3} />}
            <div className="flex justify-end gap-2"><Button variant="ghost" onClick={() => setOpen(false)}>Cancel</Button><Button variant={variant === "danger" ? "danger" : "primary"} loading={busy} onClick={go} disabled={!!note && text.trim().length < 3}>Confirm</Button></div>
          </div>
        </Sheet>
      )}
    </>
  );
}

export function QueueCard({ href, label, count, tone }: { href: string; label: string; count: number | undefined; tone?: "warn" | "bad" }) {
  return (
    <Link href={href} className={clsx("block rounded-md border hairline bg-surface p-4 hover:border-ink", count && tone === "bad" && "border-[#8A2E25]/50")}>
      <div className="text-sm text-muted">{label}</div>
      <div className={clsx("num mt-1 text-3xl", count ? (tone === "bad" ? "text-[#8A2E25]" : "") : "text-stone-deep")}>{count ?? "-"}</div>
    </Link>
  );
}

export function KV({ items }: { items: Array<[string, ReactNode]> }) {
  return (
    <dl className="grid gap-x-6 gap-y-2 text-sm sm:grid-cols-2 lg:grid-cols-3">
      {items.map(([k, v]) => <div key={k}><dt className="text-xs text-muted">{k}</dt><dd className="break-words">{v ?? "-"}</dd></div>)}
    </dl>
  );
}

export function Panel({ title, children, actions, className }: { title?: string; children: ReactNode; actions?: ReactNode; className?: string }) {
  return (
    <section className={clsx("rounded-md border hairline bg-surface p-4", className)}>
      {(title || actions) && <div className="mb-3 flex flex-wrap items-center justify-between gap-2">{title && <h2 className="font-semibold">{title}</h2>}{actions}</div>}
      {children}
    </section>
  );
}
