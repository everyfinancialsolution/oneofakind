import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";
import { ToastProvider } from "../ui/Toast";
import { ActionButton, DataTable } from "./kit";

afterEach(() => vi.restoreAllMocks());

describe("admin kit", () => {
  it("DataTable shows the empty message and rows", () => {
    const { rerender } = render(<DataTable rows={[]} rowKey={(r: { id: string }) => r.id} cols={[{ h: "Id", c: (r) => r.id }]} empty="Nothing to do" />);
    expect(screen.getByText("Nothing to do")).toBeInTheDocument();
    rerender(<DataTable rows={[{ id: "a1" }]} rowKey={(r) => r.id} cols={[{ h: "Id", c: (r) => r.id }]} />);
    expect(screen.getByText("a1")).toBeInTheDocument();
  });

  it("ActionButton with a note requires a reason before posting, then sends it in the body", async () => {
    HTMLDialogElement.prototype.showModal ??= function (this: HTMLDialogElement) { this.open = true; };
    HTMLDialogElement.prototype.close ??= function (this: HTMLDialogElement) { this.open = false; };
    const fetchMock = vi.spyOn(globalThis, "fetch").mockResolvedValue(new Response(JSON.stringify({ ok: true }), { status: 200, headers: { "content-type": "application/json" } }));
    const done = vi.fn();
    render(<ToastProvider><ActionButton path="/v1/admin/x/1/reject" body={{ approve: false }} note="reason" label="Reject" onDone={done} /></ToastProvider>);
    fireEvent.click(screen.getByRole("button", { name: "Reject" }));
    const confirm = screen.getByRole("button", { name: "Confirm" });
    expect(confirm).toBeDisabled();
    fireEvent.change(screen.getByLabelText(/Reason/), { target: { value: "Blurry ID photo" } });
    fireEvent.click(confirm);
    await waitFor(() => expect(done).toHaveBeenCalled());
    const [url, init] = fetchMock.mock.calls[0]!;
    expect(url).toBe("/v1/admin/x/1/reject");
    expect(JSON.parse(String((init as RequestInit).body))).toEqual({ approve: false, reason: "Blurry ID photo" });
  });
});
