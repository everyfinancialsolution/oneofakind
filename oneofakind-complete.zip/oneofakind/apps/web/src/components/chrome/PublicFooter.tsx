import Link from "next/link";
import { S } from "@/lib/strings";
import { WhatsAppLink } from "../WhatsApp";

const COLS = [
  { title: "Shop", links: [["New arrivals", "/shop"], ["Discover", "/discover"], ["Curated edits", "/collections"], ["Sellers", "/sellers"], ["Compare", "/compare"]] },
  { title: "Sell", links: [["Sell with us", "/sell"], ["Apply to sell", "/seller/apply"], ["Managed resale", "/sell#managed"], ["Sell to us outright", "/sell#direct"], ["Seller hub", "/seller"]] },
  { title: "Resellers", links: [["Bundles", "/bundles"], ["Become a verified reseller", "/reseller"], ["Apply", "/reseller/apply"]] },
  { title: "Help", links: [["Help centre", "/help"], ["Grades explained", "/help/grades"], ["Delivery", "/help/delivery"], ["Damage claims", "/policies/returns"], ["About", "/about"]] },
];

export function PublicFooter() {
  return (
    <footer className="mt-24 border-t hairline bg-ink text-ivory">
      <div className="page grid gap-10 py-14 md:grid-cols-[1.4fr_repeat(4,1fr)]">
        <div className="space-y-4">
          <div className="font-display text-2xl tracking-[0.18em]">ONEOFAKIND</div>
          <p className="max-w-xs text-sm text-stone">{S.tagline}</p>
          <p className="text-sm text-stone">{S.prepaidOnly}</p>
          <WhatsAppLink message="Hello ONEOFAKIND, I need help." className="inline-block text-sm underline">{S.whatsappHelp}</WhatsAppLink>
        </div>
        {COLS.map((c) => (
          <nav key={c.title} aria-label={c.title}>
            <h2 className="mb-3 font-body text-sm font-semibold text-stone">{c.title}</h2>
            <ul className="space-y-2 text-sm">{c.links.map(([l, h]) => <li key={h}><Link href={h!} className="hover:underline">{l}</Link></li>)}</ul>
          </nav>
        ))}
      </div>
      <div className="border-t border-white/10">
        <div className="page flex flex-col gap-2 py-5 text-xs text-stone sm:flex-row sm:justify-between">
          <span>© {new Date().getFullYear()} ONEOFAKIND. Pakistan.</span>
          <span className="flex gap-4"><Link href="/policies/terms">Terms</Link><Link href="/policies/privacy">Privacy</Link><Link href="/policies/returns">Damage claims</Link><Link href="/policies/seller-terms">Seller terms</Link></span>
        </div>
      </div>
    </footer>
  );
}
