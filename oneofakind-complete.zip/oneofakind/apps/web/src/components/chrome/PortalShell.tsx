"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState, type ReactNode } from "react";
import clsx from "clsx";
import { useSession } from "../session";
import { WhatsAppLink } from "../WhatsApp";

export interface NavItem { href: string; label: string; exact?: boolean }
export interface NavGroup { title?: string; items: NavItem[] }

/** Shared shell for seller hub (efficient), warehouse (scan-friendly) and admin (dense). */
export function PortalShell({ title, nav, children, tone = "light", help }: { title: string; nav: NavGroup[]; children: ReactNode; tone?: "light" | "ink"; help?: string }) {
  const path = usePathname();
  const { me } = useSession();
  const [open, setOpen] = useState(false);
  const active = (n: NavItem) => (n.exact ? path === n.href : path === n.href || path.startsWith(`${n.href}/`));
  return (
    <div className="min-h-screen lg:grid lg:grid-cols-[240px_1fr]">
      <a href="#main" className="sr-only-focusable absolute left-2 top-2 z-50 bg-ink px-3 py-2 text-ivory">Skip to content</a>
      <aside className={clsx("border-b hairline lg:sticky lg:top-0 lg:h-screen lg:overflow-y-auto lg:border-b-0 lg:border-r", tone === "ink" ? "bg-ink text-ivory" : "bg-surface")}>
        <div className="flex h-14 items-center justify-between px-4 lg:h-16">
          <Link href="/" className="font-display text-lg tracking-[0.16em]">ONEOFAKIND</Link>
          <button className="text-sm lg:hidden" onClick={() => setOpen((x) => !x)} aria-expanded={open}>{open ? "Close" : "Menu"}</button>
        </div>
        <div className={clsx("px-4 pb-2 text-xs", tone === "ink" ? "text-stone" : "text-muted")}>{title}</div>
        <nav aria-label={title} className={clsx("px-2 pb-6 lg:block", open ? "block" : "hidden")}>
          {nav.map((g, gi) => (
            <div key={gi} className="mt-3">
              {g.title && <div className={clsx("px-2 pb-1 text-[11px] font-semibold uppercase tracking-wide", tone === "ink" ? "text-stone" : "text-muted")}>{g.title}</div>}
              <ul className="space-y-0.5">
                {g.items.map((n) => (
                  <li key={n.href}>
                    <Link href={n.href} onClick={() => setOpen(false)} aria-current={active(n) ? "page" : undefined}
                      className={clsx("block rounded-md px-3 py-2 text-[15px]", active(n) ? (tone === "ink" ? "bg-ivory text-ink" : "bg-ink text-ivory") : tone === "ink" ? "hover:bg-white/10" : "hover:bg-ivory-deep")}>
                      {n.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
          <div className={clsx("mt-6 border-t px-3 pt-4 text-sm", tone === "ink" ? "border-white/10" : "hairline")}>
            <div className="truncate">{me?.name}</div>
            <div className="mt-2 flex flex-col gap-1">
              {help && <WhatsAppLink message={help} className="underline">Get help on WhatsApp</WhatsAppLink>}
              <Link href="/account" className="underline">Account</Link>
            </div>
          </div>
        </nav>
      </aside>
      <main id="main" className="min-w-0 px-4 py-6 sm:px-6 lg:px-10 lg:py-8">{children}</main>
    </div>
  );
}

export function PageHeader({ title, sub, actions }: { title: string; sub?: ReactNode; actions?: ReactNode }) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
      <div><h1 className="font-display text-3xl sm:text-4xl">{title}</h1>{sub && <div className="mt-1 text-muted">{sub}</div>}</div>
      {actions && <div className="flex flex-wrap gap-2">{actions}</div>}
    </div>
  );
}
