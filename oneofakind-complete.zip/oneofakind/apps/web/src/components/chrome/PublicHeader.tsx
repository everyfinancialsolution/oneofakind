"use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";
import clsx from "clsx";
import { useSession } from "../session";
import { S } from "@/lib/strings";

const NAV = [
  { href: "/shop", label: "Shop" },
  { href: "/discover", label: "Discover" },
  { href: "/collections", label: "Edits" },
  { href: "/sellers", label: "Sellers" },
  { href: "/sell", label: "Sell with us" },
];

export function ModeSwitch() {
  const path = usePathname();
  const bundles = path.startsWith("/bundles") || path.startsWith("/reseller");
  const cls = (on: boolean) => clsx("whitespace-nowrap rounded-pill px-3 py-1 text-sm transition-colors", on ? "bg-ink text-ivory" : "text-ink hover:bg-ivory-deep");
  return (
    <nav aria-label="Storefront mode" className="inline-flex rounded-pill border hairline p-0.5">
      <Link href="/shop" className={cls(!bundles)} aria-current={!bundles ? "page" : undefined}>{S.modeRetail}</Link>
      <Link href="/bundles" className={cls(bundles)} aria-current={bundles ? "page" : undefined}>{S.modeBundles}</Link>
    </nav>
  );
}

export function PublicHeader() {
  const { me, cartCount, has } = useSession();
  const router = useRouter();
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const submit = (e: FormEvent) => { e.preventDefault(); if (q.trim()) router.push(`/search?q=${encodeURIComponent(q.trim())}`); setOpen(false); };
  const portal = has("ADMIN", "MODERATOR", "FINANCE", "SUPPORT", "SELLER_AGENT") ? { href: "/admin", label: "Admin" } : has("WAREHOUSE") ? { href: "/ops", label: "Warehouse" } : me?.seller ? { href: "/seller", label: "Seller hub" } : null;

  return (
    <header className="glass sticky top-0 z-40 border-b hairline">
      <a href="#main" className="sr-only-focusable absolute left-2 top-2 z-50 bg-ink px-3 py-2 text-ivory">Skip to content</a>
      <div className="hidden border-b hairline bg-ink text-ivory sm:block">
        <div className="page flex h-8 items-center justify-between text-xs">
          <span>Every piece inspected, graded and measured in cm · Prepaid, tracked delivery</span>
          <span className="flex gap-4"><Link href="/reseller" className="hover:underline">For resellers</Link><Link href="/help" className="hover:underline">Help</Link></span>
        </div>
      </div>
      <div className="page flex h-16 items-center gap-4">
        <button className="lg:hidden" onClick={() => setOpen((x) => !x)} aria-expanded={open} aria-controls="mobile-nav" aria-label="Menu">
          <span className="block h-0.5 w-5 bg-ink" /><span className="mt-1.5 block h-0.5 w-5 bg-ink" />
        </button>
        <Link href="/" className="font-display text-xl tracking-[0.18em] sm:text-2xl" aria-label="ONEOFAKIND home">ONEOFAKIND</Link>
        <nav aria-label="Main" className="ml-4 hidden gap-5 whitespace-nowrap text-[15px] lg:flex">
          {NAV.map((n) => <Link key={n.href} href={n.href} className="hover:underline">{n.label}</Link>)}
        </nav>
        <div className="ml-auto hidden md:block"><ModeSwitch /></div>
        <form onSubmit={submit} role="search" className="hidden xl:block">
          <label htmlFor="q" className="sr-only">Search</label>
          <input id="q" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search brands, pieces…" className="h-9 w-48 rounded-pill border hairline bg-surface px-4 text-sm focus:w-64 focus:border-ink focus:outline-none lg:w-56" />
        </form>
        <div className="ml-auto flex items-center gap-4 whitespace-nowrap text-sm md:ml-0">
          {portal && <Link href={portal.href} className="hidden hover:underline sm:inline">{portal.label}</Link>}
          <Link href="/wishlist" className="hidden hover:underline sm:inline">Saved</Link>
          {me ? <Link href="/account" className="hover:underline">{me.name.split(" ")[0]}</Link> : <Link href="/login" className="hover:underline">Log in</Link>}
          <Link href="/cart" className="relative hover:underline" aria-label={`Cart, ${cartCount} items`}>
            Cart{cartCount > 0 && <span className="ml-1 rounded-pill bg-ink px-1.5 py-0.5 text-[11px] text-ivory num">{cartCount}</span>}
          </Link>
        </div>
      </div>
      {open && (
        <div id="mobile-nav" className="border-t hairline bg-surface lg:hidden">
          <div className="page space-y-4 py-4">
            <form onSubmit={submit} role="search"><input aria-label="Search" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search brands, pieces…" className="h-11 w-full rounded-pill border hairline bg-ivory px-4" /></form>
            <ModeSwitch />
            <nav aria-label="Mobile" className="grid gap-3 text-lg">
              {NAV.map((n) => <Link key={n.href} href={n.href} onClick={() => setOpen(false)}>{n.label}</Link>)}
              <Link href="/wishlist" onClick={() => setOpen(false)}>Saved</Link>
              {portal && <Link href={portal.href} onClick={() => setOpen(false)}>{portal.label}</Link>}
              <Link href="/reseller" onClick={() => setOpen(false)}>For resellers</Link>
              <Link href="/help" onClick={() => setOpen(false)}>Help</Link>
            </nav>
          </div>
        </div>
      )}
    </header>
  );
}
