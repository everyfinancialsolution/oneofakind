import { Suspense, type ReactNode } from "react";
import { api } from "@/lib/api";
import type { Facets, SearchResult } from "@/lib/types";
import { Filters, MobileFilters, Results, SortSelect } from "./browse";

const PASS = ["q", "category", "brand", "size", "grade", "color", "minPrice", "maxPrice", "seller", "city", "managed", "sort"];

export function toQuery(sp: Record<string, string | string[] | undefined>, fixed: Record<string, string> = {}) {
  const q = new URLSearchParams();
  for (const k of PASS) { const v = sp[k]; if (typeof v === "string" && v) q.set(k, v); }
  for (const [k, v] of Object.entries(fixed)) q.set(k, v);
  return q.toString();
}

/** Shared server-rendered browse layout for /shop, /category/[slug] and /search. */
export async function BrowsePage({ title, intro, sp, fixed = {}, header }: { title: string; intro?: ReactNode; sp: Record<string, string | string[] | undefined>; fixed?: Record<string, string>; header?: ReactNode }) {
  const query = toQuery(sp, fixed);
  const [res, facets] = await Promise.all([
    api<SearchResult>(`/v1/listings?${query}`, { revalidate: 30 }),
    api<Facets>(`/v1/listings/facets?${query}`, { revalidate: 60 }),
  ]);
  return (
    <div className="page pt-8">
      {header}
      <div className="mb-8 flex flex-wrap items-end justify-between gap-4 border-b hairline pb-5">
        <div>
          <h1 className="font-display text-display-lg">{title}</h1>
          {intro && <div className="mt-2 max-w-2xl text-muted">{intro}</div>}
          <p className="mt-2 text-sm text-muted num">{res.total} {res.total === 1 ? "piece" : "pieces"}</p>
        </div>
        <Suspense><div className="flex items-center gap-3"><MobileFilters facets={facets} /><SortSelect withRelevance={!!sp.q} /></div></Suspense>
      </div>
      <div className="grid gap-10 lg:grid-cols-[240px_1fr]">
        <div className="hidden lg:block"><Suspense><Filters facets={facets} /></Suspense></div>
        <Suspense><Results initial={res.items} nextCursor={res.nextCursor} query={query} /></Suspense>
      </div>
    </div>
  );
}
