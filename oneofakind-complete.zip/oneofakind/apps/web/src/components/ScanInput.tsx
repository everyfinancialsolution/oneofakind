"use client";
import { useEffect, useRef, useState, type FormEvent } from "react";
import { Button } from "./ui/Button";

/**
 * Scan field for packing/receiving. Handheld USB scanners type the code and press Enter (keyboard wedge).
 * Phones use the camera: native BarcodeDetector where available, ZXing otherwise. Codes are opaque; the server resolves them.
 */
export function ScanInput({ onScan, label = "Scan or type a code", autoFocus = true, disabled }: { onScan: (code: string) => void | Promise<void>; label?: string; autoFocus?: boolean; disabled?: boolean }) {
  const [v, setV] = useState("");
  const [camera, setCamera] = useState(false);
  const ref = useRef<HTMLInputElement>(null);
  useEffect(() => { if (autoFocus) ref.current?.focus(); }, [autoFocus]);
  const submit = async (e?: FormEvent) => {
    e?.preventDefault();
    const code = v.trim();
    if (!code) return;
    setV("");
    await onScan(code);
    ref.current?.focus();
  };
  return (
    <div className="space-y-2">
      <form onSubmit={submit} className="flex gap-2">
        <label className="sr-only" htmlFor="scan">{label}</label>
        <input id="scan" ref={ref} value={v} onChange={(e) => setV(e.target.value)} placeholder={label} disabled={disabled} inputMode="numeric" autoComplete="off"
          className="h-14 flex-1 rounded-md border-2 border-ink bg-surface px-4 font-mono text-lg tracking-wider focus:outline-none" />
        <Button type="submit" size="lg" disabled={disabled}>Add</Button>
        <Button type="button" size="lg" variant="secondary" onClick={() => setCamera((x) => !x)}>{camera ? "Close camera" : "Camera"}</Button>
      </form>
      {camera && <CameraScanner onCode={async (c) => { await onScan(c); }} />}
    </div>
  );
}

function CameraScanner({ onCode }: { onCode: (code: string) => Promise<void> }) {
  const video = useRef<HTMLVideoElement>(null);
  const [err, setErr] = useState<string | null>(null);
  useEffect(() => {
    let stop = () => {};
    let last = "";
    let lastAt = 0;
    const seen = async (raw: string) => { const now = Date.now(); if (raw === last && now - lastAt < 2500) return; last = raw; lastAt = now; await onCode(raw); };
    (async () => {
      try {
        type BD = { detect: (v: HTMLVideoElement) => Promise<Array<{ rawValue: string }>> };
        const W = window as unknown as { BarcodeDetector?: new (o: { formats: string[] }) => BD };
        if (W.BarcodeDetector) {
          const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } });
          video.current!.srcObject = stream;
          await video.current!.play();
          const det = new W.BarcodeDetector({ formats: ["code_128", "qr_code"] });
          let alive = true;
          const tick = async () => { if (!alive) return; try { const r = await det.detect(video.current!); if (r[0]) await seen(r[0].rawValue); } catch { /* frame not ready */ } setTimeout(tick, 250); };
          void tick();
          stop = () => { alive = false; stream.getTracks().forEach((t) => t.stop()); };
        } else {
          const { BrowserMultiFormatReader } = await import("@zxing/browser");
          const reader = new BrowserMultiFormatReader();
          const controls = await reader.decodeFromVideoDevice(undefined, video.current!, (res) => { if (res) void seen(res.getText()); });
          stop = () => controls.stop();
        }
      } catch { setErr("Camera not available. Allow camera access, or type the 13 digits under the barcode."); }
    })();
    return () => stop();
  }, [onCode]);
  return (
    <div className="overflow-hidden rounded-md border hairline bg-ink">
      <video ref={video} className="aspect-video w-full object-cover" muted playsInline aria-label="Camera preview for scanning" />
      {err && <p className="bg-surface p-3 text-sm text-[#8A2E25]">{err}</p>}
    </div>
  );
}
