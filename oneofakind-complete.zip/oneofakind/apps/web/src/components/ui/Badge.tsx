import clsx from "clsx";
import type { ReactNode } from "react";
import type { Grade } from "@/lib/types";
import { stateLabel } from "@/lib/format";

export function Badge({ children, tone = "neutral", className }: { children: ReactNode; tone?: "neutral" | "ink" | "champagne" | "good" | "warn" | "bad"; className?: string }) {
  const tones = {
    neutral: "bg-ivory-deep text-ink",
    ink: "bg-ink text-ivory",
    champagne: "bg-[color-mix(in_srgb,var(--ooak-champagne)_25%,transparent)] text-champagne-ink",
    good: "bg-[#E3EDE6] text-[#2F5D50]",
    warn: "bg-[#F4EAD5] text-[#7A5A1F]",
    bad: "bg-[#F3E0DC] text-[#8A2E25]",
  };
  return <span className={clsx("inline-flex items-center gap-1 rounded-pill px-2.5 py-0.5 text-xs font-medium", tones[tone], className)}>{children}</span>;
}

const GRADE_COLOR: Record<string, string> = { A: "var(--ooak-cond-excellent)", B: "var(--ooak-cond-verygood)", C: "var(--ooak-cond-good)", D: "var(--ooak-cond-fair)" };

/** Condition grade: letter + label (never colour alone). */
export function GradeBadge({ grade, size = "sm", showLabel = true }: { grade: Grade | null; size?: "sm" | "lg"; showLabel?: boolean }) {
  if (!grade) return null;
  return (
    <span className="inline-flex items-center gap-1.5" title={grade.rule}>
      <span
        className={clsx("inline-flex items-center justify-center rounded-full font-display font-semibold text-ivory", size === "lg" ? "h-9 w-9 text-lg" : "h-5 w-5 text-[11px]")}
        style={{ background: GRADE_COLOR[grade.letter] }}
        aria-hidden
      >{grade.letter}</span>
      <span className={clsx(size === "lg" ? "text-base" : "text-xs", "text-ink")}>
        <span className="sr-only">Grade {grade.letter}: </span>{showLabel ? grade.label : <span className="sr-only">{grade.label}</span>}
      </span>
    </span>
  );
}

const STATE_TONE: Record<string, "neutral" | "ink" | "champagne" | "good" | "warn" | "bad"> = {
  PUBLISHED: "good", AVAILABLE: "good", PAID: "good", COMPLETED: "good", DELIVERED: "good", APPROVED: "good", VERIFIED: "good", TRANSFERRED: "good", ACTIVE: "good", SUCCEEDED: "good", RECONCILED: "good", CAPTURED: "good", REFUNDED: "neutral",
  PENDING_REVIEW: "warn", SUBMITTED: "warn", UNDER_REVIEW: "warn", OFFER_MADE: "champagne", RESERVED: "warn", PENDING_PAYMENT: "warn", DOCS_REQUESTED: "warn", CHANGES_REQUESTED: "warn", REQUESTED: "warn", PENDING: "warn", QUEUED: "warn", RUNNING: "warn", IN_TRANSIT: "warn",
  REJECTED: "bad", CANCELLED: "bad", REMOVED: "bad", FAILED: "bad", SUSPENDED: "bad", DISPUTED: "bad", REJECTED_BY_BUYER_TEAM: "bad", REJECTED_BY_SELLER: "bad", EXPIRED: "bad", DECLINED: "bad", LOST_OR_DAMAGED: "bad",
};
export function StatusPill({ state, label }: { state: string; label?: string }) {
  return <Badge tone={STATE_TONE[state] ?? "neutral"}>{label ?? stateLabel(state)}</Badge>;
}
