import clsx from "clsx";
import type { ReactNode } from "react";
import { pkr } from "@/lib/format";

export function Price({ minor, className, size = "md", strike }: { minor: number | null | undefined; className?: string; size?: "sm" | "md" | "lg" | "xl"; strike?: boolean }) {
  const sizes = { sm: "text-sm", md: "text-lg", lg: "text-2xl", xl: "text-4xl" };
  return <span className={clsx("num font-display", sizes[size], strike && "text-muted line-through", className)}>{pkr(minor)}</span>;
}

export function Skeleton({ className }: { className?: string }) {
  return <div className={clsx("animate-pulse rounded-sm bg-ivory-deep", className)} aria-hidden />;
}

export function EmptyState({ title, body, action }: { title: string; body?: ReactNode; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-start gap-3 border-t hairline py-12">
      <h2 className="font-display text-2xl">{title}</h2>
      {body && <div className="max-w-prose text-muted">{body}</div>}
      {action}
    </div>
  );
}

export function SectionHeading({ title, href, linkLabel, sub }: { title: string; href?: string; linkLabel?: string; sub?: string }) {
  return (
    <div className="mb-6 flex items-end justify-between gap-4 border-b hairline pb-3">
      <div>
        <h2 className="font-display text-2xl sm:text-3xl">{title}</h2>
        {sub && <p className="mt-1 text-sm text-muted">{sub}</p>}
      </div>
      {href && <a href={href} className="link shrink-0 text-sm">{linkLabel ?? "View all"}</a>}
    </div>
  );
}

export function Notice({ tone = "info", children, className }: { tone?: "info" | "warn" | "bad" | "good"; children: ReactNode; className?: string }) {
  const tones = { info: "border-stone bg-surface", warn: "border-[#C9A75E] bg-[#FBF5E8]", bad: "border-[#C98A80] bg-[#FBEDEA]", good: "border-[#8FB3A0] bg-[#EEF5F0]" };
  return <div role={tone === "bad" ? "alert" : "status"} className={clsx("rounded-md border-l-4 px-4 py-3 text-[15px]", tones[tone], className)}>{children}</div>;
}

export function Stat({ label, value, sub }: { label: string; value: ReactNode; sub?: ReactNode }) {
  return (
    <div className="rounded-md border hairline bg-surface p-4">
      <div className="text-sm text-muted">{label}</div>
      <div className="mt-1 font-display text-2xl num">{value}</div>
      {sub && <div className="mt-1 text-xs text-muted">{sub}</div>}
    </div>
  );
}

export function Steps({ steps, current }: { steps: string[]; current: number }) {
  return (
    <ol className="flex flex-wrap gap-x-6 gap-y-2 text-sm" aria-label="Progress">
      {steps.map((s, i) => (
        <li key={s} className={clsx("flex items-center gap-2", i === current ? "text-ink" : "text-muted")} aria-current={i === current ? "step" : undefined}>
          <span className={clsx("flex h-6 w-6 items-center justify-center rounded-full border text-xs", i < current ? "border-ink bg-ink text-ivory" : i === current ? "border-ink" : "hairline")}>{i < current ? "✓" : i + 1}</span>
          {s}
        </li>
      ))}
    </ol>
  );
}
