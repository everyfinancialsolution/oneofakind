import clsx from "clsx";
import { useId, type InputHTMLAttributes, type ReactNode, type SelectHTMLAttributes, type TextareaHTMLAttributes } from "react";

const control = "block w-full rounded-md border hairline bg-surface px-3 text-[15px] text-ink placeholder:text-stone-deep focus:border-ink focus:outline-none focus-visible:outline-2 focus-visible:outline-offset-1 aria-[invalid=true]:border-[#8A2E25]";

interface Wrap { label: ReactNode; help?: ReactNode; error?: string | null; className?: string; optional?: boolean }

function FieldWrap({ id, label, help, error, className, optional, children }: Wrap & { id: string; children: ReactNode }) {
  return (
    <div className={clsx("space-y-1.5", className)}>
      <label htmlFor={id} className="block text-sm font-medium">
        {label} {optional && <span className="font-normal text-muted">(optional)</span>}
      </label>
      {children}
      {help && !error && <p id={`${id}-help`} className="text-sm text-muted">{help}</p>}
      {error && <p id={`${id}-err`} className="text-sm text-[#8A2E25]" role="alert">{error}</p>}
    </div>
  );
}

export function TextField({ label, help, error, className, optional, ...rest }: Wrap & InputHTMLAttributes<HTMLInputElement>) {
  const auto = useId();
  const id = rest.id ?? auto;
  return (
    <FieldWrap id={id} label={label} help={help} error={error} className={className} optional={optional}>
      <input id={id} className={clsx(control, "h-11")} aria-invalid={!!error || undefined} aria-describedby={error ? `${id}-err` : help ? `${id}-help` : undefined} {...rest} />
    </FieldWrap>
  );
}

export function TextArea({ label, help, error, className, optional, ...rest }: Wrap & TextareaHTMLAttributes<HTMLTextAreaElement>) {
  const auto = useId();
  const id = rest.id ?? auto;
  return (
    <FieldWrap id={id} label={label} help={help} error={error} className={className} optional={optional}>
      <textarea id={id} className={clsx(control, "min-h-[96px] py-2")} aria-invalid={!!error || undefined} {...rest} />
    </FieldWrap>
  );
}

export function SelectField({ label, help, error, className, optional, children, ...rest }: Wrap & SelectHTMLAttributes<HTMLSelectElement>) {
  const auto = useId();
  const id = rest.id ?? auto;
  return (
    <FieldWrap id={id} label={label} help={help} error={error} className={className} optional={optional}>
      <select id={id} className={clsx(control, "h-11 pr-8")} aria-invalid={!!error || undefined} {...rest}>{children}</select>
    </FieldWrap>
  );
}

export function Checkbox({ label, className, ...rest }: { label: ReactNode; className?: string } & InputHTMLAttributes<HTMLInputElement>) {
  return (
    <label className={clsx("flex cursor-pointer items-start gap-3 text-[15px]", className)}>
      <input type="checkbox" className="mt-1 h-4 w-4 accent-[var(--ooak-ink)]" {...rest} />
      <span>{label}</span>
    </label>
  );
}
