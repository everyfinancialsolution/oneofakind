import Link from "next/link";
import clsx from "clsx";
import type { ButtonHTMLAttributes, ReactNode } from "react";

type Variant = "primary" | "secondary" | "ghost" | "danger" | "link" | "inverse" | "inverseOutline";
type Size = "sm" | "md" | "lg";

const base = "inline-flex items-center justify-center gap-2 rounded-md font-medium transition-colors duration-150 ease-ooak disabled:opacity-50 disabled:cursor-not-allowed select-none whitespace-nowrap";
const variants: Record<Variant, string> = {
  primary: "bg-ink text-ivory hover:bg-ink-soft shadow-[inset_0_-2px_0_var(--ooak-champagne)]",
  secondary: "border border-ink/80 text-ink hover:bg-ink hover:text-ivory",
  ghost: "text-ink hover:bg-ivory-deep",
  danger: "bg-[#8A2E25] text-ivory hover:bg-[#6f241d]",
  inverse: "bg-ivory text-ink hover:bg-ivory-deep",
  inverseOutline: "border border-ivory text-ivory hover:bg-ivory hover:text-ink",
  link: "underline decoration-stone-deep hover:decoration-ink px-0 py-0 rounded-none",
};
const sizes: Record<Size, string> = { sm: "h-9 px-3 text-sm", md: "h-11 px-5 text-[15px]", lg: "h-14 px-7 text-base" };

export function buttonClass(variant: Variant = "primary", size: Size = "md", full = false, className?: string) {
  return clsx(base, variants[variant], variant !== "link" && sizes[size], full && "w-full", className);
}

interface Props extends ButtonHTMLAttributes<HTMLButtonElement> { variant?: Variant; size?: Size; full?: boolean; loading?: boolean; href?: string; children: ReactNode }

export function Button({ variant = "primary", size = "md", full, loading, href, className, children, ...rest }: Props) {
  const cls = buttonClass(variant, size, full, className);
  if (href) return <Link href={href} className={cls}>{children}</Link>;
  return (
    <button className={cls} disabled={loading || rest.disabled} aria-busy={loading || undefined} {...rest}>
      {loading && <span className="h-4 w-4 animate-spin rounded-full border-2 border-current border-r-transparent" aria-hidden />}
      {children}
    </button>
  );
}
