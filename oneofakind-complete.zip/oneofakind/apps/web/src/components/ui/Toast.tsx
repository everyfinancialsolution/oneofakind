"use client";
import { createContext, useCallback, useContext, useState, type ReactNode } from "react";

interface ToastMsg { id: number; text: string; tone: "info" | "good" | "bad" }
const Ctx = createContext<(text: string, tone?: ToastMsg["tone"]) => void>(() => {});

export function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<ToastMsg[]>([]);
  const push = useCallback((text: string, tone: ToastMsg["tone"] = "info") => {
    const id = Date.now() + Math.random();
    setItems((xs) => [...xs, { id, text, tone }]);
    setTimeout(() => setItems((xs) => xs.filter((x) => x.id !== id)), 4500);
  }, []);
  return (
    <Ctx.Provider value={push}>
      {children}
      <div className="pointer-events-none fixed inset-x-0 bottom-4 z-[60] flex flex-col items-center gap-2 px-4" aria-live="polite">
        {items.map((t) => (
          <div key={t.id} className={`pointer-events-auto max-w-md rounded-md px-4 py-3 text-sm shadow-lg ${t.tone === "bad" ? "bg-[#8A2E25] text-ivory" : t.tone === "good" ? "bg-[#2F5D50] text-ivory" : "bg-ink text-ivory"}`}>
            {t.text}
          </div>
        ))}
      </div>
    </Ctx.Provider>
  );
}

export const useToast = () => useContext(Ctx);
