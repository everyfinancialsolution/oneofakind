"use client";
import clsx from "clsx";
import { useEffect, useRef, type ReactNode } from "react";

/** Accessible modal sheet built on <dialog> (focus trap + Esc handled by the browser). */
export function Sheet({ open, onClose, title, children, side = "right", wide }: { open: boolean; onClose: () => void; title: string; children: ReactNode; side?: "right" | "bottom" | "center"; wide?: boolean }) {
  const ref = useRef<HTMLDialogElement>(null);
  useEffect(() => {
    const d = ref.current;
    if (!d) return;
    if (open && !d.open) d.showModal();
    if (!open && d.open) d.close();
  }, [open]);
  const pos = side === "right" ? "ml-auto mr-0 h-full max-h-none my-0 w-full max-w-md" : side === "bottom" ? "mb-0 mt-auto w-full max-w-none" : clsx("m-auto w-[calc(100%-2rem)]", wide ? "max-w-3xl" : "max-w-lg");
  return (
    <dialog ref={ref} onClose={onClose} onClick={(e) => { if (e.target === ref.current) onClose(); }} className={clsx("bg-surface p-0 text-ink backdrop:bg-ink/40", pos, side === "center" && "rounded-md")} aria-label={title}>
      <div className="flex items-center justify-between border-b hairline px-5 py-4">
        <h2 className="font-display text-xl">{title}</h2>
        <button onClick={onClose} className="rounded-md px-2 py-1 text-sm hover:bg-ivory-deep" aria-label="Close">Close</button>
      </div>
      <div className="max-h-[80vh] overflow-y-auto p-5">{children}</div>
    </dialog>
  );
}
