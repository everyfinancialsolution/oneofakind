"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import type { ItemCard } from "@/lib/types";
import { call, ClientApiError } from "@/lib/client";
import { useSession } from "./session";
import { useToast } from "./ui/Toast";
import { Button } from "./ui/Button";
import { S } from "@/lib/strings";

export const RECENT_KEY = "ooak.recent";
export const COMPARE_KEY = "ooak.compare";
const read = <T,>(k: string, d: T): T => { try { return JSON.parse(localStorage.getItem(k) ?? "") as T; } catch { return d; } };
const write = (k: string, v: unknown) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* private mode */ } };

export function TrackRecentlyViewed({ item }: { item: ItemCard }) {
  useEffect(() => {
    const xs = read<ItemCard[]>(RECENT_KEY, []).filter((x) => x.slug !== item.slug);
    write(RECENT_KEY, [item, ...xs].slice(0, 12));
  }, [item]);
  return null;
}

/** Live availability check (the page itself is cached), then add to cart. Items are never reserved by add-to-cart. */
export function AddToCart({ slug, initial }: { slug: string; initial: "AVAILABLE" | "RESERVED" | "SOLD" }) {
  const [availability, setAvailability] = useState(initial);
  const [loading, setLoading] = useState(false);
  const { refreshCart } = useSession();
  const toast = useToast();
  const router = useRouter();
  useEffect(() => {
    fetch(`/v1/listings/${slug}/availability`, { cache: "no-store" }).then((r) => r.json()).then((d) => setAvailability(d.availability)).catch(() => {});
  }, [slug]);
  const add = async () => {
    setLoading(true);
    try {
      await call("/v1/cart/items", { body: { listingSlug: slug } });
      await refreshCart();
      toast("Added to your cart", "good");
      router.push("/cart");
    } catch (e) {
      toast(e instanceof ClientApiError ? e.message : "Could not add to cart", "bad");
    } finally { setLoading(false); }
  };
  if (availability !== "AVAILABLE") {
    return <div className="rounded-md border hairline px-4 py-3 text-[15px]">{availability === "RESERVED" ? "Someone is checking out with this piece right now. If they don't complete payment within 15 minutes it becomes available again." : "This piece has sold. It was one of one."}</div>;
  }
  return <Button size="lg" full onClick={add} loading={loading}>{S.addToCart}</Button>;
}

export function WishlistButton({ slug }: { slug: string }) {
  const { me } = useSession();
  const toast = useToast();
  const router = useRouter();
  const [saved, setSaved] = useState(false);
  useEffect(() => {
    if (!me) return;
    call<{ slugs: string[] }>("/v1/wishlist/slugs").then((r) => setSaved(r.slugs.includes(slug))).catch(() => {});
  }, [me, slug]);
  const toggle = async () => {
    if (!me) { router.push(`/login?next=/product/${slug}`); return; }
    try {
      await call(`/v1/wishlist/${slug}`, { method: saved ? "DELETE" : "PUT" });
      setSaved(!saved);
      toast(saved ? "Removed from saved" : "Saved", "good");
    } catch (e) { toast((e as Error).message, "bad"); }
  };
  return <Button variant="secondary" size="lg" full onClick={toggle} aria-pressed={saved}>{saved ? "Saved ♥" : "Save"}</Button>;
}

export function CompareToggle({ slug }: { slug: string }) {
  const [on, setOn] = useState(false);
  useEffect(() => setOn(read<string[]>(COMPARE_KEY, []).includes(slug)), [slug]);
  const toggle = () => {
    const xs = read<string[]>(COMPARE_KEY, []);
    const next = xs.includes(slug) ? xs.filter((x) => x !== slug) : [...xs, slug].slice(-4);
    write(COMPARE_KEY, next);
    setOn(next.includes(slug));
  };
  return (
    <span className="inline-flex items-center gap-3 text-sm">
      <label className="inline-flex cursor-pointer items-center gap-2"><input type="checkbox" checked={on} onChange={toggle} className="accent-[var(--ooak-ink)]" />Compare</label>
      {on && <a href="/compare" className="link">View comparison</a>}
    </span>
  );
}

export { read as readLocal, write as writeLocal };
