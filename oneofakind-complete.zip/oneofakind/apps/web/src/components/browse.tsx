"use client";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { useState, useTransition } from "react";
import clsx from "clsx";
import type { Facets, ItemCard } from "@/lib/types";
import { ProductGrid } from "./product";
import { Button } from "./ui/Button";
import { EmptyState } from "./ui/misc";
import { S } from "@/lib/strings";

const GRADE_NAMES: Record<string, string> = { A: "A · Excellent", B: "B · Very good", C: "C · Good", D: "D · Fair" };

function useParamsEditor() {
  const router = useRouter();
  const path = usePathname();
  const sp = useSearchParams();
  const [pending, start] = useTransition();
  const set = (patch: Record<string, string | null>) => {
    const next = new URLSearchParams(sp.toString());
    for (const [k, v] of Object.entries(patch)) { if (v === null || v === "") next.delete(k); else next.set(k, v); }
    next.delete("cursor");
    start(() => router.replace(`${path}?${next.toString()}`, { scroll: false }));
  };
  const toggleCsv = (key: string, value: string) => {
    const cur = new Set((sp.get(key) ?? "").split(",").filter(Boolean));
    if (cur.has(value)) cur.delete(value); else cur.add(value);
    set({ [key]: [...cur].join(",") || null });
  };
  const has = (key: string, value: string) => (sp.get(key) ?? "").split(",").includes(value);
  return { sp, set, toggleCsv, has, pending };
}

function FacetGroup({ title, children, defaultOpen = true }: { title: string; children: React.ReactNode; defaultOpen?: boolean }) {
  return (
    <details open={defaultOpen} className="border-b hairline py-4">
      <summary className="cursor-pointer list-none text-sm font-semibold">{title}</summary>
      <div className="mt-3 space-y-2">{children}</div>
    </details>
  );
}

export function Filters({ facets, hideCategory }: { facets: Facets; hideCategory?: boolean }) {
  const { sp, set, toggleCsv, has, pending } = useParamsEditor();
  const [min, setMin] = useState(sp.get("minPrice") ? String(Number(sp.get("minPrice")) / 100) : "");
  const [max, setMax] = useState(sp.get("maxPrice") ? String(Number(sp.get("maxPrice")) / 100) : "");
  const active = ["brand", "size", "grade", "color", "minPrice", "maxPrice", "managed"].some((k) => sp.get(k));
  void hideCategory;
  return (
    <aside aria-label="Filters" className={clsx("text-sm", pending && "opacity-60")}>
      <div className="flex items-center justify-between pb-2">
        <h2 className="font-body text-sm font-semibold">Filter</h2>
        {active && <button className="link text-xs" onClick={() => set({ brand: null, size: null, grade: null, color: null, minPrice: null, maxPrice: null, managed: null })}>Clear all</button>}
      </div>
      {facets.grades.length > 0 && (
        <FacetGroup title="Condition grade">
          {facets.grades.map((g) => (
            <label key={g.value} className="flex items-center gap-2"><input type="checkbox" checked={has("grade", g.value)} onChange={() => toggleCsv("grade", g.value)} className="accent-[var(--ooak-ink)]" />{GRADE_NAMES[g.value]} <span className="text-muted">({g.count})</span></label>
          ))}
        </FacetGroup>
      )}
      {facets.sizes.length > 0 && (
        <FacetGroup title="Size">
          <div className="flex flex-wrap gap-2">
            {facets.sizes.map((s) => (
              <button key={s.value} onClick={() => toggleCsv("size", s.value)} aria-pressed={has("size", s.value)}
                className={clsx("rounded-pill border px-3 py-1 text-xs", has("size", s.value) ? "border-ink bg-ink text-ivory" : "hairline hover:border-ink")}>{s.value}</button>
            ))}
          </div>
          <p className="text-xs text-muted">Sizes vary between brands and decades. Check the measurements on each piece.</p>
        </FacetGroup>
      )}
      <FacetGroup title="Price (PKR)">
        <form className="flex items-end gap-2" onSubmit={(e) => { e.preventDefault(); set({ minPrice: min ? String(Math.round(Number(min) * 100)) : null, maxPrice: max ? String(Math.round(Number(max) * 100)) : null }); }}>
          <label className="flex-1"><span className="sr-only">Minimum price</span><input inputMode="numeric" value={min} onChange={(e) => setMin(e.target.value.replace(/\D/g, ""))} placeholder="Min" className="h-9 w-full rounded-md border hairline bg-surface px-2" /></label>
          <label className="flex-1"><span className="sr-only">Maximum price</span><input inputMode="numeric" value={max} onChange={(e) => setMax(e.target.value.replace(/\D/g, ""))} placeholder="Max" className="h-9 w-full rounded-md border hairline bg-surface px-2" /></label>
          <button className="h-9 rounded-md border border-ink px-3 text-xs">Go</button>
        </form>
      </FacetGroup>
      {facets.brands.length > 0 && (
        <FacetGroup title="Brand" defaultOpen={facets.brands.length < 12}>
          {facets.brands.map((b) => (
            <label key={b.slug} className="flex items-center gap-2"><input type="checkbox" checked={has("brand", b.slug)} onChange={() => toggleCsv("brand", b.slug)} className="accent-[var(--ooak-ink)]" />{b.name} <span className="text-muted">({b.count})</span></label>
          ))}
        </FacetGroup>
      )}
      {facets.colors.length > 0 && (
        <FacetGroup title="Colour" defaultOpen={false}>
          {facets.colors.map((c) => (
            <label key={c.value} className="flex items-center gap-2"><input type="checkbox" checked={has("color", c.value)} onChange={() => toggleCsv("color", c.value)} className="accent-[var(--ooak-ink)]" />{c.value} <span className="text-muted">({c.count})</span></label>
          ))}
        </FacetGroup>
      )}
      <FacetGroup title="Handling">
        <label className="flex items-center gap-2"><input type="checkbox" checked={sp.get("managed") === "true"} onChange={(e) => set({ managed: e.target.checked ? "true" : null })} className="accent-[var(--ooak-ink)]" />Inspected by ONEOFAKIND</label>
      </FacetGroup>
    </aside>
  );
}

export function SortSelect({ withRelevance }: { withRelevance?: boolean }) {
  const { sp, set } = useParamsEditor();
  return (
    <label className="flex items-center gap-2 text-sm">
      <span className="text-muted">Sort</span>
      <select value={sp.get("sort") ?? (withRelevance ? "relevance" : "newest")} onChange={(e) => set({ sort: e.target.value })} className="h-9 rounded-md border hairline bg-surface px-2">
        {withRelevance && <option value="relevance">Best match</option>}
        <option value="newest">Newest</option>
        <option value="price_asc">Price: low to high</option>
        <option value="price_desc">Price: high to low</option>
      </select>
    </label>
  );
}

/** Appends further pages client-side (cursor pagination). */
export function Results({ initial, nextCursor, query }: { initial: ItemCard[]; nextCursor: string | null; query: string }) {
  const [items, setItems] = useState(initial);
  const [cursor, setCursor] = useState(nextCursor);
  const [loading, setLoading] = useState(false);
  const [lastQuery, setLastQuery] = useState(query);
  if (query !== lastQuery) { setItems(initial); setCursor(nextCursor); setLastQuery(query); }
  const more = async () => {
    if (!cursor) return;
    setLoading(true);
    try {
      const r = await fetch(`/v1/listings?${query}${query ? "&" : ""}cursor=${encodeURIComponent(cursor)}`);
      const d = (await r.json()) as { items: ItemCard[]; nextCursor: string | null };
      setItems((xs) => [...xs, ...d.items]);
      setCursor(d.nextCursor);
    } finally { setLoading(false); }
  };
  if (!items.length) return <EmptyState title="No pieces found" body={S.emptySearch} />;
  return (
    <div>
      <ProductGrid items={items} priorityCount={2} cols={3} />
      {cursor && <div className="mt-12 flex justify-center"><Button variant="secondary" onClick={more} loading={loading}>Load more</Button></div>}
    </div>
  );
}

export function MobileFilters({ facets }: { facets: Facets }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="lg:hidden">
      <Button variant="secondary" size="sm" onClick={() => setOpen((x) => !x)} aria-expanded={open}>{open ? "Hide filters" : "Filters"}</Button>
      {open && <div className="mt-4 rounded-md border hairline bg-surface p-4"><Filters facets={facets} /></div>}
    </div>
  );
}
