import type { BundlePiece } from "@/lib/types";
import { measureLabel, measureValue } from "@/lib/format";
import { GradeBadge } from "./ui/Badge";
import { ProductImage } from "./product";

/** Contact sheet: EVERY piece of the lot with photo, grade, size and measurements. No carousel hides pieces. */
export function BundleLotSheet({ pieces }: { pieces: BundlePiece[] }) {
  return (
    <ol className="grid grid-cols-2 gap-x-4 gap-y-8 sm:grid-cols-3 lg:grid-cols-5" aria-label={`${pieces.length} pieces in this lot`}>
      {pieces.map((p) => (
        <li key={p.sku} className="text-sm">
          <div className="relative">
            <ProductImage img={p.images[0] ?? null} />
            <span className="absolute left-1.5 top-1.5 rounded-pill bg-ivory px-2 py-0.5 text-[11px] num">{p.position}/{pieces.length}</span>
          </div>
          <div className="mt-2 flex items-center justify-between">
            <span className="font-medium">{p.size ?? "-"}</span>
            <GradeBadge grade={p.grade} />
          </div>
          <div className="text-xs text-muted">{p.color}</div>
          {p.measurements && (
            <dl className="mt-1 grid grid-cols-[auto_1fr] gap-x-2 text-xs">
              {Object.entries(p.measurements).map(([k, v]) => (
                <div key={k} className="contents"><dt className="text-muted">{measureLabel(k)}</dt><dd className="num text-right">{measureValue(k, v)}</dd></div>
              ))}
            </dl>
          )}
          {p.defects.length > 0 && <p className="mt-1 text-xs text-[#7A5A1F]">Noted: {p.defects.map((d) => `${d.type} (${d.location})`).join(", ")}</p>}
        </li>
      ))}
    </ol>
  );
}
