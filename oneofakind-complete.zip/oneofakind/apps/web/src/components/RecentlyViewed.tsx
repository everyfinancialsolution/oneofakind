"use client";
import { useEffect, useState } from "react";
import type { ItemCard } from "@/lib/types";
import { ProductGrid } from "./product";
import { RECENT_KEY, readLocal } from "./ProductActions";
import { SectionHeading } from "./ui/misc";

export function RecentlyViewed() {
  const [items, setItems] = useState<ItemCard[]>([]);
  useEffect(() => setItems(readLocal<ItemCard[]>(RECENT_KEY, []).slice(0, 4)), []);
  if (!items.length) return null;
  return <section className="mt-14"><SectionHeading title="Recently viewed" /><ProductGrid items={items} /></section>;
}
