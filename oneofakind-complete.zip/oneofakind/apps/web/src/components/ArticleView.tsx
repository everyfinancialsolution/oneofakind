import type { Article } from "@/lib/content";

export function ArticleView({ a }: { a: Article }) {
  return (
    <article className="mx-auto max-w-2xl space-y-6">
      <header><h1 className="font-display text-display-lg">{a.title}</h1><p className="mt-2 text-muted">{a.summary}</p></header>
      {a.sections.map((s, i) => (
        <section key={i} className="space-y-3">
          {s.heading && <h2 className="font-display text-2xl">{s.heading}</h2>}
          {s.body.map((p, j) => <p key={j} className="text-[16px] leading-relaxed">{p}</p>)}
        </section>
      ))}
    </article>
  );
}
