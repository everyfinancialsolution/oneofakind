"use client";
import Link from "next/link";
import { useEffect, useState, type FormEvent } from "react";
import { call, ClientApiError } from "@/lib/client";
import { stateLabel } from "@/lib/format";
import { useSession } from "./session";
import { Button } from "./ui/Button";
import { SelectField, TextField } from "./ui/Field";
import { Notice, Steps } from "./ui/misc";
import { StatusPill } from "./ui/Badge";
import { S } from "@/lib/strings";

type Kind = "SELLER" | "RESELLER";
interface App {
  reference: string; kind: Kind; status: string; fullName: string; phone: string; email: string | null; city: string | null; businessName: string | null; shopLink: string | null;
  intendedSellerType: string | null; decisionNote: string | null; documents: Array<{ id: string; kind: string; verified: boolean; rejectedReason: string | null }>; missing: string[];
}

const DOC_LABELS: Record<string, { title: string; help: string }> = {
  ID_FRONT: { title: "National ID card (front)", help: "A clear photo, all four corners visible." },
  ID_BACK: { title: "National ID card (back)", help: "A clear photo, all four corners visible." },
  PAYOUT_ACCOUNT_PROOF: { title: "Bank or wallet account in your own name", help: "A screenshot or photo showing the account title. It must match the name on your ID." },
  SHOP_PROOF: { title: "Proof of your shop", help: "A photo of your shop or signboard, or a screenshot of your online store/social page." },
  BUSINESS_REG: { title: "Business registration or NTN (optional)", help: "Only if you have one." },
};
const REQUIRED: Record<Kind, string[]> = { SELLER: ["ID_FRONT", "ID_BACK", "PAYOUT_ACCOUNT_PROOF"], RESELLER: ["ID_FRONT", "ID_BACK", "SHOP_PROOF"] };

export function WhatsAppApplyButton({ kind }: { kind: Kind }) {
  const [busy, setBusy] = useState(false);
  const go = async () => {
    setBusy(true);
    const win = window.open("", "_blank");
    try {
      const r = await call<{ reference: string; link: string }>("/v1/onboarding/whatsapp-reference", { body: { kind } });
      if (win) win.location.href = r.link; else window.location.href = r.link;
    } catch { win?.close(); } finally { setBusy(false); }
  };
  return <Button variant="secondary" onClick={go} loading={busy}>{S.whatsappApply}</Button>;
}

export function ApplyFlow({ kind }: { kind: Kind }) {
  const { me, loading, refresh } = useSession();
  const [app, setApp] = useState<App | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [step, setStep] = useState(0);

  useEffect(() => {
    if (loading || !me) return;
    call<App>("/v1/onboarding/applications", { body: { kind } }).then((a) => { setApp(a); if (a.status !== "DRAFT" && a.status !== "DOCS_REQUESTED") setStep(3); else if (a.city) setStep(1); })
      .catch((e: ClientApiError) => setErr(e.message));
  }, [me, loading, kind]);

  if (loading) return <p className="text-muted">Loading…</p>;
  if (!me) {
    return (
      <div className="space-y-4 rounded-md border hairline bg-surface p-6">
        <p className="text-[15px]">First, confirm your phone number. It takes a few seconds and becomes your login.</p>
        <div className="flex flex-wrap gap-3"><Button href={`/login?next=/${kind === "SELLER" ? "seller" : "reseller"}/apply`}>Continue with phone number</Button><WhatsAppApplyButton kind={kind} /></div>
      </div>
    );
  }
  if (err && !app) return <Notice tone="bad">{err} {err.includes("already") && <Link className="link" href={kind === "SELLER" ? "/seller" : "/bundles"}>Go there</Link>}</Notice>;
  if (!app) return <p className="text-muted">Loading your application…</p>;

  const saveDetails = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault(); setErr(null); setBusy(true);
    const fd = new FormData(e.currentTarget);
    const body = Object.fromEntries([...fd.entries()].map(([k, v]) => [k, String(v).trim() || null]));
    try { setApp(await call<App>(`/v1/onboarding/applications/${app.reference}`, { method: "PATCH", body })); setStep(1); }
    catch (x) { setErr((x as Error).message); } finally { setBusy(false); }
  };
  const uploadDoc = async (docKind: string, file: File) => {
    setErr(null); setBusy(true);
    const fd = new FormData(); fd.set("kind", docKind); fd.set("file", file);
    try { setApp(await call<App>(`/v1/onboarding/applications/${app.reference}/documents`, { form: fd })); }
    catch (x) { setErr((x as Error).message); } finally { setBusy(false); }
  };
  const submit = async () => {
    setErr(null); setBusy(true);
    try { setApp(await call<App>(`/v1/onboarding/applications/${app.reference}/submit`, { method: "POST" })); setStep(3); await refresh(); }
    catch (x) { setErr((x as Error).message); } finally { setBusy(false); }
  };
  const docs = [...REQUIRED[kind], ...(kind === "RESELLER" ? ["BUSINESS_REG"] : [])];
  const have = (k: string) => app.documents.find((d) => d.kind === k && !d.rejectedReason);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <Steps steps={["Your details", "Documents", "Check and send", "Review"]} current={step} />
        <span className="text-sm text-muted">Reference <strong className="num text-ink">{app.reference}</strong></span>
      </div>
      {err && <Notice tone="bad">{err}</Notice>}
      {app.status === "DOCS_REQUESTED" && <Notice tone="warn">We need something more: {app.decisionNote}</Notice>}

      {step === 0 && (
        <form onSubmit={saveDetails} className="grid gap-4 sm:grid-cols-2">
          <TextField name="fullName" label="Full name (as on your ID)" defaultValue={app.fullName} required className="sm:col-span-2" />
          <TextField name="city" label="City" defaultValue={app.city ?? ""} required />
          <TextField name="email" type="email" label="Email" optional defaultValue={app.email ?? ""} />
          <TextField name="businessName" label={kind === "SELLER" ? "Shop or store name" : "Business name"} optional={kind === "SELLER"} required={kind === "RESELLER"} defaultValue={app.businessName ?? ""} help={kind === "SELLER" ? "Shown on your storefront. Leave empty to use your name." : undefined} />
          <TextField name="shopLink" type="url" label="Shop or social link" optional defaultValue={app.shopLink ?? ""} placeholder="https://instagram.com/…" />
          {kind === "SELLER" && (
            <SelectField name="intendedSellerType" label="You are…" defaultValue={app.intendedSellerType ?? "INDIVIDUAL"}>
              <option value="INDIVIDUAL">An individual selling my own clothes</option><option value="RESELLER">A thrift reseller</option><option value="BUSINESS">A registered business</option>
            </SelectField>
          )}
          <div className="sm:col-span-2"><Button type="submit" loading={busy}>Save and continue</Button></div>
        </form>
      )}

      {step === 1 && (
        <div className="space-y-4">
          <p className="text-[15px] text-muted">Take a photo with your phone or choose one from your gallery. Documents are private: only our onboarding team can see them, and images are deleted 90 days after we decide.</p>
          <ul className="space-y-3">
            {docs.map((k) => (
              <li key={k} className="flex flex-col gap-3 rounded-md border hairline bg-surface p-4 sm:flex-row sm:items-center sm:justify-between">
                <div><p className="font-medium">{DOC_LABELS[k]!.title}</p><p className="text-sm text-muted">{DOC_LABELS[k]!.help}</p></div>
                <div className="flex items-center gap-3">
                  {have(k) ? <span className="text-sm text-[#2F5D50]">✓ Received</span> : app.documents.find((d) => d.kind === k)?.rejectedReason ? <span className="text-sm text-[#8A2E25]">Please upload again</span> : null}
                  <label className="inline-flex h-10 cursor-pointer items-center rounded-md border border-ink px-4 text-sm hover:bg-ink hover:text-ivory">
                    {have(k) ? "Replace" : "Add photo"}
                    <input type="file" accept="image/*,application/pdf" className="sr-only" disabled={busy} onChange={(e) => { const f = e.target.files?.[0]; if (f) void uploadDoc(k, f); e.target.value = ""; }} />
                  </label>
                </div>
              </li>
            ))}
          </ul>
          <div className="flex gap-3"><Button variant="ghost" onClick={() => setStep(0)}>Back</Button><Button onClick={() => setStep(2)} disabled={app.missing.length > 0}>Continue</Button></div>
          {app.missing.length > 0 && <p className="text-sm text-muted">Still needed: {app.missing.map((m) => DOC_LABELS[m]?.title ?? m).join(", ")}.</p>}
        </div>
      )}

      {step === 2 && (
        <div className="space-y-4">
          <dl className="grid gap-2 rounded-md border hairline bg-surface p-4 text-[15px] sm:grid-cols-2">
            <div><dt className="text-sm text-muted">Name</dt><dd>{app.fullName}</dd></div>
            <div><dt className="text-sm text-muted">Phone</dt><dd className="num">{app.phone}</dd></div>
            <div><dt className="text-sm text-muted">City</dt><dd>{app.city}</dd></div>
            <div><dt className="text-sm text-muted">Business</dt><dd>{app.businessName ?? "-"}</dd></div>
            <div className="sm:col-span-2"><dt className="text-sm text-muted">Documents</dt><dd>{app.documents.map((d) => DOC_LABELS[d.kind]?.title ?? d.kind).join(" · ")}</dd></div>
          </dl>
          <p className="text-sm text-muted">By sending, you agree to our <Link href="/policies/seller-terms" className="link">seller terms</Link>{kind === "SELLER" ? ", including that payouts go only to an account in your own name" : ""}.</p>
          <div className="flex gap-3"><Button variant="ghost" onClick={() => setStep(1)}>Back</Button><Button onClick={submit} loading={busy}>Send application</Button></div>
        </div>
      )}

      {step === 3 && (
        <div className="space-y-3 rounded-md border hairline bg-surface p-6">
          <div className="flex items-center gap-3"><StatusPill state={app.status} /><span className="text-sm text-muted">{stateLabel(app.status)}</span></div>
          {app.status === "APPROVED" ? (
            <p className="text-[15px]">You're approved. {kind === "SELLER" ? <Link href="/seller" className="link">Open your seller hub</Link> : <Link href="/bundles" className="link">See bundle prices</Link>}</p>
          ) : app.status === "REJECTED" ? (
            <p className="text-[15px]">Your application was not approved: {app.decisionNote}. You can apply again, or message us on WhatsApp.</p>
          ) : (
            <p className="text-[15px]">Thank you. we've received your application. We reply within 2 working days, usually sooner. We'll send you an SMS. Quote <strong className="num">{app.reference}</strong> if you message us.</p>
          )}
        </div>
      )}
    </div>
  );
}
