"use client";
import Link from "next/link";
import { useEffect, useState } from "react";
import type { ItemDetail } from "@/lib/types";
import { COMPARE_KEY, readLocal, writeLocal } from "./ProductActions";
import { ProductImage } from "./product";
import { GradeBadge } from "./ui/Badge";
import { EmptyState, Price } from "./ui/misc";
import { measureLabel, measureValue } from "@/lib/format";

export function CompareTable() {
  const [items, setItems] = useState<ItemDetail[] | null>(null);
  useEffect(() => {
    const slugs = readLocal<string[]>(COMPARE_KEY, []);
    Promise.all(slugs.map((s) => fetch(`/v1/listings/${s}`).then((r) => (r.ok ? r.json() : null)).catch(() => null)))
      .then((rs) => setItems(rs.filter(Boolean).map((r) => r.item as ItemDetail)));
  }, []);
  const remove = (slug: string) => {
    writeLocal(COMPARE_KEY, readLocal<string[]>(COMPARE_KEY, []).filter((s) => s !== slug));
    setItems((xs) => xs?.filter((x) => x.slug !== slug) ?? null);
  };
  if (items === null) return <p className="mt-10 text-muted">Loading…</p>;
  if (!items.length) return <EmptyState title="Nothing to compare yet" body="Tick “Compare” on up to four product pages." action={<Link href="/shop" className="link">Browse pieces</Link>} />;
  const keys = [...new Set(items.flatMap((i) => Object.keys(i.measurements ?? {})))];
  const row = (label: string, render: (i: ItemDetail) => React.ReactNode) => (
    <tr className="border-b hairline"><th scope="row" className="w-40 py-3 pr-4 text-left text-sm font-normal text-muted">{label}</th>{items.map((i) => <td key={i.slug} className="py-3 pr-4 align-top text-[15px]">{render(i)}</td>)}</tr>
  );
  return (
    <div className="mt-10 overflow-x-auto">
      <table className="w-full min-w-[640px] table-fixed">
        <thead><tr><th className="w-40" />{items.map((i) => (
          <th key={i.slug} className="pb-4 pr-4 text-left align-top font-normal">
            <Link href={`/product/${i.slug}`}><ProductImage img={i.images[0] ?? null} /></Link>
            <Link href={`/product/${i.slug}`} className="mt-2 block text-[15px] hover:underline">{i.title}</Link>
            <button onClick={() => remove(i.slug)} className="link mt-1 text-xs">Remove</button>
          </th>
        ))}</tr></thead>
        <tbody>
          {row("Price", (i) => <Price minor={i.priceMinor} />)}
          {row("Availability", (i) => (i.availability === "AVAILABLE" ? "Available" : i.availability === "RESERVED" ? "Reserved" : "Sold"))}
          {row("Grade", (i) => <GradeBadge grade={i.grade} />)}
          {row("Flaws noted", (i) => (i.condition?.defects.length ? i.condition.defects.map((d) => d.type).join(", ") : "None"))}
          {row("Size", (i) => i.size)}
          {keys.map((k) => row(measureLabel(k), (i) => (i.measurements?.[k] !== undefined ? measureValue(k, i.measurements[k]!) : "-")))}
          {row("Ships from", (i) => i.fulfilment.shipsFrom)}
          {row("Delivery", (i) => i.fulfilment.deliveryEstimate)}
        </tbody>
      </table>
    </div>
  );
}
