"use client";
import { Suspense } from "react";
import { Canvas } from "@react-three/fiber";
import { Bounds, ContactShadows, OrbitControls, useGLTF } from "@react-three/drei";

function Model({ url }: { url: string }) {
  const { scene } = useGLTF(url);
  return <primitive object={scene} />;
}

/** Interactive viewer for a published ASSET_3D (GLB, ≤3 MB budget). Lazy-loaded; respects reduced motion (no auto-rotate). */
export function Model3DViewer({ url, title }: { url: string; title: string }) {
  const reduce = typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  return (
    <figure className="overflow-hidden rounded-sm border hairline bg-ivory-deep">
      <div className="aspect-square w-full" role="img" aria-label={`3D model of ${title}. Drag to rotate.`}>
        <Canvas camera={{ position: [0, 0.4, 2.2], fov: 40 }} dpr={[1, 2]}>
          <ambientLight intensity={0.6} />
          <Suspense fallback={null}>
            <Bounds fit clip observe margin={1.2}><Model url={url} /></Bounds>
            <ContactShadows position={[0, -0.6, 0]} opacity={0.35} blur={2.5} />
            <directionalLight position={[2, 3, 2]} intensity={1.2} /><directionalLight position={[-2, 1, -1]} intensity={0.4} />
          </Suspense>
          <OrbitControls autoRotate={!reduce} autoRotateSpeed={0.6} enablePan={false} />
        </Canvas>
      </div>
      <figcaption className="px-3 py-2 text-xs text-muted">3D model · drag to rotate, pinch to zoom</figcaption>
    </figure>
  );
}
