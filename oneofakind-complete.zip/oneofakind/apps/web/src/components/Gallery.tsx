"use client";
import { useState, type KeyboardEvent } from "react";
import clsx from "clsx";
import type { Img } from "@/lib/types";
import { ProductImage } from "./product";

export function Gallery({ images, title }: { images: Img[]; title: string }) {
  const [i, setI] = useState(0);
  if (!images.length) return <ProductImage img={null} />;
  const onKey = (e: KeyboardEvent) => {
    if (e.key === "ArrowRight") setI((x) => (x + 1) % images.length);
    if (e.key === "ArrowLeft") setI((x) => (x - 1 + images.length) % images.length);
  };
  return (
    <div className="flex flex-col-reverse gap-3 lg:flex-row" onKeyDown={onKey}>
      <div className="flex gap-2 overflow-x-auto lg:w-20 lg:flex-col" role="tablist" aria-label={`${title} photos`}>
        {images.map((img, idx) => (
          <button key={img.id} role="tab" aria-selected={idx === i} aria-label={`Photo ${idx + 1}`} onClick={() => setI(idx)}
            className={clsx("w-16 shrink-0 overflow-hidden rounded-sm border-2 lg:w-full", idx === i ? "border-ink" : "border-transparent opacity-70 hover:opacity-100")}>
            <ProductImage img={img} />
          </button>
        ))}
      </div>
      <div className="flex-1" role="tabpanel" tabIndex={0} aria-label={`Photo ${i + 1} of ${images.length}. Use arrow keys to browse.`}>
        <ProductImage img={images[i]!} priority sizes="(min-width: 1024px) 55vw, 100vw" className="animate-plate" />
        <p className="mt-2 text-xs text-muted num">{i + 1} / {images.length}</p>
      </div>
    </div>
  );
}
