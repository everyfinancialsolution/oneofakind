"use client";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { useState, type FormEvent } from "react";
import { call, ClientApiError } from "@/lib/client";
import { useSession } from "./session";
import { Button } from "./ui/Button";
import { Checkbox, TextField } from "./ui/Field";
import { Notice } from "./ui/misc";

interface ReqResp { phone: string; expiresInSec: number; devCode?: string; isNewAccount: boolean; needsActivation: boolean }

/** One phone-number + code login for buyers, sellers, verified resellers and staff. No passwords. */
export function LoginForm({ heading = "Log in or create an account", activation }: { heading?: string; activation?: boolean }) {
  const router = useRouter();
  const sp = useSearchParams();
  const { refresh, refreshCart } = useSession();
  const [step, setStep] = useState<"phone" | "code">("phone");
  const [phone, setPhone] = useState("");
  const [req, setReq] = useState<ReqResp | null>(null);
  const [code, setCode] = useState("");
  const [name, setName] = useState("");
  const [terms, setTerms] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const next = sp.get("next");
  const safeNext = next && next.startsWith("/") && !next.startsWith("//") ? next : "/account";

  const sendCode = async (e?: FormEvent) => {
    e?.preventDefault(); setErr(null); setBusy(true);
    try { const r = await call<ReqResp>("/v1/auth/otp/request", { body: { phone } }); setReq(r); setStep("code"); }
    catch (x) { setErr((x as Error).message); } finally { setBusy(false); }
  };
  const verify = async (e: FormEvent) => {
    e.preventDefault(); setErr(null); setBusy(true);
    try {
      await call("/v1/auth/otp/verify", { body: { phone, code, ...(name ? { name } : {}), ...(terms ? { acceptTerms: true } : {}) } });
      await refresh(); await refreshCart();
      router.replace(safeNext); router.refresh();
    } catch (x) {
      const ex = x as ClientApiError;
      if (ex.code === "TERMS_REQUIRED" || ex.code === "NAME_REQUIRED") setReq((r) => (r ? { ...r, isNewAccount: ex.code === "NAME_REQUIRED" || r.isNewAccount, needsActivation: true } : r));
      setErr(ex.message);
    } finally { setBusy(false); }
  };
  const needsName = !!req?.isNewAccount;
  const needsTerms = !!req && (req.isNewAccount || req.needsActivation);

  return (
    <div className="mx-auto max-w-md space-y-6">
      <div>
        <h1 className="font-display text-display-lg">{heading}</h1>
        <p className="mt-2 text-muted">{activation ? "Our team registered you. Confirm your phone number to activate your account. We never know or set your login." : "We'll send a 6-digit code to your phone. No passwords to remember."}</p>
      </div>
      {err && <Notice tone="bad">{err}</Notice>}
      {step === "phone" ? (
        <form onSubmit={sendCode} className="space-y-4">
          <TextField label="Mobile number" type="tel" inputMode="tel" autoComplete="tel" placeholder="0300 1234567" value={phone} onChange={(e) => setPhone(e.target.value)} required help="Pakistani mobile numbers only." />
          <Button type="submit" full size="lg" loading={busy}>Send code</Button>
        </form>
      ) : (
        <form onSubmit={verify} className="space-y-4">
          <p className="text-[15px]">Code sent to <strong className="num">{req?.phone}</strong>. <button type="button" className="link text-sm" onClick={() => { setStep("phone"); setCode(""); }}>Change number</button></p>
          {req?.devCode && <Notice tone="warn">Development mode: your code is <strong className="num">{req.devCode}</strong>. (Real codes arrive by SMS.)</Notice>}
          <TextField label="6-digit code" inputMode="numeric" autoComplete="one-time-code" pattern="\d{6}" maxLength={6} value={code} onChange={(e) => setCode(e.target.value.replace(/\D/g, ""))} required autoFocus />
          {needsName && <TextField label="Your name" autoComplete="name" value={name} onChange={(e) => setName(e.target.value)} required minLength={2} />}
          {needsTerms && <Checkbox checked={terms} onChange={(e) => setTerms(e.target.checked)} required label={<>I agree to the <Link href="/policies/terms" className="link" target="_blank">Terms</Link> and <Link href="/policies/privacy" className="link" target="_blank">Privacy Policy</Link>.</>} />}
          <Button type="submit" full size="lg" loading={busy}>{needsName ? "Create account" : activation ? "Activate account" : "Log in"}</Button>
          <button type="button" className="link text-sm" onClick={() => sendCode()} disabled={busy}>Send a new code</button>
        </form>
      )}
      <p className="text-sm text-muted">Never share your code. Our team will never ask for it, not on WhatsApp and not on the phone.</p>
    </div>
  );
}
