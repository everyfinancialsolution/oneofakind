"use client";
import type { ReactNode } from "react";
import { whatsappLink } from "@ooak/shared";
import { useSession } from "./session";
import { buttonClass } from "./ui/Button";

/** wa.me deep link to the onboarding/support number from config (never hard-coded). */
export function WhatsAppLink({ message, children, className, button }: { message: string; children: ReactNode; className?: string; button?: "primary" | "secondary" }) {
  const { config } = useSession();
  const href = config ? whatsappLink(config.whatsappNumber, message) : "#";
  return (
    <a href={href} target="_blank" rel="noopener noreferrer" className={button ? buttonClass(button, "md", false, className) : className} aria-disabled={!config}>
      {children}
    </a>
  );
}

export function ShareOnWhatsApp({ title, path }: { title: string; path: string }) {
  const url = `${process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000"}${path}`;
  return (
    <a href={`https://wa.me/?text=${encodeURIComponent(`${title} ${url}`)}`} target="_blank" rel="noopener noreferrer" className="link text-sm">Share on WhatsApp</a>
  );
}
