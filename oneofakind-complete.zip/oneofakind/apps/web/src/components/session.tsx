"use client";
import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from "react";
import type { Me } from "@/lib/types";

interface PublicConfig { whatsappNumber: string; whatsappHelpLink: string; features: Record<string, boolean> }
interface SessionCtx {
  me: Me["user"]; loading: boolean; refresh: () => Promise<void>;
  cartCount: number; setCartCount: (n: number) => void; refreshCart: () => Promise<void>;
  config: PublicConfig | null;
  has: (...roles: string[]) => boolean;
}
const Ctx = createContext<SessionCtx>({
  me: null, loading: true, refresh: async () => {}, cartCount: 0, setCartCount: () => {}, refreshCart: async () => {}, config: null, has: () => false,
});

/** Personalisation is client-side so public pages stay statically cacheable (and never cache prices or names). */
export function SessionProvider({ children }: { children: ReactNode }) {
  const [me, setMe] = useState<Me["user"]>(null);
  const [loading, setLoading] = useState(true);
  const [cartCount, setCartCount] = useState(0);
  const [config, setConfig] = useState<PublicConfig | null>(null);

  const refresh = useCallback(async () => {
    try {
      const r = await fetch("/v1/auth/me", { credentials: "same-origin", cache: "no-store" });
      setMe(r.ok ? ((await r.json()) as Me).user : null);
    } catch { setMe(null); } finally { setLoading(false); }
  }, []);
  const refreshCart = useCallback(async () => {
    try {
      const r = await fetch("/v1/cart", { credentials: "same-origin", cache: "no-store" });
      if (r.ok) { const c = (await r.json()) as { lines: unknown[] }; setCartCount(c.lines.length); }
    } catch { /* offline */ }
  }, []);
  useEffect(() => {
    void refresh(); void refreshCart();
    fetch("/v1/content/config").then((r) => (r.ok ? r.json() : null)).then(setConfig).catch(() => {});
  }, [refresh, refreshCart]);
  const has = useCallback((...roles: string[]) => !!me?.roles.some((r) => roles.includes(r)), [me]);
  return <Ctx.Provider value={{ me, loading, refresh, cartCount, setCartCount, refreshCart, config, has }}>{children}</Ctx.Provider>;
}

export const useSession = () => useContext(Ctx);
