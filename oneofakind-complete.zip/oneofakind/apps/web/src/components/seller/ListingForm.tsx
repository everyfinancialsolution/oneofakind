"use client";
import { useEffect, useMemo, useState } from "react";
import clsx from "clsx";
import { GRADE_CRITERIA } from "@ooak/shared";
import type { Category } from "@/lib/types";
import { measureLabel } from "@/lib/format";
import { SelectField, TextArea, TextField } from "../ui/Field";

export interface ListingValues {
  title: string; categoryId: string; brandName: string; styleId: string; size: string; color: string; material: string;
  measurements: Record<string, string>; conditionGrade: string; defects: Array<{ type: string; location: string; severity: string }>;
  description: string; priceRupees: string; weightGrams: string;
}
export const emptyListing: ListingValues = { title: "", categoryId: "", brandName: "", styleId: "", size: "", color: "", material: "", measurements: {}, conditionGrade: "", defects: [], description: "", priceRupees: "", weightGrams: "" };

/** Converts form strings to the API payload (money in minor units; measurements as numbers). */
export function toPayload(v: ListingValues) {
  const m: Record<string, number> = {};
  for (const [k, x] of Object.entries(v.measurements)) if (x !== "" && !Number.isNaN(Number(x))) m[k] = Number(x);
  return {
    title: v.title.trim(), categoryId: v.categoryId, brandName: v.brandName.trim() || null, styleId: v.styleId || null, size: v.size.trim() || null,
    color: v.color.trim() || null, material: v.material.trim() || null, measurements: m, conditionGrade: v.conditionGrade || undefined,
    defects: v.defects.filter((d) => d.type.trim()), description: v.description.trim() || null,
    priceMinor: Math.round(Number(v.priceRupees || 0) * 100), weightGrams: v.weightGrams ? Number(v.weightGrams) : null,
  };
}

const GRADES = [
  { code: "NEW_WITH_TAGS", letter: "A", label: "New with tags" }, { code: "EXCELLENT", letter: "A", label: "Excellent" },
  { code: "VERY_GOOD", letter: "B", label: "Very good" }, { code: "GOOD", letter: "C", label: "Good" }, { code: "FAIR", letter: "D", label: "Fair" },
] as const;

export function ListingForm({ value, onChange, lockedCondition, errors = {} }: { value: ListingValues; onChange: (v: ListingValues) => void; lockedCondition?: boolean; errors?: Record<string, string | undefined> }) {
  const [cats, setCats] = useState<Category[]>([]);
  const [brands, setBrands] = useState<Array<{ name: string }>>([]);
  const [styles, setStyles] = useState<Array<{ id: string; name: string; categoryId: string | null }>>([]);
  useEffect(() => {
    fetch("/v1/catalog/categories").then((r) => r.json()).then((d) => setCats(d.categories));
    fetch("/v1/catalog/brands").then((r) => r.json()).then((d) => setBrands(d.brands));
    fetch("/v1/catalog/styles").then((r) => r.json()).then((d) => setStyles(d.styles));
  }, []);
  const leaves = useMemo(() => cats.filter((c) => !cats.some((x) => x.parentId === c.id)), [cats]);
  const cat = cats.find((c) => c.id === value.categoryId);
  const keys = cat?.attributeSchema?.measurements ?? [];
  const set = (patch: Partial<ListingValues>) => onChange({ ...value, ...patch });
  const letter = GRADES.find((g) => g.code === value.conditionGrade)?.letter;

  return (
    <div className="grid gap-5 sm:grid-cols-2">
      <SelectField label="Category" value={value.categoryId} onChange={(e) => set({ categoryId: e.target.value, measurements: {} })} required error={errors.categoryId}>
        <option value="">Choose…</option>
        {leaves.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
      </SelectField>
      <TextField label="Brand" list="brands" value={value.brandName} onChange={(e) => set({ brandName: e.target.value })} placeholder="e.g. Levi's" help="Leave empty if there's no label." />
      <datalist id="brands">{brands.map((b) => <option key={b.name} value={b.name} />)}</datalist>
      <TextField label="Title" className="sm:col-span-2" value={value.title} onChange={(e) => set({ title: e.target.value })} required maxLength={120} placeholder="e.g. Type III trucker denim jacket" error={errors.title} />
      <TextField label="Size on the label" value={value.size} onChange={(e) => set({ size: e.target.value })} placeholder="M, 32, EU 42…" />
      <TextField label="Colour" value={value.color} onChange={(e) => set({ color: e.target.value })} />
      <TextField label="Price (PKR)" inputMode="numeric" value={value.priceRupees} onChange={(e) => set({ priceRupees: e.target.value.replace(/\D/g, "") })} required error={errors.priceMinor} help="What the buyer pays for the item. Delivery is added at checkout." />
      <TextField label="Weight (grams)" inputMode="numeric" optional value={value.weightGrams} onChange={(e) => set({ weightGrams: e.target.value.replace(/\D/g, "") })} help="Needed if you want to put it in a bundle." />
      {styles.filter((s) => !s.categoryId || s.categoryId === value.categoryId).length > 0 && (
        <SelectField label="Style" optional value={value.styleId} onChange={(e) => set({ styleId: e.target.value })} help="Needed for bundles (same brand + style).">
          <option value="">None</option>
          {styles.filter((s) => !s.categoryId || s.categoryId === value.categoryId).map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
        </SelectField>
      )}
      <TextField label="Material (from the care label)" optional value={value.material} onChange={(e) => set({ material: e.target.value })} help="Only what the label says." />

      {keys.length > 0 && (
        <fieldset className="sm:col-span-2" disabled={lockedCondition}>
          <legend className="text-sm font-medium">Measurements (lay flat, in cm)</legend>
          <div className="mt-2 grid grid-cols-2 gap-3 sm:grid-cols-4">
            {keys.map((k) => (
              <TextField key={k} label={measureLabel(k)} inputMode="decimal" value={value.measurements[k] ?? ""} onChange={(e) => set({ measurements: { ...value.measurements, [k]: e.target.value.replace(/[^\d.]/g, "") } })} />
            ))}
          </div>
          <p className="mt-2 text-sm text-muted">Buyers can't return for fit, so measurements are the most important part of your listing. <a href="/help/measurements" target="_blank" className="link">How to measure</a></p>
        </fieldset>
      )}

      <fieldset className="sm:col-span-2" disabled={lockedCondition}>
        <legend className="text-sm font-medium">Condition</legend>
        <div className="mt-2 grid gap-2 sm:grid-cols-5">
          {GRADES.map((g) => (
            <label key={g.code} className={clsx("cursor-pointer rounded-md border p-3 text-sm", value.conditionGrade === g.code ? "border-ink bg-ivory-deep" : "hairline hover:border-ink")}>
              <input type="radio" name="grade" className="sr-only" checked={value.conditionGrade === g.code} onChange={() => set({ conditionGrade: g.code })} />
              <span className="block font-display text-lg">{g.letter}</span><span className="block">{g.label}</span>
            </label>
          ))}
        </div>
        {letter && <p className="mt-2 text-sm text-muted">{GRADE_CRITERIA[letter].rule}</p>}
        {(letter === "B" || letter === "C" || letter === "D") && (
          <div className="mt-4 space-y-2">
            <p className="text-sm font-medium">Marks or flaws {letter !== "B" && <span className="text-[#8A2E25]">(required for grade {letter})</span>}</p>
            {value.defects.map((d, i) => (
              <div key={i} className="grid grid-cols-[1fr_1fr_auto_auto] gap-2">
                <input aria-label="Flaw" className="h-10 rounded-md border hairline bg-surface px-2 text-sm" placeholder="e.g. small stain" value={d.type} onChange={(e) => set({ defects: value.defects.map((x, j) => (j === i ? { ...x, type: e.target.value } : x)) })} />
                <input aria-label="Where" className="h-10 rounded-md border hairline bg-surface px-2 text-sm" placeholder="where (e.g. left cuff)" value={d.location} onChange={(e) => set({ defects: value.defects.map((x, j) => (j === i ? { ...x, location: e.target.value } : x)) })} />
                <select aria-label="How bad" className="h-10 rounded-md border hairline bg-surface px-2 text-sm" value={d.severity} onChange={(e) => set({ defects: value.defects.map((x, j) => (j === i ? { ...x, severity: e.target.value } : x)) })}>
                  <option value="minor">minor</option><option value="moderate">moderate</option><option value="major">major</option>
                </select>
                <button type="button" className="text-sm underline" onClick={() => set({ defects: value.defects.filter((_, j) => j !== i) })}>Remove</button>
              </div>
            ))}
            <button type="button" className="link text-sm" onClick={() => set({ defects: [...value.defects, { type: "", location: "", severity: "minor" }] })}>+ Add a mark or flaw</button>
            <p className="text-xs text-muted">Add a photo of every flaw too. Disclosed flaws can't be claimed as damage later.</p>
          </div>
        )}
      </fieldset>

      <TextArea label="Description" optional className="sm:col-span-2" value={value.description} onChange={(e) => set({ description: e.target.value })} maxLength={2000} help="Fit, feel, history. Don't guess material or authenticity." />
    </div>
  );
}
