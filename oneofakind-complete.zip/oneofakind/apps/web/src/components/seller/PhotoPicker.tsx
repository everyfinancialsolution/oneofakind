"use client";
import { useEffect } from "react";

export interface LocalPhoto { id: string; file: File; preview: string }

/** Local photo picker with previews (camera on phones). Files are uploaded after the draft is created. */
export function PhotoPicker({ photos, onChange, max = 12 }: { photos: LocalPhoto[]; onChange: (p: LocalPhoto[]) => void; max?: number }) {
  useEffect(() => () => photos.forEach((p) => URL.revokeObjectURL(p.preview)), []); // eslint-disable-line react-hooks/exhaustive-deps
  const add = (files: FileList | null) => {
    if (!files) return;
    const next = [...photos];
    for (const f of Array.from(files)) { if (next.length >= max) break; if (f.type.startsWith("image/")) next.push({ id: `${f.name}-${f.size}-${Math.random()}`, file: f, preview: URL.createObjectURL(f) }); }
    onChange(next);
  };
  const move = (i: number, d: number) => { const n = [...photos]; const [x] = n.splice(i, 1); n.splice(i + d, 0, x!); onChange(n); };
  return (
    <div>
      <ul className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {photos.map((p, i) => (
          <li key={p.id} className="relative">

            <img src={p.preview} alt={`Photo ${i + 1}`} className="aspect-[4/5] w-full rounded-sm object-cover" />
            {i === 0 && <span className="absolute left-1 top-1 rounded-pill bg-ink px-2 py-0.5 text-[11px] text-ivory">Cover</span>}
            <div className="mt-1 flex justify-between text-xs">
              <span className="flex gap-2">{i > 0 && <button type="button" className="underline" onClick={() => move(i, -1)}>← Move</button>}{i < photos.length - 1 && <button type="button" className="underline" onClick={() => move(i, 1)}>Move →</button>}</span>
              <button type="button" className="underline" onClick={() => onChange(photos.filter((x) => x.id !== p.id))}>Remove</button>
            </div>
          </li>
        ))}
        {photos.length < max && (
          <li>
            <label className="flex aspect-[4/5] cursor-pointer flex-col items-center justify-center rounded-sm border-2 border-dashed hairline text-center text-sm hover:border-ink">
              <span className="font-display text-3xl">+</span><span>Add photos</span>
              <input type="file" accept="image/*" multiple className="sr-only" onChange={(e) => { add(e.target.files); e.target.value = ""; }} />
            </label>
          </li>
        )}
      </ul>
    </div>
  );
}
