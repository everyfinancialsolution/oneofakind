import Link from "next/link";
import clsx from "clsx";
import type { BundleCard as BundleCardT, Img, ItemCard, SellerRef } from "@/lib/types";
import { GradeBadge } from "./ui/Badge";
import { Price } from "./ui/misc";
import { S } from "@/lib/strings";
import { percent } from "@/lib/format";

/** 4:5 product image on an ivory plate. Generated imagery always carries a visible label. */
export function ProductImage({ img, className, priority, sizes }: { img: Img | null; className?: string; priority?: boolean; sizes?: string }) {
  return (
    <div className={clsx("relative aspect-[4/5] overflow-hidden rounded-sm bg-ivory-deep", className)}>
      {img ? (
        <img src={img.url} alt={img.alt} width={img.width ?? 800} height={img.height ?? 1000} loading={priority ? "eager" : "lazy"} decoding="async"
          fetchPriority={priority ? "high" : undefined} sizes={sizes} className="h-full w-full object-cover" />
      ) : <div className="flex h-full items-center justify-center text-sm text-muted">No photo yet</div>}
      {img?.aiLabel && <span className="absolute bottom-2 left-2 rounded-pill bg-ink/80 px-2 py-0.5 text-[11px] text-ivory">{S.aiLabel}</span>}
    </div>
  );
}

export function SellerChip({ seller, compact }: { seller: SellerRef | { slug: string | null; displayName: string; city: string | null; type: string }; compact?: boolean }) {
  const inner = (
    <span className="inline-flex items-center gap-2">
      <span className="flex h-7 w-7 items-center justify-center rounded-full bg-ink font-display text-xs text-ivory" aria-hidden>{seller.displayName.slice(0, 1)}</span>
      <span className="leading-tight">
        <span className="block text-sm font-medium">{seller.displayName}</span>
        {!compact && <span className="block text-xs text-muted">{seller.type === "PLATFORM" ? "Sold by ONEOFAKIND" : seller.city}{"ratingAvg" in seller && seller.ratingAvg ? ` · ★ ${seller.ratingAvg.toFixed(1)} (${seller.ratingCount})` : ""}</span>}
      </span>
    </span>
  );
  return seller.slug ? <Link href={`/sellers/${seller.slug}`} className="hover:underline">{inner}</Link> : inner;
}

export function ProductCard({ item, priority }: { item: ItemCard; priority?: boolean }) {
  const unavailable = item.availability !== "AVAILABLE";
  return (
    <article className="group relative">
      <Link href={`/product/${item.slug}`} className="block focus-visible:outline-offset-4" aria-label={`${item.title}, ${item.size ?? ""}, ${item.grade ? `grade ${item.grade.letter}` : ""}`}>
        <div className="relative">
          <ProductImage img={item.image} priority={priority} sizes="(min-width: 1024px) 25vw, 50vw" />
          {item.hoverImage && (
            <div className="absolute inset-0 opacity-0 transition-opacity duration-300 ease-ooak group-hover:opacity-100 motion-reduce:hidden">
              <ProductImage img={item.hoverImage} />
            </div>
          )}
          {unavailable && <span className="absolute left-2 top-2 rounded-pill bg-ivory px-2.5 py-1 text-xs font-medium">{item.availability === "RESERVED" ? S.reserved : S.sold}</span>}
          {item.managed && !unavailable && <span className="absolute left-2 top-2 rounded-pill bg-ivory/90 px-2.5 py-1 text-[11px]">Inspected by us</span>}
        </div>
        <div className="mt-3 space-y-1">
          <div className="flex items-center justify-between gap-2 text-xs text-muted">
            <span className="truncate">{item.brand?.name ?? item.category.name}</span>
            <span className="shrink-0">{item.size}</span>
          </div>
          <h3 className="line-clamp-2 text-[15px] leading-snug">{item.title}</h3>
          <div className="flex items-center justify-between pt-0.5">
            <Price minor={item.priceMinor} size="md" />
            <GradeBadge grade={item.grade} showLabel={false} />
          </div>
        </div>
      </Link>
    </article>
  );
}

export function ProductGrid({ items, priorityCount = 0, cols = 4 }: { items: ItemCard[]; priorityCount?: number; cols?: 3 | 4 }) {
  return (
    <div className={clsx("grid grid-cols-2 gap-x-4 gap-y-10 sm:gap-x-6", cols === 4 ? "md:grid-cols-3 lg:grid-cols-4" : "md:grid-cols-3")}>
      {items.map((it, i) => <ProductCard key={it.sku} item={it} priority={i < priorityCount} />)}
    </div>
  );
}

/** Bundle card: the piece count is legible (a strip of the first pieces), and price only when the server sent it. */
export function BundleCard({ bundle }: { bundle: BundleCardT }) {
  const sizes = Object.entries(bundle.breakdown.sizes).map(([k, v]) => `${k}×${v}`).join(" · ");
  return (
    <article className="group">
      <Link href={`/bundles/${bundle.slug}`} className="block">
        <div className="grid grid-cols-3 gap-1 rounded-sm bg-ivory-deep p-1">
          {bundle.thumbnails.slice(0, 6).map((t, i) => <ProductImage key={i} img={t} className="rounded-none" />)}
        </div>
        <div className="mt-3 space-y-1">
          <div className="flex items-center justify-between text-xs text-muted">
            <span>{bundle.brand.name} · {bundle.style.name}</span>
            <span className="rounded-pill bg-ink px-2 py-0.5 text-ivory">{bundle.size} pieces</span>
          </div>
          <h3 className="text-[15px]">{bundle.title}</h3>
          <p className="text-xs text-muted">Sizes {sizes}</p>
          {bundle.priceMinor !== undefined ? (
            <div className="flex items-baseline gap-2">
              <Price minor={bundle.priceMinor} />
              <span className="text-xs text-muted num">{bundle.pricePerPieceMinor !== undefined ? `${(bundle.pricePerPieceMinor / 100).toLocaleString("en-PK")} / piece` : ""}{bundle.savingsBps ? ` · ${percent(bundle.savingsBps)} below retail` : ""}</span>
            </div>
          ) : <p className="text-sm text-champagne-ink">{S.resellerOnlyPrices}</p>}
        </div>
      </Link>
    </article>
  );
}
