"use client";
import Link from "next/link";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { useEffect, useState } from "react";
import clsx from "clsx";
import type { BundleCard as BundleCardT, BundleDetail } from "@/lib/types";
import { call, ClientApiError } from "@/lib/client";
import { BundleCard } from "./product";
import { useSession } from "./session";
import { Button } from "./ui/Button";
import { EmptyState, Price } from "./ui/misc";
import { useToast } from "./ui/Toast";
import { WhatsAppLink } from "./WhatsApp";
import { S } from "@/lib/strings";
import { percent } from "@/lib/format";

interface ListResp { bundles: BundleCardT[]; canSeePrices: boolean; sorts: string[]; facets: { brands: Array<{ slug: string; name: string }>; styles: Array<{ slug: string; name: string }>; sizes: number[] } }
const SORT_LABELS: Record<string, string> = { newest: "Newest", size: "Largest lots", brand: "Brand A-Z", price_asc: "Price: low to high", price_desc: "Price: high to low", savings: "Biggest saving" };

/**
 * The page HTML is rendered and cached WITHOUT prices. For signed-in viewers we refetch with their session;
 * the API decides whether prices are included (verified resellers, owning seller, staff).
 */
export function BundleBrowser({ initial, query }: { initial: ListResp; query: string }) {
  const { me, loading } = useSession();
  const [data, setData] = useState(initial);
  const router = useRouter();
  const path = usePathname();
  const sp = useSearchParams();
  useEffect(() => { setData(initial); }, [initial]);
  useEffect(() => {
    if (loading || !me) return;
    call<ListResp>(`/v1/bundles?${query}`).then(setData).catch(() => {});
  }, [me, loading, query]);
  const set = (k: string, v: string | null) => {
    const n = new URLSearchParams(sp.toString());
    if (v) n.set(k, v); else n.delete(k);
    router.replace(`${path}?${n.toString()}`, { scroll: false });
  };
  const chip = (on: boolean) => clsx("rounded-pill border px-3 py-1.5 text-sm", on ? "border-ink bg-ink text-ivory" : "hairline hover:border-ink");
  return (
    <div>
      <div className="mb-8 space-y-4 border-b hairline pb-6">
        <div className="flex flex-wrap items-center gap-2" role="group" aria-label="Lot size">
          <span className="mr-2 text-sm text-muted">Lot size</span>
          <button className={chip(!sp.get("size"))} onClick={() => set("size", null)}>All</button>
          {data.facets.sizes.map((s) => <button key={s} className={chip(sp.get("size") === String(s))} onClick={() => set("size", String(s))}>{s} pieces</button>)}
        </div>
        <div className="flex flex-wrap items-center gap-4 text-sm">
          <label className="flex items-center gap-2"><span className="text-muted">Brand</span>
            <select value={sp.get("brand") ?? ""} onChange={(e) => set("brand", e.target.value || null)} className="h-9 rounded-md border hairline bg-surface px-2"><option value="">All brands</option>{data.facets.brands.map((b) => <option key={b.slug} value={b.slug}>{b.name}</option>)}</select>
          </label>
          <label className="flex items-center gap-2"><span className="text-muted">Style</span>
            <select value={sp.get("style") ?? ""} onChange={(e) => set("style", e.target.value || null)} className="h-9 rounded-md border hairline bg-surface px-2"><option value="">All styles</option>{data.facets.styles.map((b) => <option key={b.slug} value={b.slug}>{b.name}</option>)}</select>
          </label>
          <label className="flex items-center gap-2"><span className="text-muted">Sort</span>
            <select value={sp.get("sort") ?? "newest"} onChange={(e) => set("sort", e.target.value)} className="h-9 rounded-md border hairline bg-surface px-2">{data.sorts.map((s) => <option key={s} value={s}>{SORT_LABELS[s] ?? s}</option>)}</select>
          </label>
          {!data.canSeePrices && <span className="text-champagne-ink">Price sorting is available to verified resellers.</span>}
        </div>
      </div>
      {data.bundles.length ? <div className="grid gap-x-8 gap-y-12 md:grid-cols-2 lg:grid-cols-3">{data.bundles.map((b) => <BundleCard key={b.slug} bundle={b} />)}</div>
        : <EmptyState title="No bundles match" body="Try another size, brand or style." />}
    </div>
  );
}

/** Price + purchase box on a lot page, loaded per viewer (never part of the cached HTML). */
export function BundleBuyBox({ slug, initial }: { slug: string; initial: BundleDetail }) {
  const { me, loading, refreshCart } = useSession();
  const toast = useToast();
  const router = useRouter();
  const [b, setB] = useState<BundleDetail>(initial);
  const [canPurchase, setCanPurchase] = useState(false);
  const [adding, setAdding] = useState(false);
  useEffect(() => {
    if (loading || !me) return;
    call<{ bundle: BundleDetail; canPurchase: boolean }>(`/v1/bundles/${slug}`).then((r) => { setB(r.bundle); setCanPurchase(r.canPurchase); }).catch(() => {});
  }, [me, loading, slug]);
  const add = async () => {
    setAdding(true);
    try { await call("/v1/cart/items", { body: { bundleSlug: slug } }); await refreshCart(); toast("Bundle added to your cart", "good"); router.push("/cart"); }
    catch (e) { toast(e instanceof ClientApiError ? e.message : "Could not add", "bad"); } finally { setAdding(false); }
  };
  const ref = me?.applications.find((a) => a.kind === "RESELLER")?.reference;
  return (
    <div className="space-y-4 rounded-md border hairline bg-surface p-5">
      {b.priceMinor !== undefined ? (
        <>
          <div className="flex items-baseline justify-between gap-3">
            <Price minor={b.priceMinor} size="xl" />
            {b.savingsBps ? <span className="text-sm text-champagne-ink">{percent(b.savingsBps)} below retail value</span> : null}
          </div>
          <p className="text-sm text-muted num">{b.pricePerPieceMinor !== undefined && <>PKR {(b.pricePerPieceMinor / 100).toLocaleString("en-PK")} per piece · </>}retail value <Price minor={b.retailValueMinor} size="sm" /></p>
          {b.availability !== "AVAILABLE" ? <p className="text-[15px]">{b.availability === "RESERVED" ? "A reseller is checking out with this lot right now." : "This lot has sold."}</p>
            : canPurchase ? <Button size="lg" full onClick={add} loading={adding}>Add lot to cart</Button>
              : <p className="text-sm text-muted">You can see this price because it is your own lot or you are staff.</p>}
        </>
      ) : (
        <>
          <p className="font-display text-xl">{S.resellerOnlyPrices}</p>
          <p className="text-sm text-muted">Everyone can see every piece. Prices and buying are for verified resellers. Applying takes about 3 minutes, or send your documents on WhatsApp.</p>
          {me?.reseller?.status === "PENDING" ? <p className="text-[15px]">Your reseller application is being reviewed{ref ? ` (reference ${ref})` : ""}. We usually decide within 2 working days.</p> : (
            <div className="flex flex-wrap gap-3">
              <Button href="/reseller/apply">{S.applyReseller}</Button>
              <WhatsAppLink button="secondary" message={`Hello ONEOFAKIND, I want to become a verified reseller.${ref ? ` My reference: ${ref}` : ""}`}>{S.whatsappApply}</WhatsAppLink>
            </div>
          )}
          {!me && <p className="text-sm">Already verified? <Link href={`/login?next=/bundles/${slug}`} className="link">Log in</Link></p>}
        </>
      )}
    </div>
  );
}
