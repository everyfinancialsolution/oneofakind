/** @type {import('tailwindcss').Config} */
module.exports = {
  presets: [require("@ooak/design-tokens")],
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      // Hex values (same as tokens.css) so Tailwind opacity modifiers like bg-ink/80 work.
      colors: { ink: { DEFAULT: "#121110", soft: "#2A2724" }, ivory: { DEFAULT: "#F7F3EA", deep: "#EDE6D6" }, stone: { DEFAULT: "#CFC8BA", deep: "#8E8778" } },
      maxWidth: { page: "1440px" },
      fontSize: { "display-xl": ["clamp(2.75rem, 6vw, 5.5rem)", { lineHeight: "0.98", letterSpacing: "-0.02em" }], "display-lg": ["clamp(2rem, 4vw, 3.25rem)", { lineHeight: "1.05", letterSpacing: "-0.015em" }] },
      keyframes: { reveal: { "0%": { opacity: "0", transform: "translateY(14px)" }, "100%": { opacity: "1", transform: "none" } }, plate: { "0%": { opacity: "0", clipPath: "inset(8% 8% 8% 8%)" }, "100%": { opacity: "1", clipPath: "inset(0 0 0 0)" } } },
      animation: { reveal: "reveal .9s var(--ooak-ease) both", plate: "plate 1.2s var(--ooak-ease) both" },
    },
  },
  plugins: [],
};
