/** @type {import('next').NextConfig} */
const API = process.env.API_INTERNAL_URL ?? "http://localhost:4000";

const securityHeaders = [
  { key: "X-Content-Type-Options", value: "nosniff" },
  { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
  { key: "X-Frame-Options", value: "DENY" },
  { key: "Permissions-Policy", value: "camera=(self), microphone=(), geolocation=()" },
];
// CSP: same-origin only (API is proxied under /v1). Next's bootstrap needs inline scripts; dev also needs eval for
// fast refresh. Nonce-based script-src can replace 'unsafe-inline' once a middleware issues per-request nonces.
const dev = process.env.NODE_ENV !== "production";
const csp = [
  "default-src 'self'",
  `script-src 'self' 'unsafe-inline'${dev ? " 'unsafe-eval'" : ""}`,
  "style-src 'self' 'unsafe-inline'",
  "img-src 'self' data: blob:",
  "font-src 'self' data:",
  `connect-src 'self'${dev ? " ws: http://localhost:4000" : ""}`,
  "media-src 'self' blob:",
  "worker-src 'self' blob:",
  "frame-ancestors 'none'",
  "base-uri 'self'",
  "form-action 'self'",
  "object-src 'none'",
].join("; ");
securityHeaders.push({ key: "Content-Security-Policy", value: csp });
if (!dev) securityHeaders.push({ key: "Strict-Transport-Security", value: "max-age=31536000; includeSubDomains" });
if (process.env.STAGING_NOINDEX === "true") securityHeaders.push({ key: "X-Robots-Tag", value: "noindex, nofollow" });

const nextConfig = {
  reactStrictMode: true,
  poweredByHeader: false,
  // Lint runs once for the whole monorepo (`pnpm lint`, root eslint.config.mjs, includes the Next plugin), not again in `next build`.
  eslint: { ignoreDuringBuilds: true },
  transpilePackages: ["@ooak/shared"],
  // The browser only ever talks to this origin: /v1/* is proxied to the API so session cookies stay first-party.
  async rewrites() {
    return [{ source: "/v1/:path*", destination: `${API}/v1/:path*` }];
  },
  async headers() {
    return [{ source: "/:path*", headers: securityHeaders }];
  },
};
export default nextConfig;
