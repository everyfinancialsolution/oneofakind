// Flat ESLint config for the whole monorepo. Type-aware rules are left to `tsc --noEmit` (pnpm typecheck).
import js from "@eslint/js";
import nextPlugin from "@next/eslint-plugin-next";
import reactHooks from "eslint-plugin-react-hooks";
import globals from "globals";
import tseslint from "typescript-eslint";

export default tseslint.config(
  { ignores: ["**/dist/**", "**/.next/**", "**/node_modules/**", "**/coverage/**", "**/next-env.d.ts", "**/*.config.*", "apps/api/prisma/migrations/**", "e2e/report/**", "e2e/results/**"] },
  js.configs.recommended,
  ...tseslint.configs.recommended,
  {
    languageOptions: { globals: { ...globals.node, ...globals.browser } },
    rules: {
      "@typescript-eslint/no-unused-vars": ["error", { argsIgnorePattern: "^_", varsIgnorePattern: "^_", caughtErrors: "none" }],
      "@typescript-eslint/no-explicit-any": "error",
      "no-console": ["warn", { allow: ["warn", "error"] }],
      eqeqeq: ["error", "smart"],
    },
  },
  {
    files: ["apps/web/**/*.{ts,tsx}"],
    plugins: { "react-hooks": reactHooks, "@next/next": nextPlugin },
    rules: { ...reactHooks.configs.recommended.rules, ...nextPlugin.configs.recommended.rules, ...nextPlugin.configs["core-web-vitals"].rules,
      // Media is served pre-optimised by the API (/v1/media: WebP, ≤1600px, immutable caching); private images need the
      // session cookie, which the next/image optimiser would not forward. Plain <img> is intentional.
      "@next/next/no-img-element": "off" },
    settings: { next: { rootDir: "apps/web" } },
  },
  { files: ["**/*.test.{ts,tsx}", "apps/api/test/**", "e2e/**"], rules: { "no-console": "off" } },
  { files: ["apps/api/prisma/seed.ts", "apps/api/prisma/seed/**"], rules: { "no-console": "off" } },
);
