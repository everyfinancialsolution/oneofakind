import { expect, test } from "@playwright/test";
import { asRole, watch } from "./helpers";

test("bundle prices: hidden for guests and customers (page + API), shown to verified resellers", async ({ page, request, browser }) => {
  const problems = watch(page);
  const { bundles } = await (await request.get("/v1/bundles?limit=5")).json();
  const lot = bundles[0];
  expect(JSON.stringify(bundles)).not.toMatch(/priceMinor|retailValueMinor|savingsBps/);
  const guestApi = await (await request.get(`/v1/bundles/${lot.slug}`)).json();
  expect(JSON.stringify(guestApi)).not.toMatch(/priceMinor|retailValueMinor|refRetailMinor/);
  await page.goto(`/bundles/${lot.slug}`);
  await expect(page.getByText("Verified resellers only. Apply to see prices")).toBeVisible();
  const html = await page.content();
  expect(html).not.toMatch(/priceMinor|retailValueMinor/);
  // a logged-in ordinary customer still sees no prices
  const { ctx, page: cust } = await asRole(browser, "buyer");
  await cust.goto(`/bundles/${lot.slug}`);
  await expect(cust.getByText("Verified resellers only. Apply to see prices")).toBeVisible();
  await ctx.close();
  // verified reseller sees the lot price
  const { ctx: r, page: rp } = await asRole(browser, "reseller");
  await rp.goto(`/bundles/${lot.slug}`);
  await expect(rp.getByText("Verified resellers only. Apply to see prices")).toHaveCount(0);
  await expect(rp.getByText(/PKR [\d,]+/).first()).toBeVisible();
  await r.close();
  expect(problems).toEqual([]);
});
