import { type Browser, expect, type Page } from "@playwright/test";
import { join } from "node:path";

export const PHONES = { admin: "+923000000001", moderator: "+923000000005", agent: "+923000000006", seller: "+923010000001", reseller: "+923020000001", buyer: "+923030000001" } as const;
export type Role = keyof typeof PHONES;

/** A fresh browser context signed in as `role` (session saved by global-setup). */
export async function asRole(browser: Browser, role: Role) {
  const ctx = await browser.newContext({ storageState: join(__dirname, ".auth", `${role}.json`) });
  return { ctx, page: await ctx.newPage() };
}

/** Phone-OTP login using the dev echo (OTP_DEV_ECHO=true shows the code on screen). */
export async function login(page: Page, phone: string) {
  await page.goto("/login");
  await page.getByLabel("Mobile number").fill(phone);
  await page.getByRole("button", { name: "Send code" }).click();
  const hint = await page.locator("text=/your code is/").innerText();
  const code = hint.match(/\d{6}/)![0];
  await page.getByLabel("6-digit code").fill(code);
  await page.getByRole("button", { name: /Log in/ }).click();
  await expect(page).not.toHaveURL(/\/login/);
}

/** Collects page errors, CSP violations and failed API calls so each test can assert a clean run. */
export function watch(page: Page) {
  const problems: string[] = [];
  page.on("pageerror", (e) => problems.push(`pageerror: ${e.message}`));
  page.on("console", (m) => { if (m.type() === "error" && /Content Security Policy|Refused to/i.test(m.text())) problems.push(`csp: ${m.text().slice(0, 200)}`); });
  page.on("response", (r) => { if (r.url().includes("/v1/") && r.status() >= 500) problems.push(`api ${r.status()}: ${r.url()}`); });
  return problems;
}
