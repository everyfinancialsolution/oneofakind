import { chromium, type FullConfig, request } from "@playwright/test";
import { existsSync, mkdirSync, readFileSync } from "node:fs";
import { join } from "node:path";
import { login, PHONES, type Role } from "./helpers";

export const AUTH_DIR = join(__dirname, ".auth");

/** Logs each role in once and saves the session. A saved session that is still valid is reused (keeps OTP requests under the rate limit). */
export default async function globalSetup(config: FullConfig) {
  const baseURL = config.projects[0]!.use.baseURL!;
  mkdirSync(AUTH_DIR, { recursive: true });
  const browser = await chromium.launch(process.env.PW_CHROMIUM_PATH ? { executablePath: process.env.PW_CHROMIUM_PATH } : {});
  for (const role of Object.keys(PHONES) as Role[]) {
    const file = join(AUTH_DIR, `${role}.json`);
    if (existsSync(file)) {
      const api = await request.newContext({ baseURL, storageState: JSON.parse(readFileSync(file, "utf8")) });
      const me = await (await api.get("/v1/auth/me")).json().catch(() => ({ user: null }));
      await api.dispose();
      if (me.user) continue;
    }
    const ctx = await browser.newContext({ baseURL });
    const page = await ctx.newPage();
    await login(page, PHONES[role]);
    await ctx.storageState({ path: file });
    await ctx.close();
  }
  await browser.close();
}
