import { expect, test } from "@playwright/test";
import { asRole, watch } from "./helpers";

test("buyer: product → cart → prepaid checkout → sandbox payment → order paid", async ({ browser, request }) => {
  const { ctx, page } = await asRole(browser, "buyer");
  const problems = watch(page);
  const list = await (await request.get("/v1/listings?limit=40")).json();
  const pick = list.items.find((i: { availability?: string; seller?: { slug?: string } }) => (i.availability ?? "AVAILABLE") === "AVAILABLE");
  expect(pick, "an available seeded listing").toBeTruthy();
  await page.goto(`/product/${pick.slug}`);
  await expect(page.getByRole("heading", { level: 1 })).toContainText(pick.title);
  await page.getByRole("button", { name: "Add to cart" }).click();
  await page.goto("/checkout");
  // Seeded buyers have a saved address; otherwise fill the form.
  await expect(page.getByText("Use a new address").or(page.getByLabel("Full name"))).toBeVisible();
  if (!(await page.getByText("Use a new address").isVisible())) {
    await page.getByLabel("Full name").fill("Fatima Noor");
    await page.getByLabel("Mobile number (for the courier)").fill("0300 1234567");
    await page.getByLabel("Address").fill("House 12, Street 4, DHA");
    await page.getByLabel("City").fill("Karachi");
  }
  await page.getByText(/returns are for damaged or undisclosed flaws only/).click();
  await expect(page.getByRole("radio", { name: /cash on delivery|\bCOD\b/i })).toHaveCount(0); // prepaid only - no COD option
  await page.getByRole("button", { name: /^Pay PKR/ }).click();
  await page.getByRole("button", { name: "Simulate successful payment" }).click();
  await expect(page).toHaveURL(/\/orders\/.+placed=1/);
  await expect(page.getByText(/paid/i).first()).toBeVisible();
  // the piece is no longer for sale
  const after = await (await request.get(`/v1/listings/${pick.slug}`)).json();
  expect(after.item.availability ?? after.item.stockState).not.toBe("AVAILABLE");
  expect(problems).toEqual([]);
  await ctx.close();
});
