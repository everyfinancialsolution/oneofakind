import { defineConfig, devices } from "@playwright/test";

/**
 * End-to-end tests against a running dev/staging stack (web on E2E_BASE_URL, API behind it) with seeded data
 * (`pnpm --filter @ooak/api db:seed`) and OTP_DEV_ECHO=true (the dev OTP is shown on screen). Never point this at production.
 */
const baseURL = process.env.E2E_BASE_URL ?? "http://localhost:3000";
if (/oneofakindretro\.com/i.test(baseURL)) throw new Error("E2E must never run against production.");

export default defineConfig({
  testDir: ".",
  globalSetup: "./global-setup.ts",
  testMatch: /.*\.spec\.ts$/,
  fullyParallel: false,
  workers: 1,
  retries: 0,
  timeout: 90_000,
  expect: { timeout: 15_000 },
  reporter: [["list"], ["html", { outputFolder: "report", open: "never" }]],
  outputDir: "results",
  use: { baseURL, trace: "retain-on-failure", screenshot: "only-on-failure", launchOptions: process.env.PW_CHROMIUM_PATH ? { executablePath: process.env.PW_CHROMIUM_PATH } : {} },
  projects: [
    { name: "desktop", use: { ...devices["Desktop Chrome"] } },
    { name: "mobile", use: { ...devices["Pixel 7"] }, testMatch: /mobile\.spec\.ts$/ },
  ],
});
