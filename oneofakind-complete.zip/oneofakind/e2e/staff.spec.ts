import { expect, test } from "@playwright/test";
import { asRole, watch } from "./helpers";

test("moderator approves a listing from the review queue; customers can't open admin", async ({ browser }) => {
  const { ctx: m, page } = await asRole(browser, "moderator");
  const problems = watch(page);
  await page.goto("/admin/moderation");
  const cards = page.locator("article");
  await expect(cards.first().or(page.getByText("Queue is clear"))).toBeVisible(); // wait for the queue to load
  const before = await cards.count();
  test.skip(before === 0, "review queue is empty (re-seed to refill)");
  await page.getByRole("button", { name: "Approve & publish" }).first().click();
  await expect(cards).toHaveCount(before - 1);
  const { ctx: c, page: cp } = await asRole(browser, "buyer");
  await cp.goto("/admin");
  await expect(cp.getByRole("heading", { name: "Staff only" })).toBeVisible();
  await c.close();
  expect(problems).toEqual([]);
  await m.close();
});

test("staff assisted registration from WhatsApp creates an application that needs consent evidence", async ({ browser }) => {
  const { ctx, page } = await asRole(browser, "agent");
  const problems = watch(page);
  await page.goto("/admin/onboarding/new");
  await page.getByLabel("Full name (as on CNIC)").fill("Sana Iqbal");
  await page.getByLabel("Mobile number").fill(`0333 ${String(Date.now()).slice(-7)}`);
  await page.getByRole("button", { name: "Create application" }).click();
  await expect(page).toHaveURL(/\/admin\/onboarding\/OOAK-S-/);
  await expect(page.getByText("No consent recorded yet.").or(page.getByText(/Evidence: missing/))).toBeVisible();
  await page.getByRole("button", { name: "Submit for review" }).click();
  await expect(page.getByText(/Record how the applicant agreed/)).toBeVisible(); // API refuses without consent evidence
  expect(problems).toEqual([]);
  await ctx.close();
});

test("seller photo studio: background removal produces a labelled copy", async ({ browser }) => {
  const { ctx, page } = await asRole(browser, "seller");
  const problems = watch(page);
  await page.goto("/seller/studio");
  await page.getByRole("button", { name: "Remove background" }).first().click();
  await expect(page.getByText("AI-edited", { exact: true }).first()).toBeVisible({ timeout: 30_000 });
  expect(problems).toEqual([]);
  await ctx.close();
});
