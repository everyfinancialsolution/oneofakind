import { expect, test } from "@playwright/test";
import { watch } from "./helpers";

test("mobile: home, discover and a product page render without horizontal scroll", async ({ page, request }) => {
  const problems = watch(page);
  const list = await (await request.get("/v1/listings?limit=1")).json();
  for (const path of ["/", "/discover", `/product/${list.items[0].slug}`, "/bundles", "/sell"]) {
    await page.goto(path);
    await expect(page.locator("main").first()).toBeVisible();
    const overflow = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
    expect(overflow, `horizontal overflow on ${path}`).toBeLessThanOrEqual(1);
  }
  expect(problems).toEqual([]);
});
