import { describe, it, expect } from "vitest";
import { makeCode, parseCode, parseScan, qrPayload, checkDigit, CodeError, verifyPackScan } from "./index";

describe("codes", () => {
  it("known GS1 check digit vector", () => expect(checkDigit("400638133393")).toBe("1")); // EAN-13 4006381333931
  it("round-trips kind and sequence", () => {
    for (const k of ["ITEM_PACK", "BUNDLE_PACK", "ORDER_PACK", "DISPATCH"] as const) {
      const c = makeCode(k, 123456);
      expect(c).toHaveLength(13);
      const p = parseCode(c);
      expect(p.valid && p.kind === k && p.sequence === 123456).toBe(true);
    }
  });
  it("kinds never collide for the same sequence", () => {
    const set = new Set(["ITEM_PACK", "BUNDLE_PACK", "ORDER_PACK", "DISPATCH"].map((k) => makeCode(k as never, 1)));
    expect(set.size).toBe(4);
  });
  it("detects single-digit typos and transpositions", () => {
    const c = makeCode("ITEM_PACK", 4242);
    for (let i = 0; i < 13; i++) {
      const bad = c.slice(0, i) + String((Number(c[i]) + 1) % 10) + c.slice(i + 1);
      expect(parseCode(bad).valid).toBe(false);
    }
  });
  it("rejects out-of-range sequence", () => {
    expect(() => makeCode("ITEM_PACK", 0)).toThrow(CodeError);
    expect(() => makeCode("ITEM_PACK", 1e11)).toThrow(CodeError);
  });
  it("parses scanner digits and QR payload identically", () => {
    const c = makeCode("ORDER_PACK", 77);
    expect(parseScan(c)).toMatchObject({ ok: true, code: c, kind: "ORDER_PACK" });
    expect(parseScan(qrPayload(c))).toMatchObject({ ok: true, code: c });
    expect(parseScan("hello").ok).toBe(false);
    expect(parseScan("OOAK1:123").ok).toBe(false);
  });
});

describe("pack verification", () => {
  const a = makeCode("ITEM_PACK", 1), b = makeCode("ITEM_PACK", 2), lot = makeCode("BUNDLE_PACK", 9), other = makeCode("ITEM_PACK", 3);
  it("complete when every expected code scanned (lot code stands for its pieces)", () => {
    expect(verifyPackScan([a, lot], [a, qrPayload(lot)]).status).toBe("COMPLETE");
  });
  it("incomplete lists what is missing", () => {
    const r = verifyPackScan([a, b], [a]);
    expect(r.status).toBe("INCOMPLETE"); expect(r.missing).toEqual([b]);
  });
  it("wrong item from another order is a MISMATCH (blocks dispatch)", () => {
    const r = verifyPackScan([a, b], [a, b, other]);
    expect(r.status).toBe("MISMATCH"); expect(r.unexpected).toEqual([other]);
  });
  it("unreadable/typo'd code is a MISMATCH; double scans are reported", () => {
    expect(verifyPackScan([a], [a, "12345"]).status).toBe("MISMATCH");
    expect(verifyPackScan([a], [a, a])).toMatchObject({ status: "COMPLETE", duplicates: [a] });
  });
});
