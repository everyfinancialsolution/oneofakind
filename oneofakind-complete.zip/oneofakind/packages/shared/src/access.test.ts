import { describe, it, expect } from "vitest";
import { canViewBundlePrices, canPurchaseBundle, redactBundlePrices, allowedBundleSorts, onboarding, missingDocuments,
  normalizePkPhone, applicationReference } from "./index";

const lot = { id: "b1", title: "10 Nike track jackets", size: 10, priceMinor: 1_500_000, retailValueMinor: 3_000_000, savingsBps: 5000,
  items: [{ id: "i1", size: "M", refRetailMinor: 300_000, grade: "A" }, { id: "i2", size: "L", refRetailMinor: 280_000, grade: "B" }], created: new Date(0) };

describe("bundle price visibility", () => {
  it("guests and plain customers cannot see prices; resellers and staff can", () => {
    expect(canViewBundlePrices(null)).toBe(false);
    expect(canViewBundlePrices({ roles: ["CUSTOMER"] })).toBe(false);
    expect(canViewBundlePrices({ roles: ["WAREHOUSE"] })).toBe(false);
    expect(canViewBundlePrices({ roles: ["CUSTOMER", "VERIFIED_RESELLER"] })).toBe(true);
    expect(canViewBundlePrices({ roles: ["FINANCE"] })).toBe(true);
  });
  it("a seller sees prices only on their own bundles", () => {
    const seller = { roles: ["SELLER" as const], sellerId: "s1" };
    expect(canViewBundlePrices(seller, "s1")).toBe(true);
    expect(canViewBundlePrices(seller, "s2")).toBe(false);
    expect(canViewBundlePrices(seller, null)).toBe(false);
  });
  it("only verified resellers can purchase", () => {
    expect(canPurchaseBundle({ roles: ["CUSTOMER"] })).toBe(false);
    expect(canPurchaseBundle({ roles: ["ADMIN"] })).toBe(false);
    expect(canPurchaseBundle({ roles: ["VERIFIED_RESELLER"] })).toBe(true);
  });
  it("redaction removes every price field at every depth, keeps the rest, does not mutate", () => {
    const snapshot = JSON.stringify(lot);
    const out = redactBundlePrices(lot, false) as typeof lot;
    expect(JSON.stringify(out)).not.toMatch(/priceMinor|retailValueMinor|savingsBps|refRetailMinor/);
    expect(out.title).toBe(lot.title); expect(out.items.map((i) => i.grade)).toEqual(["A", "B"]); expect(out.created).toBeInstanceOf(Date);
    expect(JSON.stringify(lot)).toBe(snapshot);
    expect(redactBundlePrices(lot, true)).toBe(lot);
  });
  it("price sorting is not offered to viewers who cannot see prices", () => {
    expect(allowedBundleSorts(false)).not.toContain("price_asc");
    expect(allowedBundleSorts(true)).toContain("price_asc");
  });
});

describe("onboarding", () => {
  it("state machine: rejected/withdrawn/approved are final; docs can be requested again during review", () => {
    expect(onboarding.can("UNDER_REVIEW", "DOCS_REQUESTED")).toBe(true);
    expect(onboarding.can("SUBMITTED", "APPROVED")).toBe(false); // must pass review
    for (const s of ["APPROVED", "REJECTED", "WITHDRAWN"] as const) expect(onboarding.isTerminal(s)).toBe(true);
  });
  it("reports missing documents per kind", () => {
    expect(missingDocuments("SELLER", ["ID_FRONT"])).toEqual(["ID_BACK", "PAYOUT_ACCOUNT_PROOF"]);
    expect(missingDocuments("RESELLER", ["ID_FRONT", "ID_BACK", "SHOP_PROOF"])).toEqual([]);
  });
  it("normalises Pakistani mobile numbers", () => {
    for (const raw of ["0300 1234567", "03001234567", "+92 300 1234567", "92-300-1234567", "00923001234567", "3001234567"])
      expect(normalizePkPhone(raw)).toBe("+923001234567");
    for (const bad of ["042 1234567", "0200 1234567", "12345", "+1 415 555 0100", ""]) expect(normalizePkPhone(bad)).toBeNull();
  });
  it("application references", () => {
    expect(applicationReference("SELLER", 123)).toBe("OOAK-S-000123");
    expect(applicationReference("RESELLER", 45)).toBe("OOAK-R-000045");
  });
});
