import { allocate, money, type Money } from "./money";
import { GRADE_LETTER, BUNDLE_ALLOWED_LETTERS } from "./arrangements";
import type { OwnerType, SellingArrangement, SalesChannel, ConditionGrade } from "./arrangements";

/** Default allowed bundle sizes. Runtime source of truth is the BundleTier table; this is the seed/default. */
export const BUNDLE_SIZES = [5, 10, 15] as const;
export type BundleSize = (typeof BUNDLE_SIZES)[number];

/** Enforced bundle pricing policy (adopted defaults; runtime values come from config/BundleTier). */
export interface BundlePricePolicy { minPricePerPieceMinor: number; minDiscountBps: number }
export const BUNDLE_PRICE_POLICY: BundlePricePolicy = { minPricePerPieceMinor: 100_000 /* PKR 1,000 */, minDiscountBps: 2_500 /* >=25% below retail value */ };

export interface BundleDraft {
  size: number;
  brandId: string;
  styleId: string;
  sellerId: string | null; // null => platform bundle
  ownerType: OwnerType;
  arrangement: SellingArrangement;
  priceMinor: number;
  currency: string;
}

export interface BundleCandidateItem {
  id: string;
  brandId: string | null;
  styleId: string | null;
  sellerId: string;
  ownerType: OwnerType;
  arrangement: SellingArrangement;
  stockState: string;
  conditionGrade: ConditionGrade | null;
  size?: string | null;
  color?: string | null;
  channel: SalesChannel;
  currency: string;
  refRetailMinor: number;
  activeBundleId?: string | null;
  hasPublishedRetailListing?: boolean;
}

export type BundleIssueCode =
  | "SIZE_NOT_ALLOWED" | "COUNT_MISMATCH" | "DUPLICATE_ITEM" | "BRAND_MISMATCH" | "STYLE_MISMATCH"
  | "ARRANGEMENT_MISMATCH" | "OWNER_MISMATCH" | "SELLER_MISMATCH" | "NOT_BUNDLEABLE_STATE"
  | "GRADE_NOT_ALLOWED" | "ALREADY_BUNDLED" | "RETAIL_LISTING_CONFLICT" | "CURRENCY_MISMATCH" | "MISSING_REF_PRICE"
  | "PRICE_INVALID" | "PRICE_NOT_DISCOUNTED" | "PRICE_BELOW_FLOOR";

export interface BundleIssue { code: BundleIssueCode; itemId?: string; message: string }

const BUNDLEABLE_STATES = new Set(["READY_TO_LIST", "AVAILABLE"]);

/**
 * Server-side gate for creating/publishing a bundle. Returns ALL problems (empty array = valid).
 * Rules: exactly an allowed size; every item same brand AND same style as the bundle; same arrangement;
 * same owner; every piece grade A or B (sizes and colours MAY be mixed); seller bundles only contain that seller's items; platform bundles only PLATFORM-owned items;
 * item not already in an active bundle and not live as a retail listing; bundle price must be a discount.
 */
export function validateBundleComposition(
  draft: BundleDraft,
  items: BundleCandidateItem[],
  allowedSizes: readonly number[] = BUNDLE_SIZES,
  policy: BundlePricePolicy = BUNDLE_PRICE_POLICY,
): BundleIssue[] {
  const issues: BundleIssue[] = [];
  const add = (code: BundleIssueCode, message: string, itemId?: string) => issues.push({ code, message, itemId });

  if (!allowedSizes.includes(draft.size)) add("SIZE_NOT_ALLOWED", `Bundle size ${draft.size} is not allowed (${allowedSizes.join("/")})`);
  if (items.length !== draft.size) add("COUNT_MISMATCH", `Bundle declares ${draft.size} items but contains ${items.length}`);
  if (!Number.isSafeInteger(draft.priceMinor) || draft.priceMinor <= 0) add("PRICE_INVALID", "Bundle price must be a positive integer in minor units");
  if (draft.sellerId === null && draft.ownerType !== "PLATFORM") add("OWNER_MISMATCH", "Platform bundle must have ownerType PLATFORM");

  const seen = new Set<string>();
  let retailTotal = 0;
  for (const it of items) {
    if (seen.has(it.id)) add("DUPLICATE_ITEM", "Item appears twice in bundle", it.id);
    seen.add(it.id);
    if (it.brandId !== draft.brandId) add("BRAND_MISMATCH", "Item brand differs from bundle brand", it.id);
    if (!it.styleId || it.styleId !== draft.styleId) add("STYLE_MISMATCH", "Item style differs from bundle style (or is unset)", it.id);
    if (it.arrangement !== draft.arrangement) add("ARRANGEMENT_MISMATCH", "All items in a bundle must share one selling arrangement", it.id);
    if (it.ownerType !== draft.ownerType) add("OWNER_MISMATCH", "Item owner differs from bundle owner", it.id);
    if (draft.sellerId !== null && it.sellerId !== draft.sellerId) add("SELLER_MISMATCH", "Item belongs to a different seller", it.id);
    if (!BUNDLEABLE_STATES.has(it.stockState)) add("NOT_BUNDLEABLE_STATE", `Item stock state ${it.stockState} cannot be bundled`, it.id);
    if (!it.conditionGrade || !BUNDLE_ALLOWED_LETTERS.includes(GRADE_LETTER[it.conditionGrade]))
      add("GRADE_NOT_ALLOWED", "Bundles may only contain grade A or B pieces", it.id);
    if (it.activeBundleId) add("ALREADY_BUNDLED", "Item is already in another active bundle", it.id);
    if (it.hasPublishedRetailListing) add("RETAIL_LISTING_CONFLICT", "Item has a published retail listing; withdraw it first", it.id);
    if (it.currency !== draft.currency) add("CURRENCY_MISMATCH", "Item currency differs from bundle currency", it.id);
    if (!Number.isSafeInteger(it.refRetailMinor) || it.refRetailMinor <= 0) add("MISSING_REF_PRICE", "Item needs a positive reference retail price", it.id);
    else retailTotal += it.refRetailMinor;
  }
  if (draft.priceMinor > 0 && draft.priceMinor < policy.minPricePerPieceMinor * draft.size)
    add("PRICE_BELOW_FLOOR", `Bundle price is below the per-piece floor (${policy.minPricePerPieceMinor} minor units x ${draft.size})`);
  if (draft.priceMinor > 0 && retailTotal > 0 && draft.priceMinor * 10_000 > retailTotal * (10_000 - policy.minDiscountBps))
    add("PRICE_NOT_DISCOUNTED", `Bundle price must be at least ${policy.minDiscountBps / 100}% below the sum of piece retail values`);
  return issues;
}

/**
 * Split the single bundle price across items proportionally to reference retail value.
 * The shares sum EXACTLY to the bundle price. Used so returns (damaged claims), commission and
 * ledger entries can work per item even though the buyer paid one price.
 */
export function allocateBundlePrice(
  bundlePrice: Money,
  items: ReadonlyArray<{ id: string; refRetailMinor: number }>,
): Array<{ id: string; share: Money }> {
  const shares = allocate(bundlePrice, items.map((i) => i.refRetailMinor));
  return items.map((it, idx) => ({ id: it.id, share: shares[idx]! }));
}

/** Display helpers (not accounting). */
export function pricePerPiece(bundlePrice: Money, size: number): Money {
  return money(Math.round(bundlePrice.amountMinor / size), bundlePrice.currency);
}
export function savingsBps(bundlePriceMinor: number, retailValueMinor: number): number {
  if (retailValueMinor <= 0) return 0;
  return Math.max(0, Math.round(((retailValueMinor - bundlePriceMinor) / retailValueMinor) * 10_000));
}

/** Lot-page breakdown. Sizes and colours may be mixed within a lot, so buyers must see the spread. */
export function summarizeBundle(items: ReadonlyArray<Pick<BundleCandidateItem, "size" | "color" | "conditionGrade">>) {
  const tally = (vals: (string | null | undefined)[]) =>
    vals.reduce<Record<string, number>>((acc, v) => { const k = v ?? "Unspecified"; acc[k] = (acc[k] ?? 0) + 1; return acc; }, {});
  return {
    sizes: tally(items.map((i) => i.size)),
    colors: tally(items.map((i) => i.color)),
    grades: tally(items.map((i) => (i.conditionGrade ? GRADE_LETTER[i.conditionGrade] : null))),
  };
}
