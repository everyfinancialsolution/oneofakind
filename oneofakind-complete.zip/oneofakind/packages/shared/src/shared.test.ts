import { describe, it, expect } from "vitest";
import { money, add, sub, applyBps, allocate, sum, MoneyError, itemStock, order, listing, directPurchase,
  InvalidTransitionError, ownerFor, saleAccounting } from "./index";

describe("money", () => {
  it("rejects floats", () => expect(() => money(10.5)).toThrow(MoneyError));
  it("rejects currency mix", () => expect(() => add(money(1, "PKR"), money(1, "USD"))).toThrow(MoneyError));
  it("adds/subtracts exactly", () => {
    expect(add(money(10), money(20)).amountMinor).toBe(30);
    expect(sub(money(10), money(20)).amountMinor).toBe(-10);
  });
  it("applies bps with half-up rounding", () => {
    expect(applyBps(money(1000), 1500).amountMinor).toBe(150);
    expect(applyBps(money(333), 1500).amountMinor).toBe(50); // 49.95 -> 50
  });
  it("allocate preserves the total", () => {
    for (const total of [1, 99, 100, 1001, 123457]) {
      const parts = allocate(money(total), [1, 1, 1]);
      expect(sum(parts).amountMinor).toBe(total);
    }
    expect(allocate(money(-100), [1, 2]).map((m) => m.amountMinor)).toEqual([-34, -66]);
  });
});

describe("state machines", () => {
  it("blocks selling something not reserved", () => {
    expect(itemStock.can("AVAILABLE", "SOLD")).toBe(false);
    expect(() => itemStock.assert("AVAILABLE", "SOLD")).toThrow(InvalidTransitionError);
  });
  it("only reserved items can be sold", () => expect(itemStock.can("RESERVED", "SOLD")).toBe(true));
  it("sold items cannot become available again except via cancellation path", () => {
    expect(itemStock.can("SOLD", "AVAILABLE")).toBe(true);
    expect(itemStock.can("DISPATCHED", "AVAILABLE")).toBe(false);
  });
  it("terminal states have no exits", () => {
    expect(order.isTerminal("REFUNDED")).toBe(true);
    expect(listing.isTerminal("REMOVED")).toBe(true);
  });
  it("direct purchase cannot jump to TRANSFERRED before payment", () => {
    expect(directPurchase.can("OFFER_MADE", "TRANSFERRED")).toBe(false);
    expect(directPurchase.can("ACCEPTED", "TRANSFERRED")).toBe(false);
    expect(directPurchase.can("AWAITING_PAYMENT", "TRANSFERRED")).toBe(true);
  });
  it("every state in every table is declared (no dangling targets)", () => {
    for (const m of [itemStock, order, listing, directPurchase]) {
      const keys = new Set(Object.keys(m.table));
      for (const targets of Object.values(m.table) as string[][])
        for (const t of targets) expect(keys.has(t)).toBe(true);
    }
  });
});

describe("arrangements", () => {
  it("direct purchase item is seller-owned until transfer", () => {
    expect(ownerFor("DIRECT_PURCHASE", false)).toBe("SELLER");
    expect(ownerFor("DIRECT_PURCHASE", true)).toBe("PLATFORM");
  });
  it("refuses principal sale before transfer", () => {
    expect(() => saleAccounting("DIRECT_PURCHASE", "SELLER")).toThrow();
    expect(saleAccounting("DIRECT_PURCHASE", "PLATFORM")).toBe("PRINCIPAL_SALE");
    expect(saleAccounting("MANAGED_RESALE", "SELLER")).toBe("AGENT_COMMISSION");
  });
});

import { validateBundleComposition, allocateBundlePrice, pricePerPiece, savingsBps, bundle, BUNDLE_SIZES, summarizeBundle,
  type BundleDraft, type BundleCandidateItem } from "./index";

const mkItems = (n: number, over: Partial<BundleCandidateItem> = {}): BundleCandidateItem[] =>
  Array.from({ length: n }, (_, i) => ({
    id: `i${i}`, brandId: "nike", styleId: "track-jacket", sellerId: "s1", ownerType: "SELLER",
    arrangement: "MANAGED_RESALE", stockState: "AVAILABLE", conditionGrade: "EXCELLENT", channel: "RETAIL", currency: "PKR",
    refRetailMinor: 400_000, ...over,
  }));
const draft = (size: number, over: Partial<BundleDraft> = {}): BundleDraft => ({
  size, brandId: "nike", styleId: "track-jacket", sellerId: "s1", ownerType: "SELLER",
  arrangement: "MANAGED_RESALE", priceMinor: size * 250_000, currency: "PKR", ...over,
});

describe("bundles", () => {
  it("accepts valid 5/10/15 bundles", () => {
    for (const n of BUNDLE_SIZES) expect(validateBundleComposition(draft(n), mkItems(n))).toEqual([]);
  });
  it("rejects disallowed size and count mismatch", () => {
    expect(validateBundleComposition(draft(7), mkItems(7)).map((i) => i.code)).toContain("SIZE_NOT_ALLOWED");
    expect(validateBundleComposition(draft(10), mkItems(9)).map((i) => i.code)).toContain("COUNT_MISMATCH");
  });
  it("enforces same brand and same style", () => {
    const items = mkItems(5); items[2] = { ...items[2]!, brandId: "adidas" }; items[3] = { ...items[3]!, styleId: "windbreaker" };
    const codes = validateBundleComposition(draft(5), items);
    expect(codes.find((c) => c.code === "BRAND_MISMATCH")?.itemId).toBe("i2");
    expect(codes.find((c) => c.code === "STYLE_MISMATCH")?.itemId).toBe("i3");
  });
  it("rejects items with no style set", () => {
    const items = mkItems(5); items[0] = { ...items[0]!, styleId: null };
    expect(validateBundleComposition(draft(5), items).map((i) => i.code)).toContain("STYLE_MISMATCH");
  });
  it("rejects mixed arrangement, other seller's items, and non-bundleable stock", () => {
    const items = mkItems(5);
    items[0] = { ...items[0]!, arrangement: "SELF_MANAGED" };
    items[1] = { ...items[1]!, sellerId: "s2" };
    items[2] = { ...items[2]!, stockState: "SOLD" };
    const codes = validateBundleComposition(draft(5), items).map((i) => i.code);
    expect(codes).toEqual(expect.arrayContaining(["ARRANGEMENT_MISMATCH", "SELLER_MISMATCH", "NOT_BUNDLEABLE_STATE"]));
  });
  it("blocks items already bundled or live as retail, and duplicates", () => {
    const items = mkItems(5); items[0] = { ...items[0]!, activeBundleId: "b9" };
    items[1] = { ...items[1]!, hasPublishedRetailListing: true }; items[2] = items[3]!;
    const codes = validateBundleComposition(draft(5), items).map((i) => i.code);
    expect(codes).toEqual(expect.arrayContaining(["ALREADY_BUNDLED", "RETAIL_LISTING_CONFLICT", "DUPLICATE_ITEM"]));
  });
  it("platform bundle only with platform-owned items", () => {
    const d = draft(5, { sellerId: null, ownerType: "PLATFORM", arrangement: "DIRECT_PURCHASE" });
    const ok = mkItems(5, { ownerType: "PLATFORM", arrangement: "DIRECT_PURCHASE" });
    expect(validateBundleComposition(d, ok)).toEqual([]);
    const bad = mkItems(5, { ownerType: "SELLER", arrangement: "DIRECT_PURCHASE" }); // purchased but not yet transferred
    expect(validateBundleComposition(d, bad).map((i) => i.code)).toContain("OWNER_MISMATCH");
  });
  it("bundle price must be a discount to retail value", () => {
    expect(validateBundleComposition(draft(5, { priceMinor: 5 * 400_000 }), mkItems(5)).map((i) => i.code)).toContain("PRICE_NOT_DISCOUNTED");
  });
  it("allocates bundle price exactly across items, proportional to retail value", () => {
    const items = [{ id: "a", refRetailMinor: 100_000 }, { id: "b", refRetailMinor: 300_000 }, { id: "c", refRetailMinor: 600_001 }];
    const out = allocateBundlePrice(money(999_999), items);
    expect(out.reduce((s, x) => s + x.share.amountMinor, 0)).toBe(999_999);
    expect(out.map((x) => x.id)).toEqual(["a", "b", "c"]);
    expect(out[2]!.share.amountMinor).toBeGreaterThan(out[1]!.share.amountMinor);
  });
  it("allows mixed sizes and colours but only grade A/B pieces", () => {
    const items = mkItems(5).map((it, i) => ({ ...it, size: ["S", "M", "L", "XL", "M"][i], color: ["red", "black", "blue", "black", "white"][i] }));
    items[1] = { ...items[1]!, conditionGrade: "VERY_GOOD" }; // B
    expect(validateBundleComposition(draft(5), items)).toEqual([]);
    const s = summarizeBundle(items);
    expect(s.sizes).toEqual({ S: 1, M: 2, L: 1, XL: 1 });
    expect(s.grades).toEqual({ A: 4, B: 1 });
  });
  it("rejects grade C/D and ungraded pieces in bundles", () => {
    const items = mkItems(5);
    items[0] = { ...items[0]!, conditionGrade: "GOOD" }; items[1] = { ...items[1]!, conditionGrade: "FAIR" }; items[2] = { ...items[2]!, conditionGrade: null };
    const bad = validateBundleComposition(draft(5), items).filter((i) => i.code === "GRADE_NOT_ALLOWED").map((i) => i.itemId);
    expect(bad).toEqual(["i0", "i1", "i2"]);
  });
  it("display helpers", () => {
    expect(pricePerPiece(money(1_250_000), 5).amountMinor).toBe(250_000);
    expect(savingsBps(1_250_000, 2_000_000)).toBe(3750);
  });
  it("bundle state machine: cannot sell unpublished, reservation can release", () => {
    expect(bundle.can("DRAFT", "SOLD")).toBe(false);
    expect(bundle.can("PUBLISHED", "SOLD")).toBe(false);
    expect(bundle.can("PUBLISHED", "RESERVED")).toBe(true);
    expect(bundle.can("RESERVED", "PUBLISHED")).toBe(true);
    expect(bundle.isTerminal("SOLD")).toBe(true);
  });
});
