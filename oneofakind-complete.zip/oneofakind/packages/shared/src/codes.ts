/**
 * Barcode / QR identifiers.
 * Format: 13 digits = [kind digit][11-digit sequence][GS1 mod-10 check digit].
 * Print as Code 128 (NOT EAN-13 symbology: these are internal codes and must never collide with real retail GTINs)
 * and as QR. The label carries ONLY the opaque code; the server decides what it means and who may scan it.
 */
export const SCAN_KINDS = ["ITEM_PACK", "BUNDLE_PACK", "ORDER_PACK", "DISPATCH"] as const;
export type ScanKind = (typeof SCAN_KINDS)[number];

const KIND_DIGIT: Record<ScanKind, string> = { ITEM_PACK: "1", BUNDLE_PACK: "2", ORDER_PACK: "3", DISPATCH: "4" };
const DIGIT_KIND: Record<string, ScanKind> = Object.fromEntries(Object.entries(KIND_DIGIT).map(([k, d]) => [d, k as ScanKind]));
export const MAX_SEQUENCE = 99_999_999_999; // 11 digits

export class CodeError extends Error {}

/** GS1 mod-10: from the right of the 12-digit body, weights 3,1,3,1,... */
export function checkDigit(body12: string): string {
  if (!/^\d{12}$/.test(body12)) throw new CodeError("body must be 12 digits");
  let sum = 0;
  for (let i = 0; i < 12; i++) sum += Number(body12[11 - i]) * (i % 2 === 0 ? 3 : 1);
  return String((10 - (sum % 10)) % 10);
}

export function makeCode(kind: ScanKind, sequence: number): string {
  if (!Number.isInteger(sequence) || sequence < 1 || sequence > MAX_SEQUENCE) throw new CodeError(`sequence out of range: ${sequence}`);
  const body = KIND_DIGIT[kind] + String(sequence).padStart(11, "0");
  return body + checkDigit(body);
}

export function parseCode(code: string): { valid: true; kind: ScanKind; sequence: number } | { valid: false; reason: string } {
  if (!/^\d{13}$/.test(code)) return { valid: false, reason: "not 13 digits" };
  const kind = DIGIT_KIND[code[0]!];
  if (!kind) return { valid: false, reason: "unknown kind digit" };
  if (checkDigit(code.slice(0, 12)) !== code[12]) return { valid: false, reason: "bad check digit" };
  return { valid: true, kind, sequence: Number(code.slice(1, 12)) };
}

/** QR payload: versioned + opaque. Contains no item data. */
export const qrPayload = (code: string) => `OOAK1:${code}`;

/** Accepts raw barcode digits (handheld scanner) or a QR payload (camera). Returns the code only if it is well-formed. */
export function parseScan(raw: string): { ok: true; code: string; kind: ScanKind } | { ok: false; reason: string } {
  const t = raw.trim();
  const code = t.startsWith("OOAK1:") ? t.slice(6) : t;
  const p = parseCode(code);
  return p.valid ? { ok: true, code, kind: p.kind } : { ok: false, reason: p.reason };
}
