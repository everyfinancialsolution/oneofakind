import { describe, it, expect } from "vitest";
import { LABEL_SPECS, FORBIDDEN_LABEL_FIELDS, idDocDeleteAfter, ID_DOC_RETENTION_DAYS } from "./index";

describe("labels", () => {
  it("no label may carry prices or personal data", () => {
    for (const [kind, spec] of Object.entries(LABEL_SPECS))
      for (const f of spec.fields) expect(FORBIDDEN_LABEL_FIELDS as readonly string[], `${kind}.${f}`).not.toContain(f);
  });
  it("every label has both a barcode and a QR", () => {
    for (const spec of Object.values(LABEL_SPECS)) expect(spec.fields).toEqual(expect.arrayContaining(["barcode", "qr"]));
  });
  it("item label is 50x30mm; dispatch label is 100x150mm", () => {
    expect(LABEL_SPECS.ITEM).toMatchObject({ widthMm: 50, heightMm: 30 });
    expect(LABEL_SPECS.DISPATCH).toMatchObject({ widthMm: 100, heightMm: 150 });
  });
});
describe("ID retention", () => {
  it("delete-after is 90 days after the decision", () => {
    const d = new Date("2026-10-13T00:00:00Z");
    expect(idDocDeleteAfter(d).toISOString()).toBe("2027-01-11T00:00:00.000Z");
    expect(ID_DOC_RETENTION_DAYS).toBe(90);
  });
});
