/**
 * Thermal label specs (sizes in mm, configurable). Labels print as PDFs at EXACT size so any thermal printer driver can print them
 * from the browser; raw ZPL/ESC-POS can be added per printer model later. Labels never carry prices or personal data
 * (phone, full address, ID numbers): the code is opaque and the server resolves it.
 */
export type LabelKind = "ITEM" | "LOT" | "ORDER_PACK" | "DISPATCH";
export const LABEL_SPECS: Record<LabelKind, { widthMm: number; heightMm: number; fields: readonly string[] }> = {
  ITEM:       { widthMm: 50,  heightMm: 30,  fields: ["barcode", "qr", "sku", "brand", "size", "title"] },
  LOT:        { widthMm: 100, heightMm: 50,  fields: ["barcode", "qr", "lotSku", "brand", "style", "pieceCount"] },
  ORDER_PACK: { widthMm: 100, heightMm: 150, fields: ["barcode", "qr", "orderRef", "expectedPieces", "shipToName", "shipToCity"] },
  DISPATCH:   { widthMm: 100, heightMm: 150, fields: ["barcode", "qr", "orderRef", "courier", "trackingNo", "shipToName", "shipToCity", "pieceCount", "parcelIndexOfCount"] },
};
export const FORBIDDEN_LABEL_FIELDS = ["price", "priceMinor", "phone", "address", "addressLine", "cnic", "idNumber", "email"] as const;

/** Sellers without a thermal printer can print item labels on A4 sheets (3 columns x 8 rows of 63.5x33.9mm... configurable). */
export const A4_ITEM_SHEET = { columns: 3, rows: 8 } as const;
