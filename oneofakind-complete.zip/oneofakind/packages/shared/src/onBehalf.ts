import type { ViewerRole } from "./bundleAccess";

/**
 * Authorised staff (role SELLER_AGENT, or ADMIN) may act FOR a seller who asked us to (sellers who are not comfortable with websites).
 * They never impersonate: every action is an explicit on-behalf action written to AuditLog.onBehalfOfId.
 */
export const ON_BEHALF_ROLES: readonly ViewerRole[] = ["SELLER_AGENT", "ADMIN"];

export const ON_BEHALF_ALLOWED = [
  "CREATE_DRAFT_LISTING", "EDIT_DRAFT_LISTING", "UPLOAD_PHOTOS", "REQUEST_LABEL", "CREATE_BUNDLE_DRAFT", "SUBMIT_FOR_REVIEW",
] as const;
/** Money, ownership and account-security actions ALWAYS need the seller's own confirmation (OTP), never staff. */
export const ON_BEHALF_FORBIDDEN = [
  "CHANGE_PAYOUT_DETAILS", "ACCEPT_OFFER", "ACCEPT_DIRECT_PURCHASE_OFFER", "APPROVE_PRICE", "CLOSE_ACCOUNT", "CHANGE_PHONE",
] as const;
export type OnBehalfAction = (typeof ON_BEHALF_ALLOWED)[number] | (typeof ON_BEHALF_FORBIDDEN)[number];

export interface OnBehalfContext {
  sellerApproved: boolean;          // onboarding application APPROVED
  sellerAllowsStaffListing: boolean; // SellerProfile.allowStaffListing (consent recorded)
}

export function canActOnBehalf(roles: readonly ViewerRole[], action: OnBehalfAction, ctx: OnBehalfContext): { ok: true } | { ok: false; reason: string } {
  if (!roles.some((r) => ON_BEHALF_ROLES.includes(r))) return { ok: false, reason: "not an authorised agent" };
  if ((ON_BEHALF_FORBIDDEN as readonly string[]).includes(action)) return { ok: false, reason: "requires the seller's own confirmation" };
  if (!ctx.sellerApproved) return { ok: false, reason: "seller is not approved" };
  if (!ctx.sellerAllowsStaffListing) return { ok: false, reason: "seller has not consented to staff listing for them" };
  return { ok: true };
}
