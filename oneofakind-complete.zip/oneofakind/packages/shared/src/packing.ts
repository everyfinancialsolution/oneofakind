import { parseScan } from "./codes";

/** Dispatch codes may only be issued once packing is fully verified. */
export const canIssueDispatch = (c: PackCheck) => c.status === "COMPLETE";

export type PackStatus = "COMPLETE" | "INCOMPLETE" | "MISMATCH";
export interface PackCheck {
  status: PackStatus;
  missing: string[];      // expected but not yet scanned
  unexpected: string[];   // scanned but not part of this order
  duplicates: string[];   // scanned more than once
  invalid: string[];      // raw strings that are not valid codes
}

/**
 * Pack verification. `expected` = for each order line: the ITEM_PACK code of a retail piece, or the BUNDLE_PACK code
 * of a sealed lot (scanning the lot code stands for all its pieces; an unsealed lot must expect its piece codes instead).
 * Anything unexpected or unreadable => MISMATCH, which must block dispatch-label issue until resolved.
 */
export function verifyPackScan(expected: readonly string[], scannedRaw: readonly string[]): PackCheck {
  const exp = new Set(expected);
  const invalid: string[] = [];
  const seen = new Map<string, number>();
  for (const raw of scannedRaw) {
    const r = parseScan(raw);
    if (!r.ok) { invalid.push(raw); continue; }
    seen.set(r.code, (seen.get(r.code) ?? 0) + 1);
  }
  const unexpected = [...seen.keys()].filter((c) => !exp.has(c));
  const duplicates = [...seen.entries()].filter(([c, n]) => n > 1 && exp.has(c)).map(([c]) => c);
  const missing = expected.filter((c) => !seen.has(c));
  const status: PackStatus = unexpected.length || invalid.length ? "MISMATCH" : missing.length ? "INCOMPLETE" : "COMPLETE";
  return { status, missing, unexpected, duplicates, invalid };
}
