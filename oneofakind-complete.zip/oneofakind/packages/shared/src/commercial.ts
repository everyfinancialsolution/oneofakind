import { applyBps, money, type Money } from "./money";
import type { SellingArrangement, SalesChannel } from "./arrangements";

/**
 * Adopted default commercial rules (Oct 2026). Runtime values must come from CommissionRule / config tables
 * so finance can change them without a deploy; these are the seed defaults and the reference implementation.
 * Amounts are minor units (paisa): PKR 5,000 = 500_000.
 */
export const MANAGED_RETAIL_TIERS = [
  { upToMinor: 500_000, bps: 3_500 },    // up to PKR 5,000      -> 35%
  { upToMinor: 2_000_000, bps: 3_000 },  // PKR 5,001 - 20,000   -> 30%
  { upToMinor: Infinity, bps: 2_500 },   // above PKR 20,000     -> 25%
] as const;

export const COMMISSION_BPS = {
  RETAIL_SELF_MANAGED: 1_200,   // 12%
  BUNDLE_SELF_MANAGED: 800,     // 8%
  BUNDLE_MANAGED: 2_000,        // 20% flat on the lot price
} as const;

/** Platform commission in basis points for a sale. Direct-purchase (platform-owned) = 0: it is a principal sale, margin is price - cost. */
export function commissionBps(channel: SalesChannel, arrangement: SellingArrangement, priceMinor: number): number {
  if (arrangement === "DIRECT_PURCHASE") return 0;
  if (channel === "BUNDLE") return arrangement === "MANAGED_RESALE" ? COMMISSION_BPS.BUNDLE_MANAGED : COMMISSION_BPS.BUNDLE_SELF_MANAGED;
  if (arrangement === "SELF_MANAGED") return COMMISSION_BPS.RETAIL_SELF_MANAGED;
  return MANAGED_RETAIL_TIERS.find((t) => priceMinor <= t.upToMinor)!.bps;
}

export function commissionFor(channel: SalesChannel, arrangement: SellingArrangement, price: Money): Money {
  return applyBps(price, commissionBps(channel, arrangement, price.amountMinor));
}

/** What the buying team may offer a seller, as a share of expected RETAIL resale value: 35% min, 40% target, 45% max. */
export function directPurchaseOfferRange(expectedRetailMinor: number, currency: "PKR" = "PKR") {
  const v = money(expectedRetailMinor, currency);
  return { min: applyBps(v, 3_500), target: applyBps(v, 4_000), max: applyBps(v, 4_500) };
}

export const PAYOUT_HOLD_DAYS = 7;
export const DAMAGE_CLAIM_WINDOW_HOURS = 48;
export const MIN_PAYOUT_MINOR = 100_000; // PKR 1,000
export const RESERVATION_MINUTES = { RETAIL: 15, BUNDLE: 30 } as const;
export const MANAGED_STORAGE_DAYS = 90;
export const MANAGED_MARKDOWNS = [{ day: 45, percentOff: 15 }, { day: 75, percentOff: 25 }] as const;
export const MANAGED_MIN_ITEM_PRICE_MINOR = 200_000; // PKR 2,000; below this => self-managed only
