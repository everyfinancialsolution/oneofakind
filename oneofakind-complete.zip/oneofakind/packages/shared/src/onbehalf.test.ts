import { describe, it, expect } from "vitest";
import { canActOnBehalf, compareNames, whatsappLink, applyOnWhatsAppMessage, applicationReference } from "./index";

const ok = { sellerApproved: true, sellerAllowsStaffListing: true };
describe("acting on behalf of a seller", () => {
  it("authorised agents may create drafts for consenting, approved sellers", () => {
    expect(canActOnBehalf(["SELLER_AGENT"], "CREATE_DRAFT_LISTING", ok)).toEqual({ ok: true });
    expect(canActOnBehalf(["ADMIN"], "UPLOAD_PHOTOS", ok)).toEqual({ ok: true });
  });
  it("others (support, customers, sellers) may not", () => {
    for (const r of ["SUPPORT", "CUSTOMER", "SELLER", "WAREHOUSE", "FINANCE"] as const)
      expect(canActOnBehalf([r], "CREATE_DRAFT_LISTING", ok).ok).toBe(false);
  });
  it("needs approval and the seller's consent", () => {
    expect(canActOnBehalf(["SELLER_AGENT"], "EDIT_DRAFT_LISTING", { ...ok, sellerApproved: false }).ok).toBe(false);
    expect(canActOnBehalf(["SELLER_AGENT"], "EDIT_DRAFT_LISTING", { ...ok, sellerAllowsStaffListing: false }).ok).toBe(false);
  });
  it("money/ownership/security actions are never allowed on behalf, even for admin", () => {
    for (const a of ["CHANGE_PAYOUT_DETAILS", "ACCEPT_OFFER", "ACCEPT_DIRECT_PURCHASE_OFFER", "APPROVE_PRICE", "CLOSE_ACCOUNT", "CHANGE_PHONE"] as const)
      expect(canActOnBehalf(["ADMIN"], a, ok).ok).toBe(false);
  });
});

describe("payout name check (own-name account)", () => {
  it("exact, any word order", () => expect(compareNames("Muhammad Ali Khan", "KHAN, Muhammad Ali")).toBe("EXACT"));
  it("partial needs a human", () => expect(compareNames("Ali Khan", "Muhammad Ali Khan")).toBe("PARTIAL"));
  it("different people mismatch; single shared word is not enough", () => {
    expect(compareNames("Ali Khan", "Ahmed Raza")).toBe("MISMATCH");
    expect(compareNames("Ali", "Ali Khan")).toBe("MISMATCH");
    expect(compareNames("", "Ali Khan")).toBe("MISMATCH");
  });
});

describe("WhatsApp deep link", () => {
  it("builds a wa.me link with digits only and an encoded reference message", () => {
    const url = whatsappLink("+44 7513 875488", applyOnWhatsAppMessage("SELLER", applicationReference("SELLER", 123)));
    expect(url.startsWith("https://wa.me/447513875488?text=")).toBe(true);
    expect(decodeURIComponent(url.split("text=")[1]!)).toContain("OOAK-S-000123");
    expect(() => whatsappLink("12", "x")).toThrow();
  });
});
