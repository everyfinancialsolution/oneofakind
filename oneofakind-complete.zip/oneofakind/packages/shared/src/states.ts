/**
 * Explicit state machines. The API MUST route every status change through assertTransition()
 * so invalid jumps (e.g. SOLD -> AVAILABLE) are impossible by construction.
 */
export class InvalidTransitionError extends Error {
  constructor(machine: string, from: string, to: string) {
    super(`${machine}: invalid transition ${from} -> ${to}`);
  }
}

type Machine<S extends string> = Readonly<Record<S, readonly S[]>>;

function make<S extends string>(name: string, table: Machine<S>) {
  return {
    name,
    table,
    can: (from: S, to: S) => table[from].includes(to),
    assert(from: S, to: S) {
      if (!table[from].includes(to)) throw new InvalidTransitionError(name, from, to);
    },
    isTerminal: (s: S) => table[s].length === 0,
  };
}

/** Physical + sales availability of a single one-of-a-kind item. */
export const ITEM_STOCK_STATES = [
  "EXPECTED", "RECEIVED", "IN_INSPECTION", "REJECTED", "READY_TO_LIST", "AVAILABLE",
  "RESERVED", "SOLD", "PACKED", "DISPATCHED", "DELIVERED", "RETURN_PENDING", "RETURNED_TO_STOCK",
  "RETURNED_TO_SELLER", "WITHDRAWN", "LOST_OR_DAMAGED",
] as const;
export type ItemStockState = (typeof ITEM_STOCK_STATES)[number];

export const itemStock = make<ItemStockState>("ItemStock", {
  EXPECTED: ["RECEIVED", "WITHDRAWN"],
  RECEIVED: ["IN_INSPECTION", "LOST_OR_DAMAGED"],
  IN_INSPECTION: ["READY_TO_LIST", "REJECTED"],
  REJECTED: ["RETURNED_TO_SELLER"],
  READY_TO_LIST: ["AVAILABLE", "WITHDRAWN"],
  AVAILABLE: ["RESERVED", "WITHDRAWN", "LOST_OR_DAMAGED"],
  RESERVED: ["AVAILABLE", "SOLD"], // reservation expiry/cancel -> AVAILABLE
  SOLD: ["PACKED", "AVAILABLE"], // AVAILABLE only via cancelled/refunded-before-dispatch
  PACKED: ["DISPATCHED", "SOLD"],
  DISPATCHED: ["DELIVERED", "RETURN_PENDING"],
  DELIVERED: ["RETURN_PENDING"],
  RETURN_PENDING: ["RETURNED_TO_STOCK", "DELIVERED", "LOST_OR_DAMAGED"],
  RETURNED_TO_STOCK: ["IN_INSPECTION"],
  RETURNED_TO_SELLER: [],
  WITHDRAWN: ["RETURNED_TO_SELLER"],
  LOST_OR_DAMAGED: [],
});

export const ORDER_STATES = [
  "PENDING_PAYMENT", "PAID", "PROCESSING", "PARTIALLY_FULFILLED", "FULFILLED",
  "COMPLETED", "CANCELLED", "REFUND_PENDING", "REFUNDED",
] as const;
export type OrderState = (typeof ORDER_STATES)[number];

export const order = make<OrderState>("Order", {
  PENDING_PAYMENT: ["PAID", "CANCELLED"],
  PAID: ["PROCESSING", "REFUND_PENDING", "CANCELLED"],
  PROCESSING: ["PARTIALLY_FULFILLED", "FULFILLED", "REFUND_PENDING", "CANCELLED"],
  PARTIALLY_FULFILLED: ["FULFILLED", "REFUND_PENDING"],
  FULFILLED: ["COMPLETED", "REFUND_PENDING"],
  COMPLETED: ["REFUND_PENDING"],
  CANCELLED: [],
  REFUND_PENDING: ["REFUNDED", "PROCESSING", "COMPLETED"],
  REFUNDED: [],
});

export const LISTING_STATES = ["DRAFT", "PENDING_REVIEW", "CHANGES_REQUESTED", "PUBLISHED", "PAUSED", "SOLD_OUT", "REMOVED"] as const;
export type ListingState = (typeof LISTING_STATES)[number];

export const listing = make<ListingState>("Listing", {
  DRAFT: ["PENDING_REVIEW", "REMOVED"],
  PENDING_REVIEW: ["PUBLISHED", "CHANGES_REQUESTED", "REMOVED"],
  CHANGES_REQUESTED: ["PENDING_REVIEW", "REMOVED"],
  PUBLISHED: ["PAUSED", "SOLD_OUT", "REMOVED", "PENDING_REVIEW"],
  PAUSED: ["PUBLISHED", "REMOVED"],
  SOLD_OUT: ["PUBLISHED", "REMOVED"], // PUBLISHED only on returned-to-stock relist
  REMOVED: [],
});

export const DIRECT_PURCHASE_STATES = [
  "SUBMITTED", "UNDER_REVIEW", "OFFER_MADE", "ACCEPTED", "REJECTED_BY_SELLER", "REJECTED_BY_BUYER_TEAM",
  "EXPIRED", "AWAITING_HANDOVER", "AWAITING_PAYMENT", "TRANSFERRED", "CANCELLED",
] as const;
export type DirectPurchaseState = (typeof DIRECT_PURCHASE_STATES)[number];

/** TRANSFERRED is the ONLY state that means ownership moved. The UI must never imply otherwise earlier. */
export const directPurchase = make<DirectPurchaseState>("DirectPurchase", {
  SUBMITTED: ["UNDER_REVIEW", "CANCELLED"],
  UNDER_REVIEW: ["OFFER_MADE", "REJECTED_BY_BUYER_TEAM"],
  OFFER_MADE: ["ACCEPTED", "REJECTED_BY_SELLER", "EXPIRED"],
  ACCEPTED: ["AWAITING_HANDOVER", "CANCELLED"],
  AWAITING_HANDOVER: ["AWAITING_PAYMENT", "CANCELLED"],
  AWAITING_PAYMENT: ["TRANSFERRED", "CANCELLED"],
  REJECTED_BY_SELLER: [], REJECTED_BY_BUYER_TEAM: [], EXPIRED: [], TRANSFERRED: [], CANCELLED: [],
});

export const MANIFEST_STATES = ["DRAFT", "SUBMITTED", "APPROVED", "IN_TRANSIT", "RECEIVING", "RECONCILED", "CANCELLED"] as const;
export type ManifestState = (typeof MANIFEST_STATES)[number];
export const manifest = make<ManifestState>("Manifest", {
  DRAFT: ["SUBMITTED", "CANCELLED"],
  SUBMITTED: ["APPROVED", "CANCELLED"],
  APPROVED: ["IN_TRANSIT", "CANCELLED"],
  IN_TRANSIT: ["RECEIVING"],
  RECEIVING: ["RECONCILED"],
  RECONCILED: [],
  CANCELLED: [],
});

export const BUNDLE_STATES = ["DRAFT", "PENDING_REVIEW", "CHANGES_REQUESTED", "PUBLISHED", "PAUSED", "RESERVED", "SOLD", "REMOVED"] as const;
export type BundleState = (typeof BUNDLE_STATES)[number];
/** RESERVED -> PUBLISHED happens on checkout expiry/payment failure. REMOVED releases all member items. */
export const bundle = make<BundleState>("Bundle", {
  DRAFT: ["PENDING_REVIEW", "REMOVED"],
  PENDING_REVIEW: ["PUBLISHED", "CHANGES_REQUESTED", "REMOVED"],
  CHANGES_REQUESTED: ["PENDING_REVIEW", "REMOVED"],
  PUBLISHED: ["RESERVED", "PAUSED", "REMOVED"],
  PAUSED: ["PUBLISHED", "REMOVED"],
  RESERVED: ["PUBLISHED", "SOLD"],
  SOLD: [],
  REMOVED: [],
});

export const ONBOARDING_STATES = ["DRAFT", "SUBMITTED", "DOCS_REQUESTED", "UNDER_REVIEW", "APPROVED", "REJECTED", "WITHDRAWN"] as const;
export type OnboardingState = (typeof ONBOARDING_STATES)[number];
export const onboarding = make<OnboardingState>("Onboarding", {
  DRAFT: ["SUBMITTED", "WITHDRAWN"],
  SUBMITTED: ["DOCS_REQUESTED", "UNDER_REVIEW", "REJECTED", "WITHDRAWN"],
  DOCS_REQUESTED: ["UNDER_REVIEW", "REJECTED", "WITHDRAWN"],
  UNDER_REVIEW: ["APPROVED", "REJECTED", "DOCS_REQUESTED"],
  APPROVED: [],   // revoking access is a separate action on the seller/reseller record, not an application state
  REJECTED: [],   // re-applying creates a NEW application
  WITHDRAWN: [],
});

export const PAYMENT_STATES = ["INITIATED", "AUTHORIZED", "CAPTURED", "FAILED", "CANCELLED", "REFUNDED", "PARTIALLY_REFUNDED"] as const;
export type PaymentState = (typeof PAYMENT_STATES)[number];
/** Payment status only changes from VERIFIED provider events (webhooks) or our own refund calls. */
export const payment = make<PaymentState>("Payment", {
  INITIATED: ["AUTHORIZED", "CAPTURED", "FAILED", "CANCELLED"],
  AUTHORIZED: ["CAPTURED", "FAILED", "CANCELLED"],
  CAPTURED: ["PARTIALLY_REFUNDED", "REFUNDED"],
  PARTIALLY_REFUNDED: ["PARTIALLY_REFUNDED", "REFUNDED"],
  FAILED: [], CANCELLED: [], REFUNDED: [],
});

export const SHIPMENT_STATES = ["LABEL_PENDING", "READY", "PICKED_UP", "IN_TRANSIT", "OUT_FOR_DELIVERY", "DELIVERED", "FAILED_DELIVERY", "RETURNING", "RETURNED"] as const;
export type ShipmentState = (typeof SHIPMENT_STATES)[number];
export const shipment = make<ShipmentState>("Shipment", {
  LABEL_PENDING: ["READY"],
  READY: ["PICKED_UP"],
  PICKED_UP: ["IN_TRANSIT", "OUT_FOR_DELIVERY", "DELIVERED"],
  IN_TRANSIT: ["OUT_FOR_DELIVERY", "DELIVERED", "FAILED_DELIVERY"],
  OUT_FOR_DELIVERY: ["DELIVERED", "FAILED_DELIVERY"],
  FAILED_DELIVERY: ["OUT_FOR_DELIVERY", "RETURNING"],
  RETURNING: ["RETURNED"],
  DELIVERED: [], RETURNED: [],
});

export const RETURN_STATES = ["REQUESTED", "APPROVED", "REJECTED", "IN_TRANSIT", "RECEIVED", "REFUNDED", "CLOSED"] as const;
export type ReturnState = (typeof RETURN_STATES)[number];
/** Damaged-only claims. APPROVED → REFUNDED directly = refund without return (low-value pieces). */
export const returnRequest = make<ReturnState>("ReturnRequest", {
  REQUESTED: ["APPROVED", "REJECTED"],
  APPROVED: ["IN_TRANSIT", "REFUNDED", "CLOSED"],
  IN_TRANSIT: ["RECEIVED"],
  RECEIVED: ["REFUNDED", "CLOSED"],
  REFUNDED: ["CLOSED"],
  REJECTED: [], CLOSED: [],
});
