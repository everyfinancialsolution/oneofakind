/** The three item-level selling arrangements. A seller may mix them across items. */
export const SELLING_ARRANGEMENTS = ["SELF_MANAGED", "MANAGED_RESALE", "DIRECT_PURCHASE"] as const;
export type SellingArrangement = (typeof SELLING_ARRANGEMENTS)[number];

export const CONDITION_GRADES = ["NEW_WITH_TAGS", "EXCELLENT", "VERY_GOOD", "GOOD", "FAIR"] as const;
export type ConditionGrade = (typeof CONDITION_GRADES)[number];

/** Letter grades shown to buyers. PROPOSED mapping (confirm): A = new/excellent, B = very good, C = good, D = fair. */
export type GradeLetter = "A" | "B" | "C" | "D";
export const GRADE_LETTER: Record<ConditionGrade, GradeLetter> = {
  NEW_WITH_TAGS: "A", EXCELLENT: "A", VERY_GOOD: "B", GOOD: "C", FAIR: "D",
};
/** Objective criteria the inspector applies. Same text is shown to sellers and in the help centre. */
export const GRADE_CRITERIA: Record<GradeLetter, { label: string; rule: string; bundleEligible: boolean }> = {
  A: { label: "Excellent", rule: "New with tags, or worn at most lightly: no stains, holes, repairs, odour, broken fastenings; colour and shape intact. Nothing a buyer would notice at arm's length.", bundleEligible: true },
  B: { label: "Very good", rule: "Light signs of wear only (slight fade, minor pilling, faint creasing). No stains, holes, repairs or broken fastenings. Any minor mark is photographed in the condition report.", bundleEligible: true },
  C: { label: "Good", rule: "Visible wear or small, disclosed flaws (small stain, minor hole, loose seam, replaced button). Retail only, priced accordingly.", bundleEligible: false },
  D: { label: "Fair", rule: "Significant flaws, fully photographed and disclosed. Retail only at a clear discount.", bundleEligible: false },
};

/** Bundles may only contain grade A and B pieces (decided). */
export const BUNDLE_ALLOWED_LETTERS: readonly GradeLetter[] = ["A", "B"];

export const SALES_CHANNELS = ["RETAIL", "BUNDLE"] as const;
export type SalesChannel = (typeof SALES_CHANNELS)[number];

/** Who legally owns the item right now. Drives ledger treatment of a sale. */
export type OwnerType = "SELLER" | "PLATFORM";

export function ownerFor(arrangement: SellingArrangement, transferred: boolean): OwnerType {
  if (arrangement === "DIRECT_PURCHASE") return transferred ? "PLATFORM" : "SELLER";
  return "SELLER"; // consignment + self-managed: seller owns until sale
}

/** Ledger treatment on sale: consignment/self-managed = commission revenue; direct-purchase = full sale revenue + COGS. */
export function saleAccounting(arrangement: SellingArrangement, owner: OwnerType) {
  if (arrangement === "DIRECT_PURCHASE" && owner !== "PLATFORM")
    throw new Error("Direct-purchase item cannot be sold before ownership transfer");
  return arrangement === "DIRECT_PURCHASE" ? "PRINCIPAL_SALE" : "AGENT_COMMISSION";
}
