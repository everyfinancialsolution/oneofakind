import { describe, it, expect } from "vitest";
import { commissionBps, commissionFor, directPurchaseOfferRange, money, validateBundleComposition, GRADE_CRITERIA,
  GRADE_LETTER, CONDITION_GRADES, canIssueDispatch, verifyPackScan, makeCode, type BundleCandidateItem } from "./index";

describe("commission defaults", () => {
  it("retail self-managed is flat 12%", () => expect(commissionBps("RETAIL", "SELF_MANAGED", 999_999)).toBe(1200));
  it("managed retail tiers and boundaries (PKR 5,000 / 20,000 inclusive in lower tier)", () => {
    expect(commissionBps("RETAIL", "MANAGED_RESALE", 300_000)).toBe(3500);
    expect(commissionBps("RETAIL", "MANAGED_RESALE", 500_000)).toBe(3500);
    expect(commissionBps("RETAIL", "MANAGED_RESALE", 500_001)).toBe(3000);
    expect(commissionBps("RETAIL", "MANAGED_RESALE", 2_000_000)).toBe(3000);
    expect(commissionBps("RETAIL", "MANAGED_RESALE", 2_000_001)).toBe(2500);
  });
  it("bundles: 8% self-managed, 20% managed", () => {
    expect(commissionBps("BUNDLE", "SELF_MANAGED", 5_000_000)).toBe(800);
    expect(commissionBps("BUNDLE", "MANAGED_RESALE", 5_000_000)).toBe(2000);
  });
  it("direct purchase is a principal sale: no commission", () => expect(commissionBps("BUNDLE", "DIRECT_PURCHASE", 5_000_000)).toBe(0));
  it("commission amount", () => expect(commissionFor("RETAIL", "MANAGED_RESALE", money(400_000)).amountMinor).toBe(140_000));
  it("direct purchase offer range 35/40/45%", () => {
    const r = directPurchaseOfferRange(1_000_000);
    expect([r.min.amountMinor, r.target.amountMinor, r.max.amountMinor]).toEqual([350_000, 400_000, 450_000]);
  });
});

describe("grades", () => {
  it("every grade maps to a letter and only A/B are bundle-eligible", () => {
    for (const g of CONDITION_GRADES) expect(GRADE_CRITERIA[GRADE_LETTER[g]]).toBeTruthy();
    expect(Object.entries(GRADE_CRITERIA).filter(([, v]) => v.bundleEligible).map(([k]) => k)).toEqual(["A", "B"]);
  });
});

const items = (n: number): BundleCandidateItem[] => Array.from({ length: n }, (_, i) => ({
  id: `i${i}`, brandId: "b", styleId: "s", sellerId: "s1", ownerType: "SELLER", arrangement: "MANAGED_RESALE", stockState: "AVAILABLE",
  conditionGrade: "EXCELLENT", channel: "RETAIL", currency: "PKR", refRetailMinor: 400_000 }));
const d = (price: number) => ({ size: 5, brandId: "b", styleId: "s", sellerId: "s1", ownerType: "SELLER" as const,
  arrangement: "MANAGED_RESALE" as const, priceMinor: price, currency: "PKR" });

describe("bundle price policy", () => {
  it("enforces PKR 1,000/piece floor", () => {
    expect(validateBundleComposition(d(499_999), items(5)).map((i) => i.code)).toContain("PRICE_BELOW_FLOOR");
    expect(validateBundleComposition(d(500_000), items(5)).map((i) => i.code)).not.toContain("PRICE_BELOW_FLOOR");
  });
  it("enforces >=25% discount to retail value (retail total 2,000,000)", () => {
    expect(validateBundleComposition(d(1_500_000), items(5))).toEqual([]);                     // exactly 25% off: ok
    expect(validateBundleComposition(d(1_500_001), items(5)).map((i) => i.code)).toContain("PRICE_NOT_DISCOUNTED");
  });
});

describe("dispatch gating", () => {
  it("dispatch only after COMPLETE pack verification", () => {
    const a = makeCode("ITEM_PACK", 1), b = makeCode("ITEM_PACK", 2);
    expect(canIssueDispatch(verifyPackScan([a, b], [a]))).toBe(false);
    expect(canIssueDispatch(verifyPackScan([a, b], [a, b, makeCode("ITEM_PACK", 3)]))).toBe(false);
    expect(canIssueDispatch(verifyPackScan([a, b], [a, b]))).toBe(true);
  });
});
