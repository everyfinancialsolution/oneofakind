/**
 * Money is ALWAYS integer minor units + explicit currency. Never floats.
 * PKR minor unit = paisa (1 PKR = 100 paisa).
 */
export type CurrencyCode = "PKR" | "USD" | "AED" | "GBP";

export interface Money {
  readonly amountMinor: number; // integer, may be negative for refunds/ledger debits
  readonly currency: CurrencyCode;
}

export class MoneyError extends Error {}

export function money(amountMinor: number, currency: CurrencyCode = "PKR"): Money {
  if (!Number.isSafeInteger(amountMinor)) throw new MoneyError(`amountMinor must be a safe integer, got ${amountMinor}`);
  return Object.freeze({ amountMinor, currency });
}

function same(a: Money, b: Money) {
  if (a.currency !== b.currency) throw new MoneyError(`Currency mismatch: ${a.currency} vs ${b.currency}`);
}

export const add = (a: Money, b: Money): Money => (same(a, b), money(a.amountMinor + b.amountMinor, a.currency));
export const sub = (a: Money, b: Money): Money => (same(a, b), money(a.amountMinor - b.amountMinor, a.currency));
export const negate = (a: Money): Money => money(-a.amountMinor, a.currency);
export const isZero = (a: Money) => a.amountMinor === 0;
export const sum = (items: Money[], currency: CurrencyCode = "PKR"): Money =>
  items.reduce((acc, m) => add(acc, m), money(0, currency));

/** Apply basis points (1 bps = 0.01%) with half-up rounding on positive values. */
export function applyBps(a: Money, bps: number): Money {
  if (!Number.isInteger(bps) || bps < 0 || bps > 10_000) throw new MoneyError(`bps out of range: ${bps}`);
  const raw = (a.amountMinor * bps) / 10_000;
  const rounded = a.amountMinor >= 0 ? Math.floor(raw + 0.5) : -Math.floor(-raw + 0.5);
  return money(rounded, a.currency);
}

/** Split into parts proportional to weights; remainder distributed so total is exact. */
export function allocate(a: Money, weights: number[]): Money[] {
  if (weights.length === 0 || weights.some((w) => !Number.isInteger(w) || w < 0)) throw new MoneyError("invalid weights");
  const total = weights.reduce((x, y) => x + y, 0);
  if (total === 0) throw new MoneyError("weights sum to zero");
  const sign = a.amountMinor < 0 ? -1 : 1;
  const abs = Math.abs(a.amountMinor);
  const shares = weights.map((w) => Math.floor((abs * w) / total));
  let remainder = abs - shares.reduce((x, y) => x + y, 0);
  for (let i = 0; remainder > 0; i = (i + 1) % shares.length) {
    if (weights[i]! > 0) { shares[i]! += 1; remainder -= 1; }
  }
  return shares.map((s) => money(sign * s, a.currency));
}

export function formatMoney(a: Money, locale = "en-PK"): string {
  return new Intl.NumberFormat(locale, { style: "currency", currency: a.currency, maximumFractionDigits: 0 }).format(a.amountMinor / 100);
}
