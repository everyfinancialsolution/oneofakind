import { describe, expect, it } from "vitest";
import { payment, shipment, returnRequest, InvalidTransitionError } from "./states";

describe("payment / shipment / return state machines", () => {
  it("payment: captured only from initiated/authorized; failed is terminal; refunds after capture", () => {
    expect(payment.can("INITIATED", "CAPTURED")).toBe(true);
    expect(payment.can("FAILED", "CAPTURED")).toBe(false);
    expect(payment.can("CAPTURED", "INITIATED")).toBe(false);
    expect(payment.can("CAPTURED", "PARTIALLY_REFUNDED")).toBe(true);
    expect(payment.can("PARTIALLY_REFUNDED", "REFUNDED")).toBe(true);
    expect(() => payment.assert("REFUNDED", "CAPTURED")).toThrow(InvalidTransitionError);
  });
  it("shipment: delivered and returned are terminal; no delivery before pickup", () => {
    expect(shipment.can("READY", "DELIVERED")).toBe(false);
    expect(shipment.can("PICKED_UP", "DELIVERED")).toBe(true);
    expect(shipment.isTerminal("DELIVERED")).toBe(true);
    expect(shipment.can("FAILED_DELIVERY", "RETURNING")).toBe(true);
  });
  it("returns: a rejected claim can't be refunded; refund without return is allowed after approval", () => {
    expect(returnRequest.can("REJECTED", "REFUNDED")).toBe(false);
    expect(returnRequest.can("APPROVED", "REFUNDED")).toBe(true);
    expect(returnRequest.can("REQUESTED", "REFUNDED")).toBe(false);
  });
});
