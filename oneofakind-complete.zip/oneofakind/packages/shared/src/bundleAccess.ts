/**
 * Bundle PRICES are hidden from everyone except verified resellers (to buy), the owning seller, and finance/admin/support/moderator staff.
 * This MUST be enforced in the API response (redact), the search index/sort options, cached pages and share previews - not only in the UI.
 */
export type ViewerRole = "CUSTOMER" | "SELLER" | "WAREHOUSE" | "SUPPORT" | "FINANCE" | "MODERATOR" | "ADMIN" | "SELLER_AGENT" | "VERIFIED_RESELLER";
export interface Viewer { userId?: string; roles: readonly ViewerRole[]; sellerId?: string | null }

const PRICE_STAFF: readonly ViewerRole[] = ["ADMIN", "FINANCE", "SUPPORT", "MODERATOR", "SELLER_AGENT"];

export function canViewBundlePrices(viewer: Viewer | null, bundleSellerId?: string | null): boolean {
  if (!viewer) return false;
  if (viewer.roles.includes("VERIFIED_RESELLER")) return true;
  if (viewer.roles.some((r) => PRICE_STAFF.includes(r))) return true;
  return !!bundleSellerId && viewer.sellerId === bundleSellerId; // owning seller
}

export const canPurchaseBundle = (viewer: Viewer | null): boolean => !!viewer && viewer.roles.includes("VERIFIED_RESELLER");

export const BUNDLE_PRICE_FIELDS = ["priceMinor", "retailValueMinor", "pricePerPieceMinor", "savingsBps", "refRetailMinor", "minPricePerPieceMinor"] as const;

/** Deep-strips every price field. Pure; does not mutate input. Apply to ANY bundle payload (list, detail, search hits, order previews, emails, OG data). */
export function redactBundlePrices<T>(value: T, allowPrices: boolean): T {
  if (allowPrices) return value;
  const strip = (v: unknown): unknown => {
    if (Array.isArray(v)) return v.map(strip);
    if (v && typeof v === "object" && !(v instanceof Date)) {
      const out: Record<string, unknown> = {};
      for (const [k, val] of Object.entries(v as Record<string, unknown>)) {
        if ((BUNDLE_PRICE_FIELDS as readonly string[]).includes(k)) continue;
        out[k] = strip(val);
      }
      return out;
    }
    return v;
  };
  return strip(value) as T;
}

/** Sorting by price/savings would leak price ordering, so it is only offered to viewers who may see prices. */
export function allowedBundleSorts(canSeePrices: boolean): readonly string[] {
  const base = ["newest", "size", "brand"];
  return canSeePrices ? [...base, "price_asc", "price_desc", "savings"] : base;
}
