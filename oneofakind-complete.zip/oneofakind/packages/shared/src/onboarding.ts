export type OnboardingKind = "SELLER" | "RESELLER";
export type OnboardingDocKind = "ID_FRONT" | "ID_BACK" | "PAYOUT_ACCOUNT_PROOF" | "SHOP_PROOF" | "BUSINESS_REG" | "OTHER";

/** Adopted defaults; keep configurable. Seller payout proof must match the ID name so payouts go to the right person. */
export const REQUIRED_DOCS: Record<OnboardingKind, readonly OnboardingDocKind[]> = {
  SELLER: ["ID_FRONT", "ID_BACK", "PAYOUT_ACCOUNT_PROOF"],
  RESELLER: ["ID_FRONT", "ID_BACK", "SHOP_PROOF"], // BUSINESS_REG optional
};

export function missingDocuments(kind: OnboardingKind, received: ReadonlyArray<OnboardingDocKind>): OnboardingDocKind[] {
  const have = new Set(received);
  return REQUIRED_DOCS[kind].filter((d) => !have.has(d));
}

/**
 * Normalise a Pakistani mobile number to +923XXXXXXXXX. Accepts 03xx..., 3xx..., 92 3xx..., +92-3xx..., 0092 3xx...
 * Returns null if it is not a valid mobile number. Phone is the primary identity (OTP login, WhatsApp matching).
 */
export function normalizePkPhone(raw: string): string | null {
  let d = raw.replace(/[^\d+]/g, "");
  if (d.startsWith("+")) d = d.slice(1);
  if (d.startsWith("0092")) d = d.slice(4);
  else if (d.startsWith("92")) d = d.slice(2);
  else if (d.startsWith("0")) d = d.slice(1);
  return /^3\d{9}$/.test(d) ? `+92${d}` : null;
}

export function applicationReference(kind: OnboardingKind, sequence: number): string {
  if (!Number.isInteger(sequence) || sequence < 1) throw new Error("bad sequence");
  return `OOAK-${kind === "SELLER" ? "S" : "R"}-${String(sequence).padStart(6, "0")}`;
}

export type NameMatch = "EXACT" | "PARTIAL" | "MISMATCH";
/**
 * Hint for staff comparing the ID name with the bank/wallet account title (payout must be in the seller's OWN name).
 * EXACT = same words in any order; PARTIAL = every word of the shorter name is in the longer one AND at least 2 words match
 * (e.g. "Ali Khan" vs "Muhammad Ali Khan") - staff must look; MISMATCH = reject/ask for other proof.
 * This never releases a payout by itself: SellerProfile.payoutVerifiedAt is set by a human.
 */
export function compareNames(a: string, b: string): NameMatch {
  const tok = (s: string) => s.toLowerCase().normalize("NFKD").replace(/[^a-z\s]/g, " ").split(/\s+/).filter(Boolean);
  const A = tok(a), B = tok(b);
  if (!A.length || !B.length) return "MISMATCH";
  const sa = new Set(A), sb = new Set(B);
  if (sa.size === sb.size && [...sa].every((t) => sb.has(t))) return "EXACT";
  const [short, long] = sa.size <= sb.size ? [sa, sb] : [sb, sa];
  const common = [...short].filter((t) => long.has(t)).length;
  return common === short.size && common >= 2 ? "PARTIAL" : "MISMATCH";
}

/** wa.me deep link. Number may be given as +44 7513 875488 etc.; WhatsApp wants digits only. */
export function whatsappLink(number: string, message: string): string {
  const digits = number.replace(/\D/g, "");
  if (digits.length < 8 || digits.length > 15) throw new Error("invalid WhatsApp number");
  return `https://wa.me/${digits}?text=${encodeURIComponent(message)}`;
}
export const applyOnWhatsAppMessage = (kind: OnboardingKind, reference: string) =>
  `Hello ONEOFAKIND, I want to register as a ${kind === "SELLER" ? "seller" : "reseller"}. My reference: ${reference}`;

/** Adopted: ID/bank document images are deleted 90 days after the decision; we keep only last-4 + outcome. */
export const ID_DOC_RETENTION_DAYS = 90;
export function idDocDeleteAfter(decidedAt: Date): Date {
  return new Date(decidedAt.getTime() + ID_DOC_RETENTION_DAYS * 86_400_000);
}
