# Design direction (starter, to be refined in Milestone 1)

**Subject:** one-of-a-kind secondhand garments. The distinctive material is the *single piece* — a specific object with a history, wear, and measurements — not "fashion" in general.
**Design idea:** treat every listing like a museum/auction catalogue plate: one object, generous space, a quiet caption block (grade, measurements, provenance/seller). Condition and measurements are first-class visual content, not fine print — this is the trust differentiator for resale.

**Spend boldness in one place:** the product plate (large image, caption-style data beneath, "one of one" marker). Everything else stays quiet.
**Type:** Bodoni Moda (display, headlines and prices only) + Hanken Grotesk (UI/body). Sentence case; no all-caps eyebrow labels, no number markers unless content is a sequence.
**Layout:** left-aligned editorial grid; asymmetric image/caption pairings on desktop, single column on mobile. Buyer = editorial; seller = dense/efficient (tables, keyboard-friendly); admin/warehouse = operational clarity (scan-friendly, large hit targets for handheld/tablet).
**Motion:** one orchestrated moment (home hero reveal). Interaction-driven motion only elsewhere. Respect reduced-motion (already in tokens.css).
**Avoid:** glass everywhere, gradient washes, identical rounded card grids, terracotta accents. Glass only for sticky nav/filter bar over imagery.
**Bundles mode (second storefront):** same tokens, different grammar. Retail = one object per plate. Bundles = a *lot sheet*: a contact-sheet grid showing every piece (5/10/15 tiles) with grade, size and measurements under each, price-per-piece and the lot price as the main figure. Make the count itself legible (a 10-piece lot shows 10 tiles, no carousel hiding pieces). Header switch between modes stays visible on every storefront page.
**Pakistan-specific:** PKR no decimals; WhatsApp-share on product/seller/collection; prepaid-only messaging at checkout; English only (no RTL work in v1); size guides must show cm measurements (thrift sizing is unreliable).
