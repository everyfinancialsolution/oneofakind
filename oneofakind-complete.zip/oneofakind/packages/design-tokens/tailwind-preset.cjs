/** Usage in apps/web/tailwind.config: presets: [require("@ooak/design-tokens")] */
module.exports = {
  theme: {
    extend: {
      colors: {
        ink: { DEFAULT: "var(--ooak-ink)", soft: "var(--ooak-ink-soft)" },
        ivory: { DEFAULT: "var(--ooak-ivory)", deep: "var(--ooak-ivory-deep)" },
        stone: { DEFAULT: "var(--ooak-stone)", deep: "var(--ooak-stone-deep)" },
        champagne: { DEFAULT: "var(--ooak-champagne)", ink: "var(--ooak-champagne-ink)" },
        surface: "var(--ooak-surface)", muted: "var(--ooak-text-muted)",
      },
      fontFamily: { display: ["var(--ooak-font-display)"], body: ["var(--ooak-font-body)"] },
      borderRadius: { sm: "var(--ooak-radius-sm)", md: "var(--ooak-radius-md)", pill: "var(--ooak-radius-pill)" },
      transitionTimingFunction: { ooak: "var(--ooak-ease)" },
    },
  },
};
