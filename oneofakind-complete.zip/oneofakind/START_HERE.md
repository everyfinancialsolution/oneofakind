# START HERE — state of the build

Built on the verified starter (docs, schema, shared rules) through milestones M0–M9. Everything listed as built is wired to the API and the database and covered by tests; nothing here is a mockup.

## Built
| Area | What works |
|---|---|
| Public site | Home, shop/category/search (Postgres FTS + typo tolerance), product pages (gallery, measurements, condition grade, AI labels, 3D viewer), seller storefronts `/sellers/[slug]`, collections, compare, wishlist, recently viewed, help/policies, `/sell`, `/reseller` |
| Bundles | `/bundles` storefront, lot pages; prices hidden server-side from non-verified users (page, API, OG); only verified resellers can buy |
| Accounts | One phone-OTP login, guest cart merge, orders, damage claims (48 h, photos), account deletion request |
| Checkout | Prepaid only (card / wallet / bank via sandbox gateway), idempotent, 15-min reservations, per-seller parcels, signed webhooks; **no COD**, **damaged-only returns** |
| Seller hub | Photo-first listing wizard, listings/inventory, labels (thermal/A4), orders → pack scan → dispatch code → handover, offers, earnings/statements, storefront, analytics, activity, settings & own-name payout account, bundles builder, managed resale, sell-to-us, support & appeals, **photo studio (AI)** |
| Onboarding | Online applications + WhatsApp-assisted registration by staff (consent evidence required), documents in restricted storage, activation by the person's own OTP, 90-day ID deletion |
| Warehouse `/ops` | Receiving manifests, inspection, photos & catalogue, seller price approval, shelves/movements, unified scan, pick & pack, courier handover, bundling desk, returns, unsold |
| Admin `/admin` | Dashboard queues, onboarding desk, sellers (+ list on behalf for SELLER_AGENT), users & roles, moderation + reports/appeals, orders (staff cancel + refund), damage claims, tickets & disputes, direct purchases/budgets/agreements, reconciliation, payout verification, statements (CSV) & payouts, ledger, payments, catalogue, CMS, collections, settings, AI jobs, audit log |
| Money | Double-entry ledger (DB-enforced balance), commission snapshots, settlement after 7 days with no open claim/dispute, payouts only to verified own-name accounts |
| AI & 3D | Server-side adapters; background removal (local heuristic) and fact-only listing text; originals never overwritten; AI images labelled and published only if chosen + approved; `.glb` models |

Tests: shared 70 · web 7 · API 62 (incl. concurrency, webhooks, ledger, access) · Playwright E2E 7 (desktop + mobile).

## Not built / needs you
1. **Payment gateway and courier** — pick providers and get sandbox credentials; adapters are interfaces with sandbox implementations (`apps/api/src/modules/commerce/providers.ts`).
2. **SMS provider** for OTP outside dev (`OTP_DEV_ECHO=false` in staging/production).
3. **Hosting + object storage** for staging (`docs/RUNBOOK.md` §3, §6). Nothing has been deployed; oneofakindretro.com untouched.
4. **AI provider** (optional) — the local adapters work for plain-background photos; model imagery and try-on are not built (need a real image-generation provider and a consent flow).
5. **Error monitoring DSN**, checkout load test, penetration test (`docs/SECURITY.md`).
6. CSP still allows inline scripts (Next bootstrap) — move to nonces before launch.
